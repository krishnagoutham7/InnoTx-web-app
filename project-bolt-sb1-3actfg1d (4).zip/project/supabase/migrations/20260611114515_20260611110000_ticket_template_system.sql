-- Ticket Template System for Admin-Uploaded Custom Designs

-- 1. Create ticket_templates table
CREATE TABLE IF NOT EXISTS ticket_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  
  -- Template image
  template_image_url TEXT NOT NULL,
  template_storage_path TEXT NOT NULL,
  template_width INTEGER NOT NULL DEFAULT 800,
  template_height INTEGER NOT NULL DEFAULT 400,
  
  -- Field positions (x, y as percentages of image dimensions, font settings)
  -- JSON containing all field configurations
  field_config JSONB NOT NULL DEFAULT '{
    "participant_name": {"x": 10, "y": 15, "width": 80, "fontSize": 16, "fontColor": "#000000", "fontFamily": "Arial", "align": "left"},
    "ticket_id": {"x": 10, "y": 25, "width": 80, "fontSize": 12, "fontColor": "#333333", "fontFamily": "Arial", "align": "left"},
    "event_name": {"x": 10, "y": 35, "width": 80, "fontSize": 14, "fontColor": "#000000", "fontFamily": "Arial", "align": "left"},
    "event_date": {"x": 10, "y": 45, "width": 40, "fontSize": 12, "fontColor": "#666666", "fontFamily": "Arial", "align": "left"},
    "event_time": {"x": 55, "y": 45, "width": 35, "fontSize": 12, "fontColor": "#666666", "fontFamily": "Arial", "align": "left"},
    "event_venue": {"x": 10, "y": 55, "width": 80, "fontSize": 11, "fontColor": "#666666", "fontFamily": "Arial", "align": "left"},
    "department": {"x": 10, "y": 65, "width": 80, "fontSize": 10, "fontColor": "#999999", "fontFamily": "Arial", "align": "left"},
    "qr_code": {"x": 75, "y": 20, "size": 25}
  }'::jsonb,
  
  -- Metadata
  is_default BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 2. Add ticket_template_id to events table
ALTER TABLE events ADD COLUMN IF NOT EXISTS ticket_template_id UUID REFERENCES ticket_templates(id);

-- 3. Create storage bucket for ticket templates
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'ticket-templates',
  'ticket-templates',
  true,
  20971520, -- 20MB
  ARRAY['image/jpeg', 'image/png', 'image/webp']
) ON CONFLICT (id) DO NOTHING;

-- 4. Enable RLS
ALTER TABLE ticket_templates ENABLE ROW LEVEL SECURITY;

-- 5. RLS Policies for ticket_templates
CREATE POLICY "select_ticket_templates_public" ON ticket_templates FOR SELECT
  TO authenticated USING (is_active = true);

CREATE POLICY "manage_ticket_templates_admin" ON ticket_templates FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cpo', 'program_officer', 'faculty')
    )
  );

-- 6. Storage policies for ticket-templates bucket
CREATE POLICY "select_templates_public" ON storage.objects FOR SELECT
  TO public USING (bucket_id = 'ticket-templates');

CREATE POLICY "insert_templates_admin" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (
    bucket_id = 'ticket-templates' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cpo', 'program_officer', 'faculty')
    )
  );

CREATE POLICY "update_templates_admin" ON storage.objects FOR UPDATE
  TO authenticated USING (
    bucket_id = 'ticket-templates' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cpo', 'program_officer', 'faculty')
    )
  );

CREATE POLICY "delete_templates_admin" ON storage.objects FOR DELETE
  TO authenticated USING (
    bucket_id = 'ticket-templates' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cpo', 'program_officer', 'faculty')
    )
  );

-- 7. Update event_tickets to store generated ticket image
ALTER TABLE event_tickets ADD COLUMN IF NOT EXISTS generated_ticket_url TEXT;
ALTER TABLE event_tickets ADD COLUMN IF NOT EXISTS generated_at TIMESTAMPTZ;

-- 8. Function to get default template
CREATE OR REPLACE FUNCTION get_default_ticket_template()
RETURNS UUID AS $$
DECLARE
  template_id UUID;
BEGIN
  SELECT id INTO template_id FROM ticket_templates WHERE is_default = true AND is_active = true LIMIT 1;
  RETURN template_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. Function to set default template
CREATE OR REPLACE FUNCTION set_default_ticket_template(p_template_id UUID)
RETURNS void AS $$
BEGIN
  -- Unset all defaults
  UPDATE ticket_templates SET is_default = false WHERE is_default = true;
  -- Set new default
  UPDATE ticket_templates SET is_default = true WHERE id = p_template_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. Create index
CREATE INDEX IF NOT EXISTS idx_ticket_templates_default ON ticket_templates(is_default) WHERE is_default = true;
CREATE INDEX IF NOT EXISTS idx_events_ticket_template ON events(ticket_template_id);