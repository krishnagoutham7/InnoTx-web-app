
-- Drop and recreate CMS tables to ensure clean state

DROP TABLE IF EXISTS cms_contact_info CASCADE;
DROP TABLE IF EXISTS cms_college_info CASCADE;
DROP TABLE IF EXISTS cms_about_page CASCADE;

-- CMS College Info table
CREATE TABLE cms_college_info (
  id TEXT PRIMARY KEY DEFAULT 'default',
  name TEXT NOT NULL DEFAULT 'Government Polytechnic College Adoor',
  short_name TEXT NOT NULL DEFAULT 'GPC Adoor',
  address TEXT NOT NULL DEFAULT 'Adoor, Pathanamthitta District, Kerala 691523, India',
  phone TEXT NOT NULL DEFAULT '+91 4734 225 000',
  email TEXT NOT NULL DEFAULT 'innotex@gpcadoor.ac.in',
  website TEXT NOT NULL DEFAULT 'https://gpcadoor.ac.in',
  map_embed_url TEXT NOT NULL DEFAULT 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3948.0196372929987!2d76.73!3d9.07!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b0600e000000001%3A0x0000000000000001!2sGovernment%20Polytechnic%20College%20Adoor!5e0!3m2!1sen!2sin!4v1700000000000',
  map_link TEXT NOT NULL DEFAULT 'https://maps.google.com/?q=9.07,76.73',
  portal_name TEXT NOT NULL DEFAULT 'InnoTex',
  portal_tagline TEXT NOT NULL DEFAULT 'Innovation • Entrepreneurship • Technology • Leadership',
  portal_description TEXT NOT NULL DEFAULT 'InnoTex is the Innovation and Entrepreneurship Development Centre (IEDC) of Government Polytechnic College Adoor, dedicated to nurturing the next generation of innovators, entrepreneurs, and change-makers.',
  institution_type TEXT NOT NULL DEFAULT 'Government Polytechnic College',
  district TEXT NOT NULL DEFAULT 'Pathanamthitta',
  state TEXT NOT NULL DEFAULT 'Kerala',
  programme TEXT NOT NULL DEFAULT 'Diploma in Engineering',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE cms_college_info ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_college_info" ON cms_college_info FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_college_info" ON cms_college_info FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_college_info" ON cms_college_info FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_college_info" ON cms_college_info FOR DELETE TO authenticated USING (true);
INSERT INTO cms_college_info (id) VALUES ('default');

-- CMS Contact Info table
CREATE TABLE cms_contact_info (
  id TEXT PRIMARY KEY DEFAULT 'default',
  address TEXT NOT NULL DEFAULT 'Adoor, Pathanamthitta District, Kerala 691523, India',
  phone TEXT NOT NULL DEFAULT '+91 4734 225 000',
  email TEXT NOT NULL DEFAULT 'innotex@gpcadoor.ac.in',
  office_hours TEXT NOT NULL DEFAULT 'Monday - Friday: 9:00 AM - 5:00 PM',
  saturday_hours TEXT NOT NULL DEFAULT 'Saturday: 10:00 AM - 2:00 PM',
  instagram_url TEXT NOT NULL DEFAULT '#',
  twitter_url TEXT NOT NULL DEFAULT '#',
  linkedin_url TEXT NOT NULL DEFAULT '#',
  github_url TEXT NOT NULL DEFAULT '#',
  mail_url TEXT NOT NULL DEFAULT '#',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE cms_contact_info ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_contact_info" ON cms_contact_info FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_contact_info" ON cms_contact_info FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_contact_info" ON cms_contact_info FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_contact_info" ON cms_contact_info FOR DELETE TO authenticated USING (true);
INSERT INTO cms_contact_info (id) VALUES ('default');

-- CMS About Page table
CREATE TABLE cms_about_page (
  id TEXT PRIMARY KEY DEFAULT 'default',
  vision_heading TEXT NOT NULL DEFAULT 'Our Vision',
  vision_content TEXT NOT NULL DEFAULT 'To become a leading centre of innovation and entrepreneurship that transforms aspiring students into successful entrepreneurs, contributing to the economic and social development of Kerala and the nation.',
  mission_heading TEXT NOT NULL DEFAULT 'Our Mission',
  mission_content TEXT NOT NULL DEFAULT 'To create a vibrant entrepreneurial ecosystem within the campus by providing mentorship, infrastructure, funding support, and industry connections.',
  obj_1_title TEXT NOT NULL DEFAULT 'Foster Innovation',
  obj_1_description TEXT NOT NULL DEFAULT 'Create a culture of innovation and creative problem-solving among students.',
  obj_2_title TEXT NOT NULL DEFAULT 'Skill Development',
  obj_2_description TEXT NOT NULL DEFAULT 'Develop entrepreneurial skills through workshops, bootcamps, and mentorship programmes.',
  obj_3_title TEXT NOT NULL DEFAULT 'Industry Connect',
  obj_3_description TEXT NOT NULL DEFAULT 'Build bridges between academia and industry for real-world exposure and collaboration.',
  obj_4_title TEXT NOT NULL DEFAULT 'Technology Adoption',
  obj_4_description TEXT NOT NULL DEFAULT 'Encourage adoption of emerging technologies for building scalable solutions.',
  obj_5_title TEXT NOT NULL DEFAULT 'Startup Creation',
  obj_5_description TEXT NOT NULL DEFAULT 'Support student-led ventures from ideation to market-ready products and services.',
  obj_6_title TEXT NOT NULL DEFAULT 'Ecosystem Building',
  obj_6_description TEXT NOT NULL DEFAULT 'Contribute to the larger innovation and entrepreneurship ecosystem in Kerala.',
  iedc_title TEXT NOT NULL DEFAULT 'Innovation & Entrepreneurship Development Centre',
  iedc_description_1 TEXT NOT NULL DEFAULT 'The IEDC is a flagship programme of the Kerala Startup Mission, established in educational institutions across Kerala to foster a culture of innovation and entrepreneurship.',
  iedc_description_2 TEXT NOT NULL DEFAULT 'IEDCs function as incubation centres within campuses, providing students with the necessary infrastructure, mentorship, and financial support.',
  iedc_description_3 TEXT NOT NULL DEFAULT 'The programme aims to create an entrepreneurial mindset among students, enabling them to identify opportunities and create sustainable solutions.',
  ksum_title TEXT NOT NULL DEFAULT 'Kerala Startup Mission',
  ksum_description_1 TEXT NOT NULL DEFAULT 'Kerala Startup Mission (KSUM) is the central agency of the Government of Kerala for entrepreneurship development and incubation activities in the state.',
  ksum_description_2 TEXT NOT NULL DEFAULT 'Through KSUM''s support, our IEDC receives seed funding for student projects, access to state-wide networking events, and connections to the broader innovation ecosystem.',
  ksum_description_3 TEXT NOT NULL DEFAULT 'KSUM''s initiatives including the IEDC programme, Startup Yatra, and various funding schemes have positioned Kerala as one of the most startup-friendly states in India.',
  ksum_website TEXT NOT NULL DEFAULT 'https://startupmission.kerala.gov.in',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE cms_about_page ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_about_page" ON cms_about_page FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_about_page" ON cms_about_page FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_about_page" ON cms_about_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_about_page" ON cms_about_page FOR DELETE TO authenticated USING (true);
INSERT INTO cms_about_page (id) VALUES ('default');
