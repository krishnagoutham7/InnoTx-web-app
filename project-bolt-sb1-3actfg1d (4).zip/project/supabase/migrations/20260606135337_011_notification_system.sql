/*
# Phase 4: Advanced Notification Management System

## Tables Created
1. `notifications` - Main notification records
2. `user_notifications` - User-specific delivery and read tracking
3. `notification_logs` - Audit trail for all notification actions

## Features
- Role-based targeting
- Individual user targeting
- Scheduled notifications
- Priority levels
- Read/unread tracking
- Notification analytics
- Audit logging
*/

-- ============================================
-- 1. NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  message text NOT NULL,
  notification_type text NOT NULL CHECK (notification_type IN (
    'event_alert',
    'meeting_alert',
    'certificate_available',
    'announcement',
    'custom'
  )),
  target_type text NOT NULL CHECK (target_type IN (
    'all',
    'role',
    'department',
    'team',
    'individual'
  )),
  target_role text[],
  target_department text[],
  target_user_ids uuid[],
  sender_id uuid REFERENCES auth.users(id),
  priority_level text NOT NULL DEFAULT 'medium' CHECK (priority_level IN (
    'low',
    'medium',
    'high',
    'critical'
  )),
  scheduled_at timestamptz,
  sent_at timestamptz,
  expires_at timestamptz,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN (
    'draft',
    'scheduled',
    'sending',
    'sent',
    'cancelled',
    'expired'
  )),
  attachment_url text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Indexes for performance
CREATE INDEX idx_notifications_status ON notifications(status);
CREATE INDEX idx_notifications_scheduled_at ON notifications(scheduled_at) WHERE status = 'scheduled';
CREATE INDEX idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX idx_notifications_type ON notifications(notification_type);
CREATE INDEX idx_notifications_priority ON notifications(priority_level);

-- ============================================
-- 2. USER_NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE user_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  notification_id uuid NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  is_read boolean DEFAULT false,
  read_at timestamptz,
  delivered_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(notification_id, user_id)
);

-- Indexes for performance
CREATE INDEX idx_user_notifications_user ON user_notifications(user_id, is_read);
CREATE INDEX idx_user_notifications_notification ON user_notifications(notification_id);
CREATE INDEX idx_user_notifications_created ON user_notifications(created_at DESC);

-- ============================================
-- 3. NOTIFICATION_LOGS TABLE
-- ============================================
CREATE TABLE notification_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  notification_id uuid REFERENCES notifications(id) ON DELETE SET NULL,
  action_type text NOT NULL CHECK (action_type IN (
    'created',
    'updated',
    'scheduled',
    'sent',
    'delivered',
    'read',
    'deleted',
    'cancelled'
  )),
  performed_by uuid REFERENCES auth.users(id),
  timestamp timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'
);

-- Index for analytics
CREATE INDEX idx_notification_logs_notification ON notification_logs(notification_id);
CREATE INDEX idx_notification_logs_timestamp ON notification_logs(timestamp DESC);
CREATE INDEX idx_notification_logs_action ON notification_logs(action_type);

-- ============================================
-- 4. ROW LEVEL SECURITY
-- ============================================

-- Notifications: Only super_admin can manage
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notifications_select_all" ON notifications FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "notifications_insert_super_admin" ON notifications FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role = 'super_admin')
  );

CREATE POLICY "notifications_update_super_admin" ON notifications FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role = 'super_admin')
  );

CREATE POLICY "notifications_delete_super_admin" ON notifications FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role = 'super_admin')
  );

-- User Notifications: Users can only see their own
ALTER TABLE user_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user_notifications_select_own" ON user_notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "user_notifications_update_own" ON user_notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "user_notifications_insert_system" ON user_notifications FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE POLICY "user_notifications_delete_own" ON user_notifications FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Notification Logs: Read-only for admins
ALTER TABLE notification_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notification_logs_select" ON notification_logs FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "notification_logs_insert" ON notification_logs FOR INSERT
  TO authenticated WITH CHECK (true);

-- ============================================
-- 5. HELPER FUNCTIONS
-- ============================================

-- Function to get user's role for targeting
CREATE OR REPLACE FUNCTION get_user_role_for_targeting(user_uuid uuid)
RETURNS text AS $$
  SELECT role FROM auth_user_profiles WHERE auth_user_id = user_uuid;
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Function to get user's department for targeting
CREATE OR REPLACE FUNCTION get_user_department_for_targeting(user_uuid uuid)
RETURNS text AS $$
  SELECT department FROM auth_user_profiles WHERE auth_user_id = user_uuid;
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Function to count unread notifications for a user
CREATE OR REPLACE FUNCTION count_unread_notifications(user_uuid uuid)
RETURNS bigint AS $$
  SELECT COUNT(*) FROM user_notifications
  WHERE user_id = user_uuid AND is_read = false;
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- ============================================
-- 6. REALTIME ENABLEMENT
-- ============================================
ALTER PUBLICATION supabase_realtime ADD TABLE user_notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
