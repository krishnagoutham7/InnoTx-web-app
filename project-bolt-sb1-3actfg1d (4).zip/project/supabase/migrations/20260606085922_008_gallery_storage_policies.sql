/*
# Gallery Storage Bucket Policies

1. Storage Policies for `gallery` bucket
- Public read: anyone can view gallery images
- Authenticated upload: logged-in users can upload images
- Authenticated delete: logged-in users can delete images
- Files organized in `albums/` and `team/` subfolders

2. Security
- Upload restricted to authenticated users
- Public read access for displaying images on the website
- Delete restricted to authenticated users
*/

-- Allow public read of gallery images
CREATE POLICY "gallery_public_read" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'gallery');

-- Allow authenticated users to upload gallery images
CREATE POLICY "gallery_authenticated_upload" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'gallery');

-- Allow authenticated users to delete gallery images
CREATE POLICY "gallery_authenticated_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'gallery');

-- Allow authenticated users to update gallery images
CREATE POLICY "gallery_authenticated_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'gallery')
  WITH CHECK (bucket_id = 'gallery');
