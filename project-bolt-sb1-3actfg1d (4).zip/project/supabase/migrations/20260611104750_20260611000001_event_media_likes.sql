-- Event Media and Community Like System
-- Adds banner/poster support and community engagement features

-- 1. Add media columns to events table
ALTER TABLE events ADD COLUMN IF NOT EXISTS banner_image_url TEXT;
ALTER TABLE events ADD COLUMN IF NOT EXISTS banner_storage_path TEXT;
ALTER TABLE events ADD COLUMN IF NOT EXISTS banner_thumbnail_url TEXT;
ALTER TABLE events ADD COLUMN IF NOT EXISTS banner_uploaded_by UUID REFERENCES auth.users(id);
ALTER TABLE events ADD COLUMN IF NOT EXISTS banner_uploaded_at TIMESTAMPTZ;

ALTER TABLE events ADD COLUMN IF NOT EXISTS poster_image_url TEXT;
ALTER TABLE events ADD COLUMN IF NOT EXISTS poster_storage_path TEXT;
ALTER TABLE events ADD COLUMN IF NOT EXISTS poster_uploaded_by UUID REFERENCES auth.users(id);
ALTER TABLE events ADD COLUMN IF NOT EXISTS poster_uploaded_at TIMESTAMPTZ;

-- 2. Create event_likes table
CREATE TABLE IF NOT EXISTS event_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  CONSTRAINT unique_event_like UNIQUE (event_id, user_id)
);

-- 3. Create index for performance
CREATE INDEX IF NOT EXISTS idx_event_likes_event_id ON event_likes(event_id);
CREATE INDEX IF NOT EXISTS idx_event_likes_user_id ON event_likes(user_id);

-- 4. Enable RLS
ALTER TABLE event_likes ENABLE ROW LEVEL SECURITY;

-- 5. RLS Policies for event_likes
CREATE POLICY "select_event_likes" ON event_likes FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "insert_own_like" ON event_likes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "delete_own_like" ON event_likes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- 6. Function to get like count for an event
CREATE OR REPLACE FUNCTION get_event_like_count(p_event_id UUID)
RETURNS INTEGER AS $$
DECLARE
  like_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO like_count FROM event_likes WHERE event_id = p_event_id;
  RETURN COALESCE(like_count, 0);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 7. Function to check if user liked an event
CREATE OR REPLACE FUNCTION user_liked_event(p_event_id UUID, p_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  liked BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM event_likes 
    WHERE event_id = p_event_id AND user_id = p_user_id
  ) INTO liked;
  RETURN liked;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 8. Function to toggle like
CREATE OR REPLACE FUNCTION toggle_event_like(p_event_id UUID, p_user_id UUID)
RETURNS JSONB AS $$
DECLARE
  already_liked BOOLEAN;
  result JSONB;
BEGIN
  -- Check if already liked
  SELECT EXISTS (
    SELECT 1 FROM event_likes 
    WHERE event_id = p_event_id AND user_id = p_user_id
  ) INTO already_liked;
  
  IF already_liked THEN
    -- Unlike: remove the like
    DELETE FROM event_likes 
    WHERE event_id = p_event_id AND user_id = p_user_id;
    
    result := jsonb_build_object(
      'action', 'unliked',
      'liked', false,
      'like_count', get_event_like_count(p_event_id)
    );
  ELSE
    -- Like: add the like
    INSERT INTO event_likes (event_id, user_id)
    VALUES (p_event_id, p_user_id);
    
    result := jsonb_build_object(
      'action', 'liked',
      'liked', true,
      'like_count', get_event_like_count(p_event_id)
    );
  END IF;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. Function to get trending events (most liked)
CREATE OR REPLACE FUNCTION get_trending_events(p_limit INTEGER DEFAULT 10)
RETURNS TABLE (
  id UUID,
  title TEXT,
  description TEXT,
  banner_image_url TEXT,
  poster_image_url TEXT,
  like_count BIGINT,
  status TEXT,
  start_date DATE
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    e.id,
    e.title,
    e.description,
    e.banner_image_url,
    e.poster_image_url,
    COALESCE(l.like_count, 0) as like_count,
    e.status::TEXT,
    e.start_date
  FROM events e
  LEFT JOIN (
    SELECT event_id, COUNT(*) as like_count 
    FROM event_likes 
    GROUP BY event_id
  ) l ON l.event_id = e.id
  WHERE e.status IN ('published', 'upcoming', 'registration_open', 'ongoing')
  ORDER BY COALESCE(l.like_count, 0) DESC, e.start_date ASC
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. Function to get like analytics
CREATE OR REPLACE FUNCTION get_like_analytics()
RETURNS JSONB AS $$
DECLARE
  total_likes BIGINT;
  total_events_with_likes BIGINT;
  most_liked RECORD;
  least_liked RECORD;
  this_month_likes BIGINT;
BEGIN
  -- Total likes
  SELECT COUNT(*) INTO total_likes FROM event_likes;
  
  -- Total events with likes
  SELECT COUNT(DISTINCT event_id) INTO total_events_with_likes FROM event_likes;
  
  -- Most liked event
  SELECT e.title, COALESCE(l.like_count, 0) as likes
  INTO most_liked
  FROM events e
  LEFT JOIN (
    SELECT event_id, COUNT(*) as like_count FROM event_likes GROUP BY event_id
  ) l ON l.event_id = e.id
  ORDER BY COALESCE(l.like_count, 0) DESC
  LIMIT 1;
  
  -- Least liked event (among events with at least one like or published)
  SELECT e.title, COALESCE(l.like_count, 0) as likes
  INTO least_liked
  FROM events e
  LEFT JOIN (
    SELECT event_id, COUNT(*) as like_count FROM event_likes GROUP BY event_id
  ) l ON l.event_id = e.id
  WHERE e.status IN ('published', 'upcoming', 'registration_open')
  ORDER BY COALESCE(l.like_count, 0) ASC
  LIMIT 1;
  
  -- Likes this month
  SELECT COUNT(*) INTO this_month_likes
  FROM event_likes
  WHERE created_at >= date_trunc('month', now());
  
  RETURN jsonb_build_object(
    'total_likes', total_likes,
    'total_events_with_likes', total_events_with_likes,
    'most_liked_event', jsonb_build_object('title', most_liked.title, 'likes', most_liked.likes),
    'least_liked_event', jsonb_build_object('title', least_liked.title, 'likes', least_liked.likes),
    'this_month_likes', this_month_likes
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 11. View for events with like counts
CREATE OR REPLACE VIEW events_with_likes AS
SELECT 
  e.*,
  COALESCE(l.like_count, 0) as like_count
FROM events e
LEFT JOIN (
  SELECT event_id, COUNT(*) as like_count 
  FROM event_likes 
  GROUP BY event_id
) l ON l.event_id = e.id;