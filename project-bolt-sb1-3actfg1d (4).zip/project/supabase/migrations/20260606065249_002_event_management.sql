/*
# Event Management System Tables

1. New Tables
   - `event_categories` — Predefined event categories (Workshop, Hackathon, etc.)
   - `events` — Core event records with all metadata, scheduling, and publishing state
   - `event_speakers` — Speakers/presenters linked to events
   - `event_resources` — Downloadable files linked to events (future storage)
   - `event_registrations` — Student/user registrations for events

2. Columns
   - events: id, title, short_description, full_description, category_id, event_type, status,
             start_date, end_date, start_time, end_time, venue, max_participants,
             registration_deadline, poster_url, banner_url, organizer_name,
             organizer_email, is_featured, created_by, created_at, updated_at
   - event_speakers: id, event_id, name, designation, bio, photo_url, display_order
   - event_resources: id, event_id, title, file_url, resource_type, display_order
   - event_registrations: id, event_id, user_name, user_email, user_role,
                          registration_status, registered_at, notes

3. Security
   - RLS enabled on all tables
   - Public (anon + authenticated) can read published events and categories
   - Authenticated users can insert registrations
   - Authenticated users can manage their own registrations
   - Admins control full event CRUD via authenticated policy

4. Notes
   - event_type ENUM: Workshop, Hackathon, Seminar, Webinar, Competition,
     Startup Event, Innovation Challenge, Training Program, Industrial Visit, Other
   - status ENUM: draft, published, upcoming, ongoing, completed, cancelled, archived
   - registration_status ENUM: confirmed, cancelled, waitlisted
*/

-- Event categories
CREATE TABLE IF NOT EXISTS event_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  color text DEFAULT '#8B5CF6',
  icon text DEFAULT 'Calendar',
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Core events table
CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  short_description text,
  full_description text,
  category_id uuid REFERENCES event_categories(id) ON DELETE SET NULL,
  event_type text NOT NULL DEFAULT 'Other' CHECK (event_type IN (
    'Workshop', 'Hackathon', 'Seminar', 'Webinar', 'Competition',
    'Startup Event', 'Innovation Challenge', 'Training Program', 'Industrial Visit', 'Other'
  )),
  status text NOT NULL DEFAULT 'draft' CHECK (status IN (
    'draft', 'published', 'upcoming', 'ongoing', 'completed', 'cancelled', 'archived'
  )),
  start_date date NOT NULL,
  end_date date,
  start_time time,
  end_time time,
  venue text,
  max_participants integer,
  registration_deadline date,
  poster_url text,
  banner_url text,
  organizer_name text,
  organizer_email text,
  is_featured boolean DEFAULT false,
  created_by text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Event speakers
CREATE TABLE IF NOT EXISTS event_speakers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name text NOT NULL,
  designation text,
  bio text,
  photo_url text,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Event resources (future file uploads)
CREATE TABLE IF NOT EXISTS event_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  title text NOT NULL,
  file_url text,
  resource_type text DEFAULT 'document' CHECK (resource_type IN ('document', 'presentation', 'poster', 'other')),
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Event registrations
CREATE TABLE IF NOT EXISTS event_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_name text NOT NULL,
  user_email text NOT NULL,
  user_role text,
  registration_status text NOT NULL DEFAULT 'confirmed' CHECK (registration_status IN ('confirmed', 'cancelled', 'waitlisted')),
  registered_at timestamptz DEFAULT now(),
  notes text,
  UNIQUE(event_id, user_email)
);

-- Enable RLS
ALTER TABLE event_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_speakers ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_registrations ENABLE ROW LEVEL SECURITY;

-- event_categories policies
DROP POLICY IF EXISTS "public_read_categories" ON event_categories;
CREATE POLICY "public_read_categories" ON event_categories FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_write_categories" ON event_categories;
CREATE POLICY "auth_write_categories" ON event_categories FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- events policies
DROP POLICY IF EXISTS "public_read_published_events" ON events;
CREATE POLICY "public_read_published_events" ON events FOR SELECT TO anon USING (status IN ('published', 'upcoming', 'ongoing', 'completed'));

DROP POLICY IF EXISTS "auth_read_all_events" ON events;
CREATE POLICY "auth_read_all_events" ON events FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_write_events" ON events;
CREATE POLICY "auth_write_events" ON events FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- event_speakers policies
DROP POLICY IF EXISTS "public_read_speakers" ON event_speakers;
CREATE POLICY "public_read_speakers" ON event_speakers FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_write_speakers" ON event_speakers;
CREATE POLICY "auth_write_speakers" ON event_speakers FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- event_resources policies
DROP POLICY IF EXISTS "public_read_resources" ON event_resources;
CREATE POLICY "public_read_resources" ON event_resources FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_write_resources" ON event_resources;
CREATE POLICY "auth_write_resources" ON event_resources FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- event_registrations policies
DROP POLICY IF EXISTS "auth_read_registrations" ON event_registrations;
CREATE POLICY "auth_read_registrations" ON event_registrations FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_registration" ON event_registrations;
CREATE POLICY "anon_insert_registration" ON event_registrations FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_update_registration" ON event_registrations;
CREATE POLICY "auth_update_registration" ON event_registrations FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_registration" ON event_registrations;
CREATE POLICY "auth_delete_registration" ON event_registrations FOR DELETE TO authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_start_date ON events(start_date);
CREATE INDEX IF NOT EXISTS idx_events_category ON events(category_id);
CREATE INDEX IF NOT EXISTS idx_events_featured ON events(is_featured);
CREATE INDEX IF NOT EXISTS idx_registrations_event ON event_registrations(event_id);
CREATE INDEX IF NOT EXISTS idx_registrations_email ON event_registrations(user_email);
CREATE INDEX IF NOT EXISTS idx_speakers_event ON event_speakers(event_id);

-- Seed event categories
INSERT INTO event_categories (name, description, color, icon, display_order) VALUES
('Workshop', 'Hands-on skill-building sessions', '#3B82F6', 'Wrench', 1),
('Hackathon', 'Competitive coding and innovation marathons', '#8B5CF6', 'Code', 2),
('Seminar', 'Educational talks and presentations', '#10B981', 'BookOpen', 3),
('Webinar', 'Online virtual events', '#F59E0B', 'Monitor', 4),
('Competition', 'Competitive events and contests', '#EF4444', 'Trophy', 5),
('Startup Event', 'Entrepreneurship and startup focused', '#6366F1', 'Rocket', 6),
('Innovation Challenge', 'Problem-solving innovation challenges', '#EC4899', 'Lightbulb', 7),
('Training Program', 'Structured learning programs', '#14B8A6', 'GraduationCap', 8),
('Industrial Visit', 'Industry exposure visits', '#F97316', 'Building2', 9),
('Other', 'Miscellaneous events', '#6B7280', 'Calendar', 10)
ON CONFLICT (name) DO NOTHING;
