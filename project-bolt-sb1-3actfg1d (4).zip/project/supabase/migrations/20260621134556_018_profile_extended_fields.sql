-- Extend auth_user_profiles with personal profile fields
DO $$ BEGIN
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS bio text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS phone text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS class_name text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS register_number text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS linkedin_url text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS github_url text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS instagram_url text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS portfolio_url text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS skills text[] DEFAULT '{}';
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS interests text[] DEFAULT '{}';
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS profile_photo_url text;
END $$;

-- Create profile-photos storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'profile-photos',
  'profile-photos',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for profile-photos
DROP POLICY IF EXISTS "profile_photos_public_read" ON storage.objects;
CREATE POLICY "profile_photos_public_read" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'profile-photos');

DROP POLICY IF EXISTS "profile_photos_authenticated_insert" ON storage.objects;
CREATE POLICY "profile_photos_authenticated_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'profile-photos');

DROP POLICY IF EXISTS "profile_photos_authenticated_update" ON storage.objects;
CREATE POLICY "profile_photos_authenticated_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'profile-photos');

DROP POLICY IF EXISTS "profile_photos_authenticated_delete" ON storage.objects;
CREATE POLICY "profile_photos_authenticated_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'profile-photos');
