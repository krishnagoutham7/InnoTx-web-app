/*
# Fix registration_status constraint to include 'pending'
*/

-- Drop the old constraint
ALTER TABLE event_registrations DROP CONSTRAINT IF EXISTS event_registrations_registration_status_check;

-- Add new constraint with 'pending' included
ALTER TABLE event_registrations ADD CONSTRAINT event_registrations_registration_status_check
  CHECK (registration_status IN ('pending', 'confirmed', 'cancelled', 'waitlisted'));

-- Update existing records that should be pending
UPDATE event_registrations 
SET registration_status = 'pending'
WHERE approval_status = 'pending' AND registration_status = 'confirmed';
