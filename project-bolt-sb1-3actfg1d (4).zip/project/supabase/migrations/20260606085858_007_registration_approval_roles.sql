/*
# Add Registration, Approval, and Role Management Schema

1. Modified Tables
- `auth_user_profiles`: Add department, branch, semester, status, must_change_password columns
- `cms_portal_users`: Add department, branch, semester, status, must_change_password columns
- Both tables' existing rows updated to status='approved' (they are already active users)

2. New Tables
- `cms_roles`: Stores role definitions with permissions
  - id (text PK, e.g. 'super_admin')
  - label (display name)
  - description
  - permissions (jsonb array of permission strings)
  - is_system (boolean - system roles can't be deleted)
  - display_order
  - created_at, updated_at

3. Security
- Enable RLS on `cms_roles`
- Public read, authenticated write policies

4. Notes
- Existing 6 auth_user_profiles rows set to status='approved', must_change_password=false
- Existing 7 cms_portal_users rows set to status='approved'
- 7 system roles seeded into cms_roles matching the UserRole TypeScript type
*/

-- Add columns to auth_user_profiles
DO $$ BEGIN
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS department text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS branch text;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS semester integer;
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending';
  ALTER TABLE auth_user_profiles ADD COLUMN IF NOT EXISTS must_change_password boolean NOT NULL DEFAULT false;
END $$;

-- Update existing profiles to approved status
UPDATE auth_user_profiles SET status = 'approved', must_change_password = false WHERE status = 'pending';

-- Add columns to cms_portal_users
DO $$ BEGIN
  ALTER TABLE cms_portal_users ADD COLUMN IF NOT EXISTS department text;
  ALTER TABLE cms_portal_users ADD COLUMN IF NOT EXISTS branch text;
  ALTER TABLE cms_portal_users ADD COLUMN IF NOT EXISTS semester integer;
  ALTER TABLE cms_portal_users ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending';
  ALTER TABLE cms_portal_users ADD COLUMN IF NOT EXISTS must_change_password boolean NOT NULL DEFAULT false;
END $$;

-- Update existing portal users to approved status
UPDATE cms_portal_users SET status = 'approved', must_change_password = false WHERE status = 'pending';

-- Create roles table
CREATE TABLE IF NOT EXISTS cms_roles (
  id text PRIMARY KEY,
  label text NOT NULL,
  description text NOT NULL DEFAULT '',
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_system boolean NOT NULL DEFAULT false,
  display_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_roles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_roles" ON cms_roles;
CREATE POLICY "select_roles" ON cms_roles FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_roles" ON cms_roles;
CREATE POLICY "insert_roles" ON cms_roles FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_roles" ON cms_roles;
CREATE POLICY "update_roles" ON cms_roles FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_roles" ON cms_roles;
CREATE POLICY "delete_roles" ON cms_roles FOR DELETE
  TO authenticated USING (true);

-- Seed system roles
INSERT INTO cms_roles (id, label, description, permissions, is_system, display_order) VALUES
  ('super_admin', 'Super Admin', 'Full system access with all permissions', '["*"]'::jsonb, true, 1),
  ('admin', 'Admin', 'Administrative access with most permissions', '["manage_cms","manage_events","manage_team","manage_gallery","manage_announcements","view_users"]'::jsonb, true, 2),
  ('faculty', 'Faculty Coordinator', 'Faculty coordination and mentorship', '["view_cms","manage_events","view_team","view_announcements","manage_students"]'::jsonb, true, 3),
  ('ceo', 'CEO', 'Chief Executive Officer of IEDC', '["view_cms","manage_events","view_team","view_announcements","manage_operations"]'::jsonb, true, 4),
  ('program_officer', 'Program Officer', 'Program oversight and task management', '["view_cms","view_events","manage_tasks","view_announcements","manage_activities"]'::jsonb, true, 5),
  ('executive', 'Executive Member', 'Executive committee member', '["view_cms","view_events","view_announcements","manage_tasks"]'::jsonb, true, 6),
  ('student', 'Student', 'Student member with basic access', '["view_cms","view_events","view_announcements","register_events"]'::jsonb, true, 7)
ON CONFLICT (id) DO UPDATE SET
  label = EXCLUDED.label,
  description = EXCLUDED.description,
  permissions = EXCLUDED.permissions,
  is_system = EXCLUDED.is_system,
  display_order = EXCLUDED.display_order;
