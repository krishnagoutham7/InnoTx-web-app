/*
# Add registration_open and registration_closed to event status constraint
*/

ALTER TABLE events DROP CONSTRAINT IF EXISTS events_status_check;
ALTER TABLE events ADD CONSTRAINT events_status_check
  CHECK (status IN ('draft', 'published', 'upcoming', 'registration_open', 'registration_closed', 'ongoing', 'completed', 'cancelled', 'archived'));
