-- Phase 17: Real-time Notification System Enhancement
-- Adds action_url, new notification types, and helper functions

-- 1. Add action_url to notifications
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS action_url text;

-- 2. Add new notification types
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_notification_type_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_notification_type_check CHECK (notification_type IN (
  'event_alert',
  'meeting_alert',
  'certificate_available',
  'announcement',
  'custom',
  'registration_submitted',
  'registration_approved',
  'registration_rejected',
  'ticket_generated',
  'attendance_verified',
  'certificate_generated',
  'role_changed',
  'password_reset',
  'event_published'
));

-- 3. Helper function: send notification to a single user
CREATE OR REPLACE FUNCTION send_notification_to_user(
  p_user_id uuid,
  p_title text,
  p_message text,
  p_type text DEFAULT 'custom',
  p_action_url text DEFAULT NULL,
  p_priority text DEFAULT 'medium',
  p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS uuid AS $$
DECLARE
  v_notification_id uuid;
BEGIN
  INSERT INTO notifications (
    title, message, notification_type, target_type,
    target_user_ids, priority_level, status, sent_at,
    action_url, metadata
  ) VALUES (
    p_title, p_message, p_type, 'individual',
    ARRAY[p_user_id], p_priority, 'sent', now(),
    p_action_url, p_metadata
  ) RETURNING id INTO v_notification_id;

  INSERT INTO user_notifications (notification_id, user_id, delivered_at)
  VALUES (v_notification_id, p_user_id, now());

  RETURN v_notification_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Helper function: send notification to all admins
CREATE OR REPLACE FUNCTION send_notification_to_admins(
  p_title text,
  p_message text,
  p_type text DEFAULT 'custom',
  p_action_url text DEFAULT NULL,
  p_priority text DEFAULT 'medium',
  p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS void AS $$
DECLARE
  v_notification_id uuid;
  v_admin_ids uuid[];
BEGIN
  SELECT array_agg(auth_user_id) INTO v_admin_ids
  FROM auth_user_profiles
  WHERE role IN ('super_admin', 'admin')
    AND is_active = true
    AND status = 'approved';

  IF array_length(v_admin_ids, 1) IS NULL THEN RETURN; END IF;

  INSERT INTO notifications (
    title, message, notification_type, target_type,
    target_user_ids, priority_level, status, sent_at,
    action_url, metadata
  ) VALUES (
    p_title, p_message, p_type, 'individual',
    v_admin_ids, p_priority, 'sent', now(),
    p_action_url, p_metadata
  ) RETURNING id INTO v_notification_id;

  INSERT INTO user_notifications (notification_id, user_id, delivered_at)
  SELECT v_notification_id, unnest(v_admin_ids), now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Grant execute to authenticated users
GRANT EXECUTE ON FUNCTION send_notification_to_user TO authenticated;
GRANT EXECUTE ON FUNCTION send_notification_to_admins TO authenticated;
