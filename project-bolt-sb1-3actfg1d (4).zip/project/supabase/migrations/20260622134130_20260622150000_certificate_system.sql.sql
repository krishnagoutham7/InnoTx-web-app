-- Certificate Template & Certificate Management System
-- Mirrors the ticket_templates pattern for consistency

-- 1. certificate_templates table
CREATE TABLE IF NOT EXISTS certificate_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,

  template_image_url TEXT NOT NULL,
  template_storage_path TEXT NOT NULL,
  template_width INTEGER NOT NULL DEFAULT 1200,
  template_height INTEGER NOT NULL DEFAULT 850,

  field_config JSONB NOT NULL DEFAULT '{
    "participant_name": {"x": 50, "y": 35, "width": 80, "fontSize": 36, "fontColor": "#1a1a2e", "fontFamily": "Georgia", "fontWeight": "bold", "align": "center"},
    "certificate_number": {"x": 50, "y": 45, "width": 60, "fontSize": 14, "fontColor": "#555555", "fontFamily": "Courier New", "align": "center"},
    "event_name": {"x": 50, "y": 55, "width": 80, "fontSize": 22, "fontColor": "#0f3460", "fontFamily": "Georgia", "align": "center"},
    "event_date": {"x": 35, "y": 68, "width": 30, "fontSize": 16, "fontColor": "#333333", "fontFamily": "Arial", "align": "left"},
    "issue_date": {"x": 65, "y": 68, "width": 30, "fontSize": 16, "fontColor": "#333333", "fontFamily": "Arial", "align": "right"},
    "qr_code": {"x": 90, "y": 85, "size": 12}
  }'::jsonb,

  is_default BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 2. certificate_template_id on events (assign template to event)
ALTER TABLE events ADD COLUMN IF NOT EXISTS certificate_template_id UUID REFERENCES certificate_templates(id);

-- 3. certificates table
CREATE TABLE IF NOT EXISTS certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  certificate_number TEXT NOT NULL UNIQUE,
  event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  registration_id UUID NOT NULL REFERENCES event_registrations(id) ON DELETE CASCADE,
  template_id UUID REFERENCES certificate_templates(id),

  participant_name TEXT NOT NULL,
  participant_email TEXT,
  event_name TEXT NOT NULL,
  event_date TEXT NOT NULL,
  issue_date TEXT NOT NULL,

  qr_code TEXT NOT NULL UNIQUE,
  generated_certificate_url TEXT,
  certificate_status TEXT NOT NULL DEFAULT 'issued' CHECK (certificate_status IN ('issued', 'revoked')),

  generated_by UUID REFERENCES auth.users(id),
  generated_at TIMESTAMPTZ DEFAULT now(),
  revoked_by UUID,
  revoked_at TIMESTAMPTZ,
  revoke_reason TEXT,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_certificates_user ON certificates(user_id);
CREATE INDEX IF NOT EXISTS idx_certificates_event ON certificates(event_id);
CREATE INDEX IF NOT EXISTS idx_certificates_number ON certificates(certificate_number);
CREATE INDEX IF NOT EXISTS idx_certificates_qr ON certificates(qr_code);
CREATE INDEX IF NOT EXISTS idx_certificates_status ON certificates(certificate_status);

-- 4. Storage bucket for certificate templates
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'certificate-templates', 'certificate-templates', true,
  20971520,
  ARRAY['image/jpeg', 'image/png', 'image/webp']
) ON CONFLICT (id) DO NOTHING;

-- 5. RLS on certificate_templates
ALTER TABLE certificate_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_cert_templates_authenticated" ON certificate_templates
  FOR SELECT TO authenticated USING (is_active = true);

CREATE POLICY "insert_cert_templates_admin" ON certificate_templates
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

CREATE POLICY "update_cert_templates_admin" ON certificate_templates
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

CREATE POLICY "delete_cert_templates_admin" ON certificate_templates
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

-- 6. RLS on certificates
ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_certificates" ON certificates
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

CREATE POLICY "insert_certificates_admin" ON certificates
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin')) OR
    user_id = auth.uid()
  );

CREATE POLICY "update_certificates_admin" ON certificates
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin')) OR
    user_id = auth.uid()
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin')) OR
    user_id = auth.uid()
  );

CREATE POLICY "delete_certificates_admin" ON certificates
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

-- 7. Storage policies for certificate-templates bucket
CREATE POLICY "select_cert_templates_bucket_public" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'certificate-templates');

CREATE POLICY "insert_cert_templates_bucket_admin" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'certificate-templates' AND
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

CREATE POLICY "update_cert_templates_bucket_admin" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'certificate-templates' AND
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

CREATE POLICY "delete_cert_templates_bucket_admin" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'certificate-templates' AND
    EXISTS (SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid() AND aup.role IN ('super_admin', 'admin'))
  );

-- 8. Function: set default certificate template
CREATE OR REPLACE FUNCTION set_default_certificate_template(p_template_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE certificate_templates SET is_default = false WHERE is_default = true;
  UPDATE certificate_templates SET is_default = true WHERE id = p_template_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. Function: generate unique certificate number
CREATE OR REPLACE FUNCTION generate_certificate_number()
RETURNS TEXT AS $$
DECLARE
  cert_num TEXT;
  year_str TEXT := EXTRACT(YEAR FROM now())::TEXT;
  random_part TEXT;
BEGIN
  LOOP
    random_part := substr(replace(gen_random_uuid()::TEXT, '-', ''), 1, 8);
    cert_num := 'CERT-' || year_str || '-' || upper(random_part);
    EXIT WHEN NOT EXISTS (SELECT 1 FROM certificates WHERE certificate_number = cert_num);
  END LOOP;
  RETURN cert_num;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. Default certificate number trigger
CREATE OR REPLACE FUNCTION set_certificate_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.certificate_number IS NULL OR NEW.certificate_number = '' THEN
    NEW.certificate_number := generate_certificate_number();
  END IF;
  IF NEW.qr_code IS NULL OR NEW.qr_code = '' THEN
    NEW.qr_code := 'QR-' || substr(replace(gen_random_uuid()::TEXT, '-', ''), 1, 12);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_set_certificate_number ON certificates;
CREATE TRIGGER trg_set_certificate_number
  BEFORE INSERT ON certificates
  FOR EACH ROW EXECUTE FUNCTION set_certificate_number();
