
-- Auth users profile table (links to Supabase Auth)
CREATE TABLE IF NOT EXISTS auth_user_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(auth_user_id)
);

ALTER TABLE auth_user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_user_profiles" ON auth_user_profiles FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_user_profiles" ON auth_user_profiles FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_user_profiles" ON auth_user_profiles FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_user_profiles" ON auth_user_profiles FOR DELETE TO authenticated USING (true);
