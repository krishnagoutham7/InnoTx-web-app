-- Allow authenticated users to insert their own tickets (user_id = auth.uid())
-- This fixes ticket generation for new users who self-register.
-- Previously only admins could insert tickets, causing ticket generation to fail
-- for regular users after registration approval.

DROP POLICY IF EXISTS tickets_insert_admin ON event_tickets;
DROP POLICY IF EXISTS tickets_insert_own ON event_tickets;

CREATE POLICY tickets_insert_own ON event_tickets
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Admins can still insert tickets for any user (e.g. bulk generation)
CREATE POLICY tickets_insert_admin ON event_tickets
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth_user_profiles
      WHERE auth_user_profiles.auth_user_id = auth.uid()
      AND auth_user_profiles.role IN ('super_admin', 'admin')
    )
  );

-- Allow authenticated users to UPDATE their own tickets (e.g. mark used)
-- Previously only admins could update.
DROP POLICY IF EXISTS tickets_update_own ON event_tickets;
CREATE POLICY tickets_update_own ON event_tickets
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
