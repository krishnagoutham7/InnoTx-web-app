/*
# Fix Team Category Constraint

1. Modified Constraints
- Drop old `cms_team_members_category_check` constraint
- Keep `valid_team_category` constraint which includes all new categories

2. Notes
- The old constraint was created in an earlier migration
- It didn't include coo, cfo, cpo, member categories
- Now all leadership positions are supported
*/

ALTER TABLE cms_team_members DROP CONSTRAINT IF EXISTS cms_team_members_category_check;
