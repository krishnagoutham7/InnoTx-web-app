
-- Create demo auth users and their profiles
-- Password for all: matches the demo credentials (hashed by auth.users trigger)

DO $$
DECLARE
  suid UUID;
  fid UUID;
  cid UUID;
  pid UUID;
  eid UUID;
  stid UUID;
BEGIN
  -- superadmin@innotex.com
  INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at, confirmation_token, email_change_token_new, recovery_token)
  VALUES ('00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated', 'authenticated', 'superadmin@innotex.com',
    crypt('Admin@123', gen_salt('bf')), NOW(), NOW(), NOW(), '', '', '')
  RETURNING id INTO suid;

  -- faculty@innotex.com
  INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at, confirmation_token, email_change_token_new, recovery_token)
  VALUES ('00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated', 'authenticated', 'faculty@innotex.com',
    crypt('Faculty@123', gen_salt('bf')), NOW(), NOW(), NOW(), '', '', '')
  RETURNING id INTO fid;

  -- ceo@innotex.com
  INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at, confirmation_token, email_change_token_new, recovery_token)
  VALUES ('00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated', 'authenticated', 'ceo@innotex.com',
    crypt('CEO@123', gen_salt('bf')), NOW(), NOW(), NOW(), '', '', '')
  RETURNING id INTO cid;

  -- programofficer@innotex.com
  INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at, confirmation_token, email_change_token_new, recovery_token)
  VALUES ('00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated', 'authenticated', 'programofficer@innotex.com',
    crypt('Program@123', gen_salt('bf')), NOW(), NOW(), NOW(), '', '', '')
  RETURNING id INTO pid;

  -- executive@innotex.com
  INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at, confirmation_token, email_change_token_new, recovery_token)
  VALUES ('00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated', 'authenticated', 'executive@innotex.com',
    crypt('Executive@123', gen_salt('bf')), NOW(), NOW(), NOW(), '', '', '')
  RETURNING id INTO eid;

  -- student@innotex.com
  INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at, confirmation_token, email_change_token_new, recovery_token)
  VALUES ('00000000-0000-0000-0000-000000000000', gen_random_uuid(), 'authenticated', 'authenticated', 'student@innotex.com',
    crypt('Student@123', gen_salt('bf')), NOW(), NOW(), NOW(), '', '', '')
  RETURNING id INTO stid;

  -- Insert profiles
  INSERT INTO auth_user_profiles (auth_user_id, email, name, role) VALUES
    (suid, 'superadmin@innotex.com', 'Super Administrator', 'super_admin'),
    (fid, 'faculty@innotex.com', 'Dr. Faculty Coordinator', 'faculty'),
    (cid, 'ceo@innotex.com', 'CEO Member', 'ceo'),
    (pid, 'programofficer@innotex.com', 'Program Officer', 'program_officer'),
    (eid, 'executive@innotex.com', 'Executive Member', 'executive'),
    (stid, 'student@innotex.com', 'Student User', 'student');
END $$;
