/*
# Team Module Enhancement

1. Modified Tables
- `cms_team_members`: Add `bio` column for member descriptions
- Add check constraint for valid categories

2. New Categories Supported
- CEO (Chief Executive Officer) - existing
- COO (Chief Operating Officer) - new
- CFO (Chief Financial Officer) - new
- CPO (Chief Program Officer) - new
- executive (Executive Members) - existing
- member (Team Members) - new
- principal (Principal) - existing
- student_coordinator - existing

3. Notes
- All existing records preserved
- bio column is nullable for backward compatibility
- Categories are validated via check constraint
*/

ALTER TABLE cms_team_members ADD COLUMN IF NOT EXISTS bio text;

-- Optional: Add a check constraint for valid categories
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'valid_team_category'
  ) THEN
    ALTER TABLE cms_team_members ADD CONSTRAINT valid_team_category
    CHECK (category IN ('ceo', 'coo', 'cfo', 'cpo', 'executive', 'member', 'principal', 'student_coordinator'));
  END IF;
END $$;
