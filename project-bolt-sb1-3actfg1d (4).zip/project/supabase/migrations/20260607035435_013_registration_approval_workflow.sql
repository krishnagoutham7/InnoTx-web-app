/*
# Registration Approval Workflow Enhancement

## Changes
1. Add approval status fields to event_registrations
2. Change default status from 'confirmed' to 'pending'
3. Add approval tracking columns
4. Add student info columns (department, semester)
5. Create approval logs table
6. Update RLS policies
*/

-- ============================================
-- 1. ADD APPROVAL FIELDS TO EVENT_REGISTRATIONS
-- ============================================

-- Check and add missing columns
DO $$
BEGIN
  -- Add approval_status if not exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'approval_status'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN approval_status text NOT NULL DEFAULT 'pending'
      CHECK (approval_status IN ('pending', 'approved', 'rejected', 'waitlisted'));
  END IF;

  -- Add approved_by
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'approved_by'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN approved_by uuid REFERENCES auth.users(id);
  END IF;

  -- Add approval_date
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'approval_date'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN approval_date timestamptz;
  END IF;

  -- Add remarks
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'remarks'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN remarks text;
  END IF;

  -- Add department
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'department'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN department text;
  END IF;

  -- Add semester
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'semester'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN semester text;
  END IF;

  -- Add student_id
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'student_id'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN student_id text;
  END IF;

  -- Add attendance_verified
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'attendance_verified'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN attendance_verified boolean DEFAULT false;
  END IF;

  -- Add certificate_status
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_registrations' AND column_name = 'certificate_status'
  ) THEN
    ALTER TABLE event_registrations ADD COLUMN certificate_status text DEFAULT 'not_eligible'
      CHECK (certificate_status IN ('not_eligible', 'eligible', 'generated', 'issued'));
  END IF;
END $$;

-- Update existing records - set approval_status based on registration_status
UPDATE event_registrations 
SET approval_status = CASE 
  WHEN registration_status = 'confirmed' THEN 'approved'
  WHEN registration_status = 'cancelled' THEN 'rejected'
  WHEN registration_status = 'waitlisted' THEN 'waitlisted'
  ELSE 'pending'
END,
approval_date = registered_at
WHERE approval_status IS NULL OR approval_status = 'pending';

-- ============================================
-- 2. CREATE APPROVAL LOGS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS registration_approval_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  registration_id uuid NOT NULL REFERENCES event_registrations(id) ON DELETE CASCADE,
  action text NOT NULL CHECK (action IN ('created', 'approved', 'rejected', 'waitlisted', 'unapproved', 'remarks_updated')),
  previous_status text,
  new_status text,
  performed_by uuid REFERENCES auth.users(id),
  remarks text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_approval_logs_registration ON registration_approval_logs(registration_id);
CREATE INDEX IF NOT EXISTS idx_approval_logs_created ON registration_approval_logs(created_at DESC);

-- ============================================
-- 3. CREATE APPROVAL FUNCTION
-- ============================================

CREATE OR REPLACE FUNCTION approve_registration(
  p_registration_id uuid,
  p_approved_by uuid,
  p_remarks text DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  reg record;
  result jsonb;
BEGIN
  -- Get registration
  SELECT * INTO reg FROM event_registrations WHERE id = p_registration_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Registration not found');
  END IF;
  
  -- Update registration
  UPDATE event_registrations
  SET approval_status = 'approved',
      approved_by = p_approved_by,
      approval_date = now(),
      remarks = COALESCE(p_remarks, remarks),
      registration_status = 'confirmed'
  WHERE id = p_registration_id;
  
  -- Log approval
  INSERT INTO registration_approval_logs (
    registration_id, action, previous_status, new_status, performed_by, remarks
  ) VALUES (
    p_registration_id, 'approved', reg.approval_status, 'approved', p_approved_by, p_remarks
  );
  
  RETURN jsonb_build_object(
    'success', true,
    'registration_id', p_registration_id,
    'new_status', 'approved'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION reject_registration(
  p_registration_id uuid,
  p_rejected_by uuid,
  p_remarks text DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  reg record;
BEGIN
  SELECT * INTO reg FROM event_registrations WHERE id = p_registration_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Registration not found');
  END IF;
  
  UPDATE event_registrations
  SET approval_status = 'rejected',
      approved_by = p_rejected_by,
      approval_date = now(),
      remarks = COALESCE(p_remarks, remarks),
      registration_status = 'cancelled'
  WHERE id = p_registration_id;
  
  INSERT INTO registration_approval_logs (
    registration_id, action, previous_status, new_status, performed_by, remarks
  ) VALUES (
    p_registration_id, 'rejected', reg.approval_status, 'rejected', p_rejected_by, p_remarks
  );
  
  RETURN jsonb_build_object('success', true, 'registration_id', p_registration_id, 'new_status', 'rejected');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 4. UPDATE ATTENDANCE VALIDATION
-- ============================================

CREATE OR REPLACE FUNCTION validate_qr_for_attendance(
  p_qr_code text,
  p_event_id uuid
)
RETURNS jsonb AS $$
DECLARE
  ticket record;
  attendance_window record;
  registration record;
BEGIN
  -- Get ticket
  SELECT * INTO ticket FROM event_tickets WHERE qr_code = p_qr_code;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'INVALID_QR_CODE',
      'message', 'QR code not found in system'
    );
  END IF;
  
  -- Check if ticket is for correct event
  IF ticket.event_id != p_event_id THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'WRONG_EVENT',
      'message', 'This ticket is for a different event'
    );
  END IF;
  
  -- Get registration to check approval status
  SELECT * INTO registration FROM event_registrations WHERE id = ticket.registration_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'REGISTRATION_NOT_FOUND',
      'message', 'Registration record not found'
    );
  END IF;
  
  -- CRITICAL: Check if registration is approved
  IF registration.approval_status != 'approved' THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'NOT_APPROVED',
      'message', 'You are not approved for this event. Current status: ' || registration.approval_status
    );
  END IF;
  
  -- Check if already used
  IF ticket.is_used THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'ALREADY_USED',
      'message', 'This ticket has already been used for attendance'
    );
  END IF;
  
  -- Check if ticket expired
  IF ticket.expires_at IS NOT NULL AND ticket.expires_at < now() THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'TICKET_EXPIRED',
      'message', 'This ticket has expired'
    );
  END IF;
  
  -- Check attendance window
  SELECT * INTO attendance_window FROM event_attendance_windows WHERE event_id = p_event_id;
  
  IF FOUND THEN
    IF NOT attendance_window.is_attendance_open THEN
      RETURN jsonb_build_object(
        'valid', false,
        'error', 'ATTENDANCE_CLOSED',
        'message', 'Attendance is not open for this event'
      );
    END IF;
    
    IF attendance_window.attendance_open IS NOT NULL AND now() < attendance_window.attendance_open THEN
      RETURN jsonb_build_object(
        'valid', false,
        'error', 'ATTENDANCE_NOT_STARTED',
        'message', 'Attendance window has not started yet'
      );
    END IF;
    
    IF attendance_window.attendance_close IS NOT NULL AND now() > attendance_window.attendance_close THEN
      RETURN jsonb_build_object(
        'valid', false,
        'error', 'ATTENDANCE_ENDED',
        'message', 'Attendance window has ended'
      );
    END IF;
  END IF;
  
  -- Check if attendance already marked
  IF EXISTS (SELECT 1 FROM event_attendance WHERE ticket_id = ticket.id) THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'ATTENDANCE_EXISTS',
      'message', 'Attendance already marked for this ticket'
    );
  END IF;
  
  -- Valid ticket
  RETURN jsonb_build_object(
    'valid', true,
    'ticket_id', ticket.id,
    'registration_id', ticket.registration_id,
    'participant_name', ticket.participant_name,
    'participant_email', ticket.participant_email,
    'event_id', ticket.event_id,
    'approval_status', registration.approval_status
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 5. RLS POLICIES FOR APPROVAL LOGS
-- ============================================

ALTER TABLE registration_approval_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "approval_logs_select" ON registration_approval_logs FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

CREATE POLICY "approval_logs_insert" ON registration_approval_logs FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

-- ============================================
-- 6. CREATE INDEXES
-- ============================================

CREATE INDEX IF NOT EXISTS idx_registrations_approval_status ON event_registrations(approval_status);
CREATE INDEX IF NOT EXISTS idx_registrations_event_status ON event_registrations(event_id, approval_status);
CREATE INDEX IF NOT EXISTS idx_registrations_user_id ON event_registrations(user_id);
