/*
# CMS Tables — Team Members, Gallery, Announcements, Homepage CMS, System Settings, Portal Users

## Overview
This migration creates all tables needed to back the InnoTex CMS dashboard modules.
Every table is single-tenant (no user_id ownership), so all policies use `TO anon, authenticated USING (true)`.
This allows the anon-key frontend to read and write all CMS content.

## New Tables

### 1. `cms_team_members`
Stores team members displayed on the public /team page and dashboard.
- `id` uuid PK
- `name` text NOT NULL
- `position` text NOT NULL — job title / role label
- `category` text NOT NULL — 'principal' | 'faculty' | 'program_officer' | 'ceo' | 'executive' | 'student_coordinator'
- `department` text
- `email` text
- `bio` text
- `photo_url` text
- `is_active` boolean DEFAULT true
- `display_order` int DEFAULT 0
- `created_at` timestamptz
- `updated_at` timestamptz

### 2. `cms_gallery_albums`
Albums that group gallery images.
- `id` uuid PK
- `name` text NOT NULL UNIQUE
- `description` text
- `cover_url` text
- `display_order` int DEFAULT 0
- `created_at` timestamptz
- `updated_at` timestamptz

### 3. `cms_gallery_images`
Individual images belonging to albums.
- `id` uuid PK
- `album_id` uuid FK → cms_gallery_albums(id) ON DELETE CASCADE
- `title` text
- `description` text
- `image_url` text
- `is_featured` boolean DEFAULT false
- `display_order` int DEFAULT 0
- `created_at` timestamptz

### 4. `cms_announcements`
Announcements shown on dashboard and optionally on the public homepage.
- `id` uuid PK
- `title` text NOT NULL
- `description` text
- `category` text
- `priority` text DEFAULT 'medium' — 'low' | 'medium' | 'high'
- `status` text DEFAULT 'draft' — 'draft' | 'published' | 'archived'
- `is_pinned` boolean DEFAULT false
- `publish_date` date
- `created_at` timestamptz
- `updated_at` timestamptz

### 5. `cms_homepage`
Single-row table (id = 'default') storing all editable homepage content.
- `id` text PK DEFAULT 'default'
- `hero_headline` text
- `hero_tagline` text
- `hero_description` text
- `hero_cta_primary_text` text
- `hero_cta_primary_link` text
- `hero_cta_secondary_text` text
- `hero_cta_secondary_link` text
- `stat_1_label` text, `stat_1_value` int, `stat_1_suffix` text
- `stat_2_label` text, `stat_2_value` int, `stat_2_suffix` text
- `stat_3_label` text, `stat_3_value` int, `stat_3_suffix` text
- `stat_4_label` text, `stat_4_value` int, `stat_4_suffix` text
- `about_title` text
- `about_description` text
- `vision_title` text, `vision_content` text
- `mission_title` text, `mission_content` text
- `updated_at` timestamptz

### 6. `cms_system_settings`
Single-row table (id = 'default') for portal-wide settings.
- `id` text PK DEFAULT 'default'
- `portal_name` text
- `portal_tagline` text
- `footer_text` text
- `language` text DEFAULT 'en'
- `primary_color` text
- `accent_color` text
- `enable_dark_mode` boolean DEFAULT true
- `show_announcements_on_home` boolean DEFAULT true
- `show_events_on_home` boolean DEFAULT true
- `show_gallery_on_home` boolean DEFAULT true
- `updated_at` timestamptz

### 7. `cms_portal_users`
Portal user accounts managed by super admin.
- `id` uuid PK DEFAULT gen_random_uuid()
- `email` text NOT NULL UNIQUE
- `name` text NOT NULL
- `role` text NOT NULL — 'super_admin' | 'admin' | 'faculty' | 'ceo' | 'program_officer' | 'executive' | 'student'
- `is_active` boolean DEFAULT true
- `last_login` timestamptz
- `created_at` timestamptz

## Security
- RLS enabled on all tables.
- All policies allow anon + authenticated (single-tenant app, no per-user ownership).

## Seed Data
- Inserts default row in `cms_homepage` and `cms_system_settings`.
- Seeds team members, gallery albums, announcements, and portal users from mock data.
*/

-- ─── cms_team_members ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_team_members (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text        NOT NULL,
  position      text        NOT NULL,
  category      text        NOT NULL,
  department    text,
  email         text,
  bio           text,
  photo_url     text,
  is_active     boolean     NOT NULL DEFAULT true,
  display_order int         NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_team_members ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_team_members" ON cms_team_members;
CREATE POLICY "select_team_members" ON cms_team_members FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_team_members" ON cms_team_members;
CREATE POLICY "insert_team_members" ON cms_team_members FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_team_members" ON cms_team_members;
CREATE POLICY "update_team_members" ON cms_team_members FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_team_members" ON cms_team_members;
CREATE POLICY "delete_team_members" ON cms_team_members FOR DELETE TO anon, authenticated USING (true);

-- ─── cms_gallery_albums ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_gallery_albums (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text        NOT NULL,
  description   text,
  cover_url     text,
  display_order int         NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_gallery_albums ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_gallery_albums" ON cms_gallery_albums;
CREATE POLICY "select_gallery_albums" ON cms_gallery_albums FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_gallery_albums" ON cms_gallery_albums;
CREATE POLICY "insert_gallery_albums" ON cms_gallery_albums FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_gallery_albums" ON cms_gallery_albums;
CREATE POLICY "update_gallery_albums" ON cms_gallery_albums FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_gallery_albums" ON cms_gallery_albums;
CREATE POLICY "delete_gallery_albums" ON cms_gallery_albums FOR DELETE TO anon, authenticated USING (true);

-- ─── cms_gallery_images ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_gallery_images (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  album_id      uuid        REFERENCES cms_gallery_albums(id) ON DELETE CASCADE,
  title         text,
  description   text,
  image_url     text,
  is_featured   boolean     NOT NULL DEFAULT false,
  display_order int         NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_gallery_images ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_gallery_images" ON cms_gallery_images;
CREATE POLICY "select_gallery_images" ON cms_gallery_images FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_gallery_images" ON cms_gallery_images;
CREATE POLICY "insert_gallery_images" ON cms_gallery_images FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_gallery_images" ON cms_gallery_images;
CREATE POLICY "update_gallery_images" ON cms_gallery_images FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_gallery_images" ON cms_gallery_images;
CREATE POLICY "delete_gallery_images" ON cms_gallery_images FOR DELETE TO anon, authenticated USING (true);

-- ─── cms_announcements ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_announcements (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  title        text        NOT NULL,
  description  text,
  category     text,
  priority     text        NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
  status       text        NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  is_pinned    boolean     NOT NULL DEFAULT false,
  publish_date date,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_announcements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_announcements" ON cms_announcements;
CREATE POLICY "select_announcements" ON cms_announcements FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_announcements" ON cms_announcements;
CREATE POLICY "insert_announcements" ON cms_announcements FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_announcements" ON cms_announcements;
CREATE POLICY "update_announcements" ON cms_announcements FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_announcements" ON cms_announcements;
CREATE POLICY "delete_announcements" ON cms_announcements FOR DELETE TO anon, authenticated USING (true);

-- ─── cms_homepage ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_homepage (
  id                        text        PRIMARY KEY DEFAULT 'default',
  hero_headline             text        NOT NULL DEFAULT 'Igniting Innovation, Shaping the Future',
  hero_tagline              text        NOT NULL DEFAULT 'Innovation • Entrepreneurship • Technology • Leadership',
  hero_description          text        NOT NULL DEFAULT 'InnoTex empowers students to transform ideas into impactful ventures.',
  hero_cta_primary_text     text        NOT NULL DEFAULT 'Explore Innovation',
  hero_cta_primary_link     text        NOT NULL DEFAULT '/about',
  hero_cta_secondary_text   text        NOT NULL DEFAULT 'View Events',
  hero_cta_secondary_link   text        NOT NULL DEFAULT '/gallery',
  stat_1_label              text        NOT NULL DEFAULT 'Total Members',
  stat_1_value              int         NOT NULL DEFAULT 250,
  stat_1_suffix             text        NOT NULL DEFAULT '+',
  stat_2_label              text        NOT NULL DEFAULT 'Startups Supported',
  stat_2_value              int         NOT NULL DEFAULT 18,
  stat_2_suffix             text        NOT NULL DEFAULT '+',
  stat_3_label              text        NOT NULL DEFAULT 'Innovation Projects',
  stat_3_value              int         NOT NULL DEFAULT 45,
  stat_3_suffix             text        NOT NULL DEFAULT '+',
  stat_4_label              text        NOT NULL DEFAULT 'Events Conducted',
  stat_4_value              int         NOT NULL DEFAULT 30,
  stat_4_suffix             text        NOT NULL DEFAULT '+',
  about_title               text        NOT NULL DEFAULT 'Where Ideas Meet Opportunity',
  about_description         text        NOT NULL DEFAULT 'Innovation is at the heart of everything we do.',
  vision_title              text        NOT NULL DEFAULT 'Our Vision',
  vision_content            text        NOT NULL DEFAULT 'To become a leading centre of innovation and entrepreneurship.',
  mission_title             text        NOT NULL DEFAULT 'Our Mission',
  mission_content           text        NOT NULL DEFAULT 'To create a vibrant entrepreneurial ecosystem within the campus.',
  updated_at                timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_homepage ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_homepage" ON cms_homepage;
CREATE POLICY "select_homepage" ON cms_homepage FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_homepage" ON cms_homepage;
CREATE POLICY "insert_homepage" ON cms_homepage FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_homepage" ON cms_homepage;
CREATE POLICY "update_homepage" ON cms_homepage FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- ─── cms_system_settings ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_system_settings (
  id                          text        PRIMARY KEY DEFAULT 'default',
  portal_name                 text        NOT NULL DEFAULT 'InnoTex',
  portal_tagline              text        NOT NULL DEFAULT 'Innovation • Entrepreneurship • Technology • Leadership',
  footer_text                 text        NOT NULL DEFAULT 'Government Polytechnic College Adoor',
  language                    text        NOT NULL DEFAULT 'en',
  primary_color               text        NOT NULL DEFAULT '#8B5CF6',
  accent_color                text        NOT NULL DEFAULT '#3B82F6',
  enable_dark_mode            boolean     NOT NULL DEFAULT true,
  show_announcements_on_home  boolean     NOT NULL DEFAULT true,
  show_events_on_home         boolean     NOT NULL DEFAULT true,
  show_gallery_on_home        boolean     NOT NULL DEFAULT true,
  updated_at                  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_system_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_system_settings" ON cms_system_settings;
CREATE POLICY "select_system_settings" ON cms_system_settings FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_system_settings" ON cms_system_settings;
CREATE POLICY "insert_system_settings" ON cms_system_settings FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_system_settings" ON cms_system_settings;
CREATE POLICY "update_system_settings" ON cms_system_settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- ─── cms_portal_users ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_portal_users (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  email      text        NOT NULL UNIQUE,
  name       text        NOT NULL,
  role       text        NOT NULL CHECK (role IN ('super_admin','admin','faculty','ceo','program_officer','executive','student')),
  is_active  boolean     NOT NULL DEFAULT true,
  last_login timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cms_portal_users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_portal_users" ON cms_portal_users;
CREATE POLICY "select_portal_users" ON cms_portal_users FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_portal_users" ON cms_portal_users;
CREATE POLICY "insert_portal_users" ON cms_portal_users FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_portal_users" ON cms_portal_users;
CREATE POLICY "update_portal_users" ON cms_portal_users FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_portal_users" ON cms_portal_users;
CREATE POLICY "delete_portal_users" ON cms_portal_users FOR DELETE TO anon, authenticated USING (true);

-- ─── Seed: default single-row records ─────────────────────────────────────────
INSERT INTO cms_homepage (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;
INSERT INTO cms_system_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

-- ─── Seed: team members ───────────────────────────────────────────────────────
INSERT INTO cms_team_members (name, position, category, department, email, is_active, display_order) VALUES
  ('Dr. Principal Name',    'Principal',          'principal',          'Administration',       'principal@gpcadoor.ac.in',   true, 1),
  ('Dr. Faculty Coordinator','IEDC Coordinator',  'faculty',            'Computer Engineering', 'faculty@gpcadoor.ac.in',    true, 2),
  ('Program Officer Name',  'Program Officer',    'program_officer',    'Electronics Engineering','po@gpcadoor.ac.in',        true, 3),
  ('CEO Member',            'CEO',                'ceo',                'Computer Engineering', 'ceo@innotex.com',           true, 4),
  ('Executive One',         'Head of Marketing',  'executive',          'Computer Engineering', NULL,                        true, 5),
  ('Executive Two',         'Head of Events',     'executive',          'Electronics Engineering',NULL,                     true, 6),
  ('Student Coord One',     'Student Coordinator','student_coordinator','Mechanical Engineering',NULL,                      true, 7)
ON CONFLICT DO NOTHING;

-- ─── Seed: gallery albums ─────────────────────────────────────────────────────
INSERT INTO cms_gallery_albums (name, description, display_order) VALUES
  ('Events 2024',  'Major events conducted in 2024',             1),
  ('Workshops',    'Technical workshops and training sessions',  2),
  ('Hackathons',   'Hackathon events and innovation marathons',  3),
  ('Campus',       'Campus life and facilities',                 4),
  ('Projects',     'Student innovation projects showcase',       5)
ON CONFLICT DO NOTHING;

-- ─── Seed: announcements ─────────────────────────────────────────────────────
INSERT INTO cms_announcements (title, description, category, priority, status, is_pinned, publish_date) VALUES
  ('IEDC Seed Fund Applications Open',   'Applications for IEDC seed funding are now open for student projects.', 'Funding',     'high',   'published', true,  '2026-06-05'),
  ('InnoTex Annual Report 2024 Released','The annual report showcasing our achievements has been published.',       'Report',      'medium', 'published', false, '2026-06-02'),
  ('Hackathon Registration Begins',      'Registration for the annual 48-hour hackathon is now open.',             'Events',      'high',   'published', true,  '2026-06-10'),
  ('New Partnership Announcement',       'MoU signed with leading tech company for student internships.',          'Partnership', 'low',    'draft',     false, '2026-06-15'),
  ('Workshop on Design Thinking',        'A hands-on workshop on design thinking methodology for all students.',   'Workshops',   'medium', 'archived',  false, '2026-05-20')
ON CONFLICT DO NOTHING;

-- ─── Seed: portal users ───────────────────────────────────────────────────────
INSERT INTO cms_portal_users (email, name, role, is_active) VALUES
  ('superadmin@innotex.com',    'Super Administrator',   'super_admin',    true),
  ('admin@innotex.com',         'Admin User',            'admin',          true),
  ('faculty@innotex.com',       'Dr. Faculty Coordinator','faculty',       true),
  ('ceo@innotex.com',           'CEO Member',            'ceo',            true),
  ('programofficer@innotex.com','Program Officer',       'program_officer',true),
  ('executive@innotex.com',     'Executive Member',      'executive',      true),
  ('student@innotex.com',       'Student User',          'student',        true)
ON CONFLICT (email) DO NOTHING;
