-- Event Media Storage Buckets and Policies

-- Create event-banners bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'event-banners',
  'event-banners',
  true,
  20971520, -- 20MB
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
) ON CONFLICT (id) DO NOTHING;

-- Create event-posters bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'event-posters',
  'event-posters',
  true,
  20971520, -- 20MB
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
) ON CONFLICT (id) DO NOTHING;

-- RLS Policies for event-banners
CREATE POLICY "select_banners_public" ON storage.objects FOR SELECT
  TO public USING (bucket_id = 'event-banners');

CREATE POLICY "insert_banners_admin" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (
    bucket_id = 'event-banners' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cfo', 'cpo', 'program_officer', 'faculty')
    )
  );

CREATE POLICY "update_banners_admin" ON storage.objects FOR UPDATE
  TO authenticated USING (
    bucket_id = 'event-banners' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cfo', 'cpo', 'program_officer', 'faculty')
    )
  );

CREATE POLICY "delete_banners_admin" ON storage.objects FOR DELETE
  TO authenticated USING (
    bucket_id = 'event-banners' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cfo', 'cpo', 'program_officer', 'faculty')
    )
  );

-- RLS Policies for event-posters
CREATE POLICY "select_posters_public" ON storage.objects FOR SELECT
  TO public USING (bucket_id = 'posters');

CREATE POLICY "insert_posters_admin" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (
    bucket_id = 'event-posters' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cfo', 'cpo', 'program_officer', 'faculty')
    )
  );

CREATE POLICY "update_posters_admin" ON storage.objects FOR UPDATE
  TO authenticated USING (
    bucket_id = 'event-posters' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cfo', 'cpo', 'program_officer', 'faculty')
    )
  );

CREATE POLICY "delete_posters_admin" ON storage.objects FOR DELETE
  TO authenticated USING (
    bucket_id = 'event-posters' AND
    EXISTS (
      SELECT 1 FROM auth_user_profiles aup
      WHERE aup.auth_user_id = auth.uid()
      AND aup.role IN ('super_admin', 'admin', 'ceo', 'coo', 'cfo', 'cpo', 'program_officer', 'faculty')
    )
  );