/*
# Event Participation Ticket and QR-Based Attendance Module

## Tables Modified
1. event_registrations - Add ticket_id, user_id, qr_code fields

## Tables Created
1. event_tickets - Ticket data with QR codes
2. event_attendance - Attendance records
3. attendance_logs - Attendance logging/audit trail
4. event_attendance_windows - Attendance time windows
*/

-- ============================================
-- 1. MODIFY EVENT_REGISTRATIONS TABLE
-- ============================================

ALTER TABLE event_registrations ADD COLUMN IF NOT EXISTS ticket_id uuid UNIQUE;
ALTER TABLE event_registrations ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id);
ALTER TABLE event_registrations ADD COLUMN IF NOT EXISTS qr_code text UNIQUE;
ALTER TABLE event_registrations ADD COLUMN IF NOT EXISTS ticket_generated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_event_registrations_qr ON event_registrations(qr_code);
CREATE INDEX IF NOT EXISTS idx_event_registrations_user ON event_registrations(user_id);
CREATE INDEX IF NOT EXISTS idx_event_registrations_event ON event_registrations(event_id);

-- ============================================
-- 2. HELPER FUNCTIONS (must be created before tables that use them)
-- ============================================

CREATE OR REPLACE FUNCTION generate_ticket_number()
RETURNS text AS $$
DECLARE
  prefix text := 'TKT';
  random_part text;
  ticket_no text;
  exists boolean;
BEGIN
  LOOP
    random_part := upper(substring(md5(random()::text) from 1 for 8));
    ticket_no := prefix || '-' || to_char(now(), 'YYYYMMDD') || '-' || random_part;
    SELECT EXISTS(SELECT 1 FROM event_tickets WHERE ticket_number = ticket_no) INTO exists;
    EXIT WHEN NOT exists;
  END LOOP;
  RETURN ticket_no;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION generate_qr_code()
RETURNS text AS $$
DECLARE
  qr text;
  exists boolean;
BEGIN
  LOOP
    qr := 'QR-' || upper(substring(md5(random()::text || now()::text) from 1 for 16));
    SELECT EXISTS(SELECT 1 FROM event_tickets WHERE qr_code = qr) INTO exists;
    EXIT WHEN NOT exists;
  END LOOP;
  RETURN qr;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION generate_qr_code_data(
  p_ticket_id uuid,
  p_registration_id uuid,
  p_event_id uuid,
  p_user_id uuid DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  qr_data jsonb;
  unique_hash text;
BEGIN
  unique_hash := encode(sha256(
    p_ticket_id::text || 
    p_registration_id::text || 
    p_event_id::text || 
    now()::text || 
    random()::text
  ), 'hex');
  
  qr_data := jsonb_build_object(
    'ticket_id', p_ticket_id,
    'registration_id', p_registration_id,
    'event_id', p_event_id,
    'user_id', p_user_id,
    'hash', unique_hash,
    'generated_at', now()
  );
  
  RETURN qr_data;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 3. EVENT_TICKETS TABLE
-- ============================================

CREATE TABLE event_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number text UNIQUE NOT NULL,
  registration_id uuid NOT NULL REFERENCES event_registrations(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  participant_name text NOT NULL,
  participant_email text NOT NULL,
  qr_code text UNIQUE NOT NULL,
  qr_code_data jsonb NOT NULL DEFAULT '{}',
  is_used boolean DEFAULT false,
  used_at timestamptz,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  
  CONSTRAINT unique_ticket_per_registration UNIQUE (registration_id)
);

-- Set default to use the function
ALTER TABLE event_tickets ALTER COLUMN ticket_number SET DEFAULT generate_ticket_number();

CREATE INDEX idx_event_tickets_qr ON event_tickets(qr_code);
CREATE INDEX idx_event_tickets_registration ON event_tickets(registration_id);
CREATE INDEX idx_event_tickets_event ON event_tickets(event_id);
CREATE INDEX idx_event_tickets_user ON event_tickets(user_id);

-- ============================================
-- 4. EVENT_ATTENDANCE TABLE
-- ============================================

CREATE TABLE event_attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  registration_id uuid NOT NULL REFERENCES event_registrations(id) ON DELETE CASCADE,
  ticket_id uuid NOT NULL REFERENCES event_tickets(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  participant_name text NOT NULL,
  participant_email text NOT NULL,
  scanned_at timestamptz DEFAULT now(),
  scanned_by uuid REFERENCES auth.users(id),
  attendance_method text DEFAULT 'qr_scan' CHECK (attendance_method IN ('qr_scan', 'manual')),
  notes text,
  
  CONSTRAINT unique_attendance_per_registration UNIQUE (registration_id),
  CONSTRAINT unique_attendance_per_ticket UNIQUE (ticket_id),
  CONSTRAINT one_attendance_per_participant_per_event UNIQUE (event_id, participant_email)
);

CREATE INDEX idx_event_attendance_event ON event_attendance(event_id);
CREATE INDEX idx_event_attendance_user ON event_attendance(user_id);
CREATE INDEX idx_event_attendance_scanned_at ON event_attendance(scanned_at DESC);

-- ============================================
-- 5. ATTENDANCE_LOGS TABLE
-- ============================================

CREATE TABLE attendance_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE SET NULL,
  ticket_id uuid REFERENCES event_tickets(id) ON DELETE SET NULL,
  registration_id uuid REFERENCES event_registrations(id) ON DELETE SET NULL,
  action_type text NOT NULL CHECK (action_type IN (
    'ticket_generated',
    'scan_attempt',
    'attendance_marked',
    'scan_failed',
    'attendance_window_opened',
    'attendance_window_closed',
    'manual_override'
  )),
  action_result text NOT NULL CHECK (action_result IN ('success', 'failure', 'warning')),
  error_message text,
  scanned_by uuid REFERENCES auth.users(id),
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_attendance_logs_event ON attendance_logs(event_id);
CREATE INDEX idx_attendance_logs_created ON attendance_logs(created_at DESC);

-- ============================================
-- 6. EVENT_ATTENDANCE_WINDOWS TABLE
-- ============================================

CREATE TABLE event_attendance_windows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  attendance_open timestamptz,
  attendance_close timestamptz,
  is_attendance_open boolean DEFAULT false,
  allow_manual_override boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  CONSTRAINT unique_attendance_window_per_event UNIQUE (event_id)
);

-- ============================================
-- 7. VALIDATION FUNCTION
-- ============================================

CREATE OR REPLACE FUNCTION validate_qr_for_attendance(
  p_qr_code text,
  p_event_id uuid
)
RETURNS jsonb AS $$
DECLARE
  ticket record;
  attendance_window record;
BEGIN
  SELECT * INTO ticket FROM event_tickets WHERE qr_code = p_qr_code;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'INVALID_QR_CODE',
      'message', 'QR code not found in system'
    );
  END IF;
  
  IF ticket.event_id != p_event_id THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'WRONG_EVENT',
      'message', 'This ticket is for a different event'
    );
  END IF;
  
  IF ticket.is_used THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'ALREADY_USED',
      'message', 'This ticket has already been used for attendance'
    );
  END IF;
  
  IF ticket.expires_at IS NOT NULL AND ticket.expires_at < now() THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'TICKET_EXPIRED',
      'message', 'This ticket has expired'
    );
  END IF;
  
  SELECT * INTO attendance_window FROM event_attendance_windows WHERE event_id = p_event_id;
  
  IF FOUND THEN
    IF NOT attendance_window.is_attendance_open THEN
      RETURN jsonb_build_object(
        'valid', false,
        'error', 'ATTENDANCE_CLOSED',
        'message', 'Attendance is not open for this event'
      );
    END IF;
    
    IF attendance_window.attendance_open IS NOT NULL AND now() < attendance_window.attendance_open THEN
      RETURN jsonb_build_object(
        'valid', false,
        'error', 'ATTENDANCE_NOT_STARTED',
        'message', 'Attendance window has not started yet'
      );
    END IF;
    
    IF attendance_window.attendance_close IS NOT NULL AND now() > attendance_window.attendance_close THEN
      RETURN jsonb_build_object(
        'valid', false,
        'error', 'ATTENDANCE_ENDED',
        'message', 'Attendance window has ended'
      );
    END IF;
  END IF;
  
  IF EXISTS (SELECT 1 FROM event_attendance WHERE ticket_id = ticket.id) THEN
    RETURN jsonb_build_object(
      'valid', false,
      'error', 'ATTENDANCE_EXISTS',
      'message', 'Attendance already marked for this ticket'
    );
  END IF;
  
  RETURN jsonb_build_object(
    'valid', true,
    'ticket_id', ticket.id,
    'registration_id', ticket.registration_id,
    'participant_name', ticket.participant_name,
    'participant_email', ticket.participant_email,
    'event_id', ticket.event_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 8. ROW LEVEL SECURITY
-- ============================================

ALTER TABLE event_tickets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tickets_select_own" ON event_tickets FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR 
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

CREATE POLICY "tickets_insert_admin" ON event_tickets FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

CREATE POLICY "tickets_update_admin" ON event_tickets FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

ALTER TABLE event_attendance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "attendance_select_own" ON event_attendance FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

CREATE POLICY "attendance_insert_admin" ON event_attendance FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

ALTER TABLE event_attendance_windows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "attendance_windows_select" ON event_attendance_windows FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "attendance_windows_admin" ON event_attendance_windows FOR ALL
  TO authenticated USING (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

ALTER TABLE attendance_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "attendance_logs_select" ON attendance_logs FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM auth_user_profiles WHERE auth_user_id = auth.uid() AND role IN ('super_admin', 'admin'))
  );

CREATE POLICY "attendance_logs_insert" ON attendance_logs FOR INSERT
  TO authenticated WITH CHECK (true);

-- ============================================
-- 9. REALTIME
-- ============================================

ALTER PUBLICATION supabase_realtime ADD TABLE event_attendance;
ALTER PUBLICATION supabase_realtime ADD TABLE event_tickets;
