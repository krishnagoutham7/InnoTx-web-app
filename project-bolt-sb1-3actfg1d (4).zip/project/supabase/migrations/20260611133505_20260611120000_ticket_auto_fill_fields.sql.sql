-- Add department and student_id to event_tickets for auto-fill
ALTER TABLE event_tickets
ADD COLUMN IF NOT EXISTS participant_department TEXT,
ADD COLUMN IF NOT EXISTS participant_student_id TEXT,
ADD COLUMN IF NOT EXISTS registration_number TEXT;

-- Update existing tickets from registrations
UPDATE event_tickets et
SET 
  participant_department = er.department,
  participant_student_id = er.student_id,
  registration_number = er.student_id
FROM event_registrations er
WHERE et.registration_id = er.id
AND et.participant_department IS NULL;

-- Add comment
COMMENT ON COLUMN event_tickets.participant_department IS 'Department from registration at time of ticket generation';
COMMENT ON COLUMN event_tickets.participant_student_id IS 'Student ID from registration at time of ticket generation';
COMMENT ON COLUMN event_tickets.registration_number IS 'Registration number/reference for display';
