import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const { userId, profileId } = await req.json();

    if (!userId || !profileId) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: userId and profileId" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("NEXT_PUBLIC_SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !serviceRoleKey) {
      console.error("[delete-user] Missing env vars");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create admin client with service role key — bypasses RLS
    const adminClient = createSupabaseClient(supabaseUrl, serviceRoleKey);

    // Verify the caller is an admin by checking their JWT
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const userClient = createSupabaseClient(supabaseUrl, token);
    const { data: { user: caller }, error: callerError } = await userClient.auth.getUser();
    if (callerError || !caller) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify caller is super_admin or admin
    const { data: callerProfile } = await adminClient
      .from("auth_user_profiles")
      .select("role")
      .eq("auth_user_id", caller.id)
      .maybeSingle();

    if (!callerProfile || !["super_admin", "admin"].includes(callerProfile.role)) {
      return new Response(
        JSON.stringify({ error: "Forbidden: admin access required" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[delete-user] Admin ${caller.id} deleting user ${userId}`);

    // STEP 1: Delete certificates
    const { error: certErr } = await adminClient
      .from("certificates")
      .delete()
      .eq("user_id", userId);
    if (certErr) console.error("[delete-user] certificates delete error:", certErr.message);

    // STEP 2: Delete attendance records
    const { error: attErr } = await adminClient
      .from("event_attendance")
      .delete()
      .eq("user_id", userId);
    if (attErr) console.error("[delete-user] attendance delete error:", attErr.message);

    // STEP 3: Delete tickets
    const { error: ticketErr } = await adminClient
      .from("event_tickets")
      .delete()
      .eq("user_id", userId);
    if (ticketErr) console.error("[delete-user] tickets delete error:", ticketErr.message);

    // STEP 4: Delete registrations
    const { error: regErr } = await adminClient
      .from("event_registrations")
      .delete()
      .eq("user_id", userId);
    if (regErr) console.error("[delete-user] registrations delete error:", regErr.message);

    // STEP 5: Delete likes
    const { error: likeErr } = await adminClient
      .from("event_likes")
      .delete()
      .eq("user_id", userId);
    if (likeErr) console.error("[delete-user] likes delete error:", likeErr.message);

    // STEP 6: Delete notifications
    const { error: notifErr } = await adminClient
      .from("user_notifications")
      .delete()
      .eq("user_id", userId);
    if (notifErr) console.error("[delete-user] notifications delete error:", notifErr.message);

    // STEP 7: Delete CMS portal user (by email lookup)
    const { data: profile } = await adminClient
      .from("auth_user_profiles")
      .select("email")
      .eq("auth_user_id", userId)
      .maybeSingle();

    if (profile?.email) {
      const { error: cmsErr } = await adminClient
        .from("cms_portal_users")
        .delete()
        .eq("email", profile.email);
      if (cmsErr) console.error("[delete-user] cms portal user delete error:", cmsErr.message);
    }

    // STEP 8: Delete profile
    const { error: profileErr } = await adminClient
      .from("auth_user_profiles")
      .delete()
      .eq("auth_user_id", userId);
    if (profileErr) console.error("[delete-user] profile delete error:", profileErr.message);

    // STEP 9: Delete auth account from auth.users
    const { error: authErr } = await adminClient.auth.admin.deleteUser(userId);
    if (authErr) {
      console.error("[delete-user] auth delete error:", authErr.message);
      return new Response(
        JSON.stringify({ error: `Failed to delete auth account: ${authErr.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[delete-user] Successfully deleted user ${userId}`);

    return new Response(
      JSON.stringify({ success: true, message: "User fully deleted" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("[delete-user] Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// Minimal Supabase client using fetch — avoids needing the npm package in Deno
function createSupabaseClient(url: string, key: string) {
  const baseUrl = url.replace(/\/$/, "");
  const headers: Record<string, string> = {
    "apikey": key,
    "Authorization": `Bearer ${key}`,
    "Content-Type": "application/json",
  };

  const auth = {
    async getUser() {
      const res = await fetch(`${baseUrl}/auth/v1/user`, { headers });
      const data = await res.json();
      if (!res.ok) return { data: { user: null }, error: new Error(data.message) };
      return { data, error: null };
    },
    admin: {
      async deleteUser(uid: string) {
        const res = await fetch(`${baseUrl}/auth/v1/admin/users/${uid}`, {
          method: "DELETE",
          headers,
        });
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          return { error: new Error(data.msg || data.message || `HTTP ${res.status}`) };
        }
        return { error: null };
      },
    },
  };

  function from(table: string) {
    return {
      select(columns: string) {
        return {
          eq(column: string, value: string) {
            return {
              maybeSingle() {
                return fetchSingle(`${baseUrl}/rest/v1/${table}?select=${columns}&${column}=eq.${encodeURIComponent(value)}`);
              },
            };
          },
        };
      },
      delete() {
        return {
          eq(column: string, value: string) {
            return fetchVoid(`${baseUrl}/rest/v1/${table}?${column}=eq.${encodeURIComponent(value)}`, "DELETE");
          },
        };
      },
      insert(payload: any) {
        return {
          select() {
            return {
              single() {
                return fetchSingle(`${baseUrl}/rest/v1/${table}`, "POST", payload);
              },
            };
          },
        };
      },
    };
  }

  async function fetchSingle(url: string, method = "GET", body?: any) {
    const res = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) return { data: null, error: { message: data?.message || `HTTP ${res.status}` } };
    return { data, error: null };
  }

  async function fetchVoid(url: string, method: string) {
    const res = await fetch(url, { method, headers });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      return { error: { message: data?.message || `HTTP ${res.status}` } };
    }
    return { error: null };
  }

  return { auth, from };
}
