import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { ErrorBoundary } from '@/components/error-boundary';
import { AuthProvider, useAuth } from '@/contexts/auth';
import { roleRoutes } from '@/types/auth';
import { DashboardGuard } from '@/guards/protected-route';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import Home from '@/pages/home-new';
import About from '@/pages/about';
import Team from '@/pages/team';
import Gallery from '@/pages/gallery';
import Contact from '@/pages/contact';
import Login from '@/pages/auth/login';
import ForgotPassword from '@/pages/auth/forgot-password';
import ResetPassword from '@/pages/auth/reset-password';
import Register from '@/pages/auth/register';
import ChangePassword from '@/pages/auth/change-password';
import Unauthorized from '@/pages/auth/unauthorized';
import SessionExpired from '@/pages/auth/session-expired';
import SuperAdminOverview from '@/pages/dashboard/super-admin/overview';
import SuperAdminTeam from '@/pages/dashboard/super-admin/team';
import SuperAdminGallery from '@/pages/dashboard/super-admin/gallery';
import SuperAdminAnnouncements from '@/pages/dashboard/super-admin/announcements';
import SuperAdminHomepageCMS from '@/pages/dashboard/super-admin/cms/homepage';
import SuperAdminAboutCMS from '@/pages/dashboard/super-admin/cms/about';
import SuperAdminContactCMS from '@/pages/dashboard/super-admin/cms/contact';
import SuperAdminCollegeCMS from '@/pages/dashboard/super-admin/cms/college';
import SuperAdminUsers from '@/pages/dashboard/super-admin/users';
import SuperAdminSettings from '@/pages/dashboard/super-admin/settings';
import SuperAdminRoles from '@/pages/dashboard/super-admin/roles';
import SuperAdminEventsPage from '@/pages/dashboard/super-admin/events/index';
import SuperAdminEventFormPage from '@/pages/dashboard/super-admin/events/form';
import EventAnalyticsPage from '@/pages/dashboard/super-admin/events/analytics';
import SuperAdminNotifications from '@/pages/dashboard/super-admin/notifications';
import SuperAdminAttendance from '@/pages/dashboard/super-admin/attendance';
import SuperAdminAttendanceReports from '@/pages/dashboard/super-admin/attendance-reports';
import SuperAdminRegistrationManagement from '@/pages/dashboard/super-admin/registration-management';
import SuperAdminTicketTemplates from '@/pages/dashboard/super-admin/ticket-templates';
import SuperAdminCertificateTemplates from '@/pages/dashboard/super-admin/certificate-templates';
import SuperAdminCertificates from '@/pages/dashboard/super-admin/certificates';
import TicketViewPage from '@/pages/ticket-view';
import CertificateVerifyPage from '@/pages/verify-certificate';
import AdminOverview from '@/pages/dashboard/admin/overview';
import AdminEventsPage from '@/pages/dashboard/admin/events/index';
import AdminEventFormPage from '@/pages/dashboard/admin/events/form';
import StudentEventsPage from '@/pages/dashboard/student/events';
import EventsPage from '@/pages/events/index-new';
import EventDetailPage from '@/pages/events/detail-new';
import FacultyDashboard from '@/pages/dashboard/faculty/index';
import CEODashboard from '@/pages/dashboard/ceo/index';
import ProgramOfficerDashboard from '@/pages/dashboard/program-officer/index';
import ExecutiveDashboard from '@/pages/dashboard/executive/index';
import StudentDashboard from '@/pages/dashboard/student/index';
import StudentMyEventsPage from '@/pages/dashboard/student/my-events';
import StudentMyCertificatesPage from '@/pages/dashboard/student/my-certificates';
import StudentRegistrationsPage from '@/pages/dashboard/student/my-registrations';
import NotificationCenter from '@/pages/notifications';
import ProfilePage from '@/pages/profile';
import SplashScreen from '@/components/pwa/splash-screen';
import InstallPrompt from '@/components/pwa/install-prompt';
import MobileBottomNav from '@/components/pwa/mobile-bottom-nav';

function DashboardRedirect() {
  const { user, isLoading } = useAuth();
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  const route = roleRoutes[user.role];
  console.log('[DashboardRedirect] redirecting to', route, 'for role', user.role);
  return <Navigate to={route} replace />;
}

function App() {
  return (
    <ErrorBoundary>
    <SplashScreen />
    <ThemeProvider defaultTheme="dark" storageKey="innotex-theme">
      <AuthProvider>
        <Router>
          <Routes>
            {/* Auth Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/change-password" element={<ChangePassword />} />
            <Route path="/unauthorized" element={<Unauthorized />} />
            <Route path="/session-expired" element={<SessionExpired />} />
            <Route path="/verify-certificate/:certificateNumber" element={<CertificateVerifyPage />} />

            {/* Super Admin Dashboard Routes */}
            <Route path="/dashboard/super-admin" element={<DashboardGuard requiredRole="super_admin"><SuperAdminOverview /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/team" element={<DashboardGuard requiredRole="super_admin"><SuperAdminTeam /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/gallery" element={<DashboardGuard requiredRole="super_admin"><SuperAdminGallery /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/announcements" element={<DashboardGuard requiredRole="super_admin"><SuperAdminAnnouncements /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/cms/homepage" element={<DashboardGuard requiredRole="super_admin"><SuperAdminHomepageCMS /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/users" element={<DashboardGuard requiredRole="super_admin"><SuperAdminUsers /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/registrations" element={<DashboardGuard requiredRole="super_admin"><SuperAdminRegistrationManagement /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/roles" element={<DashboardGuard requiredRole="super_admin"><SuperAdminRoles /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/settings" element={<DashboardGuard requiredRole="super_admin"><SuperAdminSettings /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/cms/about" element={<DashboardGuard requiredRole="super_admin"><SuperAdminAboutCMS /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/cms/contact" element={<DashboardGuard requiredRole="super_admin"><SuperAdminContactCMS /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/cms/footer" element={<DashboardGuard requiredRole="super_admin"><SuperAdminOverview /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/cms/college" element={<DashboardGuard requiredRole="super_admin"><SuperAdminCollegeCMS /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/roles" element={<DashboardGuard requiredRole="super_admin"><SuperAdminOverview /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/branding" element={<DashboardGuard requiredRole="super_admin"><SuperAdminSettings /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/events" element={<DashboardGuard requiredRole="super_admin"><SuperAdminEventsPage /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/events/create" element={<DashboardGuard requiredRole="super_admin"><SuperAdminEventFormPage mode="create" /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/events/:id/edit" element={<DashboardGuard requiredRole="super_admin"><SuperAdminEventFormPage mode="edit" /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/events/analytics" element={<DashboardGuard requiredRole="super_admin"><EventAnalyticsPage /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/notifications" element={<DashboardGuard requiredRole="super_admin"><SuperAdminNotifications /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/events/:eventId/attendance" element={<DashboardGuard requiredRole="super_admin"><SuperAdminAttendance /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/attendance-reports" element={<DashboardGuard requiredRole="super_admin"><SuperAdminAttendanceReports /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/ticket-templates" element={<DashboardGuard requiredRole="super_admin"><SuperAdminTicketTemplates /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/certificate-templates" element={<DashboardGuard requiredRole="super_admin"><SuperAdminCertificateTemplates /></DashboardGuard>} />
            <Route path="/dashboard/super-admin/certificates" element={<DashboardGuard requiredRole="super_admin"><SuperAdminCertificates /></DashboardGuard>} />

            {/* Admin Dashboard Routes */}
            <Route path="/dashboard/admin" element={<DashboardGuard requiredRole="super_admin"><AdminOverview /></DashboardGuard>} />
            <Route path="/dashboard/admin/team" element={<DashboardGuard requiredRole="super_admin"><SuperAdminTeam /></DashboardGuard>} />
            <Route path="/dashboard/admin/gallery" element={<DashboardGuard requiredRole="super_admin"><SuperAdminGallery /></DashboardGuard>} />
            <Route path="/dashboard/admin/announcements" element={<DashboardGuard requiredRole="super_admin"><SuperAdminAnnouncements /></DashboardGuard>} />
            <Route path="/dashboard/admin/homepage" element={<DashboardGuard requiredRole="super_admin"><SuperAdminHomepageCMS /></DashboardGuard>} />
            <Route path="/dashboard/admin/contact" element={<DashboardGuard requiredRole="super_admin"><SuperAdminContactCMS /></DashboardGuard>} />
            <Route path="/dashboard/admin/media" element={<DashboardGuard requiredRole="super_admin"><SuperAdminGallery /></DashboardGuard>} />
            <Route path="/dashboard/admin/events" element={<DashboardGuard requiredRole="admin"><AdminEventsPage /></DashboardGuard>} />
            <Route path="/dashboard/admin/events/create" element={<DashboardGuard requiredRole="admin"><AdminEventFormPage mode="create" /></DashboardGuard>} />
            <Route path="/dashboard/admin/events/:id/edit" element={<DashboardGuard requiredRole="admin"><AdminEventFormPage mode="edit" /></DashboardGuard>} />

            {/* Faculty Dashboard Routes */}
            <Route path="/dashboard/faculty" element={<DashboardGuard requiredRole="faculty"><FacultyDashboard /></DashboardGuard>} />
            <Route path="/dashboard/faculty/announcements" element={<DashboardGuard requiredRole="faculty"><FacultyDashboard /></DashboardGuard>} />
            <Route path="/dashboard/faculty/events" element={<DashboardGuard requiredRole="faculty"><FacultyDashboard /></DashboardGuard>} />
            <Route path="/dashboard/faculty/resources" element={<DashboardGuard requiredRole="faculty"><FacultyDashboard /></DashboardGuard>} />
            <Route path="/dashboard/faculty/reports" element={<DashboardGuard requiredRole="faculty"><FacultyDashboard /></DashboardGuard>} />

            {/* CEO Dashboard Routes */}
            <Route path="/dashboard/ceo" element={<DashboardGuard requiredRole="ceo"><CEODashboard /></DashboardGuard>} />
            <Route path="/dashboard/ceo/performance" element={<DashboardGuard requiredRole="ceo"><CEODashboard /></DashboardGuard>} />
            <Route path="/dashboard/ceo/strategy" element={<DashboardGuard requiredRole="ceo"><CEODashboard /></DashboardGuard>} />
            <Route path="/dashboard/ceo/organization" element={<DashboardGuard requiredRole="ceo"><CEODashboard /></DashboardGuard>} />
            <Route path="/dashboard/ceo/reports" element={<DashboardGuard requiredRole="ceo"><CEODashboard /></DashboardGuard>} />

            {/* Program Officer Dashboard Routes */}
            <Route path="/dashboard/program-officer" element={<DashboardGuard requiredRole="program_officer"><ProgramOfficerDashboard /></DashboardGuard>} />
            <Route path="/dashboard/program-officer/tasks" element={<DashboardGuard requiredRole="program_officer"><ProgramOfficerDashboard /></DashboardGuard>} />
            <Route path="/dashboard/program-officer/activities" element={<DashboardGuard requiredRole="program_officer"><ProgramOfficerDashboard /></DashboardGuard>} />
            <Route path="/dashboard/program-officer/statistics" element={<DashboardGuard requiredRole="program_officer"><ProgramOfficerDashboard /></DashboardGuard>} />
            <Route path="/dashboard/program-officer/calendar" element={<DashboardGuard requiredRole="program_officer"><ProgramOfficerDashboard /></DashboardGuard>} />

            {/* Executive Dashboard Routes */}
            <Route path="/dashboard/executive" element={<DashboardGuard requiredRole="executive"><ExecutiveDashboard /></DashboardGuard>} />
            <Route path="/dashboard/executive/tasks" element={<DashboardGuard requiredRole="executive"><ExecutiveDashboard /></DashboardGuard>} />
            <Route path="/dashboard/executive/announcements" element={<DashboardGuard requiredRole="executive"><ExecutiveDashboard /></DashboardGuard>} />
            <Route path="/dashboard/executive/resources" element={<DashboardGuard requiredRole="executive"><ExecutiveDashboard /></DashboardGuard>} />

            {/* Student Dashboard Routes */}
            <Route path="/dashboard/student" element={<DashboardGuard requiredRole="student"><StudentDashboard /></DashboardGuard>} />
            <Route path="/dashboard/student/profile" element={<DashboardGuard requiredRole="student"><StudentDashboard /></DashboardGuard>} />
            <Route path="/dashboard/student/announcements" element={<DashboardGuard requiredRole="student"><StudentDashboard /></DashboardGuard>} />
            <Route path="/dashboard/student/resources" element={<DashboardGuard requiredRole="student"><StudentDashboard /></DashboardGuard>} />
            <Route path="/dashboard/student/links" element={<DashboardGuard requiredRole="student"><StudentDashboard /></DashboardGuard>} />
            <Route path="/dashboard/student/events" element={<DashboardGuard requiredRole="student"><StudentEventsPage /></DashboardGuard>} />
            <Route path="/dashboard/student/my-events" element={<DashboardGuard requiredRole="student"><StudentMyEventsPage /></DashboardGuard>} />
            <Route path="/dashboard/student/my-certificates" element={<DashboardGuard requiredRole="student"><StudentMyCertificatesPage /></DashboardGuard>} />
            <Route path="/dashboard/student/my-registrations" element={<DashboardGuard requiredRole="student"><StudentRegistrationsPage /></DashboardGuard>} />

            {/* Profile Route — accessible to all authenticated users */}
            <Route path="/profile" element={<ProfilePage />} />

            {/* Dashboard root — redirects to role-based dashboard */}
            <Route path="/dashboard" element={<DashboardRedirect />} />

            {/* Redirect old dashboard routes */}
            <Route path="/super-admin/dashboard" element={<Navigate to="/dashboard/super-admin" replace />} />
            <Route path="/faculty/dashboard" element={<Navigate to="/dashboard/faculty" replace />} />
            <Route path="/ceo/dashboard" element={<Navigate to="/dashboard/ceo" replace />} />
            <Route path="/program-officer/dashboard" element={<Navigate to="/dashboard/program-officer" replace />} />
            <Route path="/executive/dashboard" element={<Navigate to="/dashboard/executive" replace />} />
            <Route path="/student/dashboard" element={<Navigate to="/dashboard/student" replace />} />

            {/* Public Routes */}
            <Route
              path="/*"
              element={
                <div className="min-h-screen flex flex-col">
                  <Navbar />
                  <main className="flex-1">
                    <Routes>
                      <Route path="/" element={<Home />} />
                      <Route path="/about" element={<About />} />
                      <Route path="/team" element={<Team />} />
                      <Route path="/gallery" element={<Gallery />} />
                      <Route path="/contact" element={<Contact />} />
                      <Route path="/notifications" element={<NotificationCenter />} />
                      <Route path="/ticket/:qrCode" element={<TicketViewPage />} />
                      <Route path="/events" element={<EventsPage />} />
                      <Route path="/events/:id" element={<EventDetailPage />} />
                    </Routes>
                  </main>
                  <Footer />
                </div>
              }
            />
          </Routes>
          <MobileBottomNav />
          <InstallPrompt />
        </Router>
      </AuthProvider>
    </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
