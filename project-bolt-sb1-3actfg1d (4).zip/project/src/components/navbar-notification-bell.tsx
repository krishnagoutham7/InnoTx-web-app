import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X, CheckCheck, Calendar, Users, Award, Megaphone, Ticket, CheckCircle, UserCheck, UserX, KeyRound, Sparkles } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useNotifications } from '@/hooks/use-notifications';
import { requestNotificationPermission } from '@/lib/notification-utils';
import { cn } from '@/lib/utils';

const typeIcons: Record<string, React.ElementType> = {
  event_alert: Calendar,
  event_published: Calendar,
  meeting_alert: Users,
  certificate_available: Award,
  certificate_generated: Award,
  announcement: Megaphone,
  registration_submitted: UserCheck,
  registration_approved: CheckCircle,
  registration_rejected: UserX,
  ticket_generated: Ticket,
  attendance_verified: CheckCircle,
  role_changed: Users,
  password_reset: KeyRound,
  custom: Bell,
};

const typeColors: Record<string, string> = {
  event_alert: 'text-blue-500 bg-blue-500/10',
  event_published: 'text-blue-500 bg-blue-500/10',
  meeting_alert: 'text-purple-500 bg-purple-500/10',
  certificate_available: 'text-amber-500 bg-amber-500/10',
  certificate_generated: 'text-amber-500 bg-amber-500/10',
  announcement: 'text-cyan-500 bg-cyan-500/10',
  registration_submitted: 'text-sky-500 bg-sky-500/10',
  registration_approved: 'text-green-500 bg-green-500/10',
  registration_rejected: 'text-red-500 bg-red-500/10',
  ticket_generated: 'text-indigo-500 bg-indigo-500/10',
  attendance_verified: 'text-emerald-500 bg-emerald-500/10',
  role_changed: 'text-orange-500 bg-orange-500/10',
  password_reset: 'text-pink-500 bg-pink-500/10',
  custom: 'text-muted-foreground bg-muted',
};

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

export default function NavbarNotificationBell() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { notifications, unreadCount, loading, markAsRead, markAllRead } = useNotifications();

  useEffect(() => {
    requestNotificationPermission();
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleNotificationClick(notif: any) {
    markAsRead(notif.id);
    const actionUrl = notif.notification?.action_url;
    if (actionUrl) {
      navigate(actionUrl);
      setOpen(false);
    }
  }

  const unread = notifications.filter(n => !n.is_read);
  const read = notifications.filter(n => n.is_read);

  return (
    <div className="relative" ref={dropdownRef}>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(!open)}
        className={cn(
          'relative w-10 h-10 flex items-center justify-center rounded-xl transition-colors',
          open ? 'bg-primary/10' : 'hover:bg-muted'
        )}
      >
        <Bell className={cn('w-5 h-5 transition-colors', open ? 'text-primary' : 'text-muted-foreground')} />
        <AnimatePresence>
          {unreadCount > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className={cn(
                'absolute -top-1 -right-1 min-w-5 h-5 flex items-center justify-center rounded-full',
                'bg-gradient-to-r from-primary to-accent text-white text-xs font-bold',
                'shadow-lg shadow-primary/30'
              )}
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </motion.div>
          )}
        </AnimatePresence>
        {unreadCount > 0 && (
          <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary/50 animate-ping" />
        )}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className={cn(
              'absolute right-0 top-full mt-2 w-80 sm:w-96 overflow-hidden',
              'rounded-2xl border bg-card shadow-2xl'
            )}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Bell className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Notifications</h3>
                  {unreadCount > 0 && <p className="text-xs text-muted-foreground">{unreadCount} unread</p>}
                </div>
              </div>
              <div className="flex items-center gap-1">
                {unreadCount > 0 && (
                  <button onClick={markAllRead} className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-primary hover:bg-primary/10">
                    <CheckCheck className="w-3.5 h-3.5" /> Mark all
                  </button>
                )}
                <button onClick={() => setOpen(false)} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-muted">
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>

            <ScrollArea className="max-h-[400px]">
              {loading ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="w-12 h-12 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
                  <p className="text-sm text-muted-foreground mt-3">Loading...</p>
                </div>
              ) : notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-3">
                    <Bell className="w-8 h-8 opacity-30" />
                  </div>
                  <p className="font-medium">All caught up!</p>
                  <p className="text-xs mt-1">No new notifications</p>
                </div>
              ) : (
                <div className="p-2">
                  {unread.map((un, i) => {
                    const Icon = typeIcons[un.notification?.notification_type || 'custom'] || Bell;
                    const colorClass = typeColors[un.notification?.notification_type || 'custom'];
                    return (
                      <motion.div
                        key={un.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        onClick={() => handleNotificationClick(un)}
                        className="group relative mb-1 p-3 rounded-xl cursor-pointer hover:bg-muted/50 transition-all bg-primary/5"
                      >
                        <div className="flex gap-3">
                          <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0', colorClass)}>
                            <Icon className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm line-clamp-1">{un.notification?.title}</p>
                            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{un.notification?.message}</p>
                            <p className="text-[10px] text-muted-foreground/60 mt-1">{timeAgo(un.created_at)}</p>
                          </div>
                          <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 self-start mt-2 animate-pulse" />
                        </div>
                      </motion.div>
                    );
                  })}

                  {read.length > 0 && unread.length > 0 && (
                    <div className="flex items-center gap-2 px-3 py-2">
                      <div className="flex-1 h-px bg-border" />
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Earlier</span>
                      <div className="flex-1 h-px bg-border" />
                    </div>
                  )}

                  {read.slice(0, 5).map((un) => {
                    const Icon = typeIcons[un.notification?.notification_type || 'custom'] || Bell;
                    const colorClass = typeColors[un.notification?.notification_type || 'custom'];
                    return (
                      <div
                        key={un.id}
                        onClick={() => handleNotificationClick(un)}
                        className="group relative mb-1 p-3 rounded-xl cursor-pointer opacity-60 hover:opacity-100 transition-opacity"
                      >
                        <div className="flex gap-3">
                          <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0', colorClass)}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm line-clamp-1">{un.notification?.title}</p>
                            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{un.notification?.message}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </ScrollArea>

            <div className="p-3 border-t">
              <button
                onClick={() => { setOpen(false); navigate('/notifications'); }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-primary/10 hover:bg-primary/20 text-sm font-medium transition-all"
              >
                <Sparkles className="w-4 h-4 text-primary" />
                View all notifications
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
