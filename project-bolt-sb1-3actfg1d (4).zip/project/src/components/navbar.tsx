import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Sun, Moon, Lightbulb, LogOut, User, LayoutDashboard, GraduationCap } from 'lucide-react';
import NavbarNotificationBell from '@/components/navbar-notification-bell';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/components/theme-provider';
import { useAuth, roleRoutes } from '@/contexts/auth';
import { cn } from '@/lib/utils';
import { getCollegeInfo } from '@/services/cms';
import type { CollegeInfo } from '@/services/cms';
import { roleLabels } from '@/types/auth';

const publicLinks = [
  { path: '/', label: 'Home' },
  { path: '/about', label: 'About' },
  { path: '/events', label: 'Events' },
  { path: '/team', label: 'Team' },
  { path: '/gallery', label: 'Gallery' },
  { path: '/contact', label: 'Contact' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [college, setCollege] = useState<CollegeInfo | null>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const { user, isAuthenticated, logout } = useAuth();

  useEffect(() => {
    getCollegeInfo().then(d => { if (d) setCollege(d); }).catch(() => {});
  }, []);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleDashboard = () => {
    if (user) {
      navigate(roleRoutes[user.role]);
    }
  };

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        scrolled ? 'glass shadow-lg' : 'bg-transparent'
      )}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-shadow">
              <Lightbulb className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold leading-tight tracking-tight">
                {college?.portal_name || 'InnoTex'}
              </span>
              <span className="text-[10px] leading-tight text-muted-foreground tracking-wide">
                {college?.short_name || ''}
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {!isAuthenticated ? (
              // Public Navigation
              publicLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    'px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200',
                    location.pathname === link.path
                      ? 'text-primary bg-primary/10'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  )}
                >
                  {link.label}
                </Link>
              ))
            ) : (
              // Authenticated Navigation
              <>
                <Button
                  onClick={handleDashboard}
                  variant="ghost"
                  className="gap-2 text-sm font-medium"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </Button>
                <NavbarNotificationBell />
                <Link to="/profile">
                  <div className={cn(
                    'ml-3 flex items-center gap-2 px-3 py-1.5 rounded-lg cursor-pointer transition-colors',
                    location.pathname === '/profile' ? 'bg-primary/20 ring-1 ring-primary/30' : 'bg-primary/10 hover:bg-primary/20'
                  )}>
                    <User className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium">{user?.name}</span>
                    <span className="text-xs text-muted-foreground">({user ? roleLabels[user.role] : ''})</span>
                  </div>
                </Link>
              </>
            )}

            <div className="ml-3 h-5 w-px bg-border" />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="ml-2"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>

            {!isAuthenticated ? (
              <Link to="/login" className="ml-2">
                <Button
                  size="sm"
                  className="bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20"
                >
                  Sign In
                </Button>
              </Link>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="ml-2 text-muted-foreground hover:text-destructive"
              >
                <LogOut className="w-4 w-4" />
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            >
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 h-5" />}
            </Button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden glass border-t"
          >
            <div className="px-4 py-4 space-y-1">
              {!isAuthenticated ? (
                publicLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={cn(
                      'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors',
                      location.pathname === link.path
                        ? 'text-primary bg-primary/10'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                    )}
                  >
                    {link.label}
                  </Link>
                ))
              ) : (
                <>
                  <Button
                    onClick={handleDashboard}
                    variant="ghost"
                    className="w-full justify-start gap-3 px-4 py-3"
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    Dashboard
                  </Button>
                  <Link to="/profile" className={cn(
                    'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors',
                    location.pathname === '/profile'
                      ? 'text-primary bg-primary/10'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  )}>
                    <User className="w-4 h-4" />
                    My Profile
                    <span className="text-xs text-muted-foreground ml-auto">({user ? roleLabels[user.role] : ''})</span>
                  </Link>
                </>
              )}

              <div className="pt-2 border-t mt-2">
                {!isAuthenticated ? (
                  <Link to="/login" className="block px-4 py-3">
                    <Button className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90">
                      Sign In
                    </Button>
                  </Link>
                ) : (
                  <Button
                    variant="ghost"
                    onClick={handleLogout}
                    className="w-full justify-start gap-3 px-4 py-3 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </Button>
                )}
              </div>

              <div className="pt-2 px-4">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <GraduationCap className="w-3 h-3" />
                  <span>{college?.short_name || ''}</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
