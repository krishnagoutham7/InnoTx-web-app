import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, Calendar, Ticket, Award, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/auth';

interface BottomNavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
  badge?: number;
}

export function BottomNavigation() {
  const location = useLocation();
  const { user } = useAuth();

  const items: BottomNavItem[] = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      href: user ? '/dashboard' : '/',
    },
    {
      id: 'events',
      label: 'Events',
      icon: Calendar,
      href: '/events',
    },
    {
      id: 'tickets',
      label: 'Tickets',
      icon: Ticket,
      href: '/dashboard/student/events',
    },
    {
      id: 'certificates',
      label: 'Certificates',
      icon: Award,
      href: '/dashboard/student/my-registrations',
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: User,
      href: '/dashboard/profile',
    },
  ];

  return (
    <nav
      className={cn(
        'fixed bottom-0 left-0 right-0 z-50',
        'md:hidden', // Only show on mobile
        'border-t border-white/5',
        'bg-gradient-to-t from-background via-background/95 to-background/80',
        'backdrop-blur-2xl',
        'safe-area-inset-bottom'
      )}
    >
      <div className="flex items-center justify-around px-2 py-2">
        {items.map((item) => {
          const isActive = location.pathname === item.href ||
            (item.href !== '/' && location.pathname.startsWith(item.href));
          const Icon = item.icon;

          return (
            <Link
              key={item.id}
              to={item.href}
              className="relative flex flex-col items-center justify-center w-16 py-2"
            >
              <div
                className={cn(
                  'relative w-12 h-12 rounded-xl flex items-center justify-center',
                  'transition-all duration-300',
                  isActive
                    ? 'bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20'
                    : 'hover:bg-white/5'
                )}
              >
                <Icon
                  className={cn(
                    'w-5 h-5 transition-colors',
                    isActive ? 'text-primary' : 'text-muted-foreground'
                  )}
                />

                {/* Active indicator */}
                {isActive && (
                  <motion.div
                    layoutId="bottomNav"
                    className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-6 h-1 rounded-full bg-gradient-to-r from-primary to-accent"
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  />
                )}

                {/* Badge */}
                {item.badge && item.badge > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-destructive text-[10px] text-white flex items-center justify-center font-bold">
                    {item.badge > 9 ? '9+' : item.badge}
                  </span>
                )}
              </div>

              <span
                className={cn(
                  'text-[10px] font-medium mt-1 transition-colors',
                  isActive ? 'text-primary' : 'text-muted-foreground'
                )}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

// Desktop sidebar quick navigation
export function QuickNavigation() {
  const location = useLocation();

  const items = [
    { id: 'home', label: 'Home', icon: Home, href: '/' },
    { id: 'events', label: 'Events', icon: Calendar, href: '/events' },
  ];

  return (
    <div className="hidden md:flex items-center gap-1">
      {items.map((item) => {
        const isActive = location.pathname === item.href;
        const Icon = item.icon;

        return (
          <Link
            key={item.id}
            to={item.href}
            className={cn(
              'flex items-center gap-2 px-3 py-2 rounded-xl transition-all',
              isActive
                ? 'bg-primary/10 text-primary'
                : 'hover:bg-white/5 text-muted-foreground hover:text-foreground'
            )}
          >
            <Icon className="w-4 h-4" />
            <span className="text-sm">{item.label}</span>
          </Link>
        );
      })}
    </div>
  );
}
