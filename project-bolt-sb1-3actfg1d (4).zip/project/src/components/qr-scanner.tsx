import { useEffect, useRef, useState, useCallback } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats, CameraDevice } from 'html5-qrcode';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Camera,
  CameraOff,
  RefreshCw,
  AlertTriangle,
  Scan,
  SwitchCamera,
  Video,
  VideoOff,
} from 'lucide-react';

interface QRScannerProps {
  onScan: (qrCode: string) => void;
  isScanningEnabled: boolean;
}

type ScannerState = 'idle' | 'checking_permission' | 'requesting_permission' | 'starting' | 'scanning' | 'success' | 'error';

interface ScannerError {
  type: 'permission_denied' | 'permission_blocked' | 'not_found' | 'not_readable' | 'overconstrained' | 'insecure' | 'unknown';
  message: string;
}

const SCANNER_ID = 'qr-scanner-container';

export default function QRScanner({ onScan, isScanningEnabled }: QRScannerProps) {
  const [state, setState] = useState<ScannerState>('idle');
  const [error, setError] = useState<ScannerError | null>(null);
  const [cameras, setCameras] = useState<CameraDevice[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const lastScannedRef = useRef<string>('');
  const lastScannedTimeRef = useRef<number>(0);
  const isStartingRef = useRef(false);

  // Enumerate available cameras
  const enumerateCameras = useCallback(async (): Promise<CameraDevice[]> => {
    try {
      const devices = await Html5Qrcode.getCameras();
      if (devices && devices.length > 0) {
        setCameras(devices);
        // Prefer rear camera on mobile
        const rearCamera = devices.find(
          d => d.label.toLowerCase().includes('back') ||
               d.label.toLowerCase().includes('rear') ||
               d.label.toLowerCase().includes('environment') ||
               d.label.toLowerCase().includes('后置')
        );
        const defaultCamera = rearCamera?.id || devices[0]?.id;
        if (defaultCamera) {
          setSelectedCameraId(defaultCamera);
        }
        return devices;
      }
      return [];
    } catch (err) {
      console.error('Failed to enumerate cameras:', err);
      return [];
    }
  }, []);

  // Get friendly camera name
  const getCameraLabel = (device: CameraDevice): string => {
    const label = device.label.toLowerCase();
    if (label.includes('back') || label.includes('rear') || label.includes('environment')) {
      return 'Rear Camera';
    }
    if (label.includes('front') || label.includes('user') || label.includes('face')) {
      return 'Front Camera';
    }
    if (label.includes('ultra') || label.includes('wide')) {
      return 'Wide Camera';
    }
    if (label.includes('external') || label.includes('usb') || label.includes('webcam')) {
      return 'External Camera';
    }
    return device.label || `Camera ${cameras.indexOf(device) + 1}`;
  };

  // Check permission status before attempting to use camera
  const checkPermissionStatus = useCallback(async (): Promise<PermissionState> => {
    try {
      if ('permissions' in navigator && 'query' in navigator.permissions) {
        const result = await navigator.permissions.query({ name: 'camera' as PermissionName });
        return result.state;
      }
    } catch {
      // Permissions API not supported, will try direct access
    }
    return 'prompt';
  }, []);

  // Stop scanner safely
  const stopScanner = useCallback(async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        scannerRef.current.clear();
      } catch (err) {
        console.error('Error stopping scanner:', err);
      }
      scannerRef.current = null;
    }
    setState('idle');
    isStartingRef.current = false;
  }, []);

  // Start scanner with selected camera
  const startScanner = useCallback(async (cameraId?: string) => {
    if (!isScanningEnabled || isStartingRef.current) return;

    const container = document.getElementById(SCANNER_ID);
    if (!container) {
      console.error('Scanner container not found');
      return;
    }

    isStartingRef.current = true;
    setError(null);
    setState('checking_permission');

    try {
      // Check secure context
      const isSecure = location.protocol === 'https:' ||
                        location.hostname === 'localhost' ||
                        location.hostname === '127.0.0.1';

      if (!isSecure) {
        setError({
          type: 'insecure',
          message: 'Camera access requires a secure connection (HTTPS). Please use https:// or access via localhost.',
        });
        setState('error');
        isStartingRef.current = false;
        return;
      }

      // Check permission status
      setState('requesting_permission');
      const permStatus = await checkPermissionStatus();

      if (permStatus === 'denied') {
        setError({
          type: 'permission_blocked',
          message: 'Camera permission was previously denied. Please enable camera access in your browser settings and refresh the page.',
        });
        setState('error');
        isStartingRef.current = false;
        return;
      }

      // Enumerate cameras if not already done
      let devices = cameras;
      if (devices.length === 0) {
        devices = await enumerateCameras();
      }

      if (devices.length === 0) {
        setError({
          type: 'not_found',
          message: 'No camera found on this device. Please connect a camera and try again.',
        });
        setState('error');
        isStartingRef.current = false;
        return;
      }

      // Use provided camera or selected/default camera
      const targetCameraId = cameraId || selectedCameraId || devices[0].id;
      if (!selectedCameraId) {
        setSelectedCameraId(targetCameraId);
      }

      setState('starting');

      // Initialize scanner
      scannerRef.current = new Html5Qrcode(SCANNER_ID, {
        verbose: false,
        formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE],
      });

      // Configuration for optimal scanning
      const config = {
        fps: 10,
        qrbox: { width: 280, height: 280 },
        aspectRatio: 1.7778, // 16:9 for mobile
        disableFlip: false,
      };

      await scannerRef.current.start(
        targetCameraId,
        config,
        (decodedText) => {
          // Prevent duplicate scans within 3 seconds
          const now = Date.now();
          if (lastScannedRef.current === decodedText && now - lastScannedTimeRef.current < 3000) {
            return;
          }
          lastScannedRef.current = decodedText;
          lastScannedTimeRef.current = now;

          // Show success state
          setState('success');
          onScan(decodedText);

          // Resume scanning after 1.5 seconds
          setTimeout(() => {
            if (scannerRef.current?.isScanning) {
              setState('scanning');
            }
          }, 1500);
        },
        () => {
          // Silently ignore scan failures (no QR detected)
        }
      );

      setState('scanning');
      isStartingRef.current = false;

    } catch (err: any) {
      console.error('Scanner error:', err);
      isStartingRef.current = false;

      let scannerError: ScannerError;

      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        const perm = await checkPermissionStatus();
        if (perm === 'denied') {
          scannerError = {
            type: 'permission_blocked',
            message: 'Camera permission was denied. Please enable camera access in your browser settings.',
          };
        } else {
          scannerError = {
            type: 'permission_denied',
            message: 'Camera permission was denied. Please allow camera access to scan QR codes.',
          };
        }
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        scannerError = {
          type: 'not_found',
          message: 'No camera found on this device.',
        };
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        scannerError = {
          type: 'not_readable',
          message: 'Camera is already in use by another application. Please close other apps using the camera.',
        };
      } else if (err.name === 'OverconstrainedError' || err.name === 'ConstraintNotSatisfiedError') {
        scannerError = {
          type: 'overconstrained',
          message: 'Camera does not support required features. Try a different camera.',
        };
      } else {
        scannerError = {
          type: 'unknown',
          message: err.message || 'An unexpected error occurred while accessing the camera.',
        };
      }

      setError(scannerError);
      setState('error');

      // Cleanup
      if (scannerRef.current) {
        try {
          scannerRef.current.clear();
        } catch {}
        scannerRef.current = null;
      }
    }
  }, [isScanningEnabled, cameras, selectedCameraId, checkPermissionStatus, enumerateCameras, onScan]);

  // Switch to next camera
  const switchCamera = useCallback(async () => {
    if (cameras.length <= 1) return;

    const currentIndex = cameras.findIndex(c => c.id === selectedCameraId);
    const nextIndex = (currentIndex + 1) % cameras.length;
    const nextCamera = cameras[nextIndex];

    if (scannerRef.current?.isScanning) {
      // Stop current scanner
      await scannerRef.current.stop();
      scannerRef.current.clear();
      scannerRef.current = null;
    }

    setSelectedCameraId(nextCamera.id);

    // Start with new camera after a brief delay
    setTimeout(() => {
      startScanner(nextCamera.id);
    }, 100);
  }, [cameras, selectedCameraId, startScanner]);

  // Select specific camera
  const handleCameraSelect = useCallback(async (cameraId: string) => {
    if (scannerRef.current?.isScanning) {
      await scannerRef.current.stop();
      scannerRef.current.clear();
      scannerRef.current = null;
    }

    setSelectedCameraId(cameraId);
    setTimeout(() => {
      startScanner(cameraId);
    }, 100);
  }, [startScanner]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        if (scannerRef.current.isScanning) {
          scannerRef.current.stop().catch(() => {});
        }
        scannerRef.current.clear();
      }
    };
  }, []);

  // Stop scanner when scanning is disabled externally
  useEffect(() => {
    if (!isScanningEnabled && state === 'scanning') {
      stopScanner();
    }
  }, [isScanningEnabled, state, stopScanner]);

  // Enumerate cameras on mount
  useEffect(() => {
    enumerateCameras();
  }, [enumerateCameras]);

  const handleStartClick = () => {
    if (state === 'idle' || state === 'error') {
      startScanner();
    }
  };

  const handleRetryClick = () => {
    setError(null);
    startScanner();
  };

  return (
    <div className="space-y-4">
      {/* Status indicator */}
      <div
        className={`p-4 rounded-lg transition-colors ${
          state === 'scanning'
            ? 'bg-green-50 border border-green-200'
            : state === 'error'
            ? 'bg-red-50 border border-red-200'
            : state === 'success'
            ? 'bg-emerald-50 border border-emerald-200'
            : state === 'requesting_permission' || state === 'starting'
            ? 'bg-blue-50 border border-blue-200'
            : 'bg-muted/50 border'
        }`}
      >
        <div className="flex items-center gap-2">
          {state === 'idle' && (
            <>
              <Scan className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground">Click "Start Scanner" to begin scanning</span>
            </>
          )}
          {state === 'checking_permission' && (
            <>
              <Video className="w-4 h-4 text-blue-600" />
              <span className="text-blue-800">Checking camera availability...</span>
            </>
          )}
          {state === 'requesting_permission' && (
            <>
              <RefreshCw className="w-4 h-4 text-blue-600 animate-spin" />
              <span className="text-blue-800 font-medium">Requesting camera permission...</span>
            </>
          )}
          {state === 'starting' && (
            <>
              <Video className="w-4 h-4 text-blue-600 animate-pulse" />
              <span className="text-blue-800">Starting camera...</span>
            </>
          )}
          {state === 'scanning' && (
            <>
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
              <span className="text-green-800 font-medium">Scanner active - Point camera at QR code</span>
            </>
          )}
          {state === 'success' && (
            <>
              <RefreshCw className="w-4 h-4 text-emerald-600 animate-spin" />
              <span className="text-emerald-800 font-medium">QR code detected! Ready for next scan...</span>
            </>
          )}
          {state === 'error' && (
            <>
              <VideoOff className="w-4 h-4 text-red-600" />
              <span className="text-red-800 font-medium">Camera error</span>
            </>
          )}
        </div>
      </div>

      {/* Camera container - always rendered for scanner */}
      <div
        id={SCANNER_ID}
        className={`overflow-hidden rounded-lg border-2 transition-all ${
          state === 'scanning'
            ? 'border-green-400'
            : state === 'error'
            ? 'border-red-400'
            : 'border-muted'
        }`}
        style={{
          display: state === 'scanning' || state === 'starting' ? 'block' : 'none',
          minHeight: state === 'scanning' || state === 'starting' ? '300px' : '0',
        }}
      />

      {/* Placeholder when not scanning */}
      {state !== 'scanning' && state !== 'starting' && (
        <div className="aspect-square max-w-sm mx-auto bg-muted/50 rounded-lg border-2 border-dashed border-muted-foreground/30 flex items-center justify-center">
          <div className="text-center p-6">
            {state === 'error' ? (
              <VideoOff className="w-16 h-16 mx-auto text-red-400 mb-3" />
            ) : (
              <Camera className="w-16 h-16 mx-auto text-muted-foreground/40 mb-3" />
            )}
            <p className="text-sm text-muted-foreground">
              {state === 'error'
                ? 'Camera access failed'
                : state === 'requesting_permission'
                ? 'Please allow camera access when prompted'
                : 'Camera preview will appear here'}
            </p>
          </div>
        </div>
      )}

      {/* Error message with retry */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-red-800 font-medium">Camera Access Error</p>
              <p className="text-red-700 text-sm mt-1">{error.message}</p>
              {error.type === 'permission_denied' && (
                <p className="text-red-600 text-xs mt-2">
                  Tip: Click "Retry" to request camera access again, or check your browser settings.
                </p>
              )}
              {error.type === 'permission_blocked' && (
                <p className="text-red-600 text-xs mt-2">
                  Camera access is blocked. Go to browser settings → Privacy → Camera, and allow access for this site.
                </p>
              )}
              {error.type === 'insecure' && (
                <p className="text-red-600 text-xs mt-2">
                  Camera requires HTTPS. Access this app via https:// or localhost.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Camera selector - show when scanning or when cameras available */}
      {cameras.length > 1 && (state === 'scanning' || state === 'idle') && (
        <div className="flex items-center gap-2">
          <Select value={selectedCameraId} onValueChange={handleCameraSelect} disabled={state === 'scanning'}>
            <SelectTrigger className="flex-1">
              <Camera className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Select camera" />
            </SelectTrigger>
            <SelectContent>
              {cameras.map((device) => (
                <SelectItem key={device.id} value={device.id}>
                  {getCameraLabel(device)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Controls */}
      <div className="flex gap-2">
        {(state === 'idle' || state === 'error') && (
          <>
            <Button
              onClick={handleStartClick}
              disabled={!isScanningEnabled}
              className="flex-1"
            >
              <Camera className="w-4 h-4 mr-2" />
              Start Scanner
            </Button>
            {state === 'error' && (
              <Button onClick={handleRetryClick} variant="outline" disabled={!isScanningEnabled}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Retry
              </Button>
            )}
          </>
        )}
        {state === 'scanning' && (
          <>
            <Button onClick={stopScanner} variant="outline" className="flex-1">
              <CameraOff className="w-4 h-4 mr-2" />
              Stop Scanner
            </Button>
            {cameras.length > 1 && (
              <Button onClick={switchCamera} variant="secondary">
                <SwitchCamera className="w-4 h-4 mr-2" />
                Switch
              </Button>
            )}
          </>
        )}
      </div>

      {/* Help text */}
      {state === 'idle' && cameras.length === 0 && (
        <p className="text-xs text-muted-foreground text-center">
          No cameras detected. Connect a camera and refresh the page.
        </p>
      )}
    </div>
  );
}
