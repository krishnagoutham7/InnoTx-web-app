import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogOut, Lightbulb, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/contexts/auth';
import { roleLabels } from '@/types/auth';
import type { UserRole } from '@/types/auth';

interface DashboardLayoutProps {
  title: string;
  requiredRole: UserRole;
}

export function DashboardLayout({ title, requiredRole: _requiredRole }: DashboardLayoutProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const roleLabel = user ? roleLabels[user.role] : 'Unknown';

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
                <Lightbulb className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-lg font-bold">InnoTex</span>
                <span className="block text-xs text-muted-foreground">{title}</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{roleLabel}</p>
              </div>
              <Button variant="ghost" size="icon" className="rounded-full bg-muted">
                <User className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="glass-card border-0 shadow-lg mb-8">
            <CardContent className="pt-8 pb-8 text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-6">
                <User className="w-10 h-10 text-primary" />
              </div>
              <h1 className="text-3xl font-bold mb-2">
                Welcome, {user?.name}
              </h1>
              <p className="text-muted-foreground mb-1">
                You are logged in as <span className="text-primary font-medium">{roleLabel}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Email: {user?.email}
              </p>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: 'Quick Actions', description: 'Manage your daily tasks and activities' },
              { title: 'Recent Activity', description: 'View your recent actions and updates' },
              { title: 'Announcements', description: 'Stay updated with important news' },
            ].map((item) => (
              <Card key={item.title} className="glass-card hover:shadow-lg transition-all hover:border-primary/30">
                <CardContent className="pt-6">
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="border-t py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} InnoTex IEDC. All rights reserved.
          </p>
          <Button variant="outline" onClick={handleLogout} className="gap-2">
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>
      </footer>
    </div>
  );
}
