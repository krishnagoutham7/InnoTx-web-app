import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface TabItem {
  id: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  badge?: number;
  content: React.ReactNode;
}

interface TabbedLayoutProps {
  tabs: TabItem[];
  defaultTab?: string;
  className?: string;
  tabsListClassName?: string;
  contentClassName?: string;
}

// Animation variants for tab content
const tabContentVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 20 : -20,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction < 0 ? 20 : -20,
    opacity: 0,
  }),
};

export function TabbedLayout({
  tabs,
  defaultTab,
  className,
  tabsListClassName,
  contentClassName,
}: TabbedLayoutProps) {
  const [activeTab, setActiveTab] = useState(defaultTab || tabs[0]?.id);
  const [direction, setDirection] = useState(0);

  const handleTabChange = (tabId: string) => {
    const currentIndex = tabs.findIndex((t) => t.id === activeTab);
    const newIndex = tabs.findIndex((t) => t.id === tabId);
    setDirection(newIndex > currentIndex ? 1 : -1);
    setActiveTab(tabId);
  };

  const activeTabData = tabs.find((t) => t.id === activeTab);

  return (
    <div className={cn('flex flex-col h-full', className)}>
      {/* Tab Navigation */}
      <div
        className={cn(
          'sticky top-0 z-20 flex items-center gap-1 p-1.5 rounded-2xl',
          'bg-background/50 backdrop-blur-xl border border-white/5',
          tabsListClassName
        )}
      >
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              className={cn(
                'relative flex items-center gap-2 px-4 py-2.5 rounded-xl',
                'text-sm font-medium transition-all duration-300',
                'hover:bg-white/5',
                isActive
                  ? 'text-primary bg-gradient-to-r from-primary/15 via-primary/10 to-accent/10'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {Icon && <Icon className="w-4 h-4" />}
              <span className="hidden sm:inline">{tab.label}</span>
              {tab.badge !== undefined && tab.badge > 0 && (
                <span
                  className={cn(
                    'ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold',
                    isActive
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-white/10 text-muted-foreground'
                  )}
                >
                  {tab.badge}
                </span>
              )}

              {/* Active indicator */}
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full bg-gradient-to-r from-primary to-accent"
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className={cn('flex-1 overflow-hidden', contentClassName)}>
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={activeTab}
            custom={direction}
            variants={tabContentVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="h-full overflow-y-auto scrollbar-premium"
          >
            {activeTabData?.content}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

// Compact tabs for inline use
export function CompactTabs({
  tabs,
  defaultTab,
  onChange,
  className,
}: {
  tabs: { id: string; label: string; count?: number }[];
  defaultTab?: string;
  onChange?: (tabId: string) => void;
  className?: string;
}) {
  const [activeTab, setActiveTab] = useState(defaultTab || tabs[0]?.id);

  const handleChange = (tabId: string) => {
    setActiveTab(tabId);
    onChange?.(tabId);
  };

  return (
    <div className={cn('inline-flex rounded-xl bg-white/5 p-1', className)}>
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => handleChange(tab.id)}
          className={cn(
            'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all',
            activeTab === tab.id
              ? 'bg-gradient-to-r from-primary/20 to-accent/20 text-primary'
              : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
          )}
        >
          <span>{tab.label}</span>
          {tab.count !== undefined && (
            <span
              className={cn(
                'px-1.5 py-0.25 rounded-full text-[10px]',
                activeTab === tab.id
                  ? 'bg-primary/20'
                  : 'bg-white/10'
              )}
            >
              {tab.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

// Horizontal scrollable cards container
export function HorizontalCarousel({
  children,
  className,
  title,
  action,
}: {
  children: React.ReactNode;
  className?: string;
  title?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className={cn('space-y-3', className)}>
      {title && (
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold font-heading">{title}</h3>
          {action}
        </div>
      )}
      <div
        className={cn(
          'flex gap-4 overflow-x-auto pb-4',
          'scrollbar-premium scroll-smooth',
          'snap-x snap-mandatory'
        )}
      >
        {children}
      </div>
    </div>
  );
}

// Carousel card wrapper
export function CarouselCard({
  children,
  className,
  width = '320px',
}: {
  children: React.ReactNode;
  className?: string;
  width?: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className={cn(
        'flex-shrink-0 snap-start',
        className
      )}
      style={{ width }}
    >
      {children}
    </motion.div>
  );
}

// Split view layout
export function SplitViewLayout({
  left,
  right,
  leftWidth = '60%',
  rightWidth = '40%',
  className,
  rightSticky = true,
}: {
  left: React.ReactNode;
  right: React.ReactNode;
  leftWidth?: string;
  rightWidth?: string;
  className?: string;
  rightSticky?: boolean;
}) {
  return (
    <div className={cn('flex gap-6', className)}>
      {/* Left content */}
      <div className="flex-1 overflow-y-auto scrollbar-premium" style={{ maxWidth: leftWidth }}>
        {left}
      </div>

      {/* Right content - sticky panel */}
      <div
        className={cn(
          'flex-shrink-0',
          rightSticky && 'sticky top-0 h-[calc(100vh-8rem)] overflow-y-auto scrollbar-premium'
        )}
        style={{ width: rightWidth }}
      >
        {right}
      </div>
    </div>
  );
}

// Floating Action Button
export function FloatingActionButton({
  icon: Icon,
  onClick,
  label,
  className,
}: {
  icon: React.ComponentType<{ className?: string }>;
  onClick: () => void;
  label?: string;
  className?: string;
}) {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={cn(
        'fixed bottom-24 right-6 z-50',
        'flex items-center gap-2 px-4 py-3 rounded-2xl',
        'bg-gradient-to-r from-primary via-secondary to-accent',
        'text-white font-medium shadow-glow',
        'hover:shadow-glow-lg transition-shadow',
        className
      )}
    >
      <Icon className="w-5 h-5" />
      {label && <span className="hidden sm:inline">{label}</span>}
    </motion.button>
  );
}

// Quick action modal trigger buttons
export function QuickActionButton({
  icon: Icon,
  onClick,
  label,
  description,
  color = 'primary',
}: {
  icon: React.ComponentType<{ className?: string }>;
  onClick: () => void;
  label: string;
  description?: string;
  color?: 'primary' | 'secondary' | 'accent' | 'success';
}) {
  const colorConfig = {
    primary: 'from-primary/20 to-primary/5 hover:from-primary/30 hover:to-primary/10',
    secondary: 'from-secondary/20 to-secondary/5 hover:from-secondary/30 hover:to-secondary/10',
    accent: 'from-accent/20 to-accent/5 hover:from-accent/30 hover:to-accent/10',
    success: 'from-success/20 to-success/5 hover:from-success/30 hover:to-success/10',
  };

  const iconColorConfig = {
    primary: 'text-primary bg-primary/20',
    secondary: 'text-secondary bg-secondary/20',
    accent: 'text-accent bg-accent/20',
    success: 'text-success bg-success/20',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02, x: 4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        'w-full flex items-center gap-4 p-4 rounded-xl',
        'bg-gradient-to-r border border-white/5',
        'transition-all duration-300',
        colorConfig[color]
      )}
    >
      <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center', iconColorConfig[color])}>
        <Icon className="w-6 h-6" />
      </div>
      <div className="text-left">
        <p className="font-medium">{label}</p>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
      </div>
    </motion.button>
  );
}
