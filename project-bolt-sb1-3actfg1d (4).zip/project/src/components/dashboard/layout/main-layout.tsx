import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import Sidebar from '@/components/dashboard/sidebar/sidebar';
import DashboardHeader from '@/components/dashboard/header/header';
import { BottomNavigation } from '@/components/navigation';
import { useAuth } from '@/contexts/auth';
import { roleNavigation } from '@/types/dashboard/navigation';
import type { UserRole } from '@/types/auth';
import { cn } from '@/lib/utils';

interface DashboardLayoutProps {
  children: React.ReactNode;
  requiredRole: UserRole;
}

export default function DashboardLayout({ children, requiredRole: _requiredRole }: DashboardLayoutProps) {
  const { user } = useAuth();
  const location = useLocation();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  useEffect(() => {
    setIsMobileSidebarOpen(false);
  }, [location]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const navigation = roleNavigation[user.role] || [];

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar
          navigation={navigation}
          isCollapsed={isSidebarCollapsed}
          onToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />
      </div>

      {/* Mobile Sidebar Overlay */}
      <div className="lg:hidden">
        {isMobileSidebarOpen && (
          <div
            className="fixed inset-0 z-50 bg-black/50"
            onClick={() => setIsMobileSidebarOpen(false)}
          />
        )}
        <motion.div
          initial={{ x: -256 }}
          animate={{ x: isMobileSidebarOpen ? 0 : -256 }}
          transition={{ duration: 0.3 }}
          className="fixed left-0 top-0 z-50"
        >
          <Sidebar
            navigation={navigation}
            isCollapsed={false}
            onToggle={() => {}}
          />
        </motion.div>
      </div>

      {/* Header */}
      <DashboardHeader
        onMenuClick={() => setIsMobileSidebarOpen(true)}
        isSidebarCollapsed={isSidebarCollapsed}
      />

      {/* Main Content */}
      <main
        className={cn(
          'pt-16 min-h-screen transition-all duration-300',
          'lg:transition-all',
          isSidebarCollapsed ? 'lg:pl-[68px]' : 'lg:pl-64',
          'pb-20 md:pb-0' // Add padding for mobile bottom nav
        )}
      >
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="p-4 lg:p-6"
        >
          {children}
        </motion.div>
      </main>

      {/* Footer - Desktop only */}
      <footer
        className={cn(
          'hidden md:block border-t py-4 transition-all duration-300',
          isSidebarCollapsed ? 'lg:pl-[68px]' : 'lg:pl-64'
        )}
      >
        <div className="px-4 lg:px-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>&copy; {new Date().getFullYear()} InnoTex IEDC. All rights reserved.</span>
          <span>Government Polytechnic College Adoor</span>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}
