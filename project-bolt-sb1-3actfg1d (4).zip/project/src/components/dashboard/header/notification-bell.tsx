import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X, CheckCheck, Calendar, Users, Award, Megaphone, Sparkles } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  getUserNotifications,
  getUnreadNotificationCount,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  subscribeToUserNotifications,
  type UserNotification,
} from '@/services/cms';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

const priorityColors = {
  low: 'from-gray-500/20 to-gray-500/5',
  medium: 'from-primary/20 to-primary/5',
  high: 'from-warning/20 to-warning/5',
  critical: 'from-destructive/20 to-destructive/5',
};

const typeIcons: Record<string, React.ElementType> = {
  event_alert: Calendar,
  meeting_alert: Users,
  certificate_available: Award,
  announcement: Megaphone,
  custom: Bell,
};

const typeColors: Record<string, string> = {
  event_alert: 'text-primary bg-primary/10',
  meeting_alert: 'text-secondary bg-secondary/10',
  certificate_available: 'text-success bg-success/10',
  announcement: 'text-accent bg-accent/10',
  custom: 'text-muted-foreground bg-muted',
};

export default function NotificationBell() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<UserNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadNotifications();
    loadUnreadCount();
  }, []);

  useEffect(() => {
    if (!user) return;
    const channel = subscribeToUserNotifications(user.id, () => {
      loadNotifications();
      loadUnreadCount();
    });
    return () => {
      channel.unsubscribe();
    };
  }, [user]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  async function loadNotifications() {
    try {
      setLoading(true);
      const data = await getUserNotifications({ limit: 10 });
      setNotifications(data);
    } catch (err) {
      console.error('Failed to load notifications:', err);
    } finally {
      setLoading(false);
    }
  }

  async function loadUnreadCount() {
    try {
      const count = await getUnreadNotificationCount();
      setUnreadCount(count);
    } catch (err) {
      console.error('Failed to load unread count:', err);
    }
  }

  async function handleMarkAsRead(userNotificationId: string) {
    try {
      await markNotificationAsRead(userNotificationId);
      setNotifications((prev) =>
        prev.map((n) => (n.id === userNotificationId ? { ...n, is_read: true } : n))
      );
      setUnreadCount((prev) => Math.max(0, prev - 1));
    } catch (err) {
      console.error('Failed to mark as read:', err);
    }
  }

  async function handleMarkAllAsRead() {
    try {
      await markAllNotificationsAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error('Failed to mark all as read:', err);
    }
  }

  function handleViewAll() {
    setOpen(false);
    navigate('/notifications');
  }

  const unreadNotifications = notifications.filter((n) => !n.is_read);
  const readNotifications = notifications.filter((n) => n.is_read);

  return (
    <div className="relative" ref={dropdownRef}>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(!open)}
        className={cn(
          'relative w-10 h-10 flex items-center justify-center rounded-xl transition-colors',
          open ? 'bg-white/10' : 'bg-white/5 hover:bg-white/10'
        )}
      >
        <Bell className={cn('w-5 h-5 transition-colors', open && 'text-primary')} />

        {/* Unread badge */}
        <AnimatePresence>
          {unreadCount > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className={cn(
                'absolute -top-1 -right-1 min-w-5 h-5 flex items-center justify-center rounded-full',
                'bg-gradient-to-r from-primary to-secondary text-white text-xs font-bold',
                'shadow-lg shadow-primary/30'
              )}
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Pulse effect for unread */}
        {unreadCount > 0 && (
          <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary/50 animate-ping" />
        )}
      </motion.button>

      {/* Dropdown */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className={cn(
              'absolute right-0 top-full mt-2 w-80 sm:w-96 overflow-hidden',
              'rounded-2xl border border-white/10',
              'bg-gradient-to-b from-background/95 to-background/90',
              'backdrop-blur-2xl',
              'shadow-2xl shadow-black/30'
            )}
          >
            {/* Header */}
            <div className="relative flex items-center justify-between px-4 py-3 border-b border-white/5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                  <Bell className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Notifications</h3>
                  {unreadCount > 0 && (
                    <p className="text-xs text-muted-foreground">{unreadCount} unread</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1">
                {unreadCount > 0 && (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleMarkAllAsRead}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-primary hover:bg-primary/10 transition-colors"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                    Mark all
                  </motion.button>
                )}
                <button
                  onClick={() => setOpen(false)}
                  className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/5 transition-colors"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>

            {/* Content */}
            <ScrollArea className="max-h-[400px]">
              {loading ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
                    <Sparkles className="absolute inset-0 m-auto w-5 h-5 text-primary" />
                  </div>
                  <p className="text-sm text-muted-foreground mt-3">Loading...</p>
                </div>
              ) : notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-3">
                    <Bell className="w-8 h-8 opacity-30" />
                  </div>
                  <p className="font-medium">All caught up!</p>
                  <p className="text-xs mt-1">No new notifications</p>
                </div>
              ) : (
                <div className="p-2">
                  {/* Unread Notifications */}
                  {unreadNotifications.map((un, index) => {
                    const Icon = typeIcons[un.notification?.notification_type || 'custom'] || Bell;
                    const priority = un.notification?.priority_level || 'medium';
                    const colorClass = typeColors[un.notification?.notification_type || 'custom'];

                    return (
                      <motion.div
                        key={un.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        onClick={() => handleMarkAsRead(un.id)}
                        className={cn(
                          'group relative mb-1 p-3 rounded-xl cursor-pointer transition-all duration-300',
                          'hover:shadow-lg hover:shadow-primary/5',
                          'bg-gradient-to-r',
                          priorityColors[priority]
                        )}
                      >
                        <div className="flex gap-3">
                          <div
                            className={cn(
                              'w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110',
                              colorClass
                            )}
                          >
                            <Icon className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm line-clamp-1">{un.notification?.title}</p>
                            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                              {un.notification?.message}
                            </p>
                            <p className="text-[10px] text-muted-foreground/60 mt-1">
                              {new Date(un.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="w-2 h-2 rounded-full bg-gradient-to-r from-primary to-accent flex-shrink-0 self-start mt-2 animate-pulse" />
                        </div>
                      </motion.div>
                    );
                  })}

                  {/* Divider */}
                  {readNotifications.length > 0 && unreadNotifications.length > 0 && (
                    <div className="flex items-center gap-2 px-3 py-2">
                      <div className="flex-1 h-px bg-white/5" />
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Earlier</span>
                      <div className="flex-1 h-px bg-white/5" />
                    </div>
                  )}

                  {/* Read Notifications */}
                  {readNotifications.slice(0, 3).map((un, index) => {
                    const Icon = typeIcons[un.notification?.notification_type || 'custom'] || Bell;
                    const colorClass = typeColors[un.notification?.notification_type || 'custom'];

                    return (
                      <motion.div
                        key={un.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: (unreadNotifications.length + index) * 0.05 }}
                        className="group relative mb-1 p-3 rounded-xl cursor-pointer opacity-60 hover:opacity-80 transition-opacity bg-white/2"
                      >
                        <div className="flex gap-3">
                          <div
                            className={cn(
                              'w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0',
                              colorClass
                            )}
                          >
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm line-clamp-1">{un.notification?.title}</p>
                            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                              {un.notification?.message}
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </ScrollArea>

            {/* Footer */}
            <div className="p-3 border-t border-white/5">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleViewAll}
                className={cn(
                  'w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl',
                  'bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10',
                  'hover:from-primary/20 hover:via-secondary/20 hover:to-accent/20',
                  'text-sm font-medium transition-all'
                )}
              >
                <Sparkles className="w-4 h-4 text-primary" />
                View all notifications
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
