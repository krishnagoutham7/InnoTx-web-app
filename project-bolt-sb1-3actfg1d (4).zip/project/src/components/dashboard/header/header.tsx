import { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, Menu, Moon, Settings, Sun, User, ChevronDown, HelpCircle, Sparkles } from 'lucide-react';
import { useTheme } from '@/components/theme-provider';
import { useAuth } from '@/contexts/auth';
import { roleLabels } from '@/types/auth';
import NotificationBell from './notification-bell';
import { cn } from '@/lib/utils';

interface HeaderProps {
  onMenuClick: () => void;
  isSidebarCollapsed: boolean;
}

export default function DashboardHeader({ onMenuClick, isSidebarCollapsed }: HeaderProps) {
  const { theme, setTheme } = useTheme();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [showProfile, setShowProfile] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfile(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Get page title from path
  const getPageTitle = () => {
    const path = location.pathname;
    const segments = path.split('/').filter(Boolean);
    if (segments.length === 1) return 'Dashboard';
    const last = segments[segments.length - 1];
    return last.charAt(0).toUpperCase() + last.slice(1).replace(/-/g, ' ');
  };

  return (
    <motion.header
      initial={false}
      animate={{ left: isSidebarCollapsed ? 68 : 256 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className={cn(
        'fixed top-0 right-0 z-30 h-16',
        'border-b border-white/5',
        'bg-gradient-to-r from-background/95 via-background/90 to-background/95',
        'backdrop-blur-2xl',
        'shadow-lg shadow-black/10'
      )}
    >
      {/* Subtle gradient line at top */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

      <div className="h-full px-4 lg:px-6 flex items-center justify-between">
        {/* Left side - Menu & Title */}
        <div className="flex items-center gap-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onMenuClick}
            className="lg:hidden w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </motion.button>

          <div className="flex flex-col">
            <motion.h1
              key={getPageTitle()}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-lg font-semibold text-foreground font-heading"
            >
              {getPageTitle()}
            </motion.h1>
            <p className="text-xs text-muted-foreground hidden sm:block">
              Welcome back, {user?.name?.split(' ')[0] || 'User'}
            </p>
          </div>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center gap-2 lg:gap-3">
          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="hidden md:flex items-center gap-1 px-3 py-1.5 rounded-full bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 border border-white/5"
          >
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span className="text-xs font-medium text-muted-foreground">Innovation Hub</span>
          </motion.div>

          {/* Divider */}
          <div className="hidden lg:block w-px h-8 bg-white/5" />

          {/* Theme Toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <AnimatePresence mode="wait">
              {theme === 'dark' ? (
                <motion.div
                  key="sun"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Sun className="w-4 h-4 text-yellow-400" />
                </motion.div>
              ) : (
                <motion.div
                  key="moon"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Moon className="w-4 h-4 text-primary" />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>

          {/* Notifications */}
          <NotificationBell />

          {/* Divider */}
          <div className="hidden lg:block w-px h-8 bg-white/5" />

          {/* Profile */}
          <div ref={profileRef} className="relative">
            <motion.button
              whileHover={{ scale: 1.02 }}
              onClick={() => setShowProfile(!showProfile)}
              className={cn(
                'flex items-center gap-2 px-2 py-1.5 rounded-xl transition-all duration-300',
                showProfile ? 'bg-white/10' : 'hover:bg-white/5'
              )}
            >
              <div className="relative">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary via-secondary to-accent p-0.5">
                  <div className="w-full h-full rounded-[10px] bg-background flex items-center justify-center text-sm font-bold text-foreground">
                    {user?.name?.charAt(0) || 'U'}
                  </div>
                </div>
                {/* Online indicator */}
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-success border-2 border-background" />
              </div>
              <div className="hidden lg:block text-left">
                <p className="text-sm font-medium leading-tight">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{user ? roleLabels[user.role] : ''}</p>
              </div>
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-muted-foreground hidden lg:block transition-transform duration-200',
                  showProfile && 'rotate-180'
                )}
              />
            </motion.button>

            {/* Profile Dropdown */}
            <AnimatePresence>
              {showProfile && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  transition={{ duration: 0.2, ease: 'easeOut' }}
                  className={cn(
                    'absolute right-0 top-full mt-2 w-72 overflow-hidden',
                    'rounded-2xl border border-white/10',
                    'bg-gradient-to-b from-background/95 to-background/90',
                    'backdrop-blur-2xl',
                    'shadow-2xl shadow-black/30'
                  )}
                >
                  {/* Profile Header */}
                  <div className="relative p-4 border-b border-white/5">
                    {/* Gradient background */}
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10" />
                    <div className="relative flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary via-secondary to-accent p-0.5">
                        <div className="w-full h-full rounded-[10px] bg-background flex items-center justify-center text-xl font-bold text-foreground">
                          {user?.name?.charAt(0) || 'U'}
                        </div>
                      </div>
                      <div>
                        <p className="font-semibold">{user?.name}</p>
                        <p className="text-xs text-muted-foreground">{user?.email}</p>
                        <div className="mt-1">
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/20 text-primary">
                            {user ? roleLabels[user.role] : ''}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Menu Items */}
                  <div className="p-2">
                    <Link
                      to="/dashboard/profile"
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm hover:bg-white/5 transition-colors"
                      onClick={() => setShowProfile(false)}
                    >
                      <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
                        <User className="w-4 h-4 text-primary" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Profile</p>
                        <p className="text-xs text-muted-foreground">Manage your account</p>
                      </div>
                    </Link>
                    <Link
                      to="/dashboard/settings"
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm hover:bg-white/5 transition-colors"
                      onClick={() => setShowProfile(false)}
                    >
                      <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
                        <Settings className="w-4 h-4 text-secondary" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Settings</p>
                        <p className="text-xs text-muted-foreground">App preferences</p>
                      </div>
                    </Link>
                    <Link
                      to="#"
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm hover:bg-white/5 transition-colors"
                      onClick={() => setShowProfile(false)}
                    >
                      <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
                        <HelpCircle className="w-4 h-4 text-accent" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Help Center</p>
                        <p className="text-xs text-muted-foreground">Get support</p>
                      </div>
                    </Link>
                  </div>

                  {/* Logout */}
                  <div className="p-2 border-t border-white/5">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleLogout}
                      className={cn(
                        'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm w-full transition-all',
                        'text-destructive hover:bg-destructive/10'
                      )}
                    >
                      <div className="w-8 h-8 rounded-lg bg-destructive/10 flex items-center justify-center">
                        <LogOut className="w-4 h-4" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="font-medium">Sign Out</p>
                        <p className="text-xs text-muted-foreground">See you soon!</p>
                      </div>
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.header>
  );
}
