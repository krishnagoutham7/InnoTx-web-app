import { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import * as Icons from 'lucide-react';

// Animated Counter Hook
function useAnimatedCounter(end: number, duration: number = 2000) {
  const [displayValue, setDisplayValue] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView || typeof end !== 'number') return;

    let startTime: number;
    let animationFrame: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);

      // Easing function
      const easeOut = 1 - Math.pow(1 - progress, 3);
      setDisplayValue(Math.floor(easeOut * end));

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [isInView, end, duration]);

  return { displayValue, ref };
}

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: string;
  trend?: { value: number; isPositive: boolean };
  color?: 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'danger';
}

const colorConfig: Record<string, { gradient: string; glow: string; iconBg: string; iconColor: string }> = {
  primary: {
    gradient: 'from-primary/20 via-primary/10 to-transparent',
    glow: 'shadow-glow-sm',
    iconBg: 'bg-gradient-to-br from-primary/30 to-primary/10',
    iconColor: 'text-primary',
  },
  secondary: {
    gradient: 'from-secondary/20 via-secondary/10 to-transparent',
    glow: 'shadow-glow-purple',
    iconBg: 'bg-gradient-to-br from-secondary/30 to-secondary/10',
    iconColor: 'text-secondary',
  },
  accent: {
    gradient: 'from-accent/20 via-accent/10 to-transparent',
    glow: 'shadow-glow-accent',
    iconBg: 'bg-gradient-to-br from-accent/30 to-accent/10',
    iconColor: 'text-accent',
  },
  success: {
    gradient: 'from-success/20 via-success/10 to-transparent',
    glow: 'shadow-[0_0_20px_hsl(160_84%_39%_/_0.3)]',
    iconBg: 'bg-gradient-to-br from-success/30 to-success/10',
    iconColor: 'text-success',
  },
  warning: {
    gradient: 'from-warning/20 via-warning/10 to-transparent',
    glow: 'shadow-[0_0_20px_hsl(38_92%_50%_/_0.3)]',
    iconBg: 'bg-gradient-to-br from-warning/30 to-warning/10',
    iconColor: 'text-warning',
  },
  danger: {
    gradient: 'from-destructive/20 via-destructive/10 to-transparent',
    glow: 'shadow-[0_0_20px_hsl(0_84%_60%_/_0.3)]',
    iconBg: 'bg-gradient-to-br from-destructive/30 to-destructive/10',
    iconColor: 'text-destructive',
  },
};

export function StatCard({ title, value, subtitle, icon, trend, color = 'primary' }: StatCardProps) {
  const IconComponent = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[icon] || Icons.File;
  const numericValue = typeof value === 'number' ? value : parseInt(value) || 0;
  const { displayValue, ref } = useAnimatedCounter(numericValue);
  const isNumeric = typeof value === 'number' || !isNaN(parseInt(value));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      whileHover={{ y: -5, scale: 1.02 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
    >
      <div
        className={cn(
          'relative overflow-hidden rounded-2xl p-6',
          'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
          'border border-white/5',
          'backdrop-blur-xl',
          'transition-all duration-500',
          'hover:border-white/10',
          'hover:shadow-xl hover:shadow-black/10',
          colorConfig[color].glow
        )}
      >
        {/* Gradient overlay */}
        <div className={cn('absolute inset-0 bg-gradient-to-br opacity-50', colorConfig[color].gradient)} />

        {/* Glow line at top */}
        <div className={cn('absolute top-0 left-4 right-4 h-px bg-gradient-to-r',
          color === 'primary' && 'from-transparent via-primary/50 to-transparent',
          color === 'secondary' && 'from-transparent via-secondary/50 to-transparent',
          color === 'accent' && 'from-transparent via-accent/50 to-transparent',
          color === 'success' && 'from-transparent via-success/50 to-transparent',
          color === 'warning' && 'from-transparent via-warning/50 to-transparent',
          color === 'danger' && 'from-transparent via-destructive/50 to-transparent'
        )} />

        <div className="relative flex items-start justify-between">
          <div className="flex-1" ref={ref}>
            <p className="text-sm text-muted-foreground font-medium">{title}</p>
            <div className="mt-2">
              <span className="text-4xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent font-heading">
                {isNumeric ? displayValue.toLocaleString() : value}
              </span>
            </div>
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-1.5">{subtitle}</p>
            )}
            {trend && (
              <div className={cn('flex items-center gap-1 mt-2 text-xs font-medium', trend.isPositive ? 'text-success' : 'text-danger')}>
                <Icons.TrendingUp className={cn('w-3.5 h-3.5', !trend.isPositive && 'rotate-180')} />
                <span>{trend.isPositive ? '+' : '-'}{Math.abs(trend.value)}%</span>
                <span className="text-muted-foreground font-normal">vs last month</span>
              </div>
            )}
          </div>

          <motion.div
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ type: 'spring', stiffness: 400 }}
            className={cn(
              'relative w-14 h-14 rounded-2xl flex items-center justify-center',
              'shadow-lg',
              colorConfig[color].iconBg
            )}
          >
            <IconComponent className={cn('w-7 h-7', colorConfig[color].iconColor)} />
            {/* Icon glow */}
            <div className={cn('absolute inset-0 rounded-2xl', colorConfig[color].iconBg, 'blur-xl opacity-50')} />
          </motion.div>
        </div>

        {/* Animated particles */}
        <div className="absolute -bottom-2 -right-2 w-20 h-20 bg-gradient-to-br from-white/5 to-transparent rounded-full blur-2xl" />
      </div>
    </motion.div>
  );
}

// Mini Stat Card for compact views
export function MiniStatCard({ title, value, icon, color = 'primary' }: { title: string; value: string | number; icon: string; color?: 'primary' | 'secondary' | 'accent' | 'success' }) {
  const IconComponent = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[icon] || Icons.File;

  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      className={cn(
        'relative overflow-hidden rounded-xl p-4',
        'bg-gradient-to-br from-background/80 to-background/40',
        'border border-white/5',
        'backdrop-blur-xl'
      )}
    >
      <div className="flex items-center gap-3">
        <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center', colorConfig[color].iconBg)}>
          <IconComponent className={cn('w-5 h-5', colorConfig[color].iconColor)} />
        </div>
        <div>
          <p className="text-xs text-muted-foreground">{title}</p>
          <p className="text-xl font-bold">{value}</p>
        </div>
      </div>
    </motion.div>
  );
}

interface ActivityItem {
  id: string;
  title: string;
  description: string;
  time: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface ActivityFeedProps {
  title: string;
  activities: ActivityItem[];
}

const activityConfig: Record<string, { color: string; bg: string; border: string }> = {
  success: { color: 'text-success', bg: 'bg-success/10', border: 'border-success/20' },
  info: { color: 'text-primary', bg: 'bg-primary/10', border: 'border-primary/20' },
  warning: { color: 'text-warning', bg: 'bg-warning/10', border: 'border-warning/20' },
  error: { color: 'text-destructive', bg: 'bg-destructive/10', border: 'border-destructive/20' },
};

export function ActivityFeed({ title, activities }: ActivityFeedProps) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-2xl',
        'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
        'border border-white/5',
        'backdrop-blur-xl'
      )}
    >
      {/* Header */}
      <div className="px-6 py-4 border-b border-white/5">
        <h3 className="text-lg font-semibold font-heading">{title}</h3>
        <p className="text-xs text-muted-foreground mt-0.5">Recent updates and activity</p>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <AnimatePresence>
          {activities.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Icons.Inbox className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No recent activity</p>
            </div>
          ) : (
            activities.map((activity, index) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05, duration: 0.2 }}
                whileHover={{ x: 4 }}
                className={cn(
                  'relative flex items-start gap-3 p-3 rounded-xl',
                  'bg-gradient-to-r from-white/2 to-transparent',
                  'border-l-2',
                  activityConfig[activity.type].border,
                  'hover:from-white/5 transition-colors cursor-pointer'
                )}
              >
                <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center mt-0.5', activityConfig[activity.type].bg)}>
                  <div className={cn('w-2 h-2 rounded-full', activityConfig[activity.type].color.replace('text-', 'bg-'))} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{activity.title}</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">{activity.description}</p>
                </div>
                <span className="text-xs text-muted-foreground/70 whitespace-nowrap">{activity.time}</span>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

interface QuickActionProps {
  title: string;
  description: string;
  icon: string;
  href?: string;
  onClick?: () => void;
  color?: 'primary' | 'secondary' | 'accent';
}

export function QuickAction({ title, description, icon, href, onClick, color = 'primary' }: QuickActionProps) {
  const IconComponent = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[icon] || Icons.File;
  const config = colorConfig[color];

  const content = (
    <motion.div
      whileHover={{ x: 5, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        'relative group flex items-center gap-4 p-4 rounded-xl cursor-pointer',
        'bg-gradient-to-r from-white/2 to-transparent',
        'hover:from-white/5 hover:to-white/2',
        'border border-white/5 hover:border-white/10',
        'transition-all duration-300'
      )}
    >
      <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center', config.iconBg)}>
        <IconComponent className={cn('w-6 h-6', config.iconColor)} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium">{title}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <Icons.ChevronRight className={cn('w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity', config.iconColor)} />
    </motion.div>
  );

  if (href) {
    return <Link to={href}>{content}</Link>;
  }
  return <div onClick={onClick}>{content}</div>;
}

interface StatusBadgeProps {
  status: 'online' | 'offline' | 'maintenance';
  showLabel?: boolean;
}

export function StatusBadge({ status, showLabel = true }: StatusBadgeProps) {
  const config: Record<string, { color: string; bg: string; label: string }> = {
    online: { color: 'bg-success', bg: 'bg-success/20', label: 'Online' },
    offline: { color: 'bg-destructive', bg: 'bg-destructive/20', label: 'Offline' },
    maintenance: { color: 'bg-warning', bg: 'bg-warning/20', label: 'Maintenance' },
  };

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
      <div className="relative">
        <div className={cn('w-2.5 h-2.5 rounded-full', config[status].color)} />
        <div className={cn('absolute inset-0 w-2.5 h-2.5 rounded-full animate-ping', config[status].color, 'opacity-50')} />
      </div>
      {showLabel && <span className="text-sm font-medium">{config[status].label}</span>}
    </div>
  );
}

// Hero Section Component
interface HeroSectionProps {
  title: string;
  subtitle?: string;
  userName?: string;
  stats?: Array<{ label: string; value: number | string; icon: string; color?: 'primary' | 'secondary' | 'accent' | 'success' }>;
}

export function HeroSection({ title, subtitle, userName, stats }: HeroSectionProps) {
  return (
    <div className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10 rounded-3xl" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent rounded-3xl" />

      {/* Animated gradient orbs */}
      <div className="absolute -top-20 -left-20 w-40 h-40 bg-primary/30 rounded-full blur-3xl animate-float" />
      <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-accent/30 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />

      <div className="relative p-6 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="px-3 py-1 rounded-full bg-gradient-to-r from-primary/20 to-accent/20 border border-white/10 text-xs font-medium">
              Dashboard
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold font-heading">
            {userName ? (
              <>
                Welcome back, <span className="gradient-text">{userName.split(' ')[0]}</span>
              </>
            ) : (
              title
            )}
          </h1>
          {subtitle && <p className="text-muted-foreground mt-2">{subtitle}</p>}
        </motion.div>

        {stats && stats.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="relative overflow-hidden rounded-xl p-4 bg-white/5 border border-white/5"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className={cn('w-6 h-6 rounded-lg flex items-center justify-center', colorConfig[stat.color || 'primary'].iconBg)}>
                    {(() => {
                      const StatIcon = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[stat.icon] || Icons.File;
                      return <StatIcon className={cn('w-3.5 h-3.5', colorConfig[stat.color || 'primary'].iconColor)} />;
                    })()}
                  </div>
                  <span className="text-xs text-muted-foreground">{stat.label}</span>
                </div>
                <p className="text-2xl font-bold">{stat.value}</p>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
}

// Progress Ring Component
export function ProgressRing({ progress, size = 80, strokeWidth = 6, color = 'primary' }: { progress: number; size?: number; strokeWidth?: number; color?: 'primary' | 'secondary' | 'accent' | 'success' }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle
          stroke="hsl(var(--muted))"
          fill="transparent"
          strokeWidth={strokeWidth}
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        <motion.circle
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: 'easeOut' }}
          stroke={color === 'primary' ? 'hsl(var(--primary))' : color === 'secondary' ? 'hsl(var(--secondary))' : color === 'accent' ? 'hsl(var(--accent))' : 'hsl(var(--success))'}
          fill="transparent"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-lg font-bold">{progress}%</span>
      </div>
    </div>
  );
}
