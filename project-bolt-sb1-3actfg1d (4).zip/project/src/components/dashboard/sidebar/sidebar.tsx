import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronRight, Sparkles, UserCircle } from 'lucide-react';
import type { NavItem } from '@/types/dashboard/navigation';
import { cn } from '@/lib/utils';
import * as Icons from 'lucide-react';

interface SidebarProps {
  navigation: NavItem[];
  isCollapsed: boolean;
  onToggle: () => void;
}

function DynamicIcon({ name, className }: { name: string; className?: string }) {
  const Icon = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[name] || Icons.File;
  return <Icon className={className} />;
}

function NavItemComponent({ item, isCollapsed }: { item: NavItem; isCollapsed: boolean }) {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const isActive = location.pathname === item.href;
  const hasChildren = item.children && item.children.length > 0;
  const isChildActive = hasChildren && item.children?.some((child) => location.pathname === child.href);

  if (hasChildren) {
    return (
      <div className="space-y-1">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            'group relative w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-300',
            isCollapsed && 'justify-center px-2',
            (isActive || isChildActive)
              ? 'text-primary'
              : 'text-muted-foreground hover:text-foreground'
          )}
        >
          {/* Active glow background */}
          {(isActive || isChildActive) && (
            <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-primary/15 via-primary/5 to-transparent" />
          )}
          {(isActive || isChildActive) && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-r-full bg-gradient-to-b from-primary to-accent" />
          )}

          <div
            className={cn(
              'relative w-8 h-8 flex items-center justify-center rounded-lg transition-all duration-300',
              (isActive || isChildActive)
                ? 'bg-primary/20 text-primary shadow-glow-sm'
                : 'bg-white/5 group-hover:bg-white/10'
            )}
          >
            <DynamicIcon name={item.icon} className="w-4 h-4 shrink-0" />
          </div>

          {!isCollapsed && (
            <>
              <span className="relative flex-1 text-left">{item.label}</span>
              <motion.div
                animate={{ rotate: isOpen ? 180 : 0 }}
                transition={{ duration: 0.2 }}
                className="text-muted-foreground"
              >
                <ChevronDown className="w-4 h-4" />
              </motion.div>
            </>
          )}
        </button>

        <AnimatePresence>
          {isOpen && !isCollapsed && (
            <motion.div
              initial={{ opacity: 0, height: 0, y: -10 }}
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={{ opacity: 0, height: 0, y: -10 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              className="pl-4 space-y-1 mt-1"
            >
              {item.children?.map((child, index) => (
                <motion.div
                  key={child.href}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link
                    to={child.href}
                    className={cn(
                      'group flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all duration-200',
                      location.pathname === child.href
                        ? 'text-primary bg-primary/10'
                        : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
                    )}
                  >
                    <ChevronRight
                      className={cn(
                        'w-3 h-3 transition-transform duration-200',
                        location.pathname === child.href && 'translate-x-0.5'
                      )}
                    />
                    {child.label}
                    {child.badge && (
                      <span className="ml-auto px-2 py-0.5 text-xs rounded-full bg-accent/20 text-accent">
                        {child.badge}
                      </span>
                    )}
                  </Link>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <Link
      to={item.href}
      className={cn(
        'group relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-300',
        isCollapsed && 'justify-center px-2',
        isActive
          ? 'text-primary'
          : 'text-muted-foreground hover:text-foreground'
      )}
    >
      {/* Active glow background */}
      {isActive && (
        <>
          <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-primary/15 via-primary/5 to-transparent" />
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-r-full bg-gradient-to-b from-primary to-accent" />
        </>
      )}

      <div
        className={cn(
          'relative w-8 h-8 flex items-center justify-center rounded-lg transition-all duration-300',
          isActive
            ? 'bg-primary/20 text-primary shadow-glow-sm'
            : 'bg-white/5 group-hover:bg-white/10'
        )}
      >
        <DynamicIcon name={item.icon} className="w-4 h-4 shrink-0" />
      </div>

      {!isCollapsed && (
        <>
          <span className="relative flex-1">{item.label}</span>
          {item.badge && (
            <span className="px-2 py-0.5 text-xs rounded-full bg-gradient-to-r from-primary/30 to-accent/30 text-foreground">
              {item.badge}
            </span>
          )}
        </>
      )}
    </Link>
  );
}

export default function Sidebar({ navigation, isCollapsed }: SidebarProps) {
  const location = useLocation();
  return (
    <motion.aside
      initial={false}
      animate={{ width: isCollapsed ? 68 : 256 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className={cn(
        'fixed left-0 top-0 z-40 h-screen flex flex-col',
        'border-r border-white/5',
        'bg-gradient-to-b from-background/95 via-background/90 to-background/95',
        'backdrop-blur-2xl',
        'shadow-2xl shadow-black/20'
      )}
    >
      {/* Decorative gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-accent/5 pointer-events-none" />

      {/* Logo Section */}
      <div
        className={cn(
          'relative flex items-center gap-3 h-16 px-4 border-b border-white/5',
          isCollapsed && 'justify-center px-2'
        )}
      >
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-primary via-secondary to-accent p-0.5"
        >
          <div className="w-full h-full rounded-[10px] bg-background flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          {/* Glow effect */}
          <div className="absolute -inset-1 rounded-xl bg-gradient-to-br from-primary via-secondary to-accent opacity-30 blur-lg -z-10" />
        </motion.div>

        {!isCollapsed && (
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            className="flex flex-col"
          >
            <span className="text-lg font-bold bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-transparent">
              InnoTex
            </span>
            <span className="text-[10px] text-muted-foreground tracking-widest uppercase">
              Innovation Hub
            </span>
          </motion.div>
        )}
      </div>

      {/* Navigation */}
      <nav className="relative flex-1 overflow-y-auto overflow-x-hidden py-4 px-3 space-y-1 scrollbar-premium">
        {navigation.map((item, index) => (
          <motion.div
            key={item.href}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.03, duration: 0.2 }}
          >
            <NavItemComponent item={item} isCollapsed={isCollapsed} />
          </motion.div>
        ))}
      </nav>

      {/* Bottom Section */}
      <div className="relative border-t border-white/5 p-3 space-y-1">
        <Link
          to="/profile"
          className={cn(
            'group flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-300',
            location.pathname === '/profile'
              ? 'text-primary bg-primary/10'
              : 'text-muted-foreground hover:text-foreground',
            isCollapsed && 'justify-center px-2'
          )}
        >
          <div className={cn(
            'w-8 h-8 flex items-center justify-center rounded-lg transition-colors',
            location.pathname === '/profile' ? 'bg-primary/20 text-primary' : 'bg-white/5 group-hover:bg-white/10'
          )}>
            <UserCircle className="w-4 h-4" />
          </div>
          {!isCollapsed && <span>My Profile</span>}
        </Link>
        <Link
          to="/"
          className={cn(
            'group flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-300',
            'text-muted-foreground hover:text-foreground',
            isCollapsed && 'justify-center px-2'
          )}
        >
          <div className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors">
            <Icons.Eye className="w-4 h-4" />
          </div>
          {!isCollapsed && <span>View Website</span>}
        </Link>

        {/* Brand Footer */}
        {!isCollapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 pt-3 border-t border-white/5 text-center"
          >
            <p className="text-[10px] text-muted-foreground/60">
              Powered by
            </p>
            <p className="text-xs font-medium gradient-text">
              Startup Kerala x InnoTex
            </p>
          </motion.div>
        )}
      </div>
    </motion.aside>
  );
}
