import { Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface FontControlsProps {
  fontSize: number;
  fontColor: string;
  fontFamily: string;
  fontWeight?: string;
  align: 'left' | 'center' | 'right';
  letterSpacing?: number;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  fontSizeMin?: number;
  fontSizeMax?: number;
  onUpdate: (updates: Record<string, any>) => void;
}

const FONT_FAMILIES = [
  'Arial', 'Helvetica', 'Times New Roman', 'Georgia',
  'Courier New', 'monospace', 'Impact', 'Verdana', 'Trebuchet MS',
];

export function FontControls({
  fontSize, fontColor, fontFamily, fontWeight, align, letterSpacing,
  bold, italic, underline,
  fontSizeMin = 10, fontSizeMax = 60,
  onUpdate,
}: FontControlsProps) {
  return (
    <>
      {/* Font size slider */}
      <div>
        <div className="flex items-center justify-between mb-1">
          <Label className="text-xs">Font Size</Label>
          <span className="text-xs text-muted-foreground">{fontSize}px</span>
        </div>
        <Slider
          value={[fontSize]}
          min={fontSizeMin}
          max={fontSizeMax}
          step={1}
          onValueChange={([v]) => onUpdate({ fontSize: v })}
          className="w-full"
        />
        <Input
          type="number"
          value={fontSize}
          onChange={(e) => onUpdate({ fontSize: parseInt(e.target.value) || fontSize })}
          min={fontSizeMin}
          max={fontSizeMax}
          className="h-8 mt-1 text-xs"
        />
      </div>

      {/* Font family + weight */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label className="text-xs">Font Family</Label>
          <Select
            value={fontFamily}
            onValueChange={(v) => onUpdate({ fontFamily: v })}
          >
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {FONT_FAMILIES.map((f) => (
                <SelectItem key={f} value={f}>{f}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">Font Weight</Label>
          <Select
            value={fontWeight || (bold ? 'bold' : 'normal')}
            onValueChange={(v) => onUpdate({ fontWeight: v, bold: v === 'bold' })}
          >
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="bold">Bold</SelectItem>
              <SelectItem value="300">Light</SelectItem>
              <SelectItem value="500">Medium</SelectItem>
              <SelectItem value="600">Semibold</SelectItem>
              <SelectItem value="700">Bold</SelectItem>
              <SelectItem value="800">Extrabold</SelectItem>
              <SelectItem value="900">Black</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Text color */}
      <div>
        <Label className="text-xs">Text Color</Label>
        <div className="flex items-center gap-2 mt-1">
          <input
            type="color"
            value={fontColor || '#000000'}
            onChange={(e) => onUpdate({ fontColor: e.target.value })}
            className="w-10 h-8 rounded cursor-pointer"
          />
          <Input
            value={fontColor || '#000000'}
            onChange={(e) => onUpdate({ fontColor: e.target.value })}
            className="flex-1 h-8 text-xs"
            placeholder="#000000"
          />
        </div>
      </div>

      {/* Style toggles: Bold, Italic, Underline */}
      <div>
        <Label className="text-xs">Style</Label>
        <div className="flex items-center gap-1 mt-1">
          <Button
            type="button"
            variant={bold ? 'default' : 'outline'}
            size="icon"
            className="h-8 w-8"
            onClick={() => onUpdate({ bold: !bold, fontWeight: !bold ? 'bold' : 'normal' })}
            title="Bold"
          >
            <Bold className="w-3.5 h-3.5" />
          </Button>
          <Button
            type="button"
            variant={italic ? 'default' : 'outline'}
            size="icon"
            className="h-8 w-8"
            onClick={() => onUpdate({ italic: !italic })}
            title="Italic"
          >
            <Italic className="w-3.5 h-3.5" />
          </Button>
          <Button
            type="button"
            variant={underline ? 'default' : 'outline'}
            size="icon"
            className="h-8 w-8"
            onClick={() => onUpdate({ underline: !underline })}
            title="Underline"
          >
            <Underline className="w-3.5 h-3.5" />
          </Button>
          <div className="w-px h-6 bg-border mx-1" />
          <Button
            type="button"
            variant={align === 'left' ? 'default' : 'outline'}
            size="icon"
            className="h-8 w-8"
            onClick={() => onUpdate({ align: 'left' })}
            title="Left align"
          >
            <AlignLeft className="w-3.5 h-3.5" />
          </Button>
          <Button
            type="button"
            variant={align === 'center' ? 'default' : 'outline'}
            size="icon"
            className="h-8 w-8"
            onClick={() => onUpdate({ align: 'center' })}
            title="Center align"
          >
            <AlignCenter className="w-3.5 h-3.5" />
          </Button>
          <Button
            type="button"
            variant={align === 'right' ? 'default' : 'outline'}
            size="icon"
            className="h-8 w-8"
            onClick={() => onUpdate({ align: 'right' })}
            title="Right align"
          >
            <AlignRight className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Letter spacing */}
      <div>
        <div className="flex items-center justify-between mb-1">
          <Label className="text-xs">Letter Spacing</Label>
          <span className="text-xs text-muted-foreground">{letterSpacing || 0}px</span>
        </div>
        <Slider
          value={[letterSpacing || 0]}
          min={-5}
          max={20}
          step={0.5}
          onValueChange={([v]) => onUpdate({ letterSpacing: v })}
          className="w-full"
        />
      </div>
    </>
  );
}
