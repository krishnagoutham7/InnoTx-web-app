import { useState, useCallback } from 'react';
import { Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { toggleEventLike } from '@/services/events';

interface LikeButtonProps {
  eventId: string;
  userId?: string;
  initialLiked?: boolean;
  initialCount?: number;
  onLikeChange?: (liked: boolean, count: number) => void;
  size?: 'sm' | 'default' | 'lg';
  variant?: 'default' | 'minimal' | 'card';
  className?: string;
}

export default function LikeButton({
  eventId,
  userId,
  initialLiked = false,
  initialCount = 0,
  onLikeChange,
  size = 'default',
  variant = 'default',
  className,
}: LikeButtonProps) {
  const [liked, setLiked] = useState(initialLiked);
  const [count, setCount] = useState(initialCount);
  const [loading, setLoading] = useState(false);

  const handleToggle = useCallback(async () => {
    if (!userId) return;

    // Optimistic update
    const newLiked = !liked;
    setLiked(newLiked);
    setCount(c => newLiked ? c + 1 : c - 1);

    setLoading(true);
    try {
      const result = await toggleEventLike(eventId, userId);
      setLiked(result.liked);
      setCount(result.like_count);
      onLikeChange?.(result.liked, result.like_count);
    } catch (err) {
      // Revert on error
      setLiked(!newLiked);
      setCount(c => newLiked ? c - 1 : c + 1);
      console.error('Failed to toggle like:', err);
    } finally {
      setLoading(false);
    }
  }, [eventId, userId, liked, onLikeChange]);

  if (!userId) {
    return (
      <div className={cn('flex items-center gap-1', className)}>
        <Heart className={cn('w-4 h-4 text-muted-foreground')} />
        <span className="text-sm text-muted-foreground">{count}</span>
      </div>
    );
  }

  if (variant === 'minimal') {
    return (
      <button
        onClick={handleToggle}
        disabled={loading}
        className={cn(
          'flex items-center gap-1 transition-colors',
          liked ? 'text-red-500' : 'text-muted-foreground hover:text-red-500',
          className
        )}
      >
        <Heart className={cn('w-4 h-4', liked && 'fill-current')} />
        <span className="text-sm">{count}</span>
      </button>
    );
  }

  if (variant === 'card') {
    return (
      <button
        onClick={handleToggle}
        disabled={loading}
        className={cn(
          'flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-muted/50 hover:bg-muted transition-colors',
          className
        )}
      >
        <Heart className={cn('w-4 h-4 transition-colors', liked ? 'fill-red-500 text-red-500' : 'text-muted-foreground group-hover:text-red-400')} />
        <span className={cn('text-sm', liked ? 'text-red-600' : 'text-muted-foreground')}>{count}</span>
      </button>
    );
  }

  return (
    <Button
      variant="ghost"
      size={size}
      onClick={handleToggle}
      disabled={loading}
      className={cn(
        'gap-1.5',
        liked && 'text-red-500 hover:text-red-600 hover:bg-red-50',
        className
      )}
    >
      <Heart className={cn('w-4 h-4', liked && 'fill-current animate-pulse')} />
      <span>{count}</span>
    </Button>
  );
}
