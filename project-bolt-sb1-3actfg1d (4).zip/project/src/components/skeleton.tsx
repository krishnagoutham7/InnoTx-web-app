import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

// Skeleton base with shimmer animation
const skeletonBase = 'skeleton animate-shimmer rounded-lg';

// Card Skeleton
export function CardSkeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-2xl',
        'bg-gradient-to-br from-white/5 to-white/2',
        'border border-white/5',
        className
      )}
    >
      {/* Shimmer overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-shimmer" />
    </div>
  );
}

// Stat Card Skeleton
export function StatCardSkeleton() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'relative overflow-hidden rounded-2xl p-6',
        'bg-gradient-to-br from-background/90 to-background/50',
        'border border-white/5'
      )}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-3 flex-1">
          <div className={cn(skeletonBase, 'w-24 h-4 bg-white/5')} />
          <div className={cn(skeletonBase, 'w-20 h-10 bg-white/10')} />
          <div className={cn(skeletonBase, 'w-32 h-3 bg-white/5')} />
        </div>
        <div className={cn(skeletonBase, 'w-14 h-14 rounded-2xl bg-primary/10')} />
      </div>
    </motion.div>
  );
}

// Event Card Skeleton
export function EventCardSkeleton() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'relative overflow-hidden rounded-2xl',
        'bg-gradient-to-br from-background/90 to-background/50',
        'border border-white/5'
      )}
    >
      {/* Poster skeleton */}
      <div className={cn(skeletonBase, 'aspect-[16/9] bg-white/5')} />

      {/* Content skeleton */}
      <div className="p-5 space-y-3">
        <div className="flex gap-2">
          <div className={cn(skeletonBase, 'w-20 h-5 bg-primary/10 rounded-full')} />
          <div className={cn(skeletonBase, 'w-16 h-5 bg-accent/10 rounded-full')} />
        </div>
        <div className={cn(skeletonBase, 'w-3/4 h-6 bg-white/10 rounded-lg')} />
        <div className="space-y-2">
          <div className={cn(skeletonBase, 'w-1/2 h-4 bg-white/5 rounded-lg')} />
          <div className={cn(skeletonBase, 'w-2/3 h-4 bg-white/5 rounded-lg')} />
        </div>
      </div>
    </motion.div>
  );
}

// Team Card Skeleton
export function TeamCardSkeleton({ featured = false }: { featured?: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'relative overflow-hidden rounded-2xl text-center',
        'bg-gradient-to-br from-background/90 to-background/50',
        'border border-white/5',
        featured ? 'p-6' : 'p-5'
      )}
    >
      {/* Avatar skeleton */}
      <div
        className={cn(
          skeletonBase,
          'rounded-full mx-auto mb-4 ring-4 ring-primary/10',
          featured ? 'w-28 h-28' : 'w-20 h-20'
        )}
        style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.2), hsl(var(--accent) / 0.2))' }}
      />

      {/* Text skeletons */}
      <div className="space-y-2">
        <div className={cn(skeletonBase, 'w-3/4 h-5 bg-white/10 mx-auto rounded-lg')} />
        <div className={cn(skeletonBase, 'w-1/2 h-4 bg-primary/10 mx-auto rounded-lg')} />
      </div>

      {/* Social links skeleton */}
      <div className="flex justify-center gap-1.5 mt-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className={cn(skeletonBase, 'w-8 h-8 rounded-lg bg-white/5')} />
        ))}
      </div>
    </motion.div>
  );
}

// Notification Item Skeleton
export function NotificationSkeleton() {
  return (
    <div className="flex gap-3 p-3">
      <div className={cn(skeletonBase, 'w-10 h-10 rounded-xl bg-white/5 shrink-0')} />
      <div className="flex-1 space-y-2">
        <div className={cn(skeletonBase, 'w-3/4 h-4 bg-white/10 rounded-lg')} />
        <div className={cn(skeletonBase, 'w-full h-3 bg-white/5 rounded-lg')} />
      </div>
    </div>
  );
}

// Table Row Skeleton
export function TableRowSkeleton({ columns = 4 }: { columns?: number }) {
  return (
    <motion.tr
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      className="border-b border-white/5"
    >
      {Array.from({ length: columns }).map((_, i) => (
        <td key={i} className="p-4">
          <div className={cn(skeletonBase, 'w-full h-4 bg-white/5 rounded-lg', i === 0 && 'w-16')} />
        </td>
      ))}
    </motion.tr>
  );
}

// List Item Skeleton
export function ListItemSkeleton() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'flex items-center gap-4 p-4 rounded-xl',
        'bg-gradient-to-r from-white/2 to-transparent',
        'border border-white/5'
      )}
    >
      <div className={cn(skeletonBase, 'w-12 h-12 rounded-xl bg-white/5')} />
      <div className="flex-1 space-y-2">
        <div className={cn(skeletonBase, 'w-1/3 h-4 bg-white/10 rounded-lg')} />
        <div className={cn(skeletonBase, 'w-2/3 h-3 bg-white/5 rounded-lg')} />
      </div>
      <div className={cn(skeletonBase, 'w-20 h-8 rounded-lg bg-white/5')} />
    </motion.div>
  );
}

// Grid Skeleton
export function GridSkeleton({
  count = 8,
  columns = 4,
  itemSkeleton: ItemSkeleton = StatCardSkeleton,
}: {
  count?: number;
  columns?: number;
  itemSkeleton?: React.ComponentType;
}) {
  const gridCols = {
    2: 'sm:grid-cols-2',
    3: 'sm:grid-cols-2 lg:grid-cols-3',
    4: 'sm:grid-cols-2 lg:grid-cols-4',
    5: 'sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5',
  };

  return (
    <div className={cn('grid gap-4', gridCols[columns as keyof typeof gridCols] || gridCols[4])}>
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
        >
          <ItemSkeleton />
        </motion.div>
      ))}
    </div>
  );
}

// Full Page Skeleton
export function PageSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      {/* Header skeleton */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className={cn(skeletonBase, 'w-48 h-8 bg-white/10 rounded-lg')} />
          <div className={cn(skeletonBase, 'w-64 h-4 bg-white/5 rounded-lg')} />
        </div>
        <div className={cn(skeletonBase, 'w-32 h-10 bg-primary/10 rounded-xl')} />
      </div>

      {/* Stats skeleton */}
      <GridSkeleton count={4} columns={4} itemSkeleton={StatCardSkeleton} />

      {/* Content skeleton */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className={cn(skeletonBase, 'h-64 bg-white/5 rounded-2xl')} />
        <div className="lg:col-span-2 space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <ListItemSkeleton key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

// Sidebar Navigation Skeleton
export function SidebarSkeleton() {
  return (
    <div className="space-y-2 animate-pulse">
      {Array.from({ length: 6 }).map((_, i) => (
        <div
          key={i}
          className={cn(
            'flex items-center gap-3 px-3 py-2.5 rounded-xl',
            i === 0 ? 'bg-primary/10' : 'bg-white/2'
          )}
        >
          <div className={cn(skeletonBase, 'w-8 h-8 rounded-lg bg-white/5')} />
          <div className={cn(skeletonBase, 'w-20 h-4 bg-white/5 rounded-lg hidden sm:block')} />
        </div>
      ))}
    </div>
  );
}

// Header Skeleton
export function HeaderSkeleton() {
  return (
    <div className="flex items-center justify-between h-16 px-4 animate-pulse">
      <div className="flex items-center gap-4">
        <div className={cn(skeletonBase, 'w-10 h-10 rounded-xl bg-white/5 sm:hidden')} />
        <div className="space-y-1">
          <div className={cn(skeletonBase, 'w-32 h-6 bg-white/10 rounded-lg')} />
          <div className={cn(skeletonBase, 'w-48 h-3 bg-white/5 rounded-lg hidden sm:block')} />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className={cn(skeletonBase, 'w-10 h-10 rounded-xl bg-white/5')} />
        <div className={cn(skeletonBase, 'w-10 h-10 rounded-xl bg-white/5')} />
        <div className={cn(skeletonBase, 'w-9 h-9 rounded-xl bg-primary/10')} />
      </div>
    </div>
  );
}
