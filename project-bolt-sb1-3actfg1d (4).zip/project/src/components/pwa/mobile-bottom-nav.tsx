import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, Calendar, Ticket, Award, User } from 'lucide-react';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

const navItems = [
  { label: 'Home', icon: Home, path: '/' },
  { label: 'Events', icon: Calendar, path: '/events' },
  { label: 'Tickets', icon: Ticket, path: '/dashboard/student/my-registrations' },
  { label: 'Certificates', icon: Award, path: '/dashboard/student/my-certificates' },
  { label: 'Profile', icon: User, path: '/profile' },
];

export default function MobileBottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  if (!user) return null;

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', damping: 25, stiffness: 300 }}
      className="fixed bottom-0 left-0 right-0 z-40 md:hidden"
    >
      <div className="mx-2 mb-2 rounded-2xl border bg-card/95 backdrop-blur-xl shadow-2xl">
        <div className="flex items-center justify-around px-2 py-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;

            return (
              <button
                key={item.label}
                onClick={() => navigate(item.path)}
                className={cn(
                  'flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all',
                  isActive ? 'text-primary' : 'text-muted-foreground'
                )}
              >
                <motion.div
                  whileTap={{ scale: 0.9 }}
                  className={cn(
                    'w-9 h-9 rounded-lg flex items-center justify-center transition-colors',
                    isActive && 'bg-primary/10'
                  )}
                >
                  <Icon className="w-5 h-5" />
                </motion.div>
                <span className={cn('text-[10px] font-medium', isActive && 'text-primary')}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </motion.nav>
  );
}
