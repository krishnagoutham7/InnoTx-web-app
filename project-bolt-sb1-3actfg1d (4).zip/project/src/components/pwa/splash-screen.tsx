import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState } from 'react';

export default function SplashScreen() {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 to-slate-950"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="flex flex-col items-center"
          >
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-blue-500 to-blue-800 flex items-center justify-center mb-6 shadow-2xl shadow-blue-500/30">
              <span className="text-5xl font-extrabold text-white">I</span>
            </div>
            <h1 className="text-3xl font-extrabold text-white mb-1">InnoTex</h1>
            <p className="text-sm text-slate-400 mb-8">Innovation Ecosystem Platform</p>

            <div className="flex flex-col items-center gap-3 text-center">
              <p className="text-xs text-slate-500">IEDC</p>
              <p className="text-xs text-slate-500">Kerala Startup Mission</p>
              <p className="text-xs text-slate-500">Government Polytechnic College Adoor</p>
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="mt-8"
            >
              <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
