import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Clock, Users, Heart, ArrowRight, Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Event } from '@/types/events';

interface EventCardProps {
  event: Event;
  index?: number;
  showPoster?: boolean;
}

const categoryColors: Record<string, string> = {
  workshop: 'from-primary/30 to-primary/10 text-primary border-primary/30',
  seminar: 'from-secondary/30 to-secondary/10 text-secondary border-secondary/30',
  hackathon: 'from-accent/30 to-accent/10 text-accent border-accent/30',
  conference: 'from-warning/30 to-warning/10 text-warning border-warning/30',
  competition: 'from-success/30 to-success/10 text-success border-success/30',
  default: 'from-muted/30 to-muted/10 text-muted-foreground border-muted/30',
};

const statusColors: Record<string, string> = {
  upcoming: 'bg-primary/20 text-primary',
  ongoing: 'bg-success/20 text-success',
  completed: 'bg-muted text-muted-foreground',
  cancelled: 'bg-destructive/20 text-destructive',
};

export function EventCard({ event, index = 0, showPoster = true }: EventCardProps) {
  const categoryStyle = categoryColors[event.event_type?.toLowerCase()] || categoryColors.default;
  const statusStyle = statusColors[event.status] || statusColors.upcoming;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.4 }}
      whileHover={{ y: -8 }}
      className="group relative"
    >
      <div
        className={cn(
          'relative overflow-hidden rounded-2xl',
          'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
          'border border-white/5',
          'backdrop-blur-xl',
          'transition-all duration-500',
          'hover:border-white/10',
          'hover:shadow-2xl hover:shadow-black/20',
          'hover:shadow-primary/5'
        )}
      >
        {/* Poster Section */}
        {showPoster && (
          <div className="relative aspect-[16/9] overflow-hidden">
            {/* Gradient overlay for text readability */}
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent z-10" />

            {/* Event poster */}
            {event.poster_url ? (
              <img
                src={event.poster_url}
                alt={event.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 flex items-center justify-center">
                <Calendar className="w-16 h-16 text-white/20" />
              </div>
            )}

            {/* Status badge */}
            <div className="absolute top-3 left-3 z-20">
              <span className={cn(
                'px-3 py-1 rounded-full text-xs font-semibold',
                'backdrop-blur-xl border border-white/10',
                statusStyle
              )}>
                {event.status?.charAt(0).toUpperCase() + event.status?.slice(1)}
              </span>
            </div>

            {/* Category badge */}
            <div className="absolute top-3 right-3 z-20">
              <span className={cn(
                'px-3 py-1 rounded-full text-xs font-medium',
                'bg-gradient-to-r backdrop-blur-xl border',
                categoryStyle
              )}>
                {event.event_type || 'Event'}
              </span>
            </div>

            {/* Date overlay */}
            <div className="absolute bottom-3 left-3 z-20 flex items-center gap-2">
              <div className={cn(
                'flex flex-col items-center justify-center',
                'w-12 h-14 rounded-xl',
                'bg-background/90 backdrop-blur-xl',
                'border border-white/10'
              )}>
                <span className="text-xs font-medium text-primary uppercase">
                  {new Date(event.start_date).toLocaleDateString('en-US', { month: 'short' })}
                </span>
                <span className="text-xl font-bold">
                  {new Date(event.start_date).getDate()}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Content Section */}
        <div className="p-5">
          {/* Title */}
          <h3 className="font-semibold text-lg font-heading line-clamp-1 group-hover:text-primary transition-colors">
            {event.title}
          </h3>

          {/* Meta info */}
          <div className="mt-3 space-y-2">
            {event.start_time && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4 text-primary/60" />
                <span>
                  {event.start_time.slice(0, 5)}
                  {event.end_time ? ` — ${event.end_time.slice(0, 5)}` : ''}
                </span>
              </div>
            )}
            {event.venue && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4 text-secondary/60" />
                <span className="line-clamp-1">{event.venue}</span>
              </div>
            )}
            {event.max_participants !== undefined && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="w-4 h-4 text-accent/60" />
                <span>
                  <span className="text-foreground font-medium">{event.max_participants}</span> max participants
                </span>
              </div>
            )}
          </div>

          {/* Footer with likes and action */}
          <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {event.like_count !== undefined && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Heart className="w-4 h-4 text-rose-500" />
                  <span>{event.like_count}</span>
                </div>
              )}
              {event.registration_count !== undefined && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>{event.registration_count}</span>
                </div>
              )}
            </div>

            <Link
              to={`/events/${event.id}`}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium',
                'bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10',
                'hover:from-primary/20 hover:via-secondary/20 hover:to-accent/20',
                'transition-all duration-300',
                'group/link'
              )}
            >
              <span>View Details</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover/link:translate-x-1" />
            </Link>
          </div>
        </div>

        {/* Hover glow effect */}
        <div className="absolute -inset-1 bg-gradient-to-r from-primary/0 via-primary/5 to-accent/0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10 blur-xl" />
      </div>
    </motion.div>
  );
}

// Compact event card for sideways scrolling or smaller views
export function EventCardCompact({ event, index = 0 }: { event: Event; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ scale: 1.02 }}
      className="group"
    >
      <Link
        to={`/events/${event.id}`}
        className={cn(
          'flex items-center gap-4 p-3 rounded-xl',
          'bg-gradient-to-r from-white/3 to-transparent',
          'border border-white/5 hover:border-white/10',
          'transition-all duration-300'
        )}
      >
        {/* Mini poster */}
        <div className="w-16 h-16 rounded-lg overflow-hidden shrink-0">
          {event.poster_url ? (
            <img src={event.poster_url} alt={event.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-white/50" />
            </div>
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm line-clamp-1">{event.title}</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            {new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
          </p>
        </div>

        {/* Arrow */}
        <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </Link>
    </motion.div>
  );
}

// Featured event card with large display
export function EventCardFeatured({ event }: { event: Event }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="group relative"
    >
      <div
        className={cn(
          'relative overflow-hidden rounded-3xl',
          'bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10',
          'border border-white/10'
        )}
      >
        {/* Background */}
        {event.poster_url && (
          <div className="absolute inset-0">
            <img
              src={event.poster_url}
              alt={event.title}
              className="w-full h-full object-cover opacity-20 blur-sm"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/70" />
          </div>
        )}

        <div className="relative flex flex-col md:flex-row gap-6 p-6 md:p-8">
          {/* Poster */}
          <div className="md:w-1/3 aspect-[3/4] rounded-2xl overflow-hidden shadow-2xl">
            {event.poster_url ? (
              <img
                src={event.poster_url}
                alt={event.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-primary/30 via-secondary/30 to-accent/30 flex items-center justify-center">
                <Star className="w-16 h-16 text-white/30" />
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 flex flex-col justify-center">
            <div className="flex items-center gap-2 mb-3">
              <span className={cn(
                'px-3 py-1 rounded-full text-xs font-semibold',
                'bg-gradient-to-r from-primary/20 to-secondary/20',
                'text-primary border border-primary/20'
              )}>
                Featured
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent">
                {event.event_type || 'Event'}
              </span>
            </div>

            <h2 className="text-2xl md:text-3xl font-bold font-heading gradient-text">
              {event.title}
            </h2>

            <p className="text-muted-foreground mt-3 line-clamp-2 max-w-lg">
              Join us for this amazing event!
            </p>

            <div className="flex flex-wrap gap-4 mt-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                <span>{new Date(event.start_date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</span>
              </div>
              {event.start_time && (
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-secondary" />
                  <span>{event.start_time.slice(0, 5)}</span>
                </div>
              )}
              {event.venue && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-accent" />
                  <span>{event.venue}</span>
                </div>
              )}
            </div>

            <div className="mt-6">
              <Link
                to={`/events/${event.id}`}
                className={cn(
                  'inline-flex items-center gap-2 px-6 py-3 rounded-xl',
                  'bg-gradient-to-r from-primary via-secondary to-accent',
                  'text-white font-semibold',
                  'shadow-glow hover:shadow-glow-lg',
                  'transition-all duration-300',
                  'hover:scale-105'
                )}
              >
                <span>Register Now</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
