import { useState, useRef, useCallback } from 'react';
import { Upload, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface MediaUploadProps {
  eventId?: string;
  type: 'banner' | 'poster';
  currentUrl?: string | null;
  onUpload: (file: File) => Promise<string | { url: string; thumbnailUrl: string }>;
  onDelete?: () => Promise<void>;
  onUploadComplete?: (url: string) => void;
  disabled?: boolean;
  className?: string;
  aspectRatio?: 'banner' | 'poster' | 'square';
}

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_SIZE = 20 * 1024 * 1024; // 20MB

export default function MediaUpload({
  type,
  currentUrl,
  onUpload,
  onDelete,
  onUploadComplete,
  disabled = false,
  className,
  aspectRatio = 'banner',
}: MediaUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(currentUrl || null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const aspectClasses = {
    banner: 'aspect-[16/9]',
    poster: 'aspect-[3/4]',
    square: 'aspect-square',
  };

  const validateFile = (file: File): string | null => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return 'Invalid file type. Please upload JPG, PNG, WEBP, or GIF.';
    }
    if (file.size > MAX_SIZE) {
      return 'File is too large. Maximum size is 20MB.';
    }
    return null;
  };

  const handleFile = useCallback(async (file: File) => {
    const validationError = validateFile(file);
    if (validationError) {
      toast({ title: 'Invalid file', description: validationError, variant: 'destructive' });
      return;
    }

    // Show preview immediately
    const reader = new FileReader();
    reader.onload = (e) => setPreview(e.target?.result as string);
    reader.readAsDataURL(file);

    setUploading(true);
    try {
      const result = await onUpload(file);
      const url = typeof result === 'string' ? result : result.url;
      onUploadComplete?.(url);
      toast({ title: 'Success', description: `${type === 'banner' ? 'Banner' : 'Poster'} uploaded successfully` });
    } catch (err: any) {
      toast({ title: 'Upload failed', description: err.message, variant: 'destructive' });
      setPreview(currentUrl || null);
    } finally {
      setUploading(false);
    }
  }, [currentUrl, onUpload, onUploadComplete, toast, type]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOver(false);
  }, []);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDelete = async () => {
    if (!onDelete) return;
    setUploading(true);
    try {
      await onDelete();
      setPreview(null);
      onUploadComplete?.('');
      toast({ title: 'Success', description: `${type === 'banner' ? 'Banner' : 'Poster'} removed` });
    } catch (err: any) {
      toast({ title: 'Delete failed', description: err.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className={cn('space-y-3', className)}>
      <div
        className={cn(
          'relative border-2 border-dashed rounded-lg overflow-hidden transition-colors',
          aspectClasses[aspectRatio],
          dragOver ? 'border-primary bg-primary/5' : 'border-muted-foreground/25',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
      >
        {preview ? (
          <img
            src={preview}
            alt={`${type} preview`}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-muted/50 text-muted-foreground">
            <ImageIcon className="w-12 h-12 mb-2" />
            <p className="text-sm font-medium">{type === 'banner' ? 'Banner' : 'Poster'} Image</p>
            <p className="text-xs mt-1">Drag & drop or click to upload</p>
          </div>
        )}

        {uploading && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <Loader2 className="w-8 h-8 text-white animate-spin" />
          </div>
        )}

        {preview && !uploading && !disabled && (
          <Button
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2 h-8 w-8"
            onClick={handleDelete}
          >
            <X className="w-4 h-4" />
          </Button>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
          onChange={handleInputChange}
          disabled={disabled || uploading}
        />
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled || uploading}
        >
          <Upload className="w-4 h-4 mr-2" />
          {preview ? 'Replace' : 'Upload'} {type === 'banner' ? 'Banner' : 'Poster'}
        </Button>
        <span className="text-xs text-muted-foreground">
          JPG, PNG, WEBP, GIF (max 20MB)
        </span>
      </div>
    </div>
  );
}
