import { useRef, useState, useEffect, ReactNode } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CarouselProps {
  children: ReactNode;
  className?: string;
  itemWidth?: number;
  gap?: number;
  showArrows?: boolean;
  showDots?: boolean;
  autoPlay?: boolean;
  autoPlayInterval?: number;
}

export function Carousel({
  children,
  className,
  itemWidth = 320,
  gap = 16,
  showArrows = true,
  showDots = false,
  autoPlay = false,
  autoPlayInterval = 5000,
}: CarouselProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  const childCount = Array.isArray(children) ? children.length : 1;

  const checkScroll = () => {
    if (!containerRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = containerRef.current;
    setCanScrollLeft(scrollLeft > 0);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  const childArray = Array.isArray(children) ? children : [children];

  useEffect(() => {
    checkScroll();
    const container = containerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScroll);
      return () => container.removeEventListener('scroll', checkScroll);
    }
  }, []);

  useEffect(() => {
    if (!autoPlay || !containerRef.current) return;
    const interval = setInterval(() => {
      const container = containerRef.current;
      if (container) {
        const nextScroll = container.scrollLeft + itemWidth + gap;
        if (nextScroll >= container.scrollWidth - container.clientWidth) {
          container.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          container.scrollTo({ left: nextScroll, behavior: 'smooth' });
        }
      }
    }, autoPlayInterval);
    return () => clearInterval(interval);
  }, [autoPlay, autoPlayInterval, itemWidth, gap]);

  const scroll = (direction: 'left' | 'right') => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const scrollAmount = itemWidth + gap;
    const newScroll = direction === 'left'
      ? container.scrollLeft - scrollAmount
      : container.scrollLeft + scrollAmount;
    container.scrollTo({ left: newScroll, behavior: 'smooth' });
  };

  return (
    <div className={cn('relative group', className)}>
      {/* Left Arrow */}
      {showArrows && canScrollLeft && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => scroll('left')}
          className={cn(
            'absolute left-0 top-1/2 -translate-y-1/2 z-10',
            'w-10 h-10 rounded-full flex items-center justify-center',
            'bg-background/90 border border-white/10 backdrop-blur-xl',
            'shadow-lg hover:shadow-xl transition-shadow',
            '-ml-5'
          )}
        >
          <ChevronLeft className="w-5 h-5" />
        </motion.button>
      )}

      {/* Right Arrow */}
      {showArrows && canScrollRight && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => scroll('right')}
          className={cn(
            'absolute right-0 top-1/2 -translate-y-1/2 z-10',
            'w-10 h-10 rounded-full flex items-center justify-center',
            'bg-background/90 border border-white/10 backdrop-blur-xl',
            'shadow-lg hover:shadow-xl transition-shadow',
            '-mr-5'
          )}
        >
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      )}

      {/* Scrollable Container */}
      <div
        ref={containerRef}
        className={cn(
          'flex overflow-x-auto scrollbar-none',
          'gap-4',
          'snap-x snap-mandatory',
          'pb-2'
        )}
        style={{ scrollSnapType: 'x mandatory' }}
      >
        {childArray.map((child, index) => (
          <div
            key={index}
            className="flex-shrink-0 snap-start"
            style={{ width: itemWidth }}
          >
            {child}
          </div>
        ))}
      </div>

      {/* Dots */}
      {showDots && (
        <div className="flex justify-center gap-2 mt-4">
          {Array.from({ length: childCount }).map((_, index) => (
            <button
              key={index}
              onClick={() => {
                if (containerRef.current) {
                  containerRef.current.scrollTo({
                    left: index * (itemWidth + gap),
                    behavior: 'smooth',
                  });
                  setActiveIndex(index);
                }
              }}
              className={cn(
                'w-2 h-2 rounded-full transition-all',
                index === activeIndex
                  ? 'bg-primary w-4'
                  : 'bg-white/20 hover:bg-white/40'
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Mini carousel for compact sections
export function MiniCarousel({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <Carousel
      itemWidth={240}
      gap={12}
      className={className}
      showArrows={false}
    >
      {children}
    </Carousel>
  );
}

// Featured carousel for hero sections
export function FeaturedCarousel({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <Carousel
      itemWidth={500}
      gap={20}
      className={className}
      showArrows={true}
      showDots={true}
    >
      {children}
    </Carousel>
  );
}
