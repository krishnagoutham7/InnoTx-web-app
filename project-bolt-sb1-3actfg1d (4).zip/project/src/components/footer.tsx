import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb, Github, Twitter, Linkedin, Instagram, Mail, GraduationCap, ExternalLink } from 'lucide-react';
import { getCollegeInfo, getContactInfo } from '@/services/cms';
import type { CollegeInfo, ContactInfo } from '@/services/cms';

const footerNav = [
  { label: 'Home', path: '/' },
  { label: 'About', path: '/about' },
  { label: 'Team', path: '/team' },
  { label: 'Gallery', path: '/gallery' },
  { label: 'Contact', path: '/contact' },
];

const resources = [
  { label: 'Kerala Startup Mission', href: 'https://startupmission.kerala.gov.in' },
  { label: 'IEDC Network', href: 'https://iedc.kerala.gov.in' },
  { label: 'Innovation Policy', href: '#' },
  { label: 'Startup Resources', href: '#' },
];

const socialIconMap: Record<string, typeof Instagram> = {
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  github: Github,
  mail: Mail,
};

export default function Footer() {
  const [college, setCollege] = useState<CollegeInfo | null>(null);
  const [contact, setContact] = useState<ContactInfo | null>(null);

  useEffect(() => {
    getCollegeInfo().then(d => { if (d) setCollege(d); }).catch(() => {});
    getContactInfo().then(d => { if (d) setContact(d); }).catch(() => {});
  }, []);

  const socials = contact
    ? [
        { icon: 'instagram', label: 'Instagram', href: contact.instagram_url },
        { icon: 'twitter', label: 'Twitter', href: contact.twitter_url },
        { icon: 'linkedin', label: 'LinkedIn', href: contact.linkedin_url },
        { icon: 'github', label: 'GitHub', href: contact.github_url },
        { icon: 'mail', label: 'Email', href: contact.mail_url },
      ]
    : [];

  return (
    <footer className="border-t bg-card/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-12 lg:py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <Link to="/" className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
                <Lightbulb className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight">{college?.portal_name || 'InnoTex'}</span>
                <span className="text-[10px] leading-tight text-muted-foreground tracking-wide">
                  {college?.short_name || ''}
                </span>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs mb-2">
              {college?.portal_tagline || ''}
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              Empowering innovation and entrepreneurship through the IEDC at {college?.name || ''}.
            </p>
            <div className="flex items-center gap-2 mt-5">
              {socials.map((social) => {
                const Icon = socialIconMap[social.icon] || Mail;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-4">Portal</h3>
            <ul className="space-y-2.5">
              {footerNav.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-4">Resources</h3>
            <ul className="space-y-2.5">
              {resources.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-1"
                  >
                    {link.label}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-4">Contact</h3>
            <div className="space-y-2.5 text-sm text-muted-foreground">
              <p className="flex items-start gap-2">
                <GraduationCap className="w-4 h-4 mt-0.5 shrink-0 text-primary" />
                <span>{college?.name || ''}</span>
              </p>
              <p>{college?.address || ''}</p>
              <a href={`mailto:${contact?.email || college?.email || ''}`} className="block hover:text-foreground transition-colors">
                {contact?.email || college?.email || ''}
              </a>
              <a href={`tel:${contact?.phone || college?.phone || ''}`} className="block hover:text-foreground transition-colors">
                {contact?.phone || college?.phone || ''}
              </a>
            </div>
          </div>
        </div>

        <div className="py-6 border-t flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} {college?.portal_name || 'InnoTex'}, {college?.short_name || ''}. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Supported by Kerala Startup Mission
          </p>
        </div>
      </div>
    </footer>
  );
}
