import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bell, Check, CheckCheck, Loader2, Calendar, Users, Award, Megaphone, Trash2, Filter, Search, CheckCircle, Ticket, UserCheck, UserX, KeyRound, ArrowRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { useNotifications } from '@/hooks/use-notifications';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const priorityColors: Record<string, string> = {
  low: 'border-l-gray-400 bg-gray-50/50',
  medium: 'border-l-blue-500 bg-blue-50/50',
  high: 'border-l-orange-500 bg-orange-50/50',
  critical: 'border-l-red-500 bg-red-50/50',
};

const typeIcons: Record<string, React.ElementType> = {
  event_alert: Calendar,
  event_published: Calendar,
  meeting_alert: Users,
  certificate_available: Award,
  certificate_generated: Award,
  announcement: Megaphone,
  registration_submitted: UserCheck,
  registration_approved: CheckCircle,
  registration_rejected: UserX,
  ticket_generated: Ticket,
  attendance_verified: CheckCheck,
  role_changed: Users,
  password_reset: KeyRound,
  custom: Bell,
};

const typeLabels: Record<string, string> = {
  event_alert: 'Event Alert',
  event_published: 'Event Published',
  meeting_alert: 'Meeting',
  certificate_available: 'Certificate',
  certificate_generated: 'Certificate Generated',
  announcement: 'Announcement',
  registration_submitted: 'Registration Submitted',
  registration_approved: 'Registration Approved',
  registration_rejected: 'Registration Rejected',
  ticket_generated: 'Ticket Generated',
  attendance_verified: 'Attendance Verified',
  role_changed: 'Role Changed',
  password_reset: 'Password Reset',
  custom: 'Notification',
};

export default function NotificationCenter() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { notifications, unreadCount, loading, markAsRead, markAllRead, deleteNotification } = useNotifications();
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  async function handleMarkAllAsRead() {
    try {
      await markAllRead();
      toast({ title: 'Success', description: 'All notifications marked as read' });
    } catch {
      toast({ title: 'Error', description: 'Failed to mark all as read', variant: 'destructive' });
    }
  }

  async function handleDelete(id: string) {
    try {
      await deleteNotification(id);
      toast({ title: 'Deleted', description: 'Notification removed' });
    } catch {
      toast({ title: 'Error', description: 'Failed to delete notification', variant: 'destructive' });
    }
  }

  function handleAction(notif: any) {
    markAsRead(notif.id);
    const actionUrl = notif.notification?.action_url;
    if (actionUrl) navigate(actionUrl);
  }

  const filtered = useMemo(() => notifications.filter((n) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch = !q || n.notification?.title?.toLowerCase().includes(q) || n.notification?.message?.toLowerCase().includes(q);
    const matchesType = typeFilter === 'all' || n.notification?.notification_type === typeFilter;
    return matchesSearch && matchesType;
  }), [notifications, searchQuery, typeFilter]);

  const unread = filtered.filter((n) => !n.is_read);
  const read = filtered.filter((n) => n.is_read);

  function NotificationCard({ un }: { un: any }) {
    const Icon = typeIcons[un.notification?.notification_type || 'custom'] || Bell;
    const priority = un.notification?.priority_level || 'medium';
    const actionUrl = un.notification?.action_url;

    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={cn('rounded-lg border-l-4 p-4 transition-all', priorityColors[priority], un.is_read ? 'opacity-70' : 'bg-card shadow-sm')}
      >
        <div className="flex gap-4">
          <div className={cn('w-12 h-12 rounded-full flex items-center justify-center shrink-0', un.is_read ? 'bg-muted' : 'bg-primary/10')}>
            <Icon className={cn('w-6 h-6', un.is_read ? 'text-muted-foreground' : 'text-primary')} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold text-lg">{un.notification?.title}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-xs">{typeLabels[un.notification?.notification_type || 'custom']}</Badge>
                  <Badge variant="secondary" className={cn('text-xs', priority === 'critical' && 'bg-red-100 text-red-700', priority === 'high' && 'bg-orange-100 text-orange-700', priority === 'medium' && 'bg-blue-100 text-blue-700', priority === 'low' && 'bg-gray-100 text-gray-700')}>{priority}</Badge>
                </div>
              </div>
              {!un.is_read && <div className="w-3 h-3 rounded-full bg-primary shrink-0" />}
            </div>
            <p className="text-muted-foreground mt-2">{un.notification?.message}</p>
            <div className="flex items-center justify-between mt-3">
              <p className="text-xs text-muted-foreground">{new Date(un.created_at).toLocaleString()}</p>
              <div className="flex items-center gap-2">
                {actionUrl && (
                  <Button variant="ghost" size="sm" onClick={() => handleAction(un)}>
                    View <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                )}
                {!un.is_read && (
                  <Button variant="ghost" size="sm" onClick={() => markAsRead(un.id)}>
                    <Check className="w-4 h-4 mr-1" /> Mark Read
                  </Button>
                )}
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => handleDelete(un.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <section className="relative pt-32 pb-12">
          <div className="absolute inset-0 -z-10">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent" />
            <div className="absolute top-1/3 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
            <div className="absolute bottom-1/3 right-1/4 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
          </div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-center max-w-3xl mx-auto">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <Bell className="w-8 h-8 text-primary" />
              </div>
              <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-[1.1] mb-4">
                Notification <span className="gradient-text">Center</span>
              </h1>
              <p className="text-lg text-muted-foreground">Stay updated with alerts, announcements, and important messages.</p>
              {unreadCount > 0 && (
                <div className="mt-4 flex items-center justify-center gap-2">
                  <Badge className="bg-primary text-white">{unreadCount} unread notification{unreadCount > 1 ? 's' : ''}</Badge>
                  <Button variant="outline" size="sm" onClick={handleMarkAllAsRead}>
                    <CheckCheck className="w-4 h-4 mr-1" /> Mark All Read
                  </Button>
                </div>
              )}
            </motion.div>
          </div>
        </section>

        <section className="py-6">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input placeholder="Search notifications..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10" />
                  </div>
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-full sm:w-48">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="registration_submitted">Registration Submitted</SelectItem>
                      <SelectItem value="registration_approved">Registration Approved</SelectItem>
                      <SelectItem value="registration_rejected">Registration Rejected</SelectItem>
                      <SelectItem value="ticket_generated">Ticket Generated</SelectItem>
                      <SelectItem value="attendance_verified">Attendance Verified</SelectItem>
                      <SelectItem value="certificate_generated">Certificate Generated</SelectItem>
                      <SelectItem value="certificate_available">Certificate Available</SelectItem>
                      <SelectItem value="role_changed">Role Changed</SelectItem>
                      <SelectItem value="password_reset">Password Reset</SelectItem>
                      <SelectItem value="event_published">Event Published</SelectItem>
                      <SelectItem value="event_alert">Event Alerts</SelectItem>
                      <SelectItem value="announcement">Announcements</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="pb-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="all">All ({filtered.length})</TabsTrigger>
                <TabsTrigger value="unread">Unread ({unread.length})</TabsTrigger>
                <TabsTrigger value="read">Read ({read.length})</TabsTrigger>
              </TabsList>

              {['all', 'unread', 'read'].map((tab) => {
                const list = tab === 'all' ? filtered : tab === 'unread' ? unread : read;
                return (
                  <TabsContent key={tab} value={tab} className="space-y-4">
                    {loading ? (
                      <div className="flex items-center justify-center py-12">
                        <Loader2 className="w-8 h-8 animate-spin text-primary" />
                      </div>
                    ) : list.length === 0 ? (
                      <Card>
                        <CardContent className="py-12 text-center text-muted-foreground">
                          <Bell className="w-12 h-12 mx-auto mb-4 opacity-30" />
                          <p>{tab === 'unread' ? 'All caught up! No unread notifications.' : 'No notifications found'}</p>
                        </CardContent>
                      </Card>
                    ) : (
                      list.map((un) => <NotificationCard key={un.id} un={un} />)
                    )}
                  </TabsContent>
                );
              })}
            </Tabs>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
