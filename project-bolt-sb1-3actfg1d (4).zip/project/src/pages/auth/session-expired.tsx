import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, ArrowLeft, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SessionExpiredPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center max-w-md"
      >
        <Link to="/" className="inline-flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
            <Lightbulb className="w-6 h-6 text-white" />
          </div>
          <div className="text-left">
            <span className="text-xl font-bold leading-tight">InnoTex</span>
            <span className="block text-xs text-muted-foreground">IEDC Portal</span>
          </div>
        </Link>

        <div className="w-20 h-20 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto mb-6">
          <Clock className="w-10 h-10 text-amber-500" />
        </div>

        <h1 className="text-3xl font-bold mb-3">Session Expired</h1>
        <p className="text-muted-foreground mb-8">
          Your session has expired due to inactivity. Please sign in again to continue
          accessing your account.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link to="/login">
            <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20">
              Sign In Again
            </Button>
          </Link>
          <Link to="/">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
