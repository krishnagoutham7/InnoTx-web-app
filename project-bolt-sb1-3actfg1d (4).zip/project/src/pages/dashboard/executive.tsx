import { DashboardLayout } from '@/components/dashboard/dashboard-layout';

export default function ExecutiveDashboard() {
  return <DashboardLayout title="Executive Dashboard" requiredRole="executive" />;
}
