import { DashboardLayout } from '@/components/dashboard/dashboard-layout';

export default function CEODashboard() {
  return <DashboardLayout title="CEO Dashboard" requiredRole="ceo" />;
}
