import { DashboardLayout } from '@/components/dashboard/dashboard-layout';

export default function SuperAdminDashboard() {
  return <DashboardLayout title="Super Admin Dashboard" requiredRole="super_admin" />;
}
