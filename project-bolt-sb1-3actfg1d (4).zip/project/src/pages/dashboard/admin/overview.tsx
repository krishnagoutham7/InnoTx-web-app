import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { StatCard, ActivityFeed, QuickAction } from '@/components/dashboard/widgets';
import { getDashboardStats } from '@/services/cms';
import { getAnnouncements } from '@/services/cms';
import type { DashboardStats, Announcement } from '@/services/cms';

export default function AdminOverview() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentAnnouncements, setRecentAnnouncements] = useState<Announcement[]>([]);

  useEffect(() => {
    getDashboardStats().then(setStats).catch(() => {});
    getAnnouncements().then(a => setRecentAnnouncements(a.slice(0, 5))).catch(() => {});
  }, []);

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
            <p className="text-sm text-muted-foreground">Content and operations management</p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Team Members" value={stats?.total_team_members ?? '—'} icon="Users" color="primary" />
          <StatCard title="Announcements" value={stats?.total_announcements ?? '—'} icon="Megaphone" color="accent" />
          <StatCard title="Gallery Images" value={stats?.total_gallery_images ?? '—'} icon="Images" color="success" />
          <StatCard title="Albums" value={stats?.total_albums ?? '—'} icon="Folder" color="warning" />
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="glass-card rounded-xl border-0 shadow-lg p-4">
            <h3 className="font-semibold mb-4">Quick Actions</h3>
            <div className="space-y-1">
              <QuickAction title="Manage Team" description="Add or edit team members" icon="Users" href="/dashboard/admin/team" />
              <QuickAction title="Update Gallery" description="Upload and organize images" icon="Images" href="/dashboard/admin/gallery" />
              <QuickAction title="Create Announcement" description="Publish news and updates" icon="Megaphone" href="/dashboard/admin/announcements" />
              <QuickAction title="Edit Homepage" description="Update homepage content" icon="Home" href="/dashboard/admin/homepage" />
            </div>
          </div>

          <div className="lg:col-span-2">
            <ActivityFeed title="Recent Announcements" activities={recentAnnouncements.map(a => ({
              id: a.id,
              title: a.title,
              description: a.description || '',
              time: a.publish_date ? new Date(a.publish_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : new Date(a.created_at).toLocaleDateString(),
              type: a.priority === 'high' ? 'warning' : a.status === 'published' ? 'success' : 'info',
            }))} />
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
