import { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Save, Loader2 } from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createEvent, updateEvent, getEventById, getEventCategories } from '@/services/events';
import type { EventFormData, EventCategory } from '@/types/events';
import { eventTypes, emptyEventForm } from '@/types/events';
import { useToast } from '@/hooks/use-toast';

interface Props {
  mode: 'create' | 'edit';
}

export default function AdminEventFormPage({ mode }: Props) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [form, setForm] = useState<EventFormData>(emptyEventForm);
  const [categories, setCategories] = useState<EventCategory[]>([]);
  const [loading, setLoading] = useState(mode === 'edit');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const cats = await getEventCategories();
        setCategories(cats);
        if (mode === 'edit' && id) {
          const evt = await getEventById(id);
          if (evt) {
            setForm({
              title: evt.title,
              short_description: evt.short_description || '',
              full_description: evt.full_description || '',
              category_id: evt.category_id || '',
              event_type: evt.event_type,
              status: evt.status,
              start_date: evt.start_date,
              end_date: evt.end_date || '',
              start_time: evt.start_time || '',
              end_time: evt.end_time || '',
              venue: evt.venue || '',
              max_participants: evt.max_participants?.toString() || '',
              registration_deadline: evt.registration_deadline || '',
              organizer_name: evt.organizer_name || '',
              organizer_email: evt.organizer_email || '',
              is_featured: evt.is_featured,
            });
          }
        }
      } catch {
        toast({ title: 'Error', description: 'Failed to load data', variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [mode, id]);

  const set = (key: keyof EventFormData, value: string | boolean) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.start_date || !form.event_type) {
      toast({ title: 'Validation Error', description: 'Title, start date, and event type are required', variant: 'destructive' });
      return;
    }
    try {
      setSaving(true);
      if (mode === 'create') {
        await createEvent(form);
        toast({ title: 'Created!', description: `"${form.title}" has been created` });
      } else if (id) {
        await updateEvent(id, form);
        toast({ title: 'Updated!', description: `"${form.title}" has been updated` });
      }
      navigate('/dashboard/admin/events');
    } catch (err: any) {
      toast({ title: 'Save Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="admin">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout requiredRole="admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title={mode === 'create' ? 'Create Event' : 'Edit Event'}
          description={mode === 'create' ? 'Create a new event' : 'Update event details'}
          actions={
            <Button variant="outline" asChild>
              <Link to="/dashboard/admin/events"><ArrowLeft className="w-4 h-4 mr-2" />Back</Link>
            </Button>
          }
        />

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Basic Information</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1.5">
                    <Label>Event Title <span className="text-destructive">*</span></Label>
                    <Input value={form.title} onChange={e => set('title', e.target.value)} placeholder="Enter event title" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Short Description</Label>
                    <Textarea value={form.short_description} onChange={e => set('short_description', e.target.value)} placeholder="Brief summary" rows={2} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Full Description</Label>
                    <Textarea value={form.full_description} onChange={e => set('full_description', e.target.value)} placeholder="Detailed description" rows={5} />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Date & Time</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Start Date <span className="text-destructive">*</span></Label>
                      <Input type="date" value={form.start_date} onChange={e => set('start_date', e.target.value)} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>End Date</Label>
                      <Input type="date" value={form.end_date} onChange={e => set('end_date', e.target.value)} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Start Time</Label>
                      <Input type="time" value={form.start_time} onChange={e => set('start_time', e.target.value)} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>End Time</Label>
                      <Input type="time" value={form.end_time} onChange={e => set('end_time', e.target.value)} />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Registration Deadline</Label>
                    <Input type="date" value={form.registration_deadline} onChange={e => set('registration_deadline', e.target.value)} />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Organizer</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Organizer Name</Label>
                      <Input value={form.organizer_name} onChange={e => set('organizer_name', e.target.value)} placeholder="Name" />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Organizer Email</Label>
                      <Input type="email" value={form.organizer_email} onChange={e => set('organizer_email', e.target.value)} placeholder="email@example.com" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-5">
              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Settings</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1.5">
                    <Label>Event Type <span className="text-destructive">*</span></Label>
                    <Select value={form.event_type} onValueChange={v => set('event_type', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {eventTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Status</Label>
                    <Select value={form.status} onValueChange={v => set('status', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {['draft', 'published', 'upcoming', 'ongoing', 'completed', 'cancelled', 'archived'].map(s => (
                          <SelectItem key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Category</Label>
                    <Select value={form.category_id || 'none'} onValueChange={v => set('category_id', v === 'none' ? '' : v)}>
                      <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Venue</Label>
                    <Input value={form.venue} onChange={e => set('venue', e.target.value)} placeholder="e.g. Main Auditorium" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Max Participants</Label>
                    <Input type="number" min="1" value={form.max_participants} onChange={e => set('max_participants', e.target.value)} placeholder="Leave empty for unlimited" />
                  </div>
                  <div className="flex items-center justify-between py-1">
                    <Label htmlFor="featured-admin">Featured Event</Label>
                    <Switch id="featured-admin" checked={form.is_featured} onCheckedChange={v => set('is_featured', v)} />
                  </div>
                </CardContent>
              </Card>

              <Button type="submit" className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90" disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                {saving ? 'Saving...' : mode === 'create' ? 'Create Event' : 'Save Changes'}
              </Button>
            </div>
          </div>
        </form>
      </motion.div>
    </DashboardLayout>
  );
}
