import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, Pencil, CheckCircle, Archive, Loader2, Plus } from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { DataTable, PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { StatCard } from '@/components/dashboard/widgets';
import { getAllEvents, publishEvent, archiveEvent } from '@/services/events';
import type { Event } from '@/types/events';
import { eventStatusConfig } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function AdminEventsPage() {
  const { toast } = useToast();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAllEvents()
      .then(setEvents)
      .catch(() => toast({ title: 'Error', description: 'Failed to load events', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  const handlePublish = async (event: Event) => {
    try {
      const updated = await publishEvent(event.id);
      setEvents(prev => prev.map(e => e.id === event.id ? updated : e));
      toast({ title: 'Published', description: `"${event.title}" is now published` });
    } catch {
      toast({ title: 'Error', description: 'Failed to publish event', variant: 'destructive' });
    }
  };

  const handleArchive = async (event: Event) => {
    try {
      const updated = await archiveEvent(event.id);
      setEvents(prev => prev.map(e => e.id === event.id ? updated : e));
      toast({ title: 'Archived', description: `"${event.title}" has been archived` });
    } catch {
      toast({ title: 'Error', description: 'Failed to archive event', variant: 'destructive' });
    }
  };

  const stats = {
    total: events.length,
    published: events.filter(e => ['published', 'upcoming'].includes(e.status)).length,
    ongoing: events.filter(e => e.status === 'ongoing').length,
    completed: events.filter(e => e.status === 'completed').length,
  };

  return (
    <DashboardLayout requiredRole="admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Events"
          description="View and manage portal events"
          actions={
            <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" asChild>
              <Link to="/dashboard/admin/events/create">
                <Plus className="w-4 h-4" /> New Event
              </Link>
            </Button>
          }
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Events" value={stats.total} icon="Calendar" color="primary" />
          <StatCard title="Published" value={stats.published} icon="CheckCircle" color="success" />
          <StatCard title="Ongoing" value={stats.ongoing} icon="Activity" color="accent" />
          <StatCard title="Completed" value={stats.completed} icon="Archive" color="warning" />
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <DataTable
            data={events}
            columns={[
              {
                key: 'title',
                header: 'Event',
                render: (e) => (
                  <div>
                    <p className="font-medium line-clamp-1">{e.title}</p>
                    <p className="text-xs text-muted-foreground">{e.event_type}</p>
                  </div>
                ),
              },
              {
                key: 'status',
                header: 'Status',
                render: (e) => {
                  const conf = eventStatusConfig[e.status];
                  return (
                    <span className={cn('text-xs font-medium px-2.5 py-1 rounded-full', conf.bg, conf.color)}>
                      {conf.label}
                    </span>
                  );
                },
              },
              {
                key: 'start_date',
                header: 'Date',
                render: (e) => (
                  <span className="text-sm text-muted-foreground">
                    {new Date(e.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                ),
              },
              {
                key: 'venue',
                header: 'Venue',
                render: (e) => <span className="text-sm text-muted-foreground">{e.venue || '—'}</span>,
              },
            ]}
            searchKeys={['title', 'event_type', 'venue']}
            searchPlaceholder="Search events..."
            actions={(e) => (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" title="View" asChild>
                  <Link to={`/events/${e.id}`} target="_blank"><Eye className="w-4 h-4" /></Link>
                </Button>
                <Button variant="ghost" size="icon" title="Edit" asChild>
                  <Link to={`/dashboard/admin/events/${e.id}/edit`}><Pencil className="w-4 h-4" /></Link>
                </Button>
                {e.status === 'draft' && (
                  <Button variant="ghost" size="icon" title="Publish" onClick={() => handlePublish(e)}>
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                  </Button>
                )}
                {['published', 'upcoming', 'ongoing', 'completed'].includes(e.status) && (
                  <Button variant="ghost" size="icon" title="Archive" onClick={() => handleArchive(e)}>
                    <Archive className="w-4 h-4 text-amber-500" />
                  </Button>
                )}
              </div>
            )}
          />
        )}
      </motion.div>
    </DashboardLayout>
  );
}
