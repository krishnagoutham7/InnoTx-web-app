import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Calendar,
  Clock,
  MapPin,
  Ticket,
  CheckCircle,
  XCircle,
  Loader2,
  AlertTriangle,
  FileText,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { getUserRegistrations } from '@/services/events';
import type { Event } from '@/types/events';
import type { EventRegistration } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { format } from 'date-fns';

interface RegistrationWithEvent extends EventRegistration {
  event?: Event;
}

const statusConfig: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800 border-yellow-200', icon: Clock },
  approved: { label: 'Approved', color: 'bg-green-100 text-green-800 border-green-200', icon: CheckCircle },
  rejected: { label: 'Rejected', color: 'bg-red-100 text-red-800 border-red-200', icon: XCircle },
  cancelled: { label: 'Cancelled', color: 'bg-gray-100 text-gray-800 border-gray-200', icon: XCircle },
  waitlisted: { label: 'Waitlisted', color: 'bg-blue-100 text-blue-800 border-blue-200', icon: AlertTriangle },
};

const certificateStatusConfig: Record<string, { label: string; color: string }> = {
  not_eligible: { label: 'Not Eligible', color: 'bg-gray-100 text-gray-600' },
  eligible: { label: 'Eligible', color: 'bg-blue-100 text-blue-800' },
  generated: { label: 'Generated', color: 'bg-purple-100 text-purple-800' },
  issued: { label: 'Issued', color: 'bg-green-100 text-green-800' },
};

export default function StudentRegistrationsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [registrations, setRegistrations] = useState<RegistrationWithEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      loadRegistrations();
    } else {
      setLoading(false);
    }
  }, [user]);

  async function loadRegistrations() {
    try {
      setLoading(true);
      const data = await getUserRegistrations(user!.id);
      setRegistrations(data);
    } catch {
      toast({ title: 'Error', description: 'Failed to load registrations', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  function handleViewTicket(qrCode: string) {
    navigate(`/ticket/${qrCode}`);
  }

  const pendingRegs = registrations.filter(r => r.approval_status === 'pending');
  const approvedRegs = registrations.filter(r => r.approval_status === 'approved');
  const rejectedRegs = registrations.filter(r => r.approval_status === 'rejected');
  const cancelledRegs = registrations.filter(r => r.approval_status === 'cancelled');

  return (
    <DashboardLayout requiredRole="student">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">My Registrations</h1>
            <p className="text-muted-foreground">Track your event registration status</p>
          </div>
          <Button asChild>
            <Link to="/events">
              <Calendar className="w-4 h-4 mr-2" />
              Browse Events
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{registrations.length}</div>
              <p className="text-sm text-muted-foreground">Total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-yellow-600">{pendingRegs.length}</div>
              <p className="text-sm text-muted-foreground">Pending</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-green-600">{approvedRegs.length}</div>
              <p className="text-sm text-muted-foreground">Approved</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-red-600">{rejectedRegs.length}</div>
              <p className="text-sm text-muted-foreground">Rejected</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-gray-600">{cancelledRegs.length}</div>
              <p className="text-sm text-muted-foreground">Cancelled</p>
            </CardContent>
          </Card>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : registrations.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Calendar className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-semibold mb-2">No Registrations Yet</h2>
              <p className="text-muted-foreground mb-4">
                Register for an event to track your status here
              </p>
              <Button asChild>
                <Link to="/events">Browse Events</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="all">
            <TabsList className="flex-wrap">
              <TabsTrigger value="all">All ({registrations.length})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({pendingRegs.length})</TabsTrigger>
              <TabsTrigger value="approved">Approved ({approvedRegs.length})</TabsTrigger>
              <TabsTrigger value="rejected">Rejected ({rejectedRegs.length})</TabsTrigger>
              <TabsTrigger value="cancelled">Cancelled ({cancelledRegs.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-4 space-y-4">
              {registrations.map(renderRegistration)}
            </TabsContent>

            <TabsContent value="pending" className="mt-4 space-y-4">
              {pendingRegs.length === 0 ? (
                <Card><CardContent className="py-8 text-center text-muted-foreground">No pending registrations</CardContent></Card>
              ) : (
                pendingRegs.map(renderRegistration)
              )}
            </TabsContent>

            <TabsContent value="approved" className="mt-4 space-y-4">
              {approvedRegs.length === 0 ? (
                <Card><CardContent className="py-8 text-center text-muted-foreground">No approved registrations</CardContent></Card>
              ) : (
                approvedRegs.map(renderRegistration)
              )}
            </TabsContent>

            <TabsContent value="rejected" className="mt-4 space-y-4">
              {rejectedRegs.length === 0 ? (
                <Card><CardContent className="py-8 text-center text-muted-foreground">No rejected registrations</CardContent></Card>
              ) : (
                rejectedRegs.map(renderRegistration)
              )}
            </TabsContent>

            <TabsContent value="cancelled" className="mt-4 space-y-4">
              {cancelledRegs.length === 0 ? (
                <Card><CardContent className="py-8 text-center text-muted-foreground">No cancelled registrations</CardContent></Card>
              ) : (
                cancelledRegs.map(renderRegistration)
              )}
            </TabsContent>
          </Tabs>
        )}
      </motion.div>
    </DashboardLayout>
  );

  function renderRegistration(reg: RegistrationWithEvent) {
    const event = reg.event;
    const status = reg.approval_status || 'pending';
    const config = statusConfig[status] || statusConfig.pending;
    const StatusIcon = config.icon;
    const certStatus = reg.certificate_status || 'not_eligible';
    const certConfig = certificateStatusConfig[certStatus] || certificateStatusConfig.not_eligible;

    return (
      <Card key={reg.id} className={status === 'approved' ? 'border-green-200' : status === 'rejected' ? 'border-red-200' : status === 'cancelled' ? 'border-gray-200 opacity-60' : ''}>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Event Info */}
            <div className="flex-1 space-y-2">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold">{event?.title || 'Unknown Event'}</h3>
                  <p className="text-xs text-muted-foreground">
                    Registered: {reg.registered_at ? format(new Date(reg.registered_at), 'PPp') : 'N/A'}
                  </p>
                </div>
                <Badge className={config.color}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  {config.label}
                </Badge>
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                {event?.start_date && (
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {format(new Date(event.start_date), 'MMM d, yyyy')}
                  </div>
                )}
                {event?.start_time && (
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {event.start_time}
                  </div>
                )}
                {event?.venue && (
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {event.venue}
                  </div>
                )}
              </div>

              {/* Remarks */}
              {reg.remarks && (
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm"><strong>Remarks:</strong> {reg.remarks}</p>
                </div>
              )}

              {/* Additional Info */}
              {reg.department && (
                <p className="text-xs text-muted-foreground">Department: {reg.department}</p>
              )}

              {/* Certificate Status */}
              {status === 'approved' && (
                <div className="flex items-center gap-2 mt-2">
                  <FileText className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">Certificate:</span>
                  <Badge variant="outline" className={certConfig.color}>
                    {certConfig.label}
                  </Badge>
                </div>
              )}
            </div>

            {/* Actions */}
            {status === 'approved' && reg.qr_code && (
              <div className="flex flex-col gap-2">
                <Button
                  size="sm"
                  onClick={() => handleViewTicket(reg.qr_code!)}
                >
                  <Ticket className="w-4 h-4 mr-1" />
                  View Ticket
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }
}
