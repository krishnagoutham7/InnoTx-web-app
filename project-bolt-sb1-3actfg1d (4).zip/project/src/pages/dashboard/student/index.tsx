import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { StatCard, ActivityFeed } from '@/components/dashboard/widgets';
import { getPublishedAnnouncements } from '@/services/cms';
import type { Announcement } from '@/services/cms';
import { getUpcomingEvents } from '@/services/events';
import type { Event } from '@/types/events';

export default function StudentDashboard() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    getPublishedAnnouncements().then(a => setAnnouncements(a.slice(0, 5))).catch(() => {});
    getUpcomingEvents(3).then(setEvents).catch(() => {});
  }, []);

  return (
    <DashboardLayout requiredRole="student">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Student Dashboard</h1>
          <p className="text-sm text-muted-foreground">Your innovation journey starts here</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Upcoming Events" value={events.length} icon="Calendar" color="primary" />
          <StatCard title="Announcements" value={announcements.length} icon="Megaphone" color="accent" />
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <ActivityFeed title="Latest Announcements" activities={announcements.map(a => ({
            id: a.id,
            title: a.title,
            description: a.description || '',
            time: a.publish_date ? new Date(a.publish_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : new Date(a.created_at).toLocaleDateString(),
            type: a.priority === 'high' ? 'warning' : 'info',
          }))} />

          <div className="glass-card rounded-xl border-0 shadow-lg p-4">
            <h3 className="font-semibold mb-4">Upcoming Events</h3>
            {events.length > 0 ? (
              <div className="grid sm:grid-cols-1 gap-4">
                {events.map(event => (
                  <div key={event.id} className="p-4 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20">
                    <p className="text-sm font-medium">{event.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </p>
                    {event.start_time && (
                      <p className="text-xs text-primary">{event.start_time.slice(0, 5)}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No upcoming events at this time.</p>
            )}
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
