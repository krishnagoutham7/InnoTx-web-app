import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, MapPin, Clock, CheckCircle, X, ArrowRight, Sparkles, Ticket } from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { Button } from '@/components/ui/button';
import { getRegistrationsByEmail } from '@/services/events';
import type { EventRegistration } from '@/types/events';
import { eventStatusConfig } from '@/types/events';
import { useAuth } from '@/contexts/auth';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } }
};

export default function StudentEventsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [registrations, setRegistrations] = useState<EventRegistration[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.email) {
      setLoading(false);
      return;
    }
    getRegistrationsByEmail(user.email)
      .then(setRegistrations)
      .catch(() => toast({ title: 'Error', description: 'Failed to load your registrations', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, [user]);

  const confirmed = registrations.filter((r) => r.registration_status === 'confirmed');
  const cancelled = registrations.filter((r) => r.registration_status === 'cancelled');

  const RegCard = ({ reg }: { reg: EventRegistration }) => {
    const evt = reg.event;
    if (!evt) return null;
    const statusConf = eventStatusConfig[evt.status];

    return (
      <motion.div
        variants={itemVariants}
        className="group relative"
      >
        <div
          className={cn(
            'relative overflow-hidden rounded-2xl',
            'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
            'border border-white/5 backdrop-blur-xl',
            'transition-all duration-500',
            reg.registration_status === 'cancelled' && 'opacity-60',
            'hover:border-white/10 hover:shadow-xl hover:shadow-black/10'
          )}
        >
          {/* Decorative top line */}
          <div
            className={cn(
              'absolute top-0 left-0 right-0 h-px',
              reg.registration_status === 'cancelled'
                ? 'bg-gradient-to-r from-transparent via-destructive/50 to-transparent'
                : 'bg-gradient-to-r from-transparent via-primary/50 to-transparent'
            )}
          />

          <div className="p-5">
            <div className="flex flex-col sm:flex-row gap-4">
              {/* Left: Poster or placeholder */}
              <div className="w-full sm:w-32 h-24 rounded-xl overflow-hidden shrink-0">
                {evt.poster_url ? (
                  <img
                    src={evt.poster_url}
                    alt={evt.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 flex items-center justify-center">
                    <Calendar className="w-8 h-8 text-white/30" />
                  </div>
                )}
              </div>

              {/* Middle: Info */}
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span
                    className={cn(
                      'px-2.5 py-0.5 rounded-full text-xs font-medium',
                      'bg-gradient-to-r backdrop-blur-xl border',
                      statusConf.bg.replace('bg-', 'from-').replace('/10', '/20'),
                      statusConf.color
                    )}
                  >
                    {statusConf.label}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent/10 text-accent border border-accent/20">
                    {evt.event_type || 'Event'}
                  </span>
                  {reg.registration_status === 'cancelled' && (
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-destructive/10 text-destructive border border-destructive/20">
                      Cancelled
                    </span>
                  )}
                </div>

                <h3 className="font-semibold text-base line-clamp-1 group-hover:text-primary transition-colors">
                  {evt.title}
                </h3>

                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-primary/60" />
                    <span>{new Date(evt.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                  </div>
                  {evt.start_time && (
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-secondary/60" />
                      <span>{evt.start_time.slice(0, 5)}{evt.end_time ? ` — ${evt.end_time.slice(0, 5)}` : ''}</span>
                    </div>
                  )}
                  {evt.venue && (
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-accent/60" />
                      <span className="line-clamp-1">{evt.venue}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Right: Status & Action */}
              <div className="flex sm:flex-col items-center sm:items-end gap-2 justify-between">
                {reg.registration_status === 'confirmed' ? (
                  <div className="flex items-center gap-1.5 text-sm text-success">
                    <div className="w-5 h-5 rounded-full bg-success/20 flex items-center justify-center">
                      <CheckCircle className="w-3 h-3" />
                    </div>
                    <span className="font-medium">Registered</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-sm text-destructive">
                    <div className="w-5 h-5 rounded-full bg-destructive/20 flex items-center justify-center">
                      <X className="w-3 h-3" />
                    </div>
                    <span className="font-medium">Cancelled</span>
                  </div>
                )}

                <div className="flex gap-2">
                  {reg.registration_status === 'confirmed' && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs gap-1.5"
                      asChild
                    >
                      <Link to={`/ticket/${reg.qr_code}`}>
                        <Ticket className="w-3.5 h-3.5" />
                        Ticket
                      </Link>
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    className={cn(
                      'text-xs gap-1.5',
                      'hover:bg-gradient-to-r hover:from-primary/10 hover:to-accent/10'
                    )}
                    asChild
                  >
                    <Link to={`/events/${evt.id}`}>
                      Details
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>

            {/* Registered timestamp */}
            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                Registered on {new Date(reg.registered_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              </p>
              {reg.registration_status === 'confirmed' && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Registration ID:</span>
                  <span className="text-xs font-mono text-primary">{reg.id.slice(0, 8).toUpperCase()}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <DashboardLayout requiredRole="student">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="space-y-6"
      >
        {/* Header */}
        <div
          className={cn(
            'relative overflow-hidden rounded-2xl p-6',
            'bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10',
            'border border-white/5'
          )}
        >
          <div className="absolute -top-20 -left-20 w-40 h-40 bg-primary/20 rounded-full blur-3xl animate-float" />
          <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />

          <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5 text-primary" />
                <span className="text-xs font-medium text-primary uppercase tracking-wider">My Events</span>
              </div>
              <h1 className="text-2xl font-bold font-heading">Event Registrations</h1>
              <p className="text-sm text-muted-foreground mt-1">Manage your upcoming and past event registrations</p>
            </div>
            <Button
              className={cn(
                'gap-2',
                'bg-gradient-to-r from-primary via-secondary to-accent',
                'text-white font-medium',
                'shadow-glow hover:shadow-glow-lg',
                'hover:scale-105 transition-transform'
              )}
              asChild
            >
              <Link to="/events">
                <Calendar className="w-4 h-4" />
                Browse Events
              </Link>
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-24">
            <div className="relative">
              <div className="w-12 h-12 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
              <Sparkles className="absolute inset-0 m-auto w-5 h-5 text-primary" />
            </div>
            <p className="text-sm text-muted-foreground mt-4">Loading your registrations...</p>
          </div>
        ) : registrations.length === 0 ? (
          <div
            className={cn(
              'relative overflow-hidden rounded-2xl p-12 text-center',
              'bg-gradient-to-br from-background/80 to-background/50',
              'border border-white/5'
            )}
          >
            <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4">
              <Calendar className="w-10 h-10 text-primary/50" />
            </div>
            <h3 className="text-xl font-semibold font-heading">No Registrations Yet</h3>
            <p className="text-sm text-muted-foreground mt-2 max-w-md mx-auto">
              You haven't registered for any events. Browse upcoming events to get started on your innovation journey!
            </p>
            <Button
              className={cn(
                'mt-6 gap-2',
                'bg-gradient-to-r from-primary to-accent',
                'text-white font-medium',
                'shadow-glow'
              )}
              asChild
            >
              <Link to="/events">
                <Calendar className="w-4 h-4" />
                Explore Events
              </Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Confirmed */}
            <AnimatePresence>
              {confirmed.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-lg bg-success/20 flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-success" />
                    </div>
                    <div>
                      <h2 className="text-sm font-semibold text-foreground">Active Registrations</h2>
                      <p className="text-xs text-muted-foreground">{confirmed.length} events</p>
                    </div>
                  </div>
                  <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate="show"
                    className="space-y-3"
                  >
                    {confirmed.map((reg) => (
                      <RegCard key={reg.id} reg={reg} />
                    ))}
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Cancelled */}
            <AnimatePresence>
              {cancelled.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-lg bg-destructive/20 flex items-center justify-center">
                      <X className="w-4 h-4 text-destructive" />
                    </div>
                    <div>
                      <h2 className="text-sm font-semibold text-foreground">Cancelled Registrations</h2>
                      <p className="text-xs text-muted-foreground">{cancelled.length} events</p>
                    </div>
                  </div>
                  <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate="show"
                    className="space-y-3"
                  >
                    {cancelled.map((reg) => (
                      <RegCard key={reg.id} reg={reg} />
                    ))}
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </motion.div>
    </DashboardLayout>
  );
}
