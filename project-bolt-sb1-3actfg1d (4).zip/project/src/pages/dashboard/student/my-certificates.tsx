import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Award, Eye, ShieldCheck, Loader2, FileText, Image as ImageIcon,
  Calendar, ExternalLink,
} from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  getMyCertificates, downloadCertificateAsPDF, downloadCertificateAsPNG,
} from '@/services/certificates';
import type { Certificate } from '@/types/certificates';
import { useToast } from '@/hooks/use-toast';

export default function MyCertificatesPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [viewCert, setViewCert] = useState<Certificate | null>(null);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => { loadCertificates(); }, []);

  const loadCertificates = async () => {
    try {
      setLoading(true);
      const data = await getMyCertificates();
      setCertificates(data);
    } catch {
      toast({ title: 'Error', description: 'Failed to load certificates', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (cert: Certificate, format: 'pdf' | 'png') => {
    if (!cert.generated_certificate_url) {
      toast({ title: 'No preview', description: 'Certificate image not available', variant: 'destructive' });
      return;
    }
    setDownloading(true);
    try {
      const fileName = `certificate_${cert.certificate_number}`;
      if (format === 'pdf') await downloadCertificateAsPDF(cert.generated_certificate_url, fileName);
      else await downloadCertificateAsPNG(cert.generated_certificate_url, fileName);
      toast({ title: 'Downloaded', description: `Certificate downloaded as ${format.toUpperCase()}` });
    } catch (err: any) {
      toast({ title: 'Download failed', description: err.message, variant: 'destructive' });
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="student">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout requiredRole="student">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="My Certificates"
          description="View, download, and verify your earned certificates"
        />

        {certificates.length === 0 ? (
          <div className="text-center py-12">
            <Award className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-medium mb-2">No certificates yet</h3>
            <p className="text-muted-foreground">Certificates will appear here after you attend events and admins issue them.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {certificates.map((cert, idx) => (
              <motion.div
                key={cert.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card className="glass-card border-0 shadow-md overflow-hidden h-full flex flex-col">
                  {/* Preview thumbnail */}
                  <div className="aspect-[4/3] bg-muted relative cursor-pointer" onClick={() => setViewCert(cert)}>
                    {cert.generated_certificate_url ? (
                      <img src={cert.generated_certificate_url} alt={cert.event_name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Award className="w-12 h-12 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 hover:opacity-100">
                      <div className="bg-white/90 rounded-full p-3">
                        <Eye className="w-5 h-5 text-foreground" />
                      </div>
                    </div>
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-emerald-500/90 text-white">
                        <ShieldCheck className="w-3 h-3 mr-1" /> Verified
                      </Badge>
                    </div>
                  </div>

                  <CardContent className="pt-4 flex-1 flex flex-col">
                    <h3 className="font-semibold truncate">{cert.event_name}</h3>
                    <p className="text-xs text-muted-foreground mt-1 font-mono">{cert.certificate_number}</p>

                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-2">
                      <Calendar className="w-3.5 h-3.5" />
                      Issued: {cert.issue_date}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 mt-4 pt-3 border-t">
                      <Button variant="default" size="sm" className="flex-1" onClick={() => setViewCert(cert)}>
                        <Eye className="w-3.5 h-3.5 mr-1" /> View
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={downloading}
                        onClick={() => handleDownload(cert, 'pdf')}
                        title="Download PDF"
                      >
                        {downloading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={downloading}
                        onClick={() => handleDownload(cert, 'png')}
                        title="Download PNG"
                      >
                        <ImageIcon className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        asChild
                        title="Verify Certificate"
                      >
                        <a href={`/verify-certificate/${cert.certificate_number}`} target="_blank" rel="noopener noreferrer">
                          <ShieldCheck className="w-3.5 h-3.5" />
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>

      {/* Certificate view dialog */}
      <Dialog open={!!viewCert} onOpenChange={(open) => !open && setViewCert(null)}>
        <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-primary" />
              Certificate
            </DialogTitle>
          </DialogHeader>

          {viewCert && (
            <>
              {viewCert.generated_certificate_url && (
                <img src={viewCert.generated_certificate_url} alt="Certificate" className="w-full rounded-lg border shadow-lg" />
              )}

              <div className="grid grid-cols-2 gap-3 text-sm mt-4">
                <div>
                  <p className="text-xs text-muted-foreground">Student Name</p>
                  <p className="font-medium">{viewCert.participant_name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Certificate Number</p>
                  <p className="font-mono font-medium">{viewCert.certificate_number}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Event</p>
                  <p className="font-medium">{viewCert.event_name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Event Date</p>
                  <p className="font-medium">{viewCert.event_date}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Issue Date</p>
                  <p className="font-medium">{viewCert.issue_date}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <Badge className="bg-emerald-500/15 text-emerald-500 border-emerald-500/20">
                    <ShieldCheck className="w-3 h-3 mr-1" /> {viewCert.certificate_status}
                  </Badge>
                </div>
              </div>
            </>
          )}

          <DialogFooter className="flex gap-2">
            <Button variant="outline" asChild>
              <a href={`/verify-certificate/${viewCert?.certificate_number}`} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="w-4 h-4 mr-2" /> Verify
              </a>
            </Button>
            <Button variant="outline" onClick={() => viewCert && handleDownload(viewCert, 'png')} disabled={downloading}>
              {downloading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ImageIcon className="w-4 h-4 mr-2" />}
              PNG
            </Button>
            <Button onClick={() => viewCert && handleDownload(viewCert, 'pdf')} disabled={downloading}>
              {downloading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <FileText className="w-4 h-4 mr-2" />}
              PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
