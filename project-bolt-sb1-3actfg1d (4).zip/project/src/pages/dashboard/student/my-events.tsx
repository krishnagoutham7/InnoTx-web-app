import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Calendar,
  Clock,
  MapPin,
  Ticket,
  CheckCircle,
  Loader2,
  Download,
  QrCode,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import {
  getUserTickets,
  type EventTicket,
} from '@/services/events';
import type { Event } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { format } from 'date-fns';
import QRCode from 'qrcode';

interface TicketWithEvent extends EventTicket {
  event?: Event;
  attendance_status?: 'pending' | 'attended' | 'absent';
}

export default function StudentEventsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tickets, setTickets] = useState<TicketWithEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [qrDataUrls, setQrDataUrls] = useState<Record<string, string>>({});

  useEffect(() => {
    if (user?.id) {
      loadTickets();
    } else {
      setLoading(false);
    }
  }, [user]);

  async function loadTickets() {
    try {
      setLoading(true);
      const data = await getUserTickets(user!.id);

      // Get attendance status for each ticket
      const ticketsWithStatus = await Promise.all(
        data.map(async (t) => {
          if (t.event_id) {
            try {
              // Check if this user attended
              const { data: attendance } = await supabase
                .from('event_attendance')
                .select('id')
                .eq('ticket_id', t.id)
                .maybeSingle();

              return {
                ...t,
                attendance_status: attendance ? 'attended' as const : 'pending' as const,
              };
            } catch {
              return { ...t, attendance_status: 'pending' as const };
            }
          }
          return { ...t, attendance_status: 'pending' as const };
        })
      );

      setTickets(ticketsWithStatus);

      // Generate QR data URLs
      const qrUrls: Record<string, string> = {};
      for (const t of ticketsWithStatus) {
        if (t.qr_code) {
          qrUrls[t.qr_code] = await QRCode.toDataURL(t.qr_code, {
            width: 200,
            margin: 2,
          });
        }
      }
      setQrDataUrls(qrUrls);
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to load tickets', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  function handleViewTicket(qrCode: string) {
    navigate(`/ticket/${qrCode}`);
  }

  function handleDownloadQR(qrCode: string, ticketNumber: string) {
    const dataUrl = qrDataUrls[qrCode];
    if (dataUrl) {
      const link = document.createElement('a');
      link.download = `ticket-${ticketNumber}.png`;
      link.href = dataUrl;
      link.click();
    }
  }

  const upcomingTickets = tickets.filter((t) => {
    const eventDate = t.event?.start_date ? new Date(t.event.start_date) : null;
    return eventDate && eventDate >= new Date() && !t.is_used;
  });

  const pastTickets = tickets.filter((t) => {
    const eventDate = t.event?.start_date ? new Date(t.event.start_date) : null;
    return eventDate && eventDate < new Date();
  });

  const attendedTickets = tickets.filter((t) => t.is_used || t.attendance_status === 'attended');

  return (
    <DashboardLayout requiredRole="student">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">My Events & Tickets</h1>
            <p className="text-muted-foreground">View your registered events and QR tickets</p>
          </div>
          <Button asChild>
            <Link to="/events">
              <Calendar className="w-4 h-4 mr-2" />
              Browse Events
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{tickets.length}</div>
              <p className="text-sm text-muted-foreground">Total Registrations</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-blue-600">{upcomingTickets.length}</div>
              <p className="text-sm text-muted-foreground">Upcoming Events</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-green-600">{attendedTickets.length}</div>
              <p className="text-sm text-muted-foreground">Attended</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-orange-600">
                {tickets.filter((t) => t.attendance_status === 'pending' && t.event?.start_date && new Date(t.event.start_date) < new Date()).length}
              </div>
              <p className="text-sm text-muted-foreground">Missed</p>
            </CardContent>
          </Card>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : tickets.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Ticket className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-semibold mb-2">No Tickets Yet</h2>
              <p className="text-muted-foreground mb-4">
                Register for an event to get your participation ticket with QR code
              </p>
              <Button asChild>
                <Link to="/events">Browse Events</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="upcoming">
            <TabsList>
              <TabsTrigger value="upcoming">Upcoming ({upcomingTickets.length})</TabsTrigger>
              <TabsTrigger value="attended">Attended ({attendedTickets.length})</TabsTrigger>
              <TabsTrigger value="past">Past Events ({pastTickets.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="upcoming" className="mt-4 space-y-4">
              {upcomingTickets.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    No upcoming events
                  </CardContent>
                </Card>
              ) : (
                upcomingTickets.map((ticket) => (
                  <TicketCard
                    key={ticket.id}
                    ticket={ticket}
                    qrDataUrl={qrDataUrls[ticket.qr_code || '']}
                    onViewTicket={handleViewTicket}
                    onDownloadQR={handleDownloadQR}
                  />
                ))
              )}
            </TabsContent>

            <TabsContent value="attended" className="mt-4 space-y-4">
              {attendedTickets.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    No attended events yet
                  </CardContent>
                </Card>
              ) : (
                attendedTickets.map((ticket) => (
                  <TicketCard
                    key={ticket.id}
                    ticket={ticket}
                    qrDataUrl={qrDataUrls[ticket.qr_code || '']}
                    onViewTicket={handleViewTicket}
                    onDownloadQR={handleDownloadQR}
                    isAttended
                  />
                ))
              )}
            </TabsContent>

            <TabsContent value="past" className="mt-4 space-y-4">
              {pastTickets.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    No past events
                  </CardContent>
                </Card>
              ) : (
                pastTickets.map((ticket) => (
                  <TicketCard
                    key={ticket.id}
                    ticket={ticket}
                    qrDataUrl={qrDataUrls[ticket.qr_code || '']}
                    onViewTicket={handleViewTicket}
                    onDownloadQR={handleDownloadQR}
                  />
                ))
              )}
            </TabsContent>
          </Tabs>
        )}
      </motion.div>
    </DashboardLayout>
  );
}

function TicketCard({
  ticket,
  qrDataUrl,
  onViewTicket,
  onDownloadQR,
  isAttended = false,
}: {
  ticket: TicketWithEvent;
  qrDataUrl: string;
  onViewTicket: (qrCode: string) => void;
  onDownloadQR: (qrCode: string, ticketNumber: string) => void;
  isAttended?: boolean;
}) {
  const event = ticket.event;

  return (
    <Card className={isAttended ? 'border-green-200 bg-green-50/50' : ''}>
      <CardContent className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* QR Code */}
          <div className="flex-shrink-0">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="QR Code"
                className="w-24 h-24 rounded-lg border bg-white p-1"
              />
            ) : (
              <div className="w-24 h-24 rounded-lg border bg-muted flex items-center justify-center">
                <QrCode className="w-10 h-10 text-muted-foreground" />
              </div>
            )}
          </div>

          {/* Details */}
          <div className="flex-1 space-y-2">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold">{event?.title || 'Unknown Event'}</h3>
                <p className="text-xs text-muted-foreground font-mono">{ticket.ticket_number}</p>
              </div>
              {isAttended ? (
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Attended
                </Badge>
              ) : ticket.is_used ? (
                <Badge variant="secondary">Used</Badge>
              ) : (
                <Badge variant="default">Valid</Badge>
              )}
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              {event?.start_date && (
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {format(new Date(event.start_date), 'MMM d, yyyy')}
                </div>
              )}
              {event?.start_time && (
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {event.start_time}
                </div>
              )}
              {event?.venue && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {event.venue}
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button
                size="sm"
                onClick={() => onViewTicket(ticket.qr_code || '')}
                disabled={!ticket.qr_code}
              >
                <Ticket className="w-4 h-4 mr-1" />
                View Ticket
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onDownloadQR(ticket.qr_code || '', ticket.ticket_number)}
                disabled={!qrDataUrl}
              >
                <Download className="w-4 h-4 mr-1" />
                Download QR
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

import { supabase } from '@/lib/supabase';
