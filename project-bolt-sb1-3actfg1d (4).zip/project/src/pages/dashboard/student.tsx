import { DashboardLayout } from '@/components/dashboard/dashboard-layout';

export default function StudentDashboard() {
  return <DashboardLayout title="Student Dashboard" requiredRole="student" />;
}
