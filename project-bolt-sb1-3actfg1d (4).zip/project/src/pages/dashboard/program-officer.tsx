import { DashboardLayout } from '@/components/dashboard/dashboard-layout';

export default function ProgramOfficerDashboard() {
  return <DashboardLayout title="Program Officer Dashboard" requiredRole="program_officer" />;
}
