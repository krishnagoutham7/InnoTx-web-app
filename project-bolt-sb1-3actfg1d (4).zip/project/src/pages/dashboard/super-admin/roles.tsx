import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Shield, Pencil, Trash2, Plus, Lock, Loader2 } from 'lucide-react';
import { getRoles, createRole, updateRole, deleteRole } from '@/services/cms';
import type { Role } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

const allPermissions = [
  'manage_cms', 'view_cms', 'manage_events', 'view_events', 'manage_team',
  'view_team', 'manage_gallery', 'manage_announcements', 'view_announcements',
  'manage_students', 'manage_operations', 'manage_tasks', 'manage_activities',
  'view_users', 'register_events',
];

const emptyForm = { id: '', label: '', description: '', permissions: [] as string[], is_system: false, display_order: 0 };

export default function RolesManagement() {
  const { toast } = useToast();
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<Role | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Role | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true);
      setRoles(await getRoles());
    } catch {
      toast({ title: 'Error', description: 'Failed to load roles', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const openCreate = () => {
    setEditTarget(null);
    setForm({ ...emptyForm, display_order: roles.length + 1 });
    setFormOpen(true);
  };

  const openEdit = (r: Role) => {
    setEditTarget(r);
    setForm({
      id: r.id,
      label: r.label,
      description: r.description,
      permissions: r.permissions,
      is_system: r.is_system,
      display_order: r.display_order,
    });
    setFormOpen(true);
  };

  const togglePermission = (perm: string) => {
    if (form.permissions.includes('*')) return;
    setForm(f => ({
      ...f,
      permissions: f.permissions.includes(perm)
        ? f.permissions.filter(p => p !== perm)
        : [...f.permissions, perm],
    }));
  };

  const handleSave = async () => {
    if (!form.id.trim() || !form.label.trim()) {
      toast({ title: 'Validation Error', description: 'Role ID and label are required', variant: 'destructive' });
      return;
    }
    try {
      setSaving(true);
      if (editTarget) {
        const updated = await updateRole(editTarget.id, {
          label: form.label,
          description: form.description,
          permissions: form.permissions,
          display_order: form.display_order,
        });
        setRoles(prev => prev.map(r => r.id === editTarget.id ? updated : r));
        toast({ title: 'Updated', description: `Role "${form.label}" updated` });
      } else {
        const created = await createRole({
          id: form.id,
          label: form.label,
          description: form.description,
          permissions: form.permissions,
          is_system: false,
          display_order: form.display_order,
        });
        setRoles(prev => [...prev, created]);
        toast({ title: 'Created', description: `Role "${form.label}" created` });
      }
      setFormOpen(false);
    } catch (err: any) {
      toast({ title: 'Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      await deleteRole(deleteTarget.id);
      setRoles(prev => prev.filter(r => r.id !== deleteTarget.id));
      toast({ title: 'Deleted', description: `Role "${deleteTarget.label}" deleted` });
      setDeleteTarget(null);
    } catch {
      toast({ title: 'Error', description: 'Failed to delete role', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader title="Role Management" description="Manage roles and their permissions"
          actions={<Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={openCreate}><Plus className="w-4 h-4" />New Role</Button>}
        />

        {loading ? (
          <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {roles.map(role => (
              <motion.div key={role.id} whileHover={{ scale: 1.02 }}>
                <Card className="glass-card border-0 shadow-lg hover:shadow-xl transition-all h-full">
                  <CardContent className="pt-5 pb-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-primary" />
                        <h3 className="font-semibold">{role.label}</h3>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(role)}><Pencil className="w-4 h-4" /></Button>
                        {!role.is_system && (
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(role)}><Trash2 className="w-4 h-4" /></Button>
                        )}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3">{role.description}</p>
                    {role.is_system && (
                      <Badge variant="secondary" className="mb-3"><Lock className="w-3 h-3 mr-1" />System Role</Badge>
                    )}
                    <div className="flex flex-wrap gap-1.5">
                      {role.permissions.includes('*') ? (
                        <Badge variant="default" className="text-xs">Full Access</Badge>
                      ) : (
                        role.permissions.map(p => (
                          <Badge key={p} variant="outline" className="text-[10px]">{p}</Badge>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Add / Edit Role Dialog */}
        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{editTarget ? 'Edit Role' : 'New Role'}</DialogTitle></DialogHeader>
            <div className="space-y-4 py-2">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Role ID <span className="text-destructive">*</span></Label>
                  <Input value={form.id} onChange={e => setForm(f => ({ ...f, id: e.target.value.replace(/\s/g, '_').toLowerCase() }))}
                    placeholder="e.g. content_manager" disabled={!!editTarget} />
                </div>
                <div className="space-y-1.5">
                  <Label>Display Label <span className="text-destructive">*</span></Label>
                  <Input value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} placeholder="e.g. Content Manager" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Description</Label>
                <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="What this role can do" rows={2} />
              </div>
              <div className="space-y-1.5">
                <Label>Display Order</Label>
                <Input type="number" value={form.display_order} onChange={e => setForm(f => ({ ...f, display_order: Number(e.target.value) }))} />
              </div>
              <div className="space-y-2">
                <Label>Permissions</Label>
                <div className="flex flex-wrap gap-2">
                  {allPermissions.map(perm => (
                    <label key={perm} className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={form.permissions.includes(perm)}
                        onChange={() => togglePermission(perm)}
                        className="rounded"
                        disabled={form.permissions.includes('*')}
                      />
                      <span className="text-xs">{perm}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
              <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                {editTarget ? 'Save Changes' : 'Create Role'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={confirmDelete}
          title="Delete Role" description={`Delete "${deleteTarget?.label}"? Users with this role will keep it until reassigned.`}
          confirmText={deleting ? 'Deleting...' : 'Delete'} variant="destructive" />
      </motion.div>
    </DashboardLayout>
  );
}
