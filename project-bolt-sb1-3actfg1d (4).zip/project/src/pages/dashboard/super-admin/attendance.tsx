import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import QRScanner from '@/components/qr-scanner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  QrCode,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Loader2,
  Play,
  Square,
  RefreshCw,
  AlertTriangle,
  CheckCheck,
  History,
} from 'lucide-react';
import {
  getEventById,
  getAttendanceWindow,
  getEventAttendanceStats,
  getEventAttendance,
  markAttendance,
  openAttendance,
  closeAttendance,
  setAttendanceWindow,
  subscribeToAttendanceUpdates,
} from '@/services/events';
import type { Event } from '@/types/events';
import type { AttendanceWindow, AttendanceStats, EventAttendance } from '@/services/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { format } from 'date-fns';

export default function AttendanceMarkerPage() {
  const { eventId } = useParams<{ eventId: string }>();
  const { toast } = useToast();
  const { user } = useAuth();

  const [event, setEvent] = useState<Event | null>(null);
  const [attendanceWindow, setAttendanceWindowState] = useState<AttendanceWindow | null>(null);
  const [stats, setStats] = useState<AttendanceStats | null>(null);
  const [recentAttendance, setRecentAttendance] = useState<EventAttendance[]>([]);
  const [loading, setLoading] = useState(true);

  const [scanResult, setScanResult] = useState<{
    success: boolean;
    message: string;
    participant?: string;
  } | null>(null);

  const [manualQRCode, setManualQRCode] = useState('');
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [lastScannedParticipant, setLastScannedParticipant] = useState<string>('');

  // Load data
  useEffect(() => {
    if (eventId) {
      loadAllData();
    }
  }, [eventId]);

  // Real-time subscription
  useEffect(() => {
    if (!eventId) return;

    const subscription = subscribeToAttendanceUpdates(eventId, () => {
      loadStats();
      loadAttendance();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [eventId]);

  async function loadAllData() {
    try {
      setLoading(true);
      const [eventData, windowData] = await Promise.all([
        getEventById(eventId!),
        getAttendanceWindow(eventId!),
      ]);
      setEvent(eventData);
      setAttendanceWindowState(windowData);
      await loadStats();
      await loadAttendance();
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to load event data', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  async function loadStats() {
    if (!eventId) return;
    try {
      const statsData = await getEventAttendanceStats(eventId);
      setStats(statsData);
    } catch (err) {
      console.error('Failed to load stats:', err);
    }
  }

  async function loadAttendance() {
    if (!eventId) return;
    try {
      const attendance = await getEventAttendance(eventId);
      setRecentAttendance(attendance.slice(0, 10));
    } catch (err) {
      console.error('Failed to load attendance:', err);
    }
  }

  async function handleToggleAttendance() {
    if (!eventId || !user) return;

    try {
      if (attendanceWindow?.is_attendance_open) {
        await closeAttendance(eventId, user.id);
        toast({ title: 'Attendance Closed', description: 'Attendance is now closed for this event' });
      } else {
        await openAttendance(eventId, user.id);
        toast({ title: 'Attendance Opened', description: 'Attendance is now open for this event' });
      }
      const windowData = await getAttendanceWindow(eventId);
      setAttendanceWindowState(windowData);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    }
  }

  async function handleScanQR(qrCode: string) {
    if (!eventId || !user || !qrCode.trim()) return;

    if (!attendanceWindow?.is_attendance_open) {
      setScanResult({ success: false, message: 'Attendance is not open for this event' });
      return;
    }

    try {
      const result = await markAttendance(qrCode.trim(), eventId, user.id);

      if (result.success && result.attendance) {
        setScanResult({
          success: true,
          message: 'Attendance marked successfully!',
          participant: result.attendance.participant_name,
        });
        setLastScannedParticipant(result.attendance.participant_name);
        setShowSuccessDialog(true);
        setManualQRCode('');
      } else {
        setScanResult({
          success: false,
          message: result.message || 'Failed to mark attendance',
        });
      }

      // Refresh stats
      await loadStats();
      await loadAttendance();
    } catch (err: any) {
      setScanResult({ success: false, message: err.message || 'Scan failed' });
    }
  }

  async function handleSetWindow(openTime: string, closeTime: string) {
    if (!eventId || !user) return;

    try {
      await setAttendanceWindow(
        eventId,
        {
          attendance_open: openTime || undefined,
          attendance_close: closeTime || undefined,
        },
        user.id
      );
      toast({ title: 'Window Updated', description: 'Attendance window has been updated' });
      const windowData = await getAttendanceWindow(eventId);
      setAttendanceWindowState(windowData);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    }
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center h-96">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (!event) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="text-center py-24">
          <AlertTriangle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold">Event not found</h2>
        </div>
      </DashboardLayout>
    );
  }

  const isOpen = attendanceWindow?.is_attendance_open ?? false;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Attendance Marker</h1>
            <p className="text-muted-foreground">{event.title}</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant={isOpen ? 'default' : 'secondary'} className="text-sm">
              {isOpen ? 'Attendance Open' : 'Attendance Closed'}
            </Badge>
            <Button onClick={handleToggleAttendance} variant={isOpen ? 'destructive' : 'default'}>
              {isOpen ? (
                <>
                  <Square className="w-4 h-4 mr-2" />
                  Close Attendance
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Open Attendance
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats?.total_registrations || 0}</p>
                  <p className="text-sm text-muted-foreground">Registered</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCheck className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats?.total_attended || 0}</p>
                  <p className="text-sm text-muted-foreground">Attended</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats?.pending_attendance || 0}</p>
                  <p className="text-sm text-muted-foreground">Pending</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary">
                    {stats?.attendance_percentage || 0}%
                  </span>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Attendance</p>
                  <p className="text-sm">Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Scanner */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <QrCode className="w-5 h-5" />
                QR Code Scanner
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Status Indicator */}
              <div
                className={`p-4 rounded-lg ${
                  isOpen ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  {isOpen ? (
                    <>
                      <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                      <span className="text-green-800 font-medium">
                        Ready to scan - Attendance is open
                      </span>
                    </>
                  ) : (
                    <>
                      <div className="w-3 h-3 rounded-full bg-red-500" />
                      <span className="text-red-800 font-medium">
                        Attendance is closed - Click "Open Attendance" to begin
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* QR Scanner */}
              <QRScanner
                onScan={handleScanQR}
                isScanningEnabled={isOpen}
              />

              {/* Manual QR Code Entry */}
              <div className="space-y-2">
                <Label htmlFor="qr-input">Or Enter QR Code Manually</Label>
                <div className="flex gap-2">
                  <Input
                    id="qr-input"
                    value={manualQRCode}
                    onChange={(e) => setManualQRCode(e.target.value)}
                    placeholder="QR-XXXX-XXXX-XXXX"
                    className="font-mono"
                    onKeyDown={(e) => e.key === 'Enter' && handleScanQR(manualQRCode)}
                  />
                  <Button onClick={() => handleScanQR(manualQRCode)} disabled={!isOpen}>
                    <QrCode className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Type the QR code from the participant's ticket if scanner is unavailable
                </p>
              </div>

              {/* Scan Result */}
              <AnimatePresence>
                {scanResult && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className={`p-4 rounded-lg ${
                      scanResult.success
                        ? 'bg-green-50 border border-green-200'
                        : 'bg-red-50 border border-red-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {scanResult.success ? (
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-600" />
                      )}
                      <div>
                        <p className={`font-medium ${scanResult.success ? 'text-green-800' : 'text-red-800'}`}>
                          {scanResult.success ? 'Success!' : 'Failed'}
                        </p>
                        <p className={`text-sm ${scanResult.success ? 'text-green-700' : 'text-red-700'}`}>
                          {scanResult.message}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Quick Actions */}
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setScanResult(null)}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Attendance Window Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Attendance Window
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Open Time</Label>
                  <Input
                    type="datetime-local"
                    value={
                      attendanceWindow?.attendance_open
                        ? new Date(attendanceWindow.attendance_open).toISOString().slice(0, 16)
                        : ''
                    }
                    onChange={(e) => handleSetWindow(e.target.value, attendanceWindow?.attendance_close || '')}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Close Time</Label>
                  <Input
                    type="datetime-local"
                    value={
                      attendanceWindow?.attendance_close
                        ? new Date(attendanceWindow.attendance_close).toISOString().slice(0, 16)
                        : ''
                    }
                    onChange={(e) => handleSetWindow(attendanceWindow?.attendance_open || '', e.target.value)}
                  />
                </div>
              </div>

              {!attendanceWindow?.attendance_open && !attendanceWindow?.attendance_close && (
                <p className="text-sm text-muted-foreground">
                  No time restrictions set. Attendance can be marked anytime when open.
                </p>
              )}

              {attendanceWindow?.attendance_open && (
                <p className="text-sm">
                  Opens: {format(new Date(attendanceWindow.attendance_open), 'PPp')}
                </p>
              )}
              {attendanceWindow?.attendance_close && (
                <p className="text-sm">
                  Closes: {format(new Date(attendanceWindow.attendance_close), 'PPp')}
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Attendance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="w-5 h-5" />
              Recent Attendance ({recentAttendance.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {recentAttendance.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">
                  No attendance records yet
                </p>
              ) : (
                recentAttendance.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium">{att.participant_name}</p>
                        <p className="text-xs text-muted-foreground">{att.participant_email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm">
                        {format(new Date(att.scanned_at), 'HH:mm:ss')}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(att.scanned_at), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Success Dialog */}
      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle className="w-6 h-6" />
              Attendance Confirmed
            </DialogTitle>
          </DialogHeader>
          <div className="py-6 text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
              <CheckCheck className="w-8 h-8 text-green-600" />
            </div>
            <p className="text-lg font-medium mb-1">{lastScannedParticipant}</p>
            <p className="text-muted-foreground">Attendance successfully recorded</p>
            <p className="text-sm text-muted-foreground mt-2">
              {format(new Date(), 'PPp')}
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
