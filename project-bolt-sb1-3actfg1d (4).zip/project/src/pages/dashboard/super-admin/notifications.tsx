import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { DataTable, PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Pencil, Trash2, Send, Loader2, Bell, Users, Eye, CheckCircle, Clock, Calendar, X, Megaphone } from 'lucide-react';
import {
  getNotifications,
  createNotification,
  updateNotification,
  deleteNotification,
  cancelNotification,
  getNotificationStats,
  type Notification,
  type NotificationStats,
} from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

const notificationTypes = [
  { value: 'event_alert', label: 'Event Alert', icon: Calendar },
  { value: 'meeting_alert', label: 'Meeting Alert', icon: Users },
  { value: 'certificate_available', label: 'Certificate Available', icon: CheckCircle },
  { value: 'announcement', label: 'Announcement', icon: Megaphone },
  { value: 'custom', label: 'Custom', icon: Bell },
];

const priorityLevels = [
  { value: 'low', label: 'Low', color: 'bg-gray-100 text-gray-700' },
  { value: 'medium', label: 'Medium', color: 'bg-blue-100 text-blue-700' },
  { value: 'high', label: 'High', color: 'bg-orange-100 text-orange-700' },
  { value: 'critical', label: 'Critical', color: 'bg-red-100 text-red-700' },
];

const targetTypes = [
  { value: 'all', label: 'All Users' },
  { value: 'role', label: 'By Role' },
  { value: 'department', label: 'By Department' },
  { value: 'individual', label: 'Individual Users' },
];

const roles = [
  'super_admin',
  'admin',
  'ceo',
  'coo',
  'cfo',
  'cpo',
  'executive',
  'faculty',
  'program_officer',
  'student',
];

const emptyForm = {
  title: '',
  message: '',
  notification_type: 'announcement' as Notification['notification_type'],
  target_type: 'all' as Notification['target_type'],
  target_role: [] as string[],
  target_department: [] as string[],
  target_user_ids: [] as string[],
  priority_level: 'medium' as Notification['priority_level'],
  scheduled_at: '',
  expires_at: '',
  send_now: false,
};

export default function NotificationManagement() {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [stats, setStats] = useState<NotificationStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<Notification | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Notification | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('notifications');

  useEffect(() => {
    loadNotifications();
    loadStats();
  }, []);

  async function loadNotifications() {
    try {
      setLoading(true);
      setNotifications(await getNotifications());
    } catch {
      toast({ title: 'Error', description: 'Failed to load notifications', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  async function loadStats() {
    try {
      setStats(await getNotificationStats());
    } catch {
      // Silent fail for stats
    }
  }

  const openCreate = () => {
    setEditTarget(null);
    setForm(emptyForm);
    setFormOpen(true);
  };

  const openEdit = (n: Notification) => {
    setEditTarget(n);
    setForm({
      title: n.title,
      message: n.message,
      notification_type: n.notification_type,
      target_type: n.target_type,
      target_role: n.target_role || [],
      target_department: n.target_department || [],
      target_user_ids: n.target_user_ids || [],
      priority_level: n.priority_level,
      scheduled_at: n.scheduled_at ? new Date(n.scheduled_at).toISOString().slice(0, 16) : '',
      expires_at: n.expires_at ? new Date(n.expires_at).toISOString().slice(0, 16) : '',
      send_now: false,
    });
    setFormOpen(true);
  };

  const handleSave = async () => {
    if (!form.title || !form.message) {
      toast({ title: 'Validation Error', description: 'Title and message are required', variant: 'destructive' });
      return;
    }

    try {
      setSaving(true);
      const payload = {
        title: form.title,
        message: form.message,
        notification_type: form.notification_type,
        target_type: form.target_type,
        target_role: form.target_type === 'role' ? form.target_role : undefined,
        target_department: form.target_type === 'department' ? form.target_department : undefined,
        target_user_ids: form.target_type === 'individual' ? form.target_user_ids : undefined,
        priority_level: form.priority_level,
        scheduled_at: form.scheduled_at ? new Date(form.scheduled_at).toISOString() : undefined,
        expires_at: form.expires_at ? new Date(form.expires_at).toISOString() : undefined,
        send_now: form.send_now,
      };

      if (editTarget) {
        const updated = await updateNotification(editTarget.id, payload);
        setNotifications(prev => prev.map(n => n.id === editTarget.id ? updated : n));
        toast({ title: 'Updated', description: `Notification "${form.title}" has been updated` });
      } else {
        const created = await createNotification(payload);
        setNotifications(prev => [created, ...prev]);
        toast({ title: 'Created', description: `Notification "${form.title}" has been ${created.status}` });
      }
      setFormOpen(false);
      loadStats();
    } catch (err: any) {
      toast({ title: 'Save Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleSend = async (notification: Notification) => {
    try {
      const updated = await updateNotification(notification.id, { send_now: true });
      setNotifications(prev => prev.map(n => n.id === notification.id ? updated : n));
      toast({ title: 'Sent', description: `Notification "${notification.title}" has been sent` });
      loadStats();
    } catch (err: any) {
      toast({ title: 'Send Failed', description: err.message, variant: 'destructive' });
    }
  };

  const handleCancel = async (notification: Notification) => {
    try {
      const updated = await cancelNotification(notification.id);
      setNotifications(prev => prev.map(n => n.id === notification.id ? updated : n));
      toast({ title: 'Cancelled', description: `Scheduled notification has been cancelled` });
    } catch (err: any) {
      toast({ title: 'Cancel Failed', description: err.message, variant: 'destructive' });
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      await deleteNotification(deleteTarget.id);
      setNotifications(prev => prev.filter(n => n.id !== deleteTarget.id));
      toast({ title: 'Deleted', description: `Notification has been removed` });
      setDeleteTarget(null);
      loadStats();
    } catch {
      toast({ title: 'Error', description: 'Failed to delete notification', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  const statusBadge = (status: string) => {
    const styles: Record<string, string> = {
      draft: 'bg-gray-100 text-gray-700',
      scheduled: 'bg-blue-100 text-blue-700',
      sending: 'bg-yellow-100 text-yellow-700',
      sent: 'bg-green-100 text-green-700',
      cancelled: 'bg-red-100 text-red-700',
      expired: 'bg-gray-100 text-gray-500',
    };
    return <Badge className={styles[status] || 'bg-gray-100'}>{status.charAt(0).toUpperCase() + status.slice(1)}</Badge>;
  };

  const priorityBadge = (level: string) => {
    const config = priorityLevels.find(p => p.value === level);
    return <Badge className={config?.color || 'bg-gray-100'}>{config?.label || level}</Badge>;
  };

  const typeBadge = (type: string) => {
    const config = notificationTypes.find(t => t.value === type);
    return <Badge variant="outline">{config?.label || type}</Badge>;
  };

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Notification Management"
          description="Create and manage notifications across the platform"
          actions={
            <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={openCreate}>
              <Bell className="w-4 h-4" /> Create Notification
            </Button>
          }
        />

        {/* Analytics Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Send className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{stats?.total_sent || 0}</p>
                  <p className="text-sm text-muted-foreground">Total Sent</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-blue-500" />
                <div>
                  <p className="text-2xl font-bold">{stats?.total_read || 0}</p>
                  <p className="text-sm text-muted-foreground">Total Read</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <div>
                  <p className="text-2xl font-bold">{stats ? Math.round(stats.read_rate * 100) : 0}%</p>
                  <p className="text-sm text-muted-foreground">Read Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-500" />
                <div>
                  <p className="text-2xl font-bold">{stats?.recent_count || 0}</p>
                  <p className="text-sm text-muted-foreground">Last 7 Days</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="notifications">All Notifications</TabsTrigger>
            <TabsTrigger value="drafts">Drafts</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
            <TabsTrigger value="sent">Sent</TabsTrigger>
          </TabsList>

          <TabsContent value="notifications" className="mt-4">
            {loading ? (
              <div className="flex items-center justify-center py-24">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <DataTable
                data={notifications}
                columns={[
                  {
                    key: 'title',
                    header: 'Notification',
                    render: (n) => (
                      <div>
                        <p className="font-medium">{n.title}</p>
                        <p className="text-xs text-muted-foreground line-clamp-1">{n.message}</p>
                      </div>
                    ),
                  },
                  { key: 'notification_type', header: 'Type', render: (n) => typeBadge(n.notification_type) },
                  { key: 'priority_level', header: 'Priority', render: (n) => priorityBadge(n.priority_level) },
                  { key: 'status', header: 'Status', render: (n) => statusBadge(n.status) },
                  {
                    key: 'recipients',
                    header: 'Recipients',
                    render: (n) => (
                      <span className="text-sm">
                        {n.recipient_count || 0} ({n.read_count || 0} read)
                      </span>
                    ),
                  },
                  {
                    key: 'sent_at',
                    header: 'Sent At',
                    render: (n) => (n.sent_at ? new Date(n.sent_at).toLocaleDateString() : '—'),
                  },
                ]}
                searchKeys={['title', 'message']}
                searchPlaceholder="Search notifications..."
                actions={(n) => (
                  <div className="flex items-center gap-1">
                    {n.status === 'draft' && (
                      <Button variant="ghost" size="icon" onClick={() => handleSend(n)} title="Send Now">
                        <Send className="w-4 h-4 text-green-600" />
                      </Button>
                    )}
                    {n.status === 'scheduled' && (
                      <Button variant="ghost" size="icon" onClick={() => handleCancel(n)} title="Cancel">
                        <X className="w-4 h-4 text-orange-600" />
                      </Button>
                    )}
                    {(n.status === 'draft' || n.status === 'scheduled') && (
                      <Button variant="ghost" size="icon" onClick={() => openEdit(n)} title="Edit">
                        <Pencil className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive"
                      onClick={() => setDeleteTarget(n)}
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              />
            )}
          </TabsContent>

          <TabsContent value="drafts" className="mt-4">
            <DataTable
              data={notifications.filter(n => n.status === 'draft')}
              columns={[
                { key: 'title', header: 'Title', render: (n) => <span className="font-medium">{n.title}</span> },
                { key: 'notification_type', header: 'Type', render: (n) => typeBadge(n.notification_type) },
                { key: 'priority_level', header: 'Priority', render: (n) => priorityBadge(n.priority_level) },
                {
                  key: 'created_at',
                  header: 'Created',
                  render: (n) => new Date(n.created_at).toLocaleDateString(),
                },
              ]}
              searchKeys={['title']}
              searchPlaceholder="Search drafts..."
              actions={(n) => (
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" onClick={() => handleSend(n)} title="Send Now">
                    <Send className="w-4 h-4 text-green-600" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => openEdit(n)} title="Edit">
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setDeleteTarget(n)} title="Delete">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              )}
              emptyMessage="No draft notifications"
            />
          </TabsContent>

          <TabsContent value="scheduled" className="mt-4">
            <DataTable
              data={notifications.filter(n => n.status === 'scheduled')}
              columns={[
                { key: 'title', header: 'Title', render: (n) => <span className="font-medium">{n.title}</span> },
                { key: 'notification_type', header: 'Type', render: (n) => typeBadge(n.notification_type) },
                {
                  key: 'scheduled_at',
                  header: 'Scheduled For',
                  render: (n) => (n.scheduled_at ? new Date(n.scheduled_at).toLocaleString() : '—'),
                },
              ]}
              searchKeys={['title']}
              searchPlaceholder="Search scheduled..."
              actions={(n) => (
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" onClick={() => handleSend(n)} title="Send Now">
                    <Send className="w-4 h-4 text-green-600" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleCancel(n)} title="Cancel">
                    <X className="w-4 h-4 text-orange-600" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => openEdit(n)} title="Edit">
                    <Pencil className="w-4 h-4" />
                  </Button>
                </div>
              )}
              emptyMessage="No scheduled notifications"
            />
          </TabsContent>

          <TabsContent value="sent" className="mt-4">
            <DataTable
              data={notifications.filter(n => n.status === 'sent')}
              columns={[
                { key: 'title', header: 'Title', render: (n) => <span className="font-medium">{n.title}</span> },
                { key: 'notification_type', header: 'Type', render: (n) => typeBadge(n.notification_type) },
                {
                  key: 'recipients',
                  header: 'Recipients',
                  render: (n) => (
                    <span className="text-sm">
                      {n.recipient_count || 0} sent, {n.read_count || 0} read
                    </span>
                  ),
                },
                {
                  key: 'sent_at',
                  header: 'Sent At',
                  render: (n) => (n.sent_at ? new Date(n.sent_at).toLocaleString() : '—'),
                },
              ]}
              searchKeys={['title']}
              searchPlaceholder="Search sent notifications..."
              actions={(n) => (
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setDeleteTarget(n)} title="Delete">
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
              emptyMessage="No sent notifications"
            />
          </TabsContent>
        </Tabs>

        {/* Create / Edit Dialog */}
        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editTarget ? 'Edit Notification' : 'Create Notification'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 sm:col-span-2">
                  <Label>Notification Title *</Label>
                  <Input
                    value={form.title}
                    onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                    placeholder="Enter notification title"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Message *</Label>
                <Textarea
                  value={form.message}
                  onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                  placeholder="Enter notification message"
                  rows={4}
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Notification Type</Label>
                  <Select
                    value={form.notification_type}
                    onValueChange={(v) => setForm((f) => ({ ...f, notification_type: v as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {notificationTypes.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          {t.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <Label>Priority Level</Label>
                  <Select
                    value={form.priority_level}
                    onValueChange={(v) => setForm((f) => ({ ...f, priority_level: v as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorityLevels.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Target Audience</Label>
                <Select
                  value={form.target_type}
                  onValueChange={(v) => setForm((f) => ({ ...f, target_type: v as any, target_role: [], target_department: [] }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {targetTypes.map((t) => (
                      <SelectItem key={t.value} value={t.value}>
                        {t.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {form.target_type === 'role' && (
                <div className="space-y-1.5">
                  <Label>Select Roles</Label>
                  <div className="flex flex-wrap gap-2">
                    {roles.map((role) => (
                      <Badge
                        key={role}
                        variant={form.target_role.includes(role) ? 'default' : 'outline'}
                        className="cursor-pointer"
                        onClick={() =>
                          setForm((f) => ({
                            ...f,
                            target_role: f.target_role.includes(role)
                              ? f.target_role.filter((r) => r !== role)
                              : [...f.target_role, role],
                          }))
                        }
                      >
                        {role}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Schedule Date (Optional)</Label>
                  <Input
                    type="datetime-local"
                    value={form.scheduled_at}
                    onChange={(e) => setForm((f) => ({ ...f, scheduled_at: e.target.value }))}
                  />
                </div>

                <div className="space-y-1.5">
                  <Label>Expiration Date (Optional)</Label>
                  <Input
                    type="datetime-local"
                    value={form.expires_at}
                    onChange={(e) => setForm((f) => ({ ...f, expires_at: e.target.value }))}
                  />
                </div>
              </div>

              {!editTarget && (
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Send Immediately</Label>
                    <p className="text-xs text-muted-foreground">Turn off to save as draft</p>
                  </div>
                  <Switch checked={form.send_now} onCheckedChange={(v) => setForm((f) => ({ ...f, send_now: v }))} />
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setFormOpen(false)}>
                Cancel
              </Button>
              <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                {editTarget ? 'Save Changes' : form.send_now ? 'Send Notification' : 'Save Draft'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <ConfirmDialog
          open={!!deleteTarget}
          onClose={() => setDeleteTarget(null)}
          onConfirm={confirmDelete}
          title="Delete Notification"
          description={`Are you sure you want to delete "${deleteTarget?.title}"?`}
          confirmText={deleting ? 'Deleting...' : 'Delete'}
          variant="destructive"
        />
      </motion.div>
    </DashboardLayout>
  );
}
