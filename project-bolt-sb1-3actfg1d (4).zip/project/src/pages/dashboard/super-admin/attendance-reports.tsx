import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DataTable } from '@/components/dashboard/shared';
import {
  Download,
  FileSpreadsheet,
  Users,
  CheckCircle,
  Clock,
  AlertTriangle,
  Loader2,
} from 'lucide-react';
import { getAllEvents, getEventAttendance, getEventAttendanceStats, type EventAttendance, type AttendanceStats } from '@/services/events';
import type { Event } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export default function AttendanceReportsPage() {
  const { toast } = useToast();
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<string>('');
  const [attendance, setAttendance] = useState<EventAttendance[]>([]);
  const [stats, setStats] = useState<AttendanceStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingAttendance, setLoadingAttendance] = useState(false);
  const [exporting] = useState(false);

  useEffect(() => {
    loadEvents();
  }, []);

  useEffect(() => {
    if (selectedEventId) {
      loadAttendanceData();
    }
  }, [selectedEventId]);

  async function loadEvents() {
    try {
      setLoading(true);
      const data = await getAllEvents();
      setEvents(data.filter(e => e.status !== 'draft'));
      if (data.length > 0 && !selectedEventId) {
        setSelectedEventId(data[0].id);
      }
    } catch {
      toast({ title: 'Error', description: 'Failed to load events', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  async function loadAttendanceData() {
    try {
      setLoadingAttendance(true);
      const [attendanceData, statsData] = await Promise.all([
        getEventAttendance(selectedEventId),
        getEventAttendanceStats(selectedEventId),
      ]);
      setAttendance(attendanceData);
      setStats(statsData);
    } catch {
      toast({ title: 'Error', description: 'Failed to load attendance data', variant: 'destructive' });
    } finally {
      setLoadingAttendance(false);
    }
  }

  function exportCSV() {
    if (attendance.length === 0) {
      toast({ title: 'No Data', description: 'No attendance data to export', variant: 'destructive' });
      return;
    }

    const headers = ['Participant Name', 'Email', 'Scanned At', 'Method', 'Status'];
    const rows = attendance.map(a => [
      a.participant_name,
      a.participant_email,
      a.scanned_at ? format(new Date(a.scanned_at), 'PPp') : 'N/A',
      a.attendance_method,
      'Attended',
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.map(cell => `"${cell}"`).join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `attendance-${selectedEventId}-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    link.click();

    toast({ title: 'Exported', description: 'CSV file downloaded' });
  }

  function exportExcel() {
    // For now, we'll export as CSV which opens in Excel
    // A proper Excel export would require additional libraries
    exportCSV();
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center h-96">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Attendance Reports</h1>
            <p className="text-muted-foreground">View and export attendance data</p>
          </div>
        </div>

        {/* Event Selector */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Event</label>
                <Select value={selectedEventId} onValueChange={setSelectedEventId}>
                  <SelectTrigger className="w-64">
                    <SelectValue placeholder="Select an event" />
                  </SelectTrigger>
                  <SelectContent>
                    {events.map((e) => (
                      <SelectItem key={e.id} value={e.id}>
                        {e.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2 ml-auto">
                <Button variant="outline" onClick={exportCSV} disabled={exporting || attendance.length === 0}>
                  <Download className="w-4 h-4 mr-2" />
                  Export CSV
                </Button>
                <Button variant="outline" onClick={exportExcel} disabled={exporting || attendance.length === 0}>
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Export Excel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.total_registrations}</p>
                    <p className="text-sm text-muted-foreground">Registered</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.total_attended}</p>
                    <p className="text-sm text-muted-foreground">Attended</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.pending_attendance}</p>
                    <p className="text-sm text-muted-foreground">Pending</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-lg font-bold text-primary">
                      {stats.attendance_percentage}%
                    </span>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Attendance</p>
                    <p className="text-sm">Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Attendance Table */}
        {loadingAttendance ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : attendance.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <AlertTriangle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-semibold mb-2">No Attendance Records</h2>
              <p className="text-muted-foreground">
                {selectedEventId
                  ? 'No attendance has been recorded for this event yet.'
                  : 'Select an event to view attendance.'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Attendance List ({attendance.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <DataTable
                data={attendance}
                columns={[
                  {
                    key: 'participant_name',
                    header: 'Participant',
                    render: (a) => (
                      <div>
                        <p className="font-medium">{a.participant_name}</p>
                        <p className="text-xs text-muted-foreground">{a.participant_email}</p>
                      </div>
                    ),
                  },
                  {
                    key: 'attendance_method',
                    header: 'Method',
                    render: (a) => (
                      <Badge variant="outline">
                        {a.attendance_method === 'qr_scan' ? 'QR Scan' : 'Manual'}
                      </Badge>
                    ),
                  },
                  {
                    key: 'scanned_at',
                    header: 'Scanned At',
                    render: (a) => (
                      <span className="text-sm">
                        {a.scanned_at ? format(new Date(a.scanned_at), 'PPp') : 'N/A'}
                      </span>
                    ),
                  },
                  {
                    key: 'status',
                    header: 'Status',
                    render: () => (
                      <Badge className="bg-green-100 text-green-800">Attended</Badge>
                    ),
                  },
                ]}
                searchKeys={['participant_name', 'participant_email']}
                searchPlaceholder="Search participants..."
              />
            </CardContent>
          </Card>
        )}
      </motion.div>
    </DashboardLayout>
  );
}
