import { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Plus, Upload, Trash2, Star, Image as ImageIcon, Loader2, Save, Move,
  Eye, RotateCcw, Palette, Copy, Settings, CheckCircle,
} from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { FontControls } from '@/components/dashboard/font-controls';
import {
  getCertificateTemplates, uploadCertificateTemplate, deleteCertificateTemplate,
  setDefaultCertificateTemplate, updateCertificateTemplateFieldConfig,
  generateCertificateQRCodeDataUrl,
} from '@/services/certificates';
import {
  CertificateTemplate, CertificateFieldConfigs, CertificateFieldConfig,
  CERTIFICATE_FIELD_LABELS, CERTIFICATE_DATA_FIELDS, DEFAULT_CERTIFICATE_FIELD_CONFIG,
} from '@/types/certificates';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_SIZE = 20 * 1024 * 1024;

const FIELD_COLORS: Record<string, string> = {
  participant_name: 'bg-blue-500',
  certificate_number: 'bg-gray-500',
  event_name: 'bg-green-500',
  event_date: 'bg-amber-500',
  issue_date: 'bg-rose-500',
  qr_code: 'bg-slate-600',
  custom_text: 'bg-pink-500',
};

function getSampleData(fieldKey: string): string {
  const df = CERTIFICATE_DATA_FIELDS.find((d) => d.key === fieldKey);
  return df?.sample || fieldKey;
}

// ── Field Settings Editor ────────────────────────────────────────────────────

function FieldSettingsEditor({
  fieldKey, config, onUpdate, onDelete, onDuplicate,
}: {
  fieldKey: string;
  config: CertificateFieldConfig;
  onUpdate: (key: string, updates: Partial<CertificateFieldConfig>) => void;
  onDelete: (key: string) => void;
  onDuplicate: (key: string) => void;
}) {
  const isQR = fieldKey === 'qr_code';
  const canDelete = fieldKey !== 'qr_code';

  return (
    <div className="p-3 rounded-lg bg-muted/50 border space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={cn('w-3 h-3 rounded-full', FIELD_COLORS[fieldKey] || 'bg-gray-400')} />
          <span className="font-medium text-sm">
            {CERTIFICATE_FIELD_LABELS[fieldKey] || config.label || fieldKey}
          </span>
          {!canDelete && (
            <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">Required</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onDuplicate(fieldKey)} title="Duplicate">
            <Copy className="w-3.5 h-3.5" />
          </Button>
          {canDelete && (
            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => onDelete(fieldKey)} title="Remove">
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      </div>

      {/* Position */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label className="text-xs">X Position (%)</Label>
          <div className="flex items-center gap-2">
            <Slider value={[config.x]} min={0} max={100} step={1} onValueChange={([v]) => onUpdate(fieldKey, { x: v })} className="flex-1" />
            <span className="text-xs w-10 text-right">{config.x.toFixed(0)}%</span>
          </div>
        </div>
        <div>
          <Label className="text-xs">Y Position (%)</Label>
          <div className="flex items-center gap-2">
            <Slider value={[config.y]} min={0} max={100} step={1} onValueChange={([v]) => onUpdate(fieldKey, { y: v })} className="flex-1" />
            <span className="text-xs w-10 text-right">{config.y.toFixed(0)}%</span>
          </div>
        </div>
      </div>

      {isQR ? (
        <div>
          <div className="flex items-center justify-between mb-1">
            <Label className="text-xs">QR Size</Label>
            <span className="text-xs text-muted-foreground">{config.size || 12}%</span>
          </div>
          <Slider value={[config.size || 12]} min={5} max={30} step={1} onValueChange={([v]) => onUpdate(fieldKey, { size: v })} className="w-full" />
        </div>
      ) : (
        <>
          {/* Data field selector */}
          <div>
            <Label className="text-xs">Auto-fill from</Label>
            <Select value={config.dataField || fieldKey} onValueChange={(v) => onUpdate(fieldKey, { dataField: v })}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {CERTIFICATE_DATA_FIELDS.map((df) => (
                  <SelectItem key={df.key} value={df.key}>{df.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Font controls */}
          <FontControls
            fontSize={config.fontSize || 14}
            fontColor={config.fontColor || '#000000'}
            fontFamily={config.fontFamily || 'Arial'}
            fontWeight={config.fontWeight}
            align={config.align || 'center'}
            letterSpacing={config.letterSpacing}
            bold={config.bold}
            italic={config.italic}
            underline={config.underline}
            fontSizeMin={10}
            fontSizeMax={60}
            onUpdate={(updates) => onUpdate(fieldKey, updates)}
          />

          {/* Custom label */}
          {fieldKey.includes('_') && (
            <div>
              <Label className="text-xs">Custom Label</Label>
              <Input value={config.label || ''} onChange={(e) => onUpdate(fieldKey, { label: e.target.value })} placeholder="e.g., Field 2" className="h-8" />
            </div>
          )}

          {/* Custom text */}
          {config.dataField === 'custom_text' && (
            <div>
              <Label className="text-xs">Static Text</Label>
              <Input value={config.customText || ''} onChange={(e) => onUpdate(fieldKey, { customText: e.target.value })} placeholder="Enter static text" className="h-8" />
            </div>
          )}
        </>
      )}
    </div>
  );
}

// Select import needed at top — add here for module scope
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

// ── Visual Field Editor ─────────────────────────────────────────────────────

function VisualFieldEditor({
  template, fieldConfig, onFieldChange, onFieldSelect, selectedField, onDeleteField,
}: {
  template: CertificateTemplate;
  fieldConfig: CertificateFieldConfigs;
  onFieldChange: (config: CertificateFieldConfigs) => void;
  onFieldSelect: (key: string | null) => void;
  selectedField: string | null;
  onDeleteField: (key: string) => void;
}) {
  const [dragging, setDragging] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    generateCertificateQRCodeDataUrl('https://example.com/verify/CERT-SAMPLE').then(setQrDataUrl);
  }, []);

  const handleMouseDown = (fieldName: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(fieldName);
    onFieldSelect(fieldName);
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!dragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    onFieldChange({
      ...fieldConfig,
      [dragging]: {
        ...fieldConfig[dragging],
        x: Math.max(0, Math.min(100, x)),
        y: Math.max(0, Math.min(100, y)),
      },
    });
  }, [dragging, fieldConfig, onFieldChange]);

  const handleMouseUp = useCallback(() => setDragging(null), []);

  useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging, handleMouseMove, handleMouseUp]);

  return (
    <div ref={containerRef} className="relative inline-block">
      <div className="relative overflow-hidden rounded-lg border-2 border-border cursor-default" style={{ width: '100%', maxWidth: '1000px', aspectRatio: `${template.template_width}/${template.template_height}` }}>
        <img src={template.template_image_url} alt={template.name} className="w-full h-full object-fill" draggable={false} />

        {Object.entries(fieldConfig).map(([key, config]) => {
          const isQR = key === 'qr_code';
          const bgColorClass = FIELD_COLORS[key] || 'bg-gray-500';
          return (
            <div
              key={key}
              className={cn(
                'absolute cursor-move select-none transition-shadow',
                (dragging === key || selectedField === key) && 'shadow-lg ring-2 ring-primary z-50',
                selectedField !== key && selectedField && 'opacity-50'
              )}
              style={{ left: `${config.x}%`, top: `${config.y}%`, transform: 'translate(-50%, -50%)' }}
              onMouseDown={(e) => handleMouseDown(key, e)}
            >
              {isQR ? (
                <div className="border-2 border-dashed border-blue-400 rounded bg-white/90 p-1" style={{ width: `${(config.size || 12) * 4}px`, height: `${(config.size || 12) * 4}px` }}>
                  {qrDataUrl && <img src={qrDataUrl} alt="QR" className="w-full h-full" />}
                </div>
              ) : (
                <div className="relative group">
                  <div
                    className={cn('px-2 py-1 rounded text-xs font-medium whitespace-nowrap text-white', bgColorClass)}
                    style={{ backgroundColor: config.fontColor || undefined, fontWeight: config.bold ? 'bold' : config.fontWeight, fontStyle: config.italic ? 'italic' : undefined, textDecoration: config.underline ? 'underline' : undefined, letterSpacing: `${config.letterSpacing || 0}px` }}
                  >
                    {config.label || CERTIFICATE_FIELD_LABELS[key] || key}
                  </div>
                  {selectedField === key && (
                    <button className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center rounded-full bg-destructive text-white hover:bg-destructive/80" onClick={(e) => { e.preventDefault(); e.stopPropagation(); if (key !== 'qr_code') { onDeleteField(key); onFieldSelect(null); } }} title="Remove">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
      <p className="text-sm text-muted-foreground mt-2 text-center">Click a field to select, drag to reposition, click X to remove</p>
    </div>
  );
}

// ── Certificate Preview ────────────────────────────────────────────────────

function CertificatePreview({ template, fieldConfig }: { template: CertificateTemplate; fieldConfig: CertificateFieldConfigs }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    generateCertificateQRCodeDataUrl('https://example.com/verify/CERT-SAMPLE').then(setQrDataUrl);
  }, []);

  useEffect(() => {
    if (!canvasRef.current || !qrDataUrl) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = template.template_width;
    canvas.height = template.template_height;

    const bgImg = new Image();
    bgImg.crossOrigin = 'anonymous';
    bgImg.onload = () => {
      ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

      Object.entries(fieldConfig).forEach(([key, config]) => {
        if (key === 'qr_code') return;
        const dataField = config.dataField || key;
        const value = config.customText || getSampleData(dataField);
        const x = (config.x / 100) * canvas.width;
        const y = (config.y / 100) * canvas.height;
        const maxWidth = config.width ? (config.width / 100) * canvas.width : canvas.width * 0.8;

        const parts: string[] = [];
        if (config.italic) parts.push('italic');
        const weight = config.bold ? 'bold' : config.fontWeight;
        if (weight && weight !== 'normal') parts.push(weight);
        parts.push(`${config.fontSize || 14}px`);
        parts.push(config.fontFamily || 'Arial');
        ctx.font = parts.join(' ');
        ctx.fillStyle = config.fontColor || '#000000';
        ctx.textAlign = (config.align as CanvasTextAlign) || 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(value, x, y, maxWidth);
      });

      if (fieldConfig.qr_code && qrDataUrl) {
        const qrConfig = fieldConfig.qr_code;
        const centerX = (qrConfig.x / 100) * canvas.width;
        const centerY = (qrConfig.y / 100) * canvas.height;
        const qrSize = ((qrConfig.size || 12) / 100) * Math.min(canvas.width, canvas.height);
        const qrImg = new Image();
        qrImg.onload = () => {
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(centerX, centerY, qrSize / 2 + 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.drawImage(qrImg, centerX - qrSize / 2, centerY - qrSize / 2, qrSize, qrSize);
          setPreviewUrl(canvas.toDataURL('image/png'));
        };
        qrImg.src = qrDataUrl;
      } else {
        setPreviewUrl(canvas.toDataURL('image/png'));
      }
    };
    bgImg.src = template.template_image_url;
  }, [template, fieldConfig, qrDataUrl]);

  if (!previewUrl) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <img src={previewUrl} alt="Certificate Preview" className="w-full rounded-lg border shadow-lg" style={{ maxWidth: '1000px', margin: '0 auto' }} />
      <p className="text-sm text-muted-foreground text-center">Live preview with sample data — updates instantly</p>
    </div>
  );
}

// ── Main Page ───────────────────────────────────────────────────────────────

export default function CertificateTemplatesPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [templates, setTemplates] = useState<CertificateTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<CertificateTemplate | null>(null);
  const [showEditorDialog, setShowEditorDialog] = useState(false);
  const [editingFieldConfig, setEditingFieldConfig] = useState<CertificateFieldConfigs | null>(null);
  const [savingConfig, setSavingConfig] = useState(false);
  const [selectedFieldKey, setSelectedFieldKey] = useState<string | null>(null);

  const [formName, setFormName] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formFile, setFormFile] = useState<File | null>(null);
  const [formPreview, setFormPreview] = useState<string | null>(null);

  useEffect(() => { loadTemplates(); }, []);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const data = await getCertificateTemplates();
      setTemplates(data);
    } catch {
      toast({ title: 'Error', description: 'Failed to load templates', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!ALLOWED_TYPES.includes(file.type)) {
      toast({ title: 'Invalid file', description: 'Please upload JPG, PNG, or WEBP', variant: 'destructive' });
      return;
    }
    if (file.size > MAX_SIZE) {
      toast({ title: 'File too large', description: 'Maximum size is 20MB', variant: 'destructive' });
      return;
    }
    setFormFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setFormPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!formFile || !formName || !user) {
      toast({ title: 'Missing fields', description: 'Name and image are required', variant: 'destructive' });
      return;
    }
    setUploading(true);
    try {
      await uploadCertificateTemplate(formFile, formName, formDescription, user.id);
      toast({ title: 'Template uploaded', description: 'Certificate template created successfully' });
      setShowUploadDialog(false);
      resetForm();
      loadTemplates();
    } catch (err: any) {
      toast({ title: 'Upload failed', description: err.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      await setDefaultCertificateTemplate(id);
      toast({ title: 'Default updated', description: 'Default certificate template changed' });
      loadTemplates();
    } catch {
      toast({ title: 'Error', description: 'Failed to set default', variant: 'destructive' });
    }
  };

  const handleDelete = async (template: CertificateTemplate) => {
    if (!window.confirm(`Delete "${template.name}"? This cannot be undone.`)) return;
    try {
      await deleteCertificateTemplate(template.id);
      toast({ title: 'Deleted', description: 'Template removed' });
      loadTemplates();
    } catch {
      toast({ title: 'Error', description: 'Failed to delete template', variant: 'destructive' });
    }
  };

  const handleEditFields = (template: CertificateTemplate) => {
    setSelectedTemplate(template);
    setEditingFieldConfig(template.field_config);
    setSelectedFieldKey(null);
    setShowEditorDialog(true);
  };

  const handleUpdateField = (key: string, updates: Partial<CertificateFieldConfig>) => {
    if (!editingFieldConfig) return;
    setEditingFieldConfig({ ...editingFieldConfig, [key]: { ...editingFieldConfig[key], ...updates } });
  };

  const handleAddField = (fieldType: string) => {
    if (!editingFieldConfig) return;
    const existing = Object.keys(editingFieldConfig).filter((k) => k.startsWith(fieldType)).length;
    const newKey = existing > 0 ? `${fieldType}_${existing + 1}` : fieldType;
    setEditingFieldConfig({
      ...editingFieldConfig,
      [newKey]: { x: 50, y: 50, fontSize: 16, fontColor: '#000000', fontFamily: 'Arial', align: 'center', dataField: fieldType, label: `${fieldType} ${existing + 1}` },
    });
    setSelectedFieldKey(newKey);
  };

  const handleDuplicateField = (key: string) => {
    if (!editingFieldConfig) return;
    const existing = Object.keys(editingFieldConfig).filter((k) => k.startsWith(key)).length;
    const newKey = `${key}_${existing + 1}`;
    setEditingFieldConfig({
      ...editingFieldConfig,
      [newKey]: { ...editingFieldConfig[key], x: Math.min(100, editingFieldConfig[key].x + 5), y: Math.min(100, editingFieldConfig[key].y + 5), label: `${editingFieldConfig[key].label || key} (copy)` },
    });
    setSelectedFieldKey(newKey);
  };

  const handleDeleteField = (key: string) => {
    if (!editingFieldConfig) return;
    const { [key]: _, ...rest } = editingFieldConfig;
    setEditingFieldConfig(rest);
    if (selectedFieldKey === key) setSelectedFieldKey(null);
  };

  const handleSaveFieldConfig = async () => {
    if (!selectedTemplate || !editingFieldConfig) return;
    setSavingConfig(true);
    try {
      await updateCertificateTemplateFieldConfig(selectedTemplate.id, editingFieldConfig);
      toast({ title: 'Saved', description: 'Certificate template updated' });
      setShowEditorDialog(false);
      loadTemplates();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setSavingConfig(false);
    }
  };

  const resetForm = () => {
    setFormName('');
    setFormDescription('');
    setFormFile(null);
    setFormPreview(null);
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Certificate Template Engine"
          description="Upload certificate templates, position fields visually, and generate professional certificates"
          actions={
            <Button onClick={() => setShowUploadDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Upload Template
            </Button>
          }
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <Card key={template.id} className="glass-card border-0 shadow-md overflow-hidden">
              <div className="aspect-[4/3] bg-muted relative">
                <img src={template.template_image_url} alt={template.name} className="w-full h-full object-cover" />
                {template.is_default && (
                  <div className="absolute top-2 left-2 px-2 py-1 bg-primary text-primary-foreground text-xs font-medium rounded flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Default
                  </div>
                )}
                <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/60 text-white text-xs rounded">
                  {Object.keys(template.field_config || {}).length} fields
                </div>
              </div>
              <CardContent className="pt-4">
                <h3 className="font-semibold truncate">{template.name}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{template.description || 'No description'}</p>
                <div className="text-xs text-muted-foreground mt-2">{template.template_width} × {template.template_height}px</div>
                <div className="flex flex-wrap items-center gap-2 mt-4">
                  <Button variant="default" size="sm" onClick={() => handleEditFields(template)}>
                    <Move className="w-4 h-4 mr-1" /> Edit Fields
                  </Button>
                  {!template.is_default && (
                    <>
                      <Button variant="ghost" size="sm" onClick={() => handleSetDefault(template.id)}>
                        <Star className="w-4 h-4 mr-1" /> Default
                      </Button>
                      <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => handleDelete(template)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {templates.length === 0 && (
          <div className="text-center py-12">
            <ImageIcon className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-medium mb-2">No certificate templates yet</h3>
            <p className="text-muted-foreground mb-4">Upload your first certificate template to get started.</p>
            <Button onClick={() => setShowUploadDialog(true)}>
              <Plus className="w-4 h-4 mr-2" /> Upload Template
            </Button>
          </div>
        )}

        {/* Upload Dialog */}
        <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Upload Certificate Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Template Name</Label>
                <Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="e.g., Workshop Certificate" />
              </div>
              <div className="space-y-1.5">
                <Label>Description</Label>
                <Textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} placeholder="Brief description" rows={2} />
              </div>
              <div className="space-y-1.5">
                <Label>Template Image</Label>
                <label className={cn('block relative border-2 border-dashed rounded-lg overflow-hidden transition-colors cursor-pointer aspect-[4/3]', !formPreview ? 'border-muted-foreground/25 bg-muted/30 hover:border-primary/50' : 'border-primary/30')}>
                  {formPreview ? (
                    <img src={formPreview} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="absolute inset-0 w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                      <Upload className="w-8 h-8 mb-2" />
                      <p className="text-sm font-medium">Click to upload image</p>
                      <p className="text-xs mt-1">PNG, JPG, WEBP (max 20MB)</p>
                    </div>
                  )}
                  <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={handleFileChange} />
                </label>
                <p className="text-xs text-muted-foreground">Recommended: 1200×850px (landscape). Use 4:3 or 3:2 aspect ratio.</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setShowUploadDialog(false); resetForm(); }}>Cancel</Button>
              <Button onClick={handleUpload} disabled={!formFile || !formName || uploading}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                Upload
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Editor Dialog */}
        <Dialog open={showEditorDialog} onOpenChange={setShowEditorDialog}>
          <DialogContent className="max-w-7xl max-h-[95vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Certificate Template Editor: {selectedTemplate?.name}
              </DialogTitle>
            </DialogHeader>

            {selectedTemplate && editingFieldConfig && (
              <Tabs defaultValue="editor" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="editor"><Move className="w-4 h-4 mr-2" /> Position Fields</TabsTrigger>
                  <TabsTrigger value="settings"><Palette className="w-4 h-4 mr-2" /> Field Settings</TabsTrigger>
                  <TabsTrigger value="preview"><Eye className="w-4 h-4 mr-2" /> Preview</TabsTrigger>
                </TabsList>

                <TabsContent value="editor" className="mt-4">
                  <VisualFieldEditor template={selectedTemplate} fieldConfig={editingFieldConfig} onFieldChange={setEditingFieldConfig} onFieldSelect={setSelectedFieldKey} selectedField={selectedFieldKey} onDeleteField={handleDeleteField} />
                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="text-sm text-muted-foreground mr-2">Add field:</span>
                    {CERTIFICATE_DATA_FIELDS.map((df) => (
                      <Button key={df.key} variant="outline" size="sm" onClick={() => handleAddField(df.key)}>
                        <Plus className="w-3 h-3 mr-1" /> {df.label}
                      </Button>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="settings" className="mt-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">Field Settings</h3>
                      <Button variant="outline" size="sm" onClick={() => { setEditingFieldConfig(DEFAULT_CERTIFICATE_FIELD_CONFIG); setSelectedFieldKey(null); }}>
                        <RotateCcw className="w-4 h-4 mr-2" /> Reset All
                      </Button>
                    </div>
                    <div className="grid gap-4">
                      {Object.entries(editingFieldConfig).map(([key, config]) => (
                        <FieldSettingsEditor key={key} fieldKey={key} config={config} onUpdate={handleUpdateField} onDelete={handleDeleteField} onDuplicate={handleDuplicateField} />
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="preview" className="mt-4">
                  <CertificatePreview template={selectedTemplate} fieldConfig={editingFieldConfig} />
                </TabsContent>
              </Tabs>
            )}

            <DialogFooter className="flex gap-2 mt-4">
              <Button variant="outline" onClick={() => setShowEditorDialog(false)}>Cancel</Button>
              <Button onClick={handleSaveFieldConfig} disabled={savingConfig}>
                {savingConfig ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                Save Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </DashboardLayout>
  );
}
