import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { DataTable, PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Trash2, UserPlus, Key, Shield, Ban, Pencil, Loader2, CheckCircle, XCircle, Clock, Users, RefreshCw } from 'lucide-react';
import {
  getPortalUsers, createPortalUser, updatePortalUser, deletePortalUser, forcePasswordReset,
  getPendingRegistrations, approveUser, rejectUser,
} from '@/services/cms';
import type { PortalUser, PendingRegistration } from '@/services/cms';
import { roleLabels } from '@/types/auth';
import type { UserRole } from '@/types/auth';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const roleOptions: UserRole[] = ['super_admin', 'admin', 'faculty', 'ceo', 'program_officer', 'executive', 'student'];
const emptyForm = { name: '', email: '', role: 'student' as UserRole, is_active: true, department: '', branch: '', semester: '' };

// ─── Pending Approvals Tab ────────────────────────────────────────────────────
function PendingApprovalsTab() {
  const { toast } = useToast();
  const [registrations, setRegistrations] = useState<PendingRegistration[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectTarget, setRejectTarget] = useState<PendingRegistration | null>(null);
  const [approving, setApproving] = useState<string | null>(null);
  const [rejecting, setRejecting] = useState(false);
  const [assignRoleOpen, setAssignRoleOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<PendingRegistration | null>(null);
  const [assignRole, setAssignRole] = useState<UserRole>('student');

  const load = async () => {
    try {
      setLoading(true);
      setRegistrations(await getPendingRegistrations());
    } catch {
      toast({ title: 'Error', description: 'Failed to load registrations', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleApprove = async (reg: PendingRegistration, role: string) => {
    try {
      setApproving(reg.id);
      await approveUser(reg.id, role);
      setRegistrations(prev => prev.filter(r => r.id !== reg.id));
      toast({ title: 'Approved', description: `${reg.name} approved as ${roleLabels[role as UserRole] || role}` });
      setAssignRoleOpen(false);
    } catch {
      toast({ title: 'Error', description: 'Failed to approve user', variant: 'destructive' });
    } finally {
      setApproving(null);
    }
  };

  const handleReject = async () => {
    if (!rejectTarget) return;
    try {
      setRejecting(true);
      await rejectUser(rejectTarget.id);
      setRegistrations(prev => prev.filter(r => r.id !== rejectTarget.id));
      toast({ title: 'Rejected', description: `${rejectTarget.name}'s registration rejected` });
      setRejectTarget(null);
    } catch {
      toast({ title: 'Error', description: 'Failed to reject registration', variant: 'destructive' });
    } finally {
      setRejecting(false);
    }
  };

  const openAssignRole = (reg: PendingRegistration) => {
    setSelectedUser(reg);
    setAssignRole('student');
    setAssignRoleOpen(true);
  };

  if (loading) {
    return <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {registrations.length === 0
            ? 'All registrations have been reviewed.'
            : `${registrations.length} registration${registrations.length > 1 ? 's' : ''} awaiting review`}
        </p>
        <Button variant="outline" size="sm" className="gap-2" onClick={load}>
          <RefreshCw className="w-4 h-4" />Refresh
        </Button>
      </div>

      {registrations.length === 0 ? (
        <Card className="glass-card border-0 shadow-lg">
          <CardContent className="py-16 text-center">
            <CheckCircle className="w-12 h-12 text-emerald-400/40 mx-auto mb-4" />
            <p className="font-medium text-muted-foreground">No pending registrations</p>
            <p className="text-sm text-muted-foreground/60 mt-1">New registrations will appear here for review.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {registrations.map((reg, i) => (
            <motion.div
              key={reg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
            >
              <Card className="glass-card border-0 shadow-lg hover:border-primary/20 transition-colors">
                <CardContent className="pt-5 pb-5">
                  <div className="flex items-start gap-4 flex-wrap sm:flex-nowrap">
                    {/* Avatar */}
                    <div className="w-11 h-11 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg shrink-0">
                      {reg.name.charAt(0).toUpperCase()}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0 space-y-1.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold">{reg.name}</h3>
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/20">
                          <Clock className="w-3 h-3" />Pending
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">{reg.email}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {reg.department && <Badge variant="secondary" className="text-xs">{reg.department}</Badge>}
                        {reg.branch && <Badge variant="secondary" className="text-xs">{reg.branch}</Badge>}
                        {reg.semester && <Badge variant="secondary" className="text-xs">Sem {reg.semester}</Badge>}
                      </div>
                      <p className="text-xs text-muted-foreground/60">
                        Registered {new Date(reg.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
                      <Button
                        className="flex-1 sm:flex-none gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90 h-9"
                        onClick={() => openAssignRole(reg)}
                        disabled={!!approving}
                      >
                        {approving === reg.id
                          ? <Loader2 className="w-4 h-4 animate-spin" />
                          : <CheckCircle className="w-4 h-4" />}
                        Approve
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-9 w-9 text-destructive hover:text-destructive hover:bg-destructive/10 shrink-0"
                        onClick={() => setRejectTarget(reg)}
                        disabled={!!approving}
                      >
                        <XCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Assign Role Dialog */}
      <Dialog open={assignRoleOpen} onOpenChange={setAssignRoleOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Approve & Assign Role</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-primary/5 border border-primary/20">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold">
                {selectedUser?.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="font-semibold text-sm">{selectedUser?.name}</p>
                <p className="text-xs text-muted-foreground">{selectedUser?.email}</p>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Assign Role</Label>
              <Select value={assignRole} onValueChange={v => setAssignRole(v as UserRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {roleOptions.map(r => (
                    <SelectItem key={r} value={r}>
                      <div className="flex items-center gap-2">
                        <Shield className="w-3 h-3 text-primary" />
                        {roleLabels[r]}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignRoleOpen(false)}>Cancel</Button>
            <Button
              className="bg-gradient-to-r from-primary to-accent hover:opacity-90"
              onClick={() => selectedUser && handleApprove(selectedUser, assignRole)}
              disabled={!!approving}
            >
              {approving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Approve as {roleLabels[assignRole]}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!rejectTarget}
        onClose={() => setRejectTarget(null)}
        onConfirm={handleReject}
        title="Reject Registration"
        description={`Reject ${rejectTarget?.name}'s registration? Their account will be disabled.`}
        confirmText={rejecting ? 'Rejecting...' : 'Reject'}
        variant="destructive"
      />
    </div>
  );
}

// ─── All Users Tab ─────────────────────────────────────────────────────────────
function AllUsersTab() {
  const { toast } = useToast();
  const [users, setUsers] = useState<PortalUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<PortalUser | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<PortalUser | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true);
      setUsers(await getPortalUsers());
    } catch {
      toast({ title: 'Error', description: 'Failed to load users', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const openCreate = () => {
    setEditTarget(null);
    setForm(emptyForm);
    setFormOpen(true);
  };

  const openEdit = (u: PortalUser) => {
    setEditTarget(u);
    setForm({
      name: u.name,
      email: u.email,
      role: u.role as UserRole,
      is_active: u.is_active,
      department: u.department || '',
      branch: u.branch || '',
      semester: u.semester?.toString() || '',
    });
    setFormOpen(true);
  };

  const handleSuspend = async (u: PortalUser) => {
    try {
      const updated = await updatePortalUser(u.id, { is_active: !u.is_active });
      setUsers(prev => prev.map(x => x.id === u.id ? updated : x));
      toast({ title: updated.is_active ? 'Activated' : 'Suspended', description: `${u.name}'s account ${updated.is_active ? 'activated' : 'suspended'}` });
    } catch {
      toast({ title: 'Error', description: 'Failed to update user', variant: 'destructive' });
    }
  };

  const handleResetPassword = async (u: PortalUser) => {
    try {
      await forcePasswordReset(u.id);
      toast({ title: 'Password Reset Required', description: `${u.name} will be prompted to change password on next login` });
    } catch {
      toast({ title: 'Error', description: 'Failed to set password reset flag', variant: 'destructive' });
    }
  };

  const handleSave = async () => {
    if (!form.name || !form.email) {
      toast({ title: 'Validation Error', description: 'Name and email are required', variant: 'destructive' });
      return;
    }
    try {
      setSaving(true);
      if (editTarget) {
        const updated = await updatePortalUser(editTarget.id, {
          name: form.name,
          email: form.email,
          role: form.role,
          is_active: form.is_active,
          department: form.department || null,
          branch: form.branch || null,
          semester: form.semester ? Number(form.semester) : null,
        });
        setUsers(prev => prev.map(u => u.id === editTarget.id ? updated : u));
        toast({ title: 'Updated', description: `${form.name} updated` });
      } else {
        const created = await createPortalUser({
          name: form.name,
          email: form.email,
          role: form.role,
          is_active: form.is_active,
          department: form.department || null,
          branch: form.branch || null,
          semester: form.semester ? Number(form.semester) : null,
          status: 'approved',
          must_change_password: true,
          last_login: null,
        });
        setUsers(prev => [created, ...prev]);
        toast({ title: 'User Added', description: `${form.name} added — must change password on first login` });
      }
      setFormOpen(false);
    } catch (err: unknown) {
      toast({ title: 'Failed', description: (err as Error).message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      await deletePortalUser(deleteTarget.id, deleteTarget.auth_user_id);
      setUsers(prev => prev.filter(u => u.id !== deleteTarget.id));
      toast({ title: 'Deleted', description: `${deleteTarget.name} removed successfully` });
      setDeleteTarget(null);
    } catch (err: any) {
      toast({ title: 'Error', description: err?.message || 'Failed to delete user', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div />
        <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={openCreate}>
          <UserPlus className="w-4 h-4" />Add User
        </Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
      ) : (
        <>
          <Card className="glass-card border-0 shadow-lg p-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {(['super_admin', 'admin', 'faculty', 'student'] as UserRole[]).map(role => (
                <div key={role} className="text-center">
                  <p className="text-2xl font-bold">{users.filter(u => u.role === role).length}</p>
                  <p className="text-xs text-muted-foreground">{roleLabels[role]}</p>
                </div>
              ))}
            </div>
          </Card>

          <DataTable
            data={users}
            columns={[
              { key: 'name', header: 'User', render: (u) => (
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-sm font-semibold shrink-0">
                    {u.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium">{u.name}</p>
                    <p className="text-xs text-muted-foreground">{u.email}</p>
                  </div>
                </div>
              )},
              { key: 'role', header: 'Role', render: (u) => (
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{roleLabels[u.role as UserRole] || u.role}</span>
                </div>
              )},
              { key: 'department', header: 'Department', render: (u) => (
                <span className="text-sm text-muted-foreground">{u.department || '—'}</span>
              )},
              { key: 'is_active', header: 'Status', render: (u) => {
                const map: Record<string, { label: string; variant: 'default' | 'destructive' | 'outline' | 'secondary' }> = {
                  approved: { label: u.is_active ? 'Active' : 'Suspended', variant: u.is_active ? 'default' : 'destructive' },
                  pending: { label: 'Pending', variant: 'secondary' },
                  rejected: { label: 'Rejected', variant: 'destructive' },
                };
                const s = map[u.status] || map.approved;
                return <Badge variant={s.variant}>{s.label}</Badge>;
              }},
              { key: 'last_login', header: 'Last Login', render: (u) => (
                <span className="text-sm text-muted-foreground">{u.last_login ? new Date(u.last_login).toLocaleDateString() : 'Never'}</span>
              )},
            ]}
            searchKeys={['name', 'email', 'department']}
            searchPlaceholder="Search users..."
            actions={(u) => (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(u)}><Pencil className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" title="Force Password Reset" onClick={() => handleResetPassword(u)}><Key className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" title={u.is_active ? 'Suspend' : 'Activate'} onClick={() => handleSuspend(u)}>
                  <Ban className={cn('w-4 h-4', u.is_active ? 'text-amber-500' : 'text-emerald-500')} />
                </Button>
                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => setDeleteTarget(u)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )}
          />
        </>
      )}

      {/* Add / Edit Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editTarget ? 'Edit User' : 'Add User'}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Full Name <span className="text-destructive">*</span></Label>
                <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="John Doe" />
              </div>
              <div className="space-y-1.5">
                <Label>Email <span className="text-destructive">*</span></Label>
                <Input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="user@innotex.com" />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Role</Label>
                <Select value={form.role} onValueChange={v => setForm(f => ({ ...f, role: v as UserRole }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{roleOptions.map(r => <SelectItem key={r} value={r}>{roleLabels[r]}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Department</Label>
                <Input value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))} placeholder="e.g. Mechanical Engineering" />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Branch</Label>
                <Input value={form.branch} onChange={e => setForm(f => ({ ...f, branch: e.target.value }))} placeholder="e.g. ME, PT" />
              </div>
              <div className="space-y-1.5">
                <Label>Semester</Label>
                <Input type="number" min="1" max="8" value={form.semester} onChange={e => setForm(f => ({ ...f, semester: e.target.value }))} placeholder="1–8" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <Label>Active</Label>
              <Switch checked={form.is_active} onCheckedChange={v => setForm(f => ({ ...f, is_active: v }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editTarget ? 'Save Changes' : 'Add User'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        title="Delete User"
        description={`Delete "${deleteTarget?.name}"? This cannot be undone.`}
        confirmText={deleting ? 'Deleting...' : 'Delete'}
        variant="destructive"
      />
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────────
export default function UsersManagement() {
  const [activeTab, setActiveTab] = useState<'users' | 'pending'>('users');
  const [pendingCount, setPendingCount] = useState<number | null>(null);

  useEffect(() => {
    getPendingRegistrations()
      .then(r => setPendingCount(r.length))
      .catch(() => setPendingCount(null));
  }, []);

  const tabs = [
    { id: 'users' as const, label: 'All Users', icon: Users },
    { id: 'pending' as const, label: 'Pending Approvals', icon: Clock, count: pendingCount },
  ];

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="User Management"
          description="Manage user accounts, roles, and pending registrations"
        />

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-muted/20 border border-white/5 w-fit">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  'relative flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap',
                  activeTab === tab.id
                    ? 'bg-primary text-white shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
                {tab.count != null && tab.count > 0 && (
                  <span className={cn(
                    'inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-bold',
                    activeTab === tab.id
                      ? 'bg-white text-primary'
                      : 'bg-amber-500 text-white'
                  )}>
                    {tab.count > 9 ? '9+' : tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === 'users' && <AllUsersTab />}
            {activeTab === 'pending' && <PendingApprovalsTab />}
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </DashboardLayout>
  );
}
