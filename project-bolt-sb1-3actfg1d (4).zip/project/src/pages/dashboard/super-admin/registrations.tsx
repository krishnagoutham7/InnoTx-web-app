import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, XCircle, Clock, Shield, Loader2 } from 'lucide-react';
import { getPendingRegistrations, approveUser, rejectUser } from '@/services/cms';
import type { PendingRegistration } from '@/services/cms';
import { roleLabels } from '@/types/auth';
import type { UserRole } from '@/types/auth';
import { useToast } from '@/hooks/use-toast';

const roleOptions: UserRole[] = ['student', 'executive', 'program_officer', 'ceo', 'faculty', 'admin', 'super_admin'];

export default function PendingRegistrations() {
  const { toast } = useToast();
  const [registrations, setRegistrations] = useState<PendingRegistration[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectTarget, setRejectTarget] = useState<PendingRegistration | null>(null);
  const [approving, setApproving] = useState<string | null>(null);
  const [rejecting, setRejecting] = useState(false);
  const [assignRoleOpen, setAssignRoleOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<PendingRegistration | null>(null);
  const [assignRole, setAssignRole] = useState<string>('student');

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true);
      setRegistrations(await getPendingRegistrations());
    } catch {
      toast({ title: 'Error', description: 'Failed to load registrations', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const handleApprove = async (reg: PendingRegistration, role: string) => {
    try {
      setApproving(reg.id);
      await approveUser(reg.id, role);
      setRegistrations(prev => prev.filter(r => r.id !== reg.id));
      toast({ title: 'Approved', description: `${reg.name} has been approved as ${roleLabels[role as UserRole] || role}` });
      setAssignRoleOpen(false);
    } catch {
      toast({ title: 'Error', description: 'Failed to approve user', variant: 'destructive' });
    } finally {
      setApproving(null);
    }
  };

  const handleReject = async () => {
    if (!rejectTarget) return;
    try {
      setRejecting(true);
      await rejectUser(rejectTarget.id);
      setRegistrations(prev => prev.filter(r => r.id !== rejectTarget.id));
      toast({ title: 'Rejected', description: `${rejectTarget.name}'s registration has been rejected` });
      setRejectTarget(null);
    } catch {
      toast({ title: 'Error', description: 'Failed to reject user', variant: 'destructive' });
    } finally {
      setRejecting(false);
    }
  };

  const openAssignRole = (reg: PendingRegistration) => {
    setSelectedUser(reg);
    setAssignRole('student');
    setAssignRoleOpen(true);
  };

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Pending Registrations"
          description="Review and approve new user registrations"
          actions={
            <Button variant="outline" className="gap-2" onClick={load}>
              <Clock className="w-4 h-4" />Refresh
            </Button>
          }
        />

        {loading ? (
          <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : registrations.length === 0 ? (
          <Card className="glass-card border-0 shadow-lg">
            <CardContent className="py-16 text-center">
              <CheckCircle className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-sm text-muted-foreground">No pending registrations</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {registrations.map(reg => (
              <motion.div key={reg.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <Card className="glass-card border-0 shadow-lg hover:shadow-xl transition-shadow">
                  <CardContent className="pt-5 pb-5">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-4 flex-1 min-w-0">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-semibold shrink-0">
                          {reg.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold truncate">{reg.name}</h3>
                            <Badge variant="outline" className="shrink-0">
                              <Clock className="w-3 h-3 mr-1" />Pending
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{reg.email}</p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {reg.department && <Badge variant="secondary" className="text-xs">{reg.department}</Badge>}
                            {reg.branch && <Badge variant="secondary" className="text-xs">{reg.branch}</Badge>}
                            {reg.semester && <Badge variant="secondary" className="text-xs">Semester {reg.semester}</Badge>}
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">
                            Registered {new Date(reg.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Button
                          className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90"
                          onClick={() => openAssignRole(reg)}
                          disabled={approving === reg.id}
                        >
                          {approving === reg.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => setRejectTarget(reg)}
                        >
                          <XCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Assign Role Dialog */}
        <Dialog open={assignRoleOpen} onOpenChange={setAssignRoleOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Approve & Assign Role</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <p className="text-sm text-muted-foreground">
                Approve <span className="font-medium text-foreground">{selectedUser?.name}</span> and assign a role:
              </p>
              <Select value={assignRole} onValueChange={setAssignRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {roleOptions.map(r => (
                    <SelectItem key={r} value={r}>
                      <div className="flex items-center gap-2">
                        <Shield className="w-3 h-3" />
                        {roleLabels[r]}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAssignRoleOpen(false)}>Cancel</Button>
              <Button
                className="bg-gradient-to-r from-primary to-accent hover:opacity-90"
                onClick={() => selectedUser && handleApprove(selectedUser, assignRole)}
                disabled={!!approving}
              >
                {approving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                Approve as {roleLabels[assignRole as UserRole]}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <ConfirmDialog open={!!rejectTarget} onClose={() => setRejectTarget(null)} onConfirm={handleReject}
          title="Reject Registration" description={`Reject ${rejectTarget?.name}? This will disable their account.`}
          confirmText={rejecting ? 'Rejecting...' : 'Reject'} variant="destructive" />
      </motion.div>
    </DashboardLayout>
  );
}
