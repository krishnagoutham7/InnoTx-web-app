import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Save, Eye, Loader2 } from 'lucide-react';
import { getContactInfo, updateContactInfo } from '@/services/cms';
import type { ContactInfo } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

export default function ContactInfoCMSPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [data, setData] = useState<ContactInfo | null>(null);

  useEffect(() => {
    getContactInfo()
      .then(d => { if (d) setData(d); })
      .catch(() => toast({ title: 'Error', description: 'Failed to load contact info', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  const set = (key: keyof ContactInfo, value: string) =>
    setData(d => d ? { ...d, [key]: value } : d);

  const handleSave = async () => {
    if (!data) return;
    try {
      setSaving(true);
      const updated = await updateContactInfo({
        address: data.address,
        phone: data.phone,
        email: data.email,
        office_hours: data.office_hours,
        saturday_hours: data.saturday_hours,
        instagram_url: data.instagram_url,
        twitter_url: data.twitter_url,
        linkedin_url: data.linkedin_url,
        github_url: data.github_url,
        mail_url: data.mail_url,
      });
      setData(updated);
      toast({ title: 'Saved', description: 'Contact info updated successfully' });
    } catch {
      toast({ title: 'Save Failed', description: 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
      </DashboardLayout>
    );
  }

  if (!data) return null;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader title="Contact Info CMS" description="Manage contact details shown on the public site"
          actions={
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2" asChild><a href="/contact" target="_blank"><Eye className="w-4 h-4" />Preview</a></Button>
              <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Save Changes
              </Button>
            </div>
          }
        />

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Contact Details */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Contact Details</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Address</Label>
                <Input value={data.address} onChange={e => set('address', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input value={data.phone} onChange={e => set('phone', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input type="email" value={data.email} onChange={e => set('email', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Office Hours (Weekdays)</Label>
                <Input value={data.office_hours} onChange={e => set('office_hours', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Office Hours (Saturday)</Label>
                <Input value={data.saturday_hours} onChange={e => set('saturday_hours', e.target.value)} />
              </div>
            </CardContent>
          </Card>

          {/* Social Links */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Social Media Links</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Instagram URL</Label>
                <Input value={data.instagram_url} onChange={e => set('instagram_url', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Twitter / X URL</Label>
                <Input value={data.twitter_url} onChange={e => set('twitter_url', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>LinkedIn URL</Label>
                <Input value={data.linkedin_url} onChange={e => set('linkedin_url', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>GitHub URL</Label>
                <Input value={data.github_url} onChange={e => set('github_url', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Mail / Email Link</Label>
                <Input value={data.mail_url} onChange={e => set('mail_url', e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
