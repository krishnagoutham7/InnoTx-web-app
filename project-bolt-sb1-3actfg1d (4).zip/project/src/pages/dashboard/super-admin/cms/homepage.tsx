import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Save, Eye, Loader2 } from 'lucide-react';
import { getHomepageCMS, updateHomepageCMS } from '@/services/cms';
import type { HomepageCMS, HomepageStat } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

export default function HomepageCMSPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [data, setData] = useState<HomepageCMS | null>(null);

  useEffect(() => {
    getHomepageCMS()
      .then(d => { if (d) setData(d); })
      .catch(() => toast({ title: 'Error', description: 'Failed to load homepage content', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  const set = (key: keyof HomepageCMS, value: string | number | HomepageStat[] | boolean) =>
    setData(d => d ? { ...d, [key]: value } : d);

  const updateStat = (index: number, field: keyof HomepageStat, value: string | number) => {
    if (!data) return;
    const newStats = [...data.stats];
    newStats[index] = { ...newStats[index], [field]: value };
    set('stats', newStats);
  };

  const handleSave = async () => {
    if (!data) return;
    try {
      setSaving(true);
      const updated = await updateHomepageCMS({
        hero_headline: data.hero_headline,
        hero_tagline: data.hero_tagline,
        hero_description: data.hero_description,
        hero_cta_primary_text: data.hero_cta_primary_text,
        hero_cta_primary_link: data.hero_cta_primary_link,
        hero_cta_secondary_text: data.hero_cta_secondary_text,
        hero_cta_secondary_link: data.hero_cta_secondary_link,
        stats: data.stats,
        about_title: data.about_title,
        about_description: data.about_description,
        vision_title: data.vision_title,
        vision_content: data.vision_content,
        mission_title: data.mission_title,
        mission_content: data.mission_content,
        show_announcements: data.show_announcements,
        show_events: data.show_events,
        show_gallery: data.show_gallery,
      });
      setData(updated);
      toast({ title: 'Saved', description: 'Homepage content updated successfully' });
    } catch {
      toast({ title: 'Save Failed', description: 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
      </DashboardLayout>
    );
  }

  if (!data) return null;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader title="Homepage CMS" description="Manage homepage content and sections"
          actions={
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2" asChild><a href="/" target="_blank"><Eye className="w-4 h-4" />Preview</a></Button>
              <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Save Changes
              </Button>
            </div>
          }
        />

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Hero Section */}
          <Card className="glass-card border-0 shadow-lg lg:col-span-2">
            <CardHeader><CardTitle className="text-lg">Hero Section</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Headline</Label>
                  <Input value={data.hero_headline} onChange={e => set('hero_headline', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Tagline</Label>
                  <Input value={data.hero_tagline} onChange={e => set('hero_tagline', e.target.value)} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea value={data.hero_description} onChange={e => set('hero_description', e.target.value)} rows={3} />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Primary CTA Text</Label>
                  <Input value={data.hero_cta_primary_text} onChange={e => set('hero_cta_primary_text', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Primary CTA Link</Label>
                  <Input value={data.hero_cta_primary_link} onChange={e => set('hero_cta_primary_link', e.target.value)} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Statistics</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {data.stats.map((stat, i) => (
                <div key={i} className="grid grid-cols-3 gap-2">
                  <Input
                    type="number"
                    value={stat.value}
                    onChange={e => updateStat(i, 'value', Number(e.target.value))}
                    placeholder="Value"
                  />
                  <Input
                    value={stat.label}
                    onChange={e => updateStat(i, 'label', e.target.value)}
                    placeholder="Label"
                    className="col-span-2"
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Vision */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Vision</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={data.vision_title} onChange={e => set('vision_title', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Content</Label>
                <Textarea value={data.vision_content || ''} onChange={e => set('vision_content', e.target.value)} rows={4} />
              </div>
            </CardContent>
          </Card>

          {/* Mission */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Mission</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={data.mission_title} onChange={e => set('mission_title', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Content</Label>
                <Textarea value={data.mission_content || ''} onChange={e => set('mission_content', e.target.value)} rows={4} />
              </div>
            </CardContent>
          </Card>

          {/* About Preview */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">About Preview</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={data.about_title} onChange={e => set('about_title', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea value={data.about_description || ''} onChange={e => set('about_description', e.target.value)} rows={3} />
              </div>
            </CardContent>
          </Card>

          {/* Section Visibility */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Section Visibility</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={data.show_announcements} onChange={e => set('show_announcements', e.target.checked)} className="rounded" />
                <span className="text-sm">Show Announcements</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={data.show_events} onChange={e => set('show_events', e.target.checked)} className="rounded" />
                <span className="text-sm">Show Events</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={data.show_gallery} onChange={e => set('show_gallery', e.target.checked)} className="rounded" />
                <span className="text-sm">Show Gallery</span>
              </label>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
