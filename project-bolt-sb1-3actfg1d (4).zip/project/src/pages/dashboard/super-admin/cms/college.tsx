import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Save, Eye, Loader2 } from 'lucide-react';
import { getCollegeInfo, updateCollegeInfo } from '@/services/cms';
import type { CollegeInfo } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

export default function CollegeInfoCMSPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [data, setData] = useState<CollegeInfo | null>(null);

  useEffect(() => {
    getCollegeInfo()
      .then(d => { if (d) setData(d); })
      .catch(() => toast({ title: 'Error', description: 'Failed to load college info', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  const set = (key: keyof CollegeInfo, value: string) =>
    setData(d => d ? { ...d, [key]: value } : d);

  const handleSave = async () => {
    if (!data) return;
    try {
      setSaving(true);
      const updated = await updateCollegeInfo({
        name: data.name,
        short_name: data.short_name,
        address: data.address,
        phone: data.phone,
        email: data.email,
        website: data.website,
        map_embed_url: data.map_embed_url,
        map_link: data.map_link,
        portal_name: data.portal_name,
        portal_tagline: data.portal_tagline,
        portal_description: data.portal_description,
        institution_type: data.institution_type,
        district: data.district,
        state: data.state,
        programme: data.programme,
      });
      setData(updated);
      toast({ title: 'Saved', description: 'College info updated successfully' });
    } catch {
      toast({ title: 'Save Failed', description: 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
      </DashboardLayout>
    );
  }

  if (!data) return null;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader title="College Info CMS" description="Manage institution and portal information"
          actions={
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2" asChild><a href="/about" target="_blank"><Eye className="w-4 h-4" />Preview</a></Button>
              <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Save Changes
              </Button>
            </div>
          }
        />

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Institution Details */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Institution Details</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={data.name} onChange={e => set('name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Short Name</Label>
                <Input value={data.short_name} onChange={e => set('short_name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Institution Type</Label>
                <Input value={data.institution_type} onChange={e => set('institution_type', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>District</Label>
                  <Input value={data.district} onChange={e => set('district', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>State</Label>
                  <Input value={data.state} onChange={e => set('state', e.target.value)} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Programme</Label>
                <Input value={data.programme} onChange={e => set('programme', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Address</Label>
                <Input value={data.address} onChange={e => set('address', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input value={data.phone} onChange={e => set('phone', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={data.email} onChange={e => set('email', e.target.value)} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Website</Label>
                <Input value={data.website} onChange={e => set('website', e.target.value)} />
              </div>
            </CardContent>
          </Card>

          {/* Portal / IEDC Info */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Portal / IEDC Info</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Portal Name</Label>
                <Input value={data.portal_name} onChange={e => set('portal_name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Portal Tagline</Label>
                <Input value={data.portal_tagline} onChange={e => set('portal_tagline', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Portal Description</Label>
                <Textarea value={data.portal_description} onChange={e => set('portal_description', e.target.value)} rows={4} />
              </div>
              <div className="space-y-2">
                <Label>Map Embed URL</Label>
                <Textarea value={data.map_embed_url} onChange={e => set('map_embed_url', e.target.value)} rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Map Link</Label>
                <Input value={data.map_link} onChange={e => set('map_link', e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
