import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Save, Eye, Loader2 } from 'lucide-react';
import { getAboutPage, updateAboutPage } from '@/services/cms';
import type { AboutPage } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

export default function AboutPageCMSPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [data, setData] = useState<AboutPage | null>(null);

  useEffect(() => {
    getAboutPage()
      .then(d => { if (d) setData(d); })
      .catch(() => toast({ title: 'Error', description: 'Failed to load about page content', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  const set = (key: keyof AboutPage, value: string) =>
    setData(d => d ? { ...d, [key]: value } : d);

  const handleSave = async () => {
    if (!data) return;
    try {
      setSaving(true);
      const updated = await updateAboutPage({
        vision_heading: data.vision_heading,
        vision_content: data.vision_content,
        mission_heading: data.mission_heading,
        mission_content: data.mission_content,
        obj_1_title: data.obj_1_title, obj_1_description: data.obj_1_description,
        obj_2_title: data.obj_2_title, obj_2_description: data.obj_2_description,
        obj_3_title: data.obj_3_title, obj_3_description: data.obj_3_description,
        obj_4_title: data.obj_4_title, obj_4_description: data.obj_4_description,
        obj_5_title: data.obj_5_title, obj_5_description: data.obj_5_description,
        obj_6_title: data.obj_6_title, obj_6_description: data.obj_6_description,
        iedc_title: data.iedc_title,
        iedc_description_1: data.iedc_description_1,
        iedc_description_2: data.iedc_description_2,
        iedc_description_3: data.iedc_description_3,
        ksum_title: data.ksum_title,
        ksum_description_1: data.ksum_description_1,
        ksum_description_2: data.ksum_description_2,
        ksum_description_3: data.ksum_description_3,
        ksum_website: data.ksum_website,
      });
      setData(updated);
      toast({ title: 'Saved', description: 'About page content updated successfully' });
    } catch {
      toast({ title: 'Save Failed', description: 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
      </DashboardLayout>
    );
  }

  if (!data) return null;

  const objectives = ([1, 2, 3, 4, 5, 6] as const).map(n => ({
    n,
    title: data[`obj_${n}_title` as keyof AboutPage] as string,
    description: data[`obj_${n}_description` as keyof AboutPage] as string,
  }));

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader title="About Page CMS" description="Manage vision, mission, objectives, IEDC and KSUM content"
          actions={
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2" asChild><a href="/about" target="_blank"><Eye className="w-4 h-4" />Preview</a></Button>
              <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Save Changes
              </Button>
            </div>
          }
        />

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Vision */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Vision</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Heading</Label>
                <Input value={data.vision_heading} onChange={e => set('vision_heading', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Content</Label>
                <Textarea value={data.vision_content} onChange={e => set('vision_content', e.target.value)} rows={5} />
              </div>
            </CardContent>
          </Card>

          {/* Mission */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Mission</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Heading</Label>
                <Input value={data.mission_heading} onChange={e => set('mission_heading', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Content</Label>
                <Textarea value={data.mission_content} onChange={e => set('mission_content', e.target.value)} rows={5} />
              </div>
            </CardContent>
          </Card>

          {/* Objectives */}
          <Card className="glass-card border-0 shadow-lg lg:col-span-2">
            <CardHeader><CardTitle className="text-lg">Objectives</CardTitle></CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {objectives.map(obj => (
                  <div key={obj.n} className="space-y-3 p-4 rounded-lg bg-muted/30">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Objective {obj.n}</p>
                    <div className="space-y-2">
                      <Label className="text-xs">Title</Label>
                      <Input
                        value={obj.title}
                        onChange={e => set(`obj_${obj.n}_title` as keyof AboutPage, e.target.value)}
                        className="h-8 text-sm"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Description</Label>
                      <Textarea
                        value={obj.description}
                        onChange={e => set(`obj_${obj.n}_description` as keyof AboutPage, e.target.value)}
                        rows={2}
                        className="text-sm"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* IEDC Info */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">IEDC Information</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={data.iedc_title} onChange={e => set('iedc_title', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Paragraph 1</Label>
                <Textarea value={data.iedc_description_1} onChange={e => set('iedc_description_1', e.target.value)} rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Paragraph 2</Label>
                <Textarea value={data.iedc_description_2} onChange={e => set('iedc_description_2', e.target.value)} rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Paragraph 3</Label>
                <Textarea value={data.iedc_description_3} onChange={e => set('iedc_description_3', e.target.value)} rows={3} />
              </div>
            </CardContent>
          </Card>

          {/* KSUM Info */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader><CardTitle className="text-lg">Kerala Startup Mission</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={data.ksum_title} onChange={e => set('ksum_title', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Paragraph 1</Label>
                <Textarea value={data.ksum_description_1} onChange={e => set('ksum_description_1', e.target.value)} rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Paragraph 2</Label>
                <Textarea value={data.ksum_description_2} onChange={e => set('ksum_description_2', e.target.value)} rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Paragraph 3</Label>
                <Textarea value={data.ksum_description_3} onChange={e => set('ksum_description_3', e.target.value)} rows={3} />
              </div>
              <div className="space-y-2">
                <Label>Website URL</Label>
                <Input value={data.ksum_website} onChange={e => set('ksum_website', e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
