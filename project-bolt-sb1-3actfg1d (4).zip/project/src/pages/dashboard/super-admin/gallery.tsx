import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Images, Pencil, Trash2, FolderPlus, Loader2, Upload } from 'lucide-react';
import {
  getGalleryAlbums, createGalleryAlbum, updateGalleryAlbum, deleteGalleryAlbum,
  getGalleryImages, createGalleryImage, deleteGalleryImage,
  uploadGalleryImage, deleteGalleryStorageFile,
} from '@/services/cms';
import type { GalleryAlbum, GalleryImage } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

export default function GalleryManagement() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [albums, setAlbums] = useState<GalleryAlbum[]>([]);
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [totalImages, setTotalImages] = useState(0);
  const [featuredImages, setFeaturedImages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<GalleryAlbum | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [albumFormOpen, setAlbumFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<GalleryAlbum | null>(null);
  const [albumForm, setAlbumForm] = useState({ name: '', description: '', display_order: 0 });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedAlbum, setSelectedAlbum] = useState<string>('');
  const [deleteImageTarget, setDeleteImageTarget] = useState<GalleryImage | null>(null);
  const [deletingImage, setDeletingImage] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true);
      const [albumData, imageData] = await Promise.all([getGalleryAlbums(), getGalleryImages()]);
      setAlbums(albumData);
      setImages(imageData);
      setTotalImages(imageData.length);
      setFeaturedImages(imageData.filter(i => i.is_featured).length);
    } catch {
      toast({ title: 'Error', description: 'Failed to load gallery', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const openCreateAlbum = () => {
    setEditTarget(null);
    setAlbumForm({ name: '', description: '', display_order: albums.length + 1 });
    setAlbumFormOpen(true);
  };

  const openEditAlbum = (a: GalleryAlbum) => {
    setEditTarget(a);
    setAlbumForm({ name: a.name, description: a.description || '', display_order: a.display_order });
    setAlbumFormOpen(true);
  };

  const handleSaveAlbum = async () => {
    if (!albumForm.name) {
      toast({ title: 'Validation Error', description: 'Album name is required', variant: 'destructive' });
      return;
    }
    try {
      setSaving(true);
      if (editTarget) {
        const updated = await updateGalleryAlbum(editTarget.id, { ...albumForm, description: albumForm.description || undefined });
        setAlbums(prev => prev.map(a => a.id === editTarget.id ? { ...updated, image_count: a.image_count } : a));
        toast({ title: 'Updated', description: `Album "${albumForm.name}" updated` });
      } else {
        const created = await createGalleryAlbum({ ...albumForm, description: albumForm.description || undefined });
        setAlbums(prev => [...prev, created]);
        toast({ title: 'Created', description: `Album "${albumForm.name}" created` });
      }
      setAlbumFormOpen(false);
    } catch (err: any) {
      toast({ title: 'Save Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      await deleteGalleryAlbum(deleteTarget.id);
      setAlbums(prev => prev.filter(a => a.id !== deleteTarget.id));
      toast({ title: 'Deleted', description: `"${deleteTarget.name}" has been removed` });
      setDeleteTarget(null);
    } catch {
      toast({ title: 'Error', description: 'Failed to delete album', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    let uploaded = 0;

    for (const file of Array.from(files)) {
      try {
        const ext = file.name.split('.').pop() || 'jpg';
        const timestamp = Date.now();
        const randomStr = Math.random().toString(36).substring(2, 8);
        const path = `albums/${selectedAlbum || 'unsorted'}/${timestamp}-${randomStr}.${ext}`;

        const publicUrl = await uploadGalleryImage(file, path);

        await createGalleryImage({
          album_id: selectedAlbum || undefined,
          title: file.name.replace(/\.[^.]+$/, ''),
          image_url: publicUrl,
          is_featured: false,
          display_order: images.length + uploaded + 1,
        });

        uploaded++;
      } catch (err: any) {
        toast({ title: 'Upload Failed', description: `Failed to upload ${file.name}: ${err.message}`, variant: 'destructive' });
      }
    }

    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (uploaded > 0) {
      toast({ title: 'Uploaded', description: `${uploaded} image${uploaded > 1 ? 's' : ''} uploaded successfully` });
      await load();
    }
  };

  const confirmDeleteImage = async () => {
    if (!deleteImageTarget) return;
    try {
      setDeletingImage(true);
      if (deleteImageTarget.image_url) {
        try {
          const url = new URL(deleteImageTarget.image_url);
          const pathParts = url.pathname.split('/gallery/');
          if (pathParts[1]) {
            await deleteGalleryStorageFile(pathParts[1]);
          }
        } catch { /* storage delete is best-effort */ }
      }
      await deleteGalleryImage(deleteImageTarget.id);
      setImages(prev => prev.filter(i => i.id !== deleteImageTarget.id));
      toast({ title: 'Deleted', description: 'Image removed' });
      setDeleteImageTarget(null);
      await load();
    } catch {
      toast({ title: 'Error', description: 'Failed to delete image', variant: 'destructive' });
    } finally {
      setDeletingImage(false);
    }
  };

  const filteredImages = selectedAlbum
    ? images.filter(i => i.album_id === selectedAlbum)
    : images;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Gallery Management"
          description="Manage albums and images for the gallery"
          actions={
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2" onClick={openCreateAlbum}><FolderPlus className="w-4 h-4" />New Album</Button>
              <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                Upload Images
              </Button>
              <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleUpload} />
            </div>
          }
        />

        {loading ? (
          <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <>
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { label: 'Total Albums', value: albums.length },
                { label: 'Total Images', value: totalImages },
                { label: 'Featured Images', value: featuredImages },
              ].map((stat) => (
                <Card key={stat.label} className="glass-card border-0 shadow-lg">
                  <CardContent className="pt-4 pb-4 flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Album filter + upload target */}
            <div className="flex flex-wrap items-center gap-2">
              <Button variant={selectedAlbum === '' ? 'default' : 'outline'} size="sm"
                onClick={() => setSelectedAlbum('')}
                className={selectedAlbum === '' ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90' : ''}>
                All Albums
              </Button>
              {albums.map(album => (
                <Button key={album.id} variant={selectedAlbum === album.id ? 'default' : 'outline'} size="sm"
                  onClick={() => setSelectedAlbum(album.id)}
                  className={selectedAlbum === album.id ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90' : ''}>
                  {album.name}
                </Button>
              ))}
            </div>

            {/* Albums grid */}
            <h3 className="text-lg font-semibold">Albums</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {albums.map((album) => (
                <motion.div key={album.id} whileHover={{ scale: 1.02 }} className="group">
                  <Card className="glass-card border-0 shadow-lg overflow-hidden hover:shadow-xl transition-all">
                    <div className="aspect-video bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center relative">
                      {album.cover_image_url ? (
                        <img src={album.cover_image_url} alt={album.name} className="w-full h-full object-cover" />
                      ) : (
                        <Images className="w-12 h-12 text-muted-foreground/50" />
                      )}
                    </div>
                    <CardContent className="pt-4 pb-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{album.name}</h3>
                          <p className="text-xs text-muted-foreground">{album.image_count ?? 0} images</p>
                        </div>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditAlbum(album)}><Pencil className="w-4 h-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(album)}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Images grid */}
            <h3 className="text-lg font-semibold">Images {selectedAlbum && `(in selected album)`}</h3>
            {filteredImages.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
                {filteredImages.map(image => (
                  <div key={image.id} className="group relative aspect-square rounded-lg overflow-hidden border hover:border-primary/30 transition-all">
                    {image.image_url ? (
                      <img src={image.image_url} alt={image.title || ''} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-muted flex items-center justify-center">
                        <Images className="w-8 h-8 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/20 h-8 w-8"
                        onClick={() => setDeleteImageTarget(image)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Images className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No images yet. Upload images to get started.</p>
              </div>
            )}
          </>
        )}

        {/* Album Form Dialog */}
        <Dialog open={albumFormOpen} onOpenChange={setAlbumFormOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>{editTarget ? 'Edit Album' : 'New Album'}</DialogTitle></DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label>Album Name <span className="text-destructive">*</span></Label>
                <Input value={albumForm.name} onChange={e => setAlbumForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Events 2024" />
              </div>
              <div className="space-y-1.5">
                <Label>Description</Label>
                <Textarea value={albumForm.description} onChange={e => setAlbumForm(f => ({ ...f, description: e.target.value }))} placeholder="Brief description" rows={2} />
              </div>
              <div className="space-y-1.5">
                <Label>Display Order</Label>
                <Input type="number" value={albumForm.display_order} onChange={e => setAlbumForm(f => ({ ...f, display_order: Number(e.target.value) }))} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAlbumFormOpen(false)}>Cancel</Button>
              <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSaveAlbum} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                {editTarget ? 'Save Changes' : 'Create Album'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={confirmDelete}
          title="Delete Album" description={`Delete "${deleteTarget?.name}"? All images in this album will remain in storage.`}
          confirmText={deleting ? 'Deleting...' : 'Delete'} variant="destructive" />

        <ConfirmDialog open={!!deleteImageTarget} onClose={() => setDeleteImageTarget(null)} onConfirm={confirmDeleteImage}
          title="Delete Image" description="Permanently delete this image?"
          confirmText={deletingImage ? 'Deleting...' : 'Delete'} variant="destructive" />
      </motion.div>
    </DashboardLayout>
  );
}
