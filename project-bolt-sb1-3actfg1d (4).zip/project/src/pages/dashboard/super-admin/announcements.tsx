import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { DataTable, PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Pencil, Trash2, Plus, Pin, Archive, Loader2 } from 'lucide-react';
import { getAnnouncements, createAnnouncement, updateAnnouncement, deleteAnnouncement } from '@/services/cms';
import type { Announcement } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

const priorityColors: Record<string, string> = {
  low: 'bg-muted text-muted-foreground',
  medium: 'bg-amber-500/10 text-amber-500',
  high: 'bg-rose-500/10 text-rose-500',
};
const statusColors: Record<string, string> = {
  draft: 'bg-muted text-muted-foreground',
  published: 'bg-emerald-500/10 text-emerald-500',
  archived: 'bg-amber-500/10 text-amber-500',
};
const priorityLabels = { low: 'Low', medium: 'Medium', high: 'High' };
const statusLabels = { draft: 'Draft', published: 'Published', archived: 'Archived' };
const categories = ['General', 'Events', 'Workshops', 'Funding', 'Partnership', 'Report', 'Achievement'];

const emptyForm: { title: string; description: string; category: string; priority: 'low' | 'medium' | 'high'; status: 'draft' | 'published' | 'archived'; is_pinned: boolean; publish_date: string } = {
  title: '', description: '', category: 'General', priority: 'medium', status: 'draft', is_pinned: false, publish_date: ''
};

export default function AnnouncementsManagement() {
  const { toast } = useToast();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<Announcement | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Announcement | null>(null);
  const [form, setForm] = useState<typeof emptyForm>(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true);
      setAnnouncements(await getAnnouncements());
    } catch {
      toast({ title: 'Error', description: 'Failed to load announcements', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const openCreate = () => {
    setEditTarget(null);
    setForm(emptyForm);
    setFormOpen(true);
  };

  const openEdit = (a: Announcement) => {
    setEditTarget(a);
    setForm({
      title: a.title,
      description: a.description || '',
      category: a.category || 'General',
      priority: a.priority as 'low' | 'medium' | 'high',
      status: a.status as 'draft' | 'published' | 'archived',
      is_pinned: a.is_pinned,
      publish_date: a.publish_date || '',
    });
    setFormOpen(true);
  };

  const handleSave = async () => {
    if (!form.title) {
      toast({ title: 'Validation Error', description: 'Title is required', variant: 'destructive' });
      return;
    }
    try {
      setSaving(true);
      const payload = { ...form, description: form.description || null, category: form.category || null, publish_date: form.publish_date || null };
      if (editTarget) {
        const updated = await updateAnnouncement(editTarget.id, payload);
        setAnnouncements(prev => prev.map(a => a.id === editTarget.id ? updated : a));
        toast({ title: 'Updated', description: `"${form.title}" updated` });
      } else {
        const created = await createAnnouncement(payload);
        setAnnouncements(prev => [created, ...prev]);
        toast({ title: 'Created', description: `"${form.title}" created` });
      }
      setFormOpen(false);
    } catch (err: any) {
      toast({ title: 'Save Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handlePin = async (a: Announcement) => {
    try {
      const updated = await updateAnnouncement(a.id, { is_pinned: !a.is_pinned });
      setAnnouncements(prev => prev.map(x => x.id === a.id ? updated : x));
      toast({ title: updated.is_pinned ? 'Pinned' : 'Unpinned', description: `"${a.title}" ${updated.is_pinned ? 'pinned' : 'unpinned'}` });
    } catch {
      toast({ title: 'Error', description: 'Failed to update announcement', variant: 'destructive' });
    }
  };

  const handleArchive = async (a: Announcement) => {
    try {
      const updated = await updateAnnouncement(a.id, { status: 'archived' });
      setAnnouncements(prev => prev.map(x => x.id === a.id ? updated : x));
      toast({ title: 'Archived', description: `"${a.title}" archived` });
    } catch {
      toast({ title: 'Error', description: 'Failed to archive', variant: 'destructive' });
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      await deleteAnnouncement(deleteTarget.id);
      setAnnouncements(prev => prev.filter(a => a.id !== deleteTarget.id));
      toast({ title: 'Deleted', description: `"${deleteTarget.title}" deleted` });
      setDeleteTarget(null);
    } catch {
      toast({ title: 'Error', description: 'Failed to delete', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Announcements"
          description="Create, edit, and manage announcements"
          actions={<Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={openCreate}><Plus className="w-4 h-4" />New Announcement</Button>}
        />

        {loading ? (
          <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <DataTable
            data={announcements}
            columns={[
              { key: 'title', header: 'Title', render: (a) => (
                <div className="flex items-center gap-2">
                  {a.is_pinned && <Pin className="w-3 h-3 text-primary" />}
                  <span className="font-medium">{a.title}</span>
                </div>
              )},
              { key: 'category', header: 'Category', render: (a) => <Badge variant="outline">{a.category || '—'}</Badge> },
              { key: 'priority', header: 'Priority', render: (a) => (
                <span className={`text-xs px-2 py-1 rounded-full ${priorityColors[a.priority]}`}>{priorityLabels[a.priority]}</span>
              )},
              { key: 'status', header: 'Status', render: (a) => (
                <span className={`text-xs px-2 py-1 rounded-full ${statusColors[a.status]}`}>{statusLabels[a.status]}</span>
              )},
              { key: 'publish_date', header: 'Date', render: (a) => <span className="text-sm text-muted-foreground">{a.publish_date || '—'}</span> },
            ]}
            searchKeys={['title', 'category']}
            searchPlaceholder="Search announcements..."
            actions={(a) => (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" onClick={() => handlePin(a)}><Pin className={`w-4 h-4 ${a.is_pinned ? 'text-primary' : ''}`} /></Button>
                <Button variant="ghost" size="icon" onClick={() => handleArchive(a)} disabled={a.status === 'archived'}><Archive className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" onClick={() => openEdit(a)}><Pencil className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => setDeleteTarget(a)}><Trash2 className="w-4 h-4" /></Button>
              </div>
            )}
          />
        )}

        {/* Form Dialog */}
        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{editTarget ? 'Edit Announcement' : 'New Announcement'}</DialogTitle></DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label>Title <span className="text-destructive">*</span></Label>
                <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Announcement title" />
              </div>
              <div className="space-y-1.5">
                <Label>Description</Label>
                <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Full description" rows={3} />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Priority</Label>
                  <Select value={form.priority} onValueChange={v => setForm(f => ({ ...f, priority: v as 'low' | 'medium' | 'high' }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Status</Label>
                  <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as 'draft' | 'published' | 'archived' }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="published">Published</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Publish Date</Label>
                  <Input type="date" value={form.publish_date} onChange={e => setForm(f => ({ ...f, publish_date: e.target.value }))} />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <Label>Pinned</Label>
                <Switch checked={form.is_pinned} onCheckedChange={v => setForm(f => ({ ...f, is_pinned: v }))} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
              <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                {editTarget ? 'Save Changes' : 'Create'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={confirmDelete}
          title="Delete Announcement" description={`Delete "${deleteTarget?.title}"?`}
          confirmText={deleting ? 'Deleting…' : 'Delete'} variant="destructive" />
      </motion.div>
    </DashboardLayout>
  );
}
