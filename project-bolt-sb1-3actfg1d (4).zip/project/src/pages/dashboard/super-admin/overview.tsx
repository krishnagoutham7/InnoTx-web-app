import { useState, useEffect } from 'react';
import { motion, type Easing } from 'framer-motion';
import {
  Award,
  Bell,
  TrendingUp,
  Sparkles,
  ArrowRight,
  Activity,
  Shield,
  Database,
} from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { StatCard, ActivityFeed, QuickAction, StatusBadge, HeroSection, ProgressRing } from '@/components/dashboard/widgets';
import { getDashboardStats } from '@/services/cms';
import type { DashboardStats } from '@/services/cms';
import { getAnnouncements } from '@/services/cms';
import type { Announcement } from '@/services/cms';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

const easeOut: Easing = 'easeOut';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.1 }
  }
};

const item = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: easeOut } }
};

export default function SuperAdminOverview() {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentAnnouncements, setRecentAnnouncements] = useState<Announcement[]>([]);

  useEffect(() => {
    getDashboardStats().then(setStats).catch(() => {});
    getAnnouncements().then((a) => setRecentAnnouncements(a.slice(0, 5))).catch(() => {});
  }, []);

  const heroStats = [
    { label: 'Members', value: stats?.total_users ?? 0, icon: 'Users', color: 'primary' as const },
    { label: 'Team', value: stats?.total_team_members ?? 0, icon: 'Users', color: 'secondary' as const },
    { label: 'Announcements', value: stats?.total_announcements ?? 0, icon: 'Megaphone', color: 'accent' as const },
    { label: 'Gallery', value: stats?.total_gallery_images ?? 0, icon: 'Images', color: 'success' as const },
  ];

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="space-y-6"
      >
        {/* Hero Section */}
        <motion.div variants={item}>
          <HeroSection
            title="Super Admin Dashboard"
            subtitle="Full portal control and management at your fingertips"
            userName={user?.name}
            stats={heroStats}
          />
        </motion.div>

        {/* Main Stats Grid */}
        <motion.div variants={item} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total Users"
            value={stats?.total_users ?? 0}
            subtitle="Active platform users"
            icon="Users"
            trend={{ value: 12, isPositive: true }}
            color="primary"
          />
          <StatCard
            title="Team Members"
            value={stats?.total_team_members ?? 0}
            subtitle="Innovation team"
            icon="Users"
            color="secondary"
          />
          <StatCard
            title="Announcements"
            value={stats?.total_announcements ?? 0}
            subtitle={`${stats?.published_announcements ?? 0} published`}
            icon="Megaphone"
            color="warning"
          />
          <StatCard
            title="Gallery Images"
            value={stats?.total_gallery_images ?? 0}
            subtitle={`${stats?.total_albums ?? 0} albums`}
            icon="Images"
            color="accent"
          />
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <motion.div variants={item} className="lg:col-span-1">
            <div
              className={cn(
                'relative overflow-hidden rounded-2xl p-6',
                'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
                'border border-white/5 backdrop-blur-xl'
              )}
            >
              {/* Header */}
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold font-heading">Quick Actions</h3>
                  <p className="text-xs text-muted-foreground">Frequent operations</p>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2">
                <QuickAction
                  title="Add Team Member"
                  description="Recruit new team members"
                  icon="UserPlus"
                  href="/dashboard/super-admin/team"
                  color="primary"
                />
                <QuickAction
                  title="Create Announcement"
                  description="Publish platform updates"
                  icon="Megaphone"
                  href="/dashboard/super-admin/announcements"
                  color="secondary"
                />
                <QuickAction
                  title="Manage Events"
                  description="Create and organize events"
                  icon="Calendar"
                  href="/dashboard/super-admin/events"
                  color="accent"
                />
                <QuickAction
                  title="Edit Homepage"
                  description="Update public content"
                  icon="Edit"
                  href="/dashboard/super-admin/cms/homepage"
                  color="primary"
                />
                <QuickAction
                  title="Manage Users"
                  description="View and control access"
                  icon="UserCog"
                  href="/dashboard/super-admin/users"
                  color="secondary"
                />
              </div>
            </div>
          </motion.div>

          {/* Recent Announcements */}
          <motion.div variants={item} className="lg:col-span-2">
            <ActivityFeed
              title="Recent Announcements"
              activities={recentAnnouncements.map((a) => ({
                id: a.id,
                title: a.title,
                description: a.description || '',
                time: a.publish_date
                  ? new Date(a.publish_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
                  : new Date(a.created_at).toLocaleDateString(),
                type: a.priority === 'high' ? 'warning' : a.status === 'published' ? 'success' : 'info',
              }))}
            />
          </motion.div>
        </div>

        {/* System Health Section */}
        <motion.div variants={item}>
          <div
            className={cn(
              'relative overflow-hidden rounded-2xl p-6',
              'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
              'border border-white/5 backdrop-blur-xl'
            )}
          >
            {/* Header */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent/20 to-success/20 flex items-center justify-center">
                <Shield className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold font-heading">System Health</h3>
                <p className="text-xs text-muted-foreground">Platform performance metrics</p>
              </div>
              <div className="ml-auto">
                <StatusBadge status="online" />
              </div>
            </div>

            {/* Health Metrics */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Active Announcements */}
              <div className="p-4 rounded-xl bg-white/2 border border-white/5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-muted-foreground">Active Announcements</span>
                  <Bell className="w-4 h-4 text-warning" />
                </div>
                <p className="text-3xl font-bold text-warning">{stats?.active_announcements ?? 0}</p>
                <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                  <TrendingUp className="w-3 h-3 text-success" />
                  <span className="text-success">+2</span> this week
                </div>
              </div>

              {/* Published */}
              <div className="p-4 rounded-xl bg-white/2 border border-white/5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-muted-foreground">Published</span>
                  <Award className="w-4 h-4 text-primary" />
                </div>
                <p className="text-3xl font-bold text-primary">{stats?.published_announcements ?? 0}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex-1 h-1 rounded-full bg-white/5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                      style={{ width: `${Math.min(((stats?.published_announcements ?? 0) / Math.max(stats?.total_announcements ?? 1, 1)) * 100, 100)}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {Math.round(((stats?.published_announcements ?? 0) / Math.max(stats?.total_announcements ?? 1, 1)) * 100)}%
                  </span>
                </div>
              </div>

              {/* Database */}
              <div className="p-4 rounded-xl bg-white/2 border border-white/5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-muted-foreground">Database</span>
                  <Database className="w-4 h-4 text-secondary" />
                </div>
                <p className="text-3xl font-bold text-secondary">Healthy</p>
                <p className="text-xs text-muted-foreground mt-2">Last backup: Today</p>
              </div>

              {/* System Status */}
              <div className="p-4 rounded-xl bg-white/2 border border-white/5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-muted-foreground">System Status</span>
                  <Activity className="w-4 h-4 text-success" />
                </div>
                <div className="flex items-center gap-2">
                  <ProgressRing progress={100} size={50} color="success" />
                  <div>
                    <p className="text-lg font-semibold">Operational</p>
                    <p className="text-xs text-muted-foreground">All systems running</p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </motion.div>

        {/* Innovation Hub Branding */}
        <motion.div variants={item}>
          <div
            className={cn(
              'relative overflow-hidden rounded-2xl p-6',
              'bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10',
              'border border-white/5'
            )}
          >
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMiI+PHBhdGggZD0iTTM2IDM0aC00djRoNHYtNHptMC0yaC00di00aDR2NHptMi0ydi00aDR2NGgtNHptLTIgMGgtNHY0aDR2LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
            <div className="relative flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary via-secondary to-accent p-0.5">
                <div className="w-full h-full rounded-[14px] bg-background flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="font-bold font-heading text-lg gradient-text">InnoTex Innovation Hub</h3>
                <p className="text-sm text-muted-foreground">Powered by Startup Kerala. Building the future of innovation ecosystem platforms.</p>
              </div>
              <div className="ml-auto hidden md:block">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-xl',
                    'bg-gradient-to-r from-primary to-secondary',
                    'text-white font-medium text-sm',
                    'shadow-glow-sm hover:shadow-glow transition-shadow'
                  )}
                >
                  <span>Explore Features</span>
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </DashboardLayout>
  );
}
