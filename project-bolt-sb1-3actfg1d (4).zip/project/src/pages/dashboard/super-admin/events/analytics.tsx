import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, TrendingUp, BarChart3, Loader2 } from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { StatCard } from '@/components/dashboard/widgets';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getEventAnalytics } from '@/services/events';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

export default function EventAnalyticsPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState<Awaited<ReturnType<typeof getEventAnalytics>> | null>(null);

  useEffect(() => {
    getEventAnalytics()
      .then(setAnalytics)
      .catch(() => toast({ title: 'Error', description: 'Failed to load analytics', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (!analytics) return null;

  const categoryEntries = Object.entries(analytics.categoryCount).sort((a, b) => b[1] - a[1]);
  const maxCatCount = categoryEntries[0]?.[1] || 1;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader title="Event Analytics" description="Insights and statistics across all events" />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard title="Total Events" value={analytics.totalEvents} icon="Calendar" color="primary" />
          <StatCard title="Upcoming / Published" value={analytics.upcomingEvents} icon="Clock" color="accent" />
          <StatCard title="Ongoing" value={analytics.ongoingEvents} icon="Activity" color="warning" />
          <StatCard title="Completed" value={analytics.completedEvents} icon="CheckCircle" color="success" />
          <StatCard title="Total Registrations" value={analytics.totalRegistrations} icon="Users" color="primary" />
          <StatCard title="Featured Events" value={analytics.featuredEvents} icon="Star" color="accent" />
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Popular Events */}
          <Card className="glass-card border-0 shadow-md">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" /> Popular Events
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {analytics.popularEvents.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No events yet</p>
              ) : analytics.popularEvents.map((evt, i) => (
                <div key={evt.id} className="flex items-center gap-3">
                  <div className={cn(
                    'w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold',
                    i === 0 ? 'bg-amber-500/20 text-amber-600' :
                    i === 1 ? 'bg-slate-400/20 text-slate-500' :
                    i === 2 ? 'bg-orange-400/20 text-orange-500' :
                    'bg-muted text-muted-foreground'
                  )}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{evt.title}</p>
                    <p className="text-xs text-muted-foreground">{evt.event_type}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-sm font-semibold">{evt.reg_count}</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Category Distribution */}
          <Card className="glass-card border-0 shadow-md">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" /> Events by Category
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {categoryEntries.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No categories yet</p>
              ) : categoryEntries.map(([cat, count]) => (
                <div key={cat}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-muted-foreground">{cat}</span>
                    <span className="font-medium">{count}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all"
                      style={{ width: `${(count / maxCatCount) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Recent Registrations */}
        <Card className="glass-card border-0 shadow-md">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" /> Recent Registrations
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analytics.recentRegistrations.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No registrations yet</p>
            ) : (
              <div className="space-y-2">
                {analytics.recentRegistrations.map(reg => (
                  <div key={reg.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                    <div>
                      <p className="text-sm font-medium">{reg.user_name}</p>
                      <p className="text-xs text-muted-foreground">{reg.user_email}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className="text-xs mb-1">{reg.registration_status}</Badge>
                      <p className="text-xs text-muted-foreground">
                        {new Date(reg.registered_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </DashboardLayout>
  );
}
