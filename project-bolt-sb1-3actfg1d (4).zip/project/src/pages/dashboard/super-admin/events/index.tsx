import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Plus, Pencil, Trash2, Eye, Copy, Archive,
  CheckCircle, Loader2, BarChart3, QrCode
} from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { DataTable, PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StatCard } from '@/components/dashboard/widgets';
import { getAllEvents, deleteEvent, publishEvent, archiveEvent, createEvent } from '@/services/events';
import type { Event } from '@/types/events';
import { eventStatusConfig } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function SuperAdminEventsPage() {
  const { toast } = useToast();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<Event | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      setLoading(true);
      const data = await getAllEvents();
      setEvents(data);
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to load events', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const handlePublish = async (event: Event) => {
    try {
      const updated = await publishEvent(event.id);
      setEvents(prev => prev.map(e => e.id === event.id ? updated : e));
      toast({ title: 'Published', description: `"${event.title}" is now published` });
    } catch {
      toast({ title: 'Error', description: 'Failed to publish event', variant: 'destructive' });
    }
  };

  const handleArchive = async (event: Event) => {
    try {
      const updated = await archiveEvent(event.id);
      setEvents(prev => prev.map(e => e.id === event.id ? updated : e));
      toast({ title: 'Archived', description: `"${event.title}" has been archived` });
    } catch {
      toast({ title: 'Error', description: 'Failed to archive event', variant: 'destructive' });
    }
  };

  const handleDuplicate = async (event: Event) => {
    try {
      const newEvent = await createEvent({
        title: `${event.title} (Copy)`,
        short_description: event.short_description || '',
        full_description: event.full_description || '',
        category_id: event.category_id || '',
        event_type: event.event_type,
        status: 'draft',
        start_date: event.start_date,
        end_date: event.end_date || '',
        start_time: event.start_time || '',
        end_time: event.end_time || '',
        venue: event.venue || '',
        max_participants: event.max_participants?.toString() || '',
        registration_deadline: event.registration_deadline || '',
        organizer_name: event.organizer_name || '',
        organizer_email: event.organizer_email || '',
        is_featured: false,
      });
      setEvents(prev => [newEvent, ...prev]);
      toast({ title: 'Duplicated', description: `"${event.title}" has been duplicated as a draft` });
    } catch {
      toast({ title: 'Error', description: 'Failed to duplicate event', variant: 'destructive' });
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      await deleteEvent(deleteTarget.id);
      setEvents(prev => prev.filter(e => e.id !== deleteTarget.id));
      toast({ title: 'Deleted', description: `"${deleteTarget.title}" has been deleted` });
      setDeleteTarget(null);
    } catch {
      toast({ title: 'Error', description: 'Failed to delete event', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  const stats = {
    total: events.length,
    published: events.filter(e => ['published', 'upcoming'].includes(e.status)).length,
    ongoing: events.filter(e => e.status === 'ongoing').length,
    completed: events.filter(e => e.status === 'completed').length,
  };

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Event Management"
          description="Create, manage, and publish events"
          actions={
            <div className="flex gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link to="/dashboard/super-admin/events/analytics">
                  <BarChart3 className="w-4 h-4 mr-2" /> Analytics
                </Link>
              </Button>
              <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" asChild>
                <Link to="/dashboard/super-admin/events/create">
                  <Plus className="w-4 h-4" /> New Event
                </Link>
              </Button>
            </div>
          }
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Events" value={stats.total} icon="Calendar" color="primary" />
          <StatCard title="Published / Upcoming" value={stats.published} icon="CheckCircle" color="success" />
          <StatCard title="Ongoing" value={stats.ongoing} icon="Activity" color="accent" />
          <StatCard title="Completed" value={stats.completed} icon="Archive" color="warning" />
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <DataTable
            data={events}
            columns={[
              {
                key: 'title',
                header: 'Event',
                render: (e) => (
                  <div>
                    <p className="font-medium line-clamp-1">{e.title}</p>
                    <p className="text-xs text-muted-foreground">{e.event_type}</p>
                  </div>
                ),
              },
              {
                key: 'status',
                header: 'Status',
                render: (e) => {
                  const conf = eventStatusConfig[e.status];
                  return (
                    <span className={cn('text-xs font-medium px-2.5 py-1 rounded-full', conf.bg, conf.color)}>
                      {conf.label}
                    </span>
                  );
                },
              },
              {
                key: 'start_date',
                header: 'Date',
                render: (e) => (
                  <span className="text-sm text-muted-foreground">
                    {new Date(e.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                ),
              },
              {
                key: 'venue',
                header: 'Venue',
                render: (e) => <span className="text-sm text-muted-foreground truncate max-w-[120px] block">{e.venue || '—'}</span>,
              },
              {
                key: 'is_featured',
                header: 'Featured',
                render: (e) => e.is_featured ? <Badge className="text-xs bg-primary">Yes</Badge> : <span className="text-xs text-muted-foreground">No</span>,
              },
            ]}
            searchKeys={['title', 'event_type', 'venue']}
            searchPlaceholder="Search events..."
            actions={(e) => (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" title="Attendance" asChild>
                  <Link to={`/dashboard/super-admin/events/${e.id}/attendance`}><QrCode className="w-4 h-4" /></Link>
                </Button>
                <Button variant="ghost" size="icon" title="View" asChild>
                  <Link to={`/events/${e.id}`} target="_blank"><Eye className="w-4 h-4" /></Link>
                </Button>
                <Button variant="ghost" size="icon" title="Edit" asChild>
                  <Link to={`/dashboard/super-admin/events/${e.id}/edit`}><Pencil className="w-4 h-4" /></Link>
                </Button>
                {e.status === 'draft' && (
                  <Button variant="ghost" size="icon" title="Publish" onClick={() => handlePublish(e)}>
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                  </Button>
                )}
                {['published', 'upcoming', 'ongoing', 'completed'].includes(e.status) && (
                  <Button variant="ghost" size="icon" title="Archive" onClick={() => handleArchive(e)}>
                    <Archive className="w-4 h-4 text-amber-500" />
                  </Button>
                )}
                <Button variant="ghost" size="icon" title="Duplicate" onClick={() => handleDuplicate(e)}>
                  <Copy className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" title="Delete" className="text-destructive hover:text-destructive" onClick={() => setDeleteTarget(e)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )}
          />
        )}

        <ConfirmDialog
          open={!!deleteTarget}
          onClose={() => setDeleteTarget(null)}
          onConfirm={confirmDelete}
          title="Delete Event"
          description={`Are you sure you want to delete "${deleteTarget?.title}"? All registrations for this event will also be deleted.`}
          confirmText={deleting ? 'Deleting...' : 'Delete'}
          variant="destructive"
        />
      </motion.div>
    </DashboardLayout>
  );
}
