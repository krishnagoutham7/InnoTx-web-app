import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Save, Loader2, Image as ImageIcon, Trash2 } from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createEvent, updateEvent, getEventById, getEventCategories, uploadEventBanner, uploadEventPoster, deleteEventBanner, deleteEventPoster } from '@/services/events';
import { getTicketTemplates } from '@/services/ticket-templates';
import { getCertificateTemplates } from '@/services/certificates';
import type { CertificateTemplate } from '@/types/certificates';
import { supabase } from '@/lib/supabase';
import type { EventFormData, EventCategory, TicketTemplate } from '@/types/events';
import { eventTypes, emptyEventForm } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

interface Props {
  mode: 'create' | 'edit';
}

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_FILE_SIZE = 20 * 1024 * 1024; // 20MB

export default function EventFormPage({ mode }: Props) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const [form, setForm] = useState<EventFormData>(emptyEventForm);
  const [categories, setCategories] = useState<EventCategory[]>([]);
  const [loading, setLoading] = useState(mode === 'edit');
  const [saving, setSaving] = useState(false);

  // Media state
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [posterFile, setPosterFile] = useState<File | null>(null);
  const [bannerPreview, setBannerPreview] = useState<string | null>(null);
  const [posterPreview, setPosterPreview] = useState<string | null>(null);
  const [existingBannerUrl, setExistingBannerUrl] = useState<string | null>(null);
  const [existingPosterUrl, setExistingPosterUrl] = useState<string | null>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);

  // Ticket templates
  const [ticketTemplates, setTicketTemplates] = useState<TicketTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');

  // Certificate templates
  const [certificateTemplates, setCertificateTemplates] = useState<CertificateTemplate[]>([]);
  const [selectedCertTemplateId, setSelectedCertTemplateId] = useState<string>('');

  // Upload refs
  const bannerInputRef = useRef<HTMLInputElement>(null);
  const posterInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    async function load() {
      try {
        const cats = await getEventCategories();
        setCategories(cats);
        const templates = await getTicketTemplates();
        setTicketTemplates(templates);
        const certTemplates = await getCertificateTemplates();
        setCertificateTemplates(certTemplates);
        if (mode === 'edit' && id) {
          const evt = await getEventById(id);
          if (evt) {
            setForm({
              title: evt.title,
              short_description: evt.short_description || '',
              full_description: evt.full_description || '',
              category_id: evt.category_id || '',
              event_type: evt.event_type,
              status: evt.status,
              start_date: evt.start_date,
              end_date: evt.end_date || '',
              start_time: evt.start_time || '',
              end_time: evt.end_time || '',
              venue: evt.venue || '',
              max_participants: evt.max_participants?.toString() || '',
              registration_deadline: evt.registration_deadline || '',
              organizer_name: evt.organizer_name || '',
              organizer_email: evt.organizer_email || '',
              is_featured: evt.is_featured,
            });
            setExistingBannerUrl(evt.banner_image_url || null);
            setExistingPosterUrl(evt.poster_image_url || null);
            setSelectedTemplateId(evt.ticket_template_id || '');
            setSelectedCertTemplateId(evt.certificate_template_id || '');
          }
        }
      } catch (err) {
        toast({ title: 'Error', description: 'Failed to load data', variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [mode, id]);

  const set = (key: keyof EventFormData, value: string | boolean) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const validateFile = (file: File): string | null => {
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      return 'Invalid file type. Please upload JPG, PNG, WEBP, or GIF.';
    }
    if (file.size > MAX_FILE_SIZE) {
      return 'File is too large. Maximum size is 20MB.';
    }
    return null;
  };

  const handleBannerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const error = validateFile(file);
    if (error) {
      toast({ title: 'Invalid file', description: error, variant: 'destructive' });
      return;
    }

    setBannerFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setBannerPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handlePosterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const error = validateFile(file);
    if (error) {
      toast({ title: 'Invalid file', description: error, variant: 'destructive' });
      return;
    }

    setPosterFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setPosterPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleRemoveBanner = async () => {
    if (mode === 'edit' && id) {
      try {
        await deleteEventBanner(id);
        setExistingBannerUrl(null);
        toast({ title: 'Banner removed' });
      } catch (err) {
        toast({ title: 'Error', description: 'Failed to remove banner', variant: 'destructive' });
      }
    }
    setBannerFile(null);
    setBannerPreview(null);
  };

  const handleRemovePoster = async () => {
    if (mode === 'edit' && id) {
      try {
        await deleteEventPoster(id);
        setExistingPosterUrl(null);
        toast({ title: 'Poster removed' });
      } catch (err) {
        toast({ title: 'Error', description: 'Failed to remove poster', variant: 'destructive' });
      }
    }
    setPosterFile(null);
    setPosterPreview(null);
  };

  const uploadMedia = async (eventId: string) => {
    if (!user) return;

    setUploadingMedia(true);
    try {
      if (bannerFile) {
        await uploadEventBanner(eventId, bannerFile, user.id);
      }
      if (posterFile) {
        await uploadEventPoster(eventId, posterFile, user.id);
      }
    } catch (err: any) {
      console.error('Media upload error:', err);
      toast({ title: 'Media upload failed', description: err.message, variant: 'destructive' });
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.start_date || !form.event_type) {
      toast({ title: 'Validation Error', description: 'Title, start date, and event type are required', variant: 'destructive' });
      return;
    }
    if (!user) {
      toast({ title: 'Error', description: 'You must be logged in', variant: 'destructive' });
      return;
    }

    try {
      setSaving(true);
      let eventId = id;

      if (mode === 'create') {
        const newEvent = await createEvent(form);
        eventId = newEvent.id;
        // Set ticket template if selected
        if (eventId) {
          const updates: Record<string, any> = {};
          if (selectedTemplateId) updates.ticket_template_id = selectedTemplateId;
          if (selectedCertTemplateId) updates.certificate_template_id = selectedCertTemplateId;
          if (Object.keys(updates).length > 0) {
            await supabase.from('events').update(updates).eq('id', eventId);
          }
        }
        toast({ title: 'Created!', description: `"${form.title}" has been created` });
      } else if (id) {
        await updateEvent(id, { ...form, ticket_template_id: selectedTemplateId, certificate_template_id: selectedCertTemplateId } as any);
        toast({ title: 'Updated!', description: `"${form.title}" has been updated` });
      }

      // Upload media if files selected
      if (eventId && (bannerFile || posterFile)) {
        await uploadMedia(eventId);
      }

      navigate('/dashboard/super-admin/events');
    } catch (err: any) {
      toast({ title: 'Save Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  const displayBanner = bannerPreview || existingBannerUrl;
  const displayPoster = posterPreview || existingPosterUrl;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title={mode === 'create' ? 'Create Event' : 'Edit Event'}
          description={mode === 'create' ? 'Create a new event for the portal' : 'Update event details'}
          actions={
            <Button variant="outline" asChild>
              <Link to="/dashboard/super-admin/events"><ArrowLeft className="w-4 h-4 mr-2" />Back</Link>
            </Button>
          }
        />

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main info */}
            <div className="lg:col-span-2 space-y-6">
              {/* Banner Upload */}
              <Card className="glass-card border-0 shadow-md">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <ImageIcon className="w-4 h-4" />
                    Event Banner
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div
                    className={cn(
                      'relative border-2 border-dashed rounded-lg overflow-hidden transition-colors',
                      'aspect-video',
                      !displayBanner ? 'border-muted-foreground/25 bg-muted/30' : 'border-primary/30'
                    )}
                  >
                    {displayBanner ? (
                      <img
                        src={displayBanner}
                        alt="Banner preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                        <ImageIcon className="w-12 h-12 mb-2 opacity-50" />
                        <p className="text-sm">Upload Event Banner</p>
                        <p className="text-xs text-muted-foreground mt-1">1920x1080 recommended • 16:9 aspect</p>
                      </div>
                    )}
                    <input
                      ref={bannerInputRef}
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      onChange={handleBannerChange}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => bannerInputRef.current?.click()}
                    >
                      <ImageIcon className="w-4 h-4 mr-2" />
                      {displayBanner ? 'Replace' : 'Upload'} Banner
                    </Button>
                    {displayBanner && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={handleRemoveBanner}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Remove
                      </Button>
                    )}
                    <span className="text-xs text-muted-foreground ml-auto">
                      PNG, JPG, WEBP • Max 20MB
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Poster Upload */}
              <Card className="glass-card border-0 shadow-md">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <ImageIcon className="w-4 h-4" />
                    Event Poster
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div
                      className={cn(
                        'relative border-2 border-dashed rounded-lg overflow-hidden transition-colors',
                        'aspect-[3/4]',
                        !displayPoster ? 'border-muted-foreground/25 bg-muted/30' : 'border-primary/30'
                      )}
                    >
                      {displayPoster ? (
                        <img
                          src={displayPoster}
                          alt="Poster preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                          <ImageIcon className="w-10 h-10 mb-2 opacity-50" />
                          <p className="text-sm">Upload Poster</p>
                        </div>
                      )}
                      <input
                        ref={posterInputRef}
                        type="file"
                        accept="image/jpeg,image/png,image/webp,image/gif"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={handlePosterChange}
                      />
                    </div>
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <p className="font-medium text-foreground">Poster Guidelines:</p>
                      <ul className="list-disc list-inside space-y-1 text-xs">
                        <li>Portrait orientation recommended</li>
                        <li>High resolution for printing</li>
                        <li>Include event title, date, venue</li>
                        <li>Supported: PNG, JPG, WEBP, GIF</li>
                        <li>Maximum file size: 20MB</li>
                      </ul>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => posterInputRef.current?.click()}
                    >
                      <ImageIcon className="w-4 h-4 mr-2" />
                      {displayPoster ? 'Replace' : 'Upload'} Poster
                    </Button>
                    {displayPoster && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={handleRemovePoster}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Remove
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Basic Information</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1.5">
                    <Label>Event Title <span className="text-destructive">*</span></Label>
                    <Input value={form.title} onChange={e => set('title', e.target.value)} placeholder="Enter event title" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Short Description</Label>
                    <Textarea value={form.short_description} onChange={e => set('short_description', e.target.value)} placeholder="Brief summary (shown on cards)" rows={2} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Full Description</Label>
                    <Textarea value={form.full_description} onChange={e => set('full_description', e.target.value)} placeholder="Detailed event description" rows={5} />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Date & Time</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Start Date <span className="text-destructive">*</span></Label>
                      <Input type="date" value={form.start_date} onChange={e => set('start_date', e.target.value)} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label>End Date</Label>
                      <Input type="date" value={form.end_date} onChange={e => set('end_date', e.target.value)} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Start Time</Label>
                      <Input type="time" value={form.start_time} onChange={e => set('start_time', e.target.value)} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>End Time</Label>
                      <Input type="time" value={form.end_time} onChange={e => set('end_time', e.target.value)} />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Registration Deadline</Label>
                    <Input type="date" value={form.registration_deadline} onChange={e => set('registration_deadline', e.target.value)} />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Organizer</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>Organizer Name</Label>
                      <Input value={form.organizer_name} onChange={e => set('organizer_name', e.target.value)} placeholder="Name of organizer" />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Organizer Email</Label>
                      <Input type="email" value={form.organizer_email} onChange={e => set('organizer_email', e.target.value)} placeholder="organizer@email.com" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-5">
              <Card className="glass-card border-0 shadow-md">
                <CardHeader><CardTitle className="text-base">Settings</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1.5">
                    <Label>Event Type <span className="text-destructive">*</span></Label>
                    <Select value={form.event_type} onValueChange={v => set('event_type', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {eventTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Status</Label>
                    <Select value={form.status} onValueChange={v => set('status', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {['draft', 'published', 'upcoming', 'registration_open', 'registration_closed', 'ongoing', 'completed', 'cancelled', 'archived'].map(s => (
                          <SelectItem key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Category</Label>
                    <Select value={form.category_id || 'none'} onValueChange={v => set('category_id', v === 'none' ? '' : v)}>
                      <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Venue</Label>
                    <Input value={form.venue} onChange={e => set('venue', e.target.value)} placeholder="e.g. Main Auditorium" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Max Participants</Label>
                    <Input type="number" min="1" value={form.max_participants} onChange={e => set('max_participants', e.target.value)} placeholder="Leave empty for unlimited" />
                  </div>
                  <div className="flex items-center justify-between py-1">
                    <Label htmlFor="featured">Featured Event</Label>
                    <Switch id="featured" checked={form.is_featured} onCheckedChange={v => set('is_featured', v)} />
                  </div>
                  {ticketTemplates.length > 0 && (
                    <div className="space-y-1.5">
                      <Label>Ticket Template</Label>
                      <Select value={selectedTemplateId || 'default'} onValueChange={v => setSelectedTemplateId(v === 'default' ? '' : v)}>
                        <SelectTrigger><SelectValue placeholder="Use default template" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Use Default Template</SelectItem>
                          {ticketTemplates.map(t => (
                            <SelectItem key={t.id} value={t.id}>{t.name}{t.is_default ? ' (Default)' : ''}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  {certificateTemplates.length > 0 && (
                    <div className="space-y-1.5">
                      <Label>Certificate Template</Label>
                      <Select value={selectedCertTemplateId || 'default'} onValueChange={v => setSelectedCertTemplateId(v === 'default' ? '' : v)}>
                        <SelectTrigger><SelectValue placeholder="Use default template" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Use Default Template</SelectItem>
                          {certificateTemplates.map(t => (
                            <SelectItem key={t.id} value={t.id}>{t.name}{t.is_default ? ' (Default)' : ''}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20"
                disabled={saving || uploadingMedia}
              >
                {saving || uploadingMedia ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                {saving || uploadingMedia
                  ? (uploadingMedia ? 'Uploading media...' : 'Saving...')
                  : (mode === 'create' ? 'Create Event' : 'Save Changes')}
              </Button>
            </div>
          </div>
        </form>
      </motion.div>
    </DashboardLayout>
  );
}
