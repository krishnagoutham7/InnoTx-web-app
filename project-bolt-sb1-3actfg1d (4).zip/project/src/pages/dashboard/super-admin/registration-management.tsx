import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import {
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Loader2,
  AlertTriangle,
  FileText,
  Search,
  CheckCheck,
  X,
} from 'lucide-react';
import {
  getRegistrationsByEvent,
  approveRegistration,
  rejectRegistration,
  bulkApproveRegistrations,
  bulkRejectRegistrations,
} from '@/services/events';
import type { Event } from '@/types/events';
import type { EventRegistration } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { format } from 'date-fns';
import { getAllEvents } from '@/services/events';

const statusConfig: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800', icon: Clock },
  approved: { label: 'Approved', color: 'bg-green-100 text-green-800', icon: CheckCircle },
  rejected: { label: 'Rejected', color: 'bg-red-100 text-red-800', icon: XCircle },
  cancelled: { label: 'Cancelled', color: 'bg-gray-100 text-gray-800', icon: X },
  waitlisted: { label: 'Waitlisted', color: 'bg-blue-100 text-blue-800', icon: AlertTriangle },
};

export default function RegistrationManagementPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<string>('');
  const [registrations, setRegistrations] = useState<EventRegistration[]>([]);
  const [filteredRegistrations, setFilteredRegistrations] = useState<EventRegistration[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingRegs, setLoadingRegs] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [processing, setProcessing] = useState(false);

  // Dialog state
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [selectedReg, setSelectedReg] = useState<EventRegistration | null>(null);
  const [remarks, setRemarks] = useState('');

  useEffect(() => {
    loadEvents();
  }, []);

  useEffect(() => {
    if (selectedEventId) {
      loadRegistrations();
    }
  }, [selectedEventId]);

  useEffect(() => {
    filterRegistrations();
  }, [registrations, statusFilter, searchQuery]);

  async function loadEvents() {
    try {
      setLoading(true);
      const data = await getAllEvents();
      setEvents(data.filter(e => e.status !== 'draft'));
      if (data.length > 0 && !selectedEventId) {
        setSelectedEventId(data[0].id);
      }
    } catch {
      toast({ title: 'Error', description: 'Failed to load events', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  async function loadRegistrations() {
    try {
      setLoadingRegs(true);
      const data = await getRegistrationsByEvent(selectedEventId);
      setRegistrations(data);
      setSelectedIds(new Set());
    } catch {
      toast({ title: 'Error', description: 'Failed to load registrations', variant: 'destructive' });
    } finally {
      setLoadingRegs(false);
    }
  }

  function filterRegistrations() {
    let filtered = [...registrations];

    if (statusFilter !== 'all') {
      filtered = filtered.filter(r => r.approval_status === statusFilter);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(r =>
        r.user_name.toLowerCase().includes(query) ||
        r.user_email.toLowerCase().includes(query) ||
        (r.department?.toLowerCase().includes(query)) ||
        (r.student_id?.toLowerCase().includes(query))
      );
    }

    setFilteredRegistrations(filtered);
  }

  function toggleSelection(id: string) {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  }

  function toggleAll() {
    if (selectedIds.size === filteredRegistrations.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredRegistrations.map(r => r.id)));
    }
  }

  async function handleApprove(reg: EventRegistration) {
    setSelectedReg(reg);
    setRemarks(reg.remarks || '');
    setShowApproveDialog(true);
  }

  async function handleReject(reg: EventRegistration) {
    setSelectedReg(reg);
    setRemarks('');
    setShowRejectDialog(true);
  }

  async function confirmApprove() {
    if (!selectedReg || !user) return;

    try {
      setProcessing(true);
      const result = await approveRegistration(selectedReg.id, user.id, remarks);
      if (result.success) {
        toast({ title: 'Approved', description: `${selectedReg.user_name}'s registration has been approved` });
        loadRegistrations();
      } else {
        toast({ title: 'Error', description: result.error || 'Failed to approve', variant: 'destructive' });
      }
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setProcessing(false);
      setShowApproveDialog(false);
      setSelectedReg(null);
    }
  }

  async function confirmReject() {
    if (!selectedReg || !user) return;

    try {
      setProcessing(true);
      const result = await rejectRegistration(selectedReg.id, user.id, remarks);
      if (result.success) {
        toast({ title: 'Rejected', description: `${selectedReg.user_name}'s registration has been rejected` });
        loadRegistrations();
      } else {
        toast({ title: 'Error', description: result.error || 'Failed to reject', variant: 'destructive' });
      }
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setProcessing(false);
      setShowRejectDialog(false);
      setSelectedReg(null);
    }
  }

  async function handleBulkApprove() {
    if (!user || selectedIds.size === 0) return;

    try {
      setProcessing(true);
      const result = await bulkApproveRegistrations(Array.from(selectedIds), user.id);
      toast({ title: 'Bulk Approve Complete', description: `${result.success} approved, ${result.failed} failed` });
      loadRegistrations();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setProcessing(false);
    }
  }

  async function handleBulkReject() {
    if (!user || selectedIds.size === 0) return;

    try {
      setProcessing(true);
      const result = await bulkRejectRegistrations(Array.from(selectedIds), user.id);
      toast({ title: 'Bulk Reject Complete', description: `${result.success} rejected, ${result.failed} failed` });
      loadRegistrations();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setProcessing(false);
    }
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center h-96">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  const stats = {
    total: registrations.length,
    pending: registrations.filter(r => r.approval_status === 'pending').length,
    approved: registrations.filter(r => r.approval_status === 'approved').length,
    rejected: registrations.filter(r => r.approval_status === 'rejected').length,
    cancelled: registrations.filter(r => r.approval_status === 'cancelled').length,
  };

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Registration Management</h1>
            <p className="text-muted-foreground">Approve or reject event registrations</p>
          </div>
        </div>

        {/* Event Selector */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Event</label>
                <Select value={selectedEventId} onValueChange={setSelectedEventId}>
                  <SelectTrigger className="w-64">
                    <SelectValue placeholder="Select an event" />
                  </SelectTrigger>
                  <SelectContent>
                    {events.map((e) => (
                      <SelectItem key={e.id} value={e.id}>
                        {e.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.total}</p>
                  <p className="text-sm text-muted-foreground">Total</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.pending}</p>
                  <p className="text-sm text-muted-foreground">Pending</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.approved}</p>
                  <p className="text-sm text-muted-foreground">Approved</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                  <XCircle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.rejected}</p>
                  <p className="text-sm text-muted-foreground">Rejected</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                  <X className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.cancelled}</p>
                  <p className="text-sm text-muted-foreground">Cancelled</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Bulk Actions */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              <div className="flex flex-wrap gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search registrations..."
                    className="pl-10 w-64"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="waitlisted">Waitlisted</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {selectedIds.size > 0 && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleBulkApprove} disabled={processing}>
                    <CheckCheck className="w-4 h-4 mr-1" />
                    Approve ({selectedIds.size})
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleBulkReject} disabled={processing} className="text-destructive">
                    <X className="w-4 h-4 mr-1" />
                    Reject ({selectedIds.size})
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Registrations Table */}
        {loadingRegs ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredRegistrations.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-semibold mb-2">No Registrations Found</h2>
              <p className="text-muted-foreground">
                {registrations.length === 0 ? 'No registrations for this event yet.' : 'No registrations match your filters.'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-2">
                {/* Header */}
                <div className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg text-sm font-medium">
                  <Checkbox
                    checked={selectedIds.size === filteredRegistrations.length && filteredRegistrations.length > 0}
                    onCheckedChange={toggleAll}
                  />
                  <div className="flex-1">Participant</div>
                  <div className="w-24 text-center">Status</div>
                  <div className="w-32 text-center">Registered</div>
                  <div className="w-24 text-center">Actions</div>
                </div>

                {/* Rows */}
                {filteredRegistrations.map((reg) => {
                  const status = reg.approval_status || 'pending';
                  const config = statusConfig[status] || statusConfig.pending;

                  return (
                    <div key={reg.id} className="flex items-center gap-4 p-3 border rounded-lg hover:bg-muted/30 transition-colors">
                      <Checkbox
                        checked={selectedIds.has(reg.id)}
                        onCheckedChange={() => toggleSelection(reg.id)}
                      />
                      <div className="flex-1">
                        <p className="font-medium">{reg.user_name}</p>
                        <p className="text-xs text-muted-foreground">{reg.user_email}</p>
                        {reg.department && (
                          <p className="text-xs text-muted-foreground">{reg.department} {reg.semester && `• Sem ${reg.semester}`}</p>
                        )}
                      </div>
                      <div className="w-24 text-center">
                        <Badge className={config.color}>{config.label}</Badge>
                      </div>
                      <div className="w-32 text-center text-sm text-muted-foreground">
                        {reg.registered_at ? format(new Date(reg.registered_at), 'MMM d, HH:mm') : 'N/A'}
                      </div>
                      <div className="w-24 flex justify-center gap-1">
                        {status === 'pending' && (
                          <>
                            <Button size="icon" variant="ghost" onClick={() => handleApprove(reg)} title="Approve">
                              <CheckCircle className="w-4 h-4 text-green-600" />
                            </Button>
                            <Button size="icon" variant="ghost" onClick={() => handleReject(reg)} title="Reject">
                              <XCircle className="w-4 h-4 text-red-600" />
                            </Button>
                          </>
                        )}
                        {status === 'approved' && (
                          <Button size="icon" variant="ghost" onClick={() => handleReject(reg)} title="Revoke">
                            <XCircle className="w-4 h-4 text-red-600" />
                          </Button>
                        )}
                        {status === 'rejected' && (
                          <Button size="icon" variant="ghost" onClick={() => handleApprove(reg)} title="Approve">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </motion.div>

      {/* Approve Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Registration</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <p>Approve registration for <strong>{selectedReg?.user_name}</strong>?</p>
            <div className="space-y-2">
              <Label>Remarks (optional)</Label>
              <Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Add any remarks..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApproveDialog(false)}>Cancel</Button>
            <Button onClick={confirmApprove} disabled={processing}>
              {processing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Registration</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <p>Reject registration for <strong>{selectedReg?.user_name}</strong>?</p>
            <div className="space-y-2">
              <Label>Reason (optional)</Label>
              <Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Provide reason for rejection..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmReject} disabled={processing}>
              {processing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Reject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
