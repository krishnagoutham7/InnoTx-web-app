import { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Upload,
  Trash2,
  Star,
  Image as ImageIcon,
  Loader2,
  Save,
  Move,
  Eye,
  RotateCcw,
  Palette,
  Copy,
  Settings,
} from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { FontControls } from '@/components/dashboard/font-controls';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import {
  getTicketTemplates,
  uploadTicketTemplate,
  deleteTicketTemplate,
  setDefaultTicketTemplate,
  updateTicketTemplateFieldConfig,
} from '@/services/ticket-templates';
import { generateQRCodeDataUrl } from '@/services/ticket-templates';
import type {
  TicketTemplate,
  TicketFieldConfigs,
  TicketFieldConfig,
} from '@/types/events';
import { STANDARD_FIELD_LABELS } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_SIZE = 20 * 1024 * 1024; // 20MB

// Available data fields for auto-fill
const DATA_FIELDS = [
  { key: 'participant_name', label: 'Student Name', sample: 'John Doe' },
  { key: 'participant_email', label: 'Email', sample: 'john@example.com' },
  { key: 'ticket_id', label: 'Ticket Number', sample: 'TKT-20260611-ABCD1234' },
  { key: 'event_name', label: 'Event Name', sample: 'Annual Tech Workshop 2026' },
  { key: 'event_date', label: 'Event Date', sample: 'June 15, 2026' },
  { key: 'event_time', label: 'Event Time', sample: '10:00 AM' },
  { key: 'event_venue', label: 'Venue', sample: 'Main Auditorium' },
  { key: 'department', label: 'Department', sample: 'Computer Science' },
  { key: 'registration_id', label: 'Registration ID', sample: 'REG-2026-001234' },
  { key: 'student_id', label: 'Student ID', sample: 'STU2024001' },
  { key: 'issue_date', label: 'Issue Date', sample: 'June 11, 2026' },
  { key: 'custom_text', label: 'Custom Text', sample: 'Custom Label' },
];

// Default field positions for new templates
const DEFAULT_FIELD_CONFIG: TicketFieldConfigs = {
  participant_name: { x: 50, y: 25, fontSize: 24, fontColor: '#ffffff', fontFamily: 'Arial', align: 'center', dataField: 'participant_name' },
  ticket_id: { x: 50, y: 45, fontSize: 12, fontColor: '#cccccc', fontFamily: 'monospace', align: 'center', dataField: 'ticket_id' },
  event_name: { x: 50, y: 55, fontSize: 18, fontColor: '#ffffff', fontFamily: 'Arial', align: 'center', dataField: 'event_name' },
  event_date: { x: 25, y: 75, fontSize: 14, fontColor: '#aaaaaa', fontFamily: 'Arial', align: 'left', dataField: 'event_date' },
  event_time: { x: 75, y: 75, fontSize: 14, fontColor: '#aaaaaa', fontFamily: 'Arial', align: 'right', dataField: 'event_time' },
  event_venue: { x: 50, y: 85, fontSize: 12, fontColor: '#999999', fontFamily: 'Arial', align: 'center', dataField: 'event_venue' },
  qr_code: { x: 88, y: 50, size: 18 },
};

// Field label color mapping
const FIELD_COLORS: Record<string, string> = {
  participant_name: 'bg-blue-500',
  ticket_id: 'bg-gray-500',
  event_name: 'bg-green-500',
  event_date: 'bg-amber-500',
  event_time: 'bg-orange-500',
  event_venue: 'bg-purple-500',
  department: 'bg-indigo-500',
  registration_id: 'bg-cyan-500',
  student_id: 'bg-teal-500',
  issue_date: 'bg-rose-500',
  qr_code: 'bg-slate-600',
  custom_text: 'bg-pink-500',
};

// Get sample data for a field
function getSampleData(fieldKey: string): string {
  const df = DATA_FIELDS.find((d) => d.key === fieldKey);
  return df?.sample || fieldKey;
}

// Field settings editor component
function FieldSettingsEditor({
  fieldKey,
  config,
  onUpdate,
  onDelete,
  onDuplicate,
}: {
  fieldKey: string;
  config: TicketFieldConfig;
  onUpdate: (key: string, updates: Partial<TicketFieldConfig>) => void;
  onDelete: (key: string) => void;
  onDuplicate: (key: string) => void;
}) {
  const isQR = fieldKey === 'qr_code';
  // Only protect qr_code from deletion (required for ticket scanning)
  const canDelete = fieldKey !== 'qr_code';

  return (
    <div className="p-3 rounded-lg bg-muted/50 border space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className={cn(
              'w-3 h-3 rounded-full',
              FIELD_COLORS[fieldKey.split('_')[0]] || 'bg-gray-400'
            )}
          />
          <span className="font-medium text-sm">
            {STANDARD_FIELD_LABELS[fieldKey] || config.label || fieldKey}
          </span>
          {!canDelete && (
            <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">Required</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => onDuplicate(fieldKey)}
            title="Duplicate field"
          >
            <Copy className="w-3.5 h-3.5" />
          </Button>
          {canDelete && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10"
              onClick={() => onDelete(fieldKey)}
              title="Remove field from template"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      </div>

      {/* Position */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label className="text-xs">X Position (%)</Label>
          <div className="flex items-center gap-2">
            <Slider
              value={[config.x]}
              min={0}
              max={100}
              step={1}
              onValueChange={([v]) => onUpdate(fieldKey, { x: v })}
              className="flex-1"
            />
            <span className="text-xs w-10 text-right">{config.x.toFixed(0)}%</span>
          </div>
        </div>
        <div>
          <Label className="text-xs">Y Position (%)</Label>
          <div className="flex items-center gap-2">
            <Slider
              value={[config.y]}
              min={0}
              max={100}
              step={1}
              onValueChange={([v]) => onUpdate(fieldKey, { y: v })}
              className="flex-1"
            />
            <span className="text-xs w-10 text-right">{config.y.toFixed(0)}%</span>
          </div>
        </div>
      </div>

      {isQR ? (
        // QR size
        <div>
          <Label className="text-xs">QR Size (%)</Label>
          <div className="flex items-center gap-2">
            <Slider
              value={[config.size || 18]}
              min={5}
              max={40}
              step={1}
              onValueChange={([v]) => onUpdate(fieldKey, { size: v })}
              className="flex-1"
            />
            <span className="text-xs w-10 text-right">{config.size || 18}%</span>
          </div>
        </div>
      ) : (
        <>
          {/* Data field selector */}
          <div>
            <Label className="text-xs">Auto-fill from</Label>
            <Select
              value={config.dataField || fieldKey.split('_')[0]}
              onValueChange={(v) => onUpdate(fieldKey, { dataField: v })}
            >
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DATA_FIELDS.map((df) => (
                  <SelectItem key={df.key} value={df.key} className="text-xs">
                    {df.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Font controls (size, family, weight, color, style, alignment, spacing) */}
          <FontControls
            fontSize={config.fontSize || 14}
            fontColor={config.fontColor || '#000000'}
            fontFamily={config.fontFamily || 'Arial'}
            fontWeight={config.fontWeight}
            align={config.align || 'center'}
            letterSpacing={config.letterSpacing}
            bold={config.bold}
            italic={config.italic}
            underline={config.underline}
            fontSizeMin={8}
            fontSizeMax={72}
            onUpdate={(updates) => onUpdate(fieldKey, updates)}
          />

          {/* Custom label for duplicates */}
          {fieldKey.includes('_') && (
            <div>
              <Label className="text-xs">Custom Label</Label>
              <Input
                value={config.label || ''}
                onChange={(e) => onUpdate(fieldKey, { label: e.target.value })}
                placeholder="e.g., Venue 2"
                className="h-8"
              />
            </div>
          )}

          {/* Custom text (for static fields) */}
          {config.dataField === 'custom_text' && (
            <div>
              <Label className="text-xs">Static Text</Label>
              <Input
                value={config.customText || ''}
                onChange={(e) => onUpdate(fieldKey, { customText: e.target.value })}
                placeholder="Enter static text"
                className="h-8"
              />
            </div>
          )}
        </>
      )}
    </div>
  );
}

// Visual field editor component
function VisualFieldEditor({
  template,
  fieldConfig,
  onFieldChange,
  imageRef,
  onFieldSelect,
  selectedField,
  onDeleteField,
}: {
  template: TicketTemplate;
  fieldConfig: TicketFieldConfigs;
  onFieldChange: (config: TicketFieldConfigs) => void;
  imageRef: React.RefObject<HTMLDivElement>;
  onFieldSelect: (key: string | null) => void;
  selectedField: string | null;
  onDeleteField: (key: string) => void;
}) {
  const [dragging, setDragging] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    generateQRCodeDataUrl('https://example.com/ticket/sample').then(setQrDataUrl);
  }, []);

  const handleMouseDown = (fieldName: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(fieldName);
    onFieldSelect(fieldName);
  };

  const handleMouseMove = useCallback(
    (e: MouseEvent) => {
      if (!dragging || !containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;

      const clampedX = Math.max(0, Math.min(100, x));
      const clampedY = Math.max(0, Math.min(100, y));

      onFieldChange({
        ...fieldConfig,
        [dragging]: {
          ...fieldConfig[dragging],
          x: clampedX,
          y: clampedY,
        },
      });
    },
    [dragging, fieldConfig, onFieldChange]
  );

  const handleMouseUp = useCallback(() => {
    setDragging(null);
  }, []);

  useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging, handleMouseMove, handleMouseUp]);

  const handleDeleteField = (key: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (key !== 'qr_code') {
      onDeleteField(key);
      onFieldSelect(null);
    }
  };

  return (
    <div ref={containerRef} className="relative inline-block">
      {/* Click outside to deselect */}
      <div
        ref={imageRef}
        className="relative overflow-hidden rounded-lg border-2 border-border cursor-default"
        style={{
          width: '100%',
          maxWidth: '800px',
          aspectRatio: `${template.template_width}/${template.template_height}`,
        }}
      >
        <img
          src={template.template_image_url}
          alt={template.name}
          className="w-full h-full object-fill"
          draggable={false}
        />

        {Object.entries(fieldConfig).map(([key, config]) => {
          const isQR = key === 'qr_code';
          const baseKey = key.split('_')[0];
          const bgColorClass = FIELD_COLORS[baseKey] || 'bg-gray-500';

          return (
            <div
              key={key}
              className={cn(
                'absolute cursor-move select-none transition-shadow',
                (dragging === key || selectedField === key) && 'shadow-lg ring-2 ring-primary z-50',
                selectedField !== key && selectedField && 'opacity-50'
              )}
              style={{
                left: `${config.x}%`,
                top: `${config.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              onMouseDown={(e) => handleMouseDown(key, e)}
            >
              {isQR ? (
                <div className="relative">
                  <div
                    className="border-2 border-dashed border-blue-400 rounded bg-white/90 p-1"
                    style={{
                      width: `${(config.size || 18) * 2}px`,
                      height: `${(config.size || 18) * 2}px`,
                    }}
                  >
                    {qrDataUrl && <img src={qrDataUrl} alt="QR" className="w-full h-full" />}
                  </div>
                  {selectedField === key && (
                    <div className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-muted text-[10px] text-muted-foreground">
                      Required
                    </div>
                  )}
                </div>
              ) : (
                <div className="relative group">
                  <div
                    className={cn(
                      'px-2 py-1 rounded text-xs font-medium whitespace-nowrap text-white',
                      bgColorClass
                    )}
                    style={{
                      backgroundColor: config.fontColor ? config.fontColor : undefined,
                    }}
                  >
                    {config.label || STANDARD_FIELD_LABELS[key] || key}
                  </div>
                  {/* Delete button - appears on selection */}
                  {selectedField === key && (
                    <button
                      className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center rounded-full bg-destructive text-white hover:bg-destructive/80 transition-colors"
                      onClick={(e) => handleDeleteField(key, e)}
                      title="Remove field"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <p className="text-sm text-muted-foreground mt-2 text-center">
        Click a field to select it, drag to reposition, or click the X to remove
      </p>
    </div>
  );
}

// Ticket preview renderer
function TicketPreview({
  template,
  fieldConfig,
}: {
  template: TicketTemplate;
  fieldConfig: TicketFieldConfigs;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    generateQRCodeDataUrl('https://example.com/verify/TKT-SAMPLE').then(setQrDataUrl);
  }, []);

  useEffect(() => {
    if (!canvasRef.current || !qrDataUrl) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = template.template_width;
    canvas.height = template.template_height;

    const bgImg = new Image();
    bgImg.crossOrigin = 'anonymous';
    bgImg.onload = () => {
      ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

      Object.entries(fieldConfig).forEach(([key, config]) => {
        if (key === 'qr_code') return;

        const fc = config as TicketFieldConfig;
        const dataField = fc.dataField || key.split('_')[0];
        let value = fc.customText || getSampleData(dataField);

        const x = (fc.x / 100) * canvas.width;
        const y = (fc.y / 100) * canvas.height;
        const maxWidth = fc.width ? (fc.width / 100) * canvas.width : canvas.width * 0.6;

        ctx.font = `${fc.fontSize || 14}px ${fc.fontFamily || 'Arial'}`;
        ctx.fillStyle = fc.fontColor || '#000000';
        ctx.textAlign = (fc.align as CanvasTextAlign) || 'center';
        ctx.textBaseline = 'middle';

        ctx.shadowColor = 'rgba(0,0,0,0.4)';
        ctx.shadowBlur = 2;
        ctx.fillText(value, x, y, maxWidth);
        ctx.shadowColor = 'transparent';
      });

      if (fieldConfig.qr_code && qrDataUrl) {
        const qrConfig = fieldConfig.qr_code;
        const centerX = (qrConfig.x / 100) * canvas.width;
        const centerY = (qrConfig.y / 100) * canvas.height;
        const qrSize = ((qrConfig.size || 18) / 100) * Math.min(canvas.width, canvas.height);

        const qrImg = new Image();
        qrImg.onload = () => {
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(centerX, centerY, qrSize / 2 + 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.drawImage(qrImg, centerX - qrSize / 2, centerY - qrSize / 2, qrSize, qrSize);
          setPreviewUrl(canvas.toDataURL('image/png'));
        };
        qrImg.src = qrDataUrl;
      } else {
        setPreviewUrl(canvas.toDataURL('image/png'));
      }
    };
    bgImg.src = template.template_image_url;
  }, [template, fieldConfig, qrDataUrl]);

  if (!previewUrl) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <img
        src={previewUrl}
        alt="Ticket Preview"
        className="w-full rounded-lg border shadow-lg"
        style={{ maxWidth: '800px', margin: '0 auto' }}
      />
      <p className="text-sm text-muted-foreground text-center">Preview with sample data</p>
    </div>
  );
}

export default function TicketTemplatesPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [templates, setTemplates] = useState<TicketTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<TicketTemplate | null>(null);
  const [showEditorDialog, setShowEditorDialog] = useState(false);
  const [editingFieldConfig, setEditingFieldConfig] = useState<TicketFieldConfigs | null>(null);
  const [savingConfig, setSavingConfig] = useState(false);
  const [selectedFieldKey, setSelectedFieldKey] = useState<string | null>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  // Form state
  const [formName, setFormName] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formFile, setFormFile] = useState<File | null>(null);
  const [formPreview, setFormPreview] = useState<string | null>(null);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const data = await getTicketTemplates();
      setTemplates(data);
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to load templates', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!ALLOWED_TYPES.includes(file.type)) {
      toast({ title: 'Invalid file', description: 'Please upload JPG, PNG, or WEBP', variant: 'destructive' });
      return;
    }

    if (file.size > MAX_SIZE) {
      toast({ title: 'File too large', description: 'Maximum size is 20MB', variant: 'destructive' });
      return;
    }

    setFormFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => {
      setFormPreview(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!formFile || !formName || !user) {
      toast({ title: 'Missing fields', description: 'Name and image are required', variant: 'destructive' });
      return;
    }

    setUploading(true);
    try {
      await uploadTicketTemplate(formFile, formName, formDescription, user.id);
      toast({ title: 'Template uploaded', description: 'Ticket template has been created' });
      setShowUploadDialog(false);
      resetForm();
      loadTemplates();
    } catch (err: any) {
      toast({ title: 'Upload failed', description: err.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      await setDefaultTicketTemplate(id);
      toast({ title: 'Default updated', description: 'Default template has been changed' });
      loadTemplates();
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to set default', variant: 'destructive' });
    }
  };

  const handleDelete = async (template: TicketTemplate) => {
    if (!window.confirm(`Delete "${template.name}"? This cannot be undone.`)) return;

    try {
      await deleteTicketTemplate(template.id);
      toast({ title: 'Deleted', description: 'Template has been removed' });
      loadTemplates();
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to delete template', variant: 'destructive' });
    }
  };

  const handleEditFields = (template: TicketTemplate) => {
    setSelectedTemplate(template);
    setEditingFieldConfig(template.field_config);
    setSelectedFieldKey(null);
    setShowEditorDialog(true);
  };

  const handleUpdateField = (key: string, updates: Partial<TicketFieldConfig>) => {
    if (!editingFieldConfig) return;
    setEditingFieldConfig({
      ...editingFieldConfig,
      [key]: { ...editingFieldConfig[key], ...updates },
    });
  };

  const handleAddField = (fieldType: string) => {
    if (!editingFieldConfig) return;

    const existingDuplicates = Object.keys(editingFieldConfig).filter((k) =>
      k.startsWith(fieldType)
    ).length;
    const newKey = existingDuplicates > 0 ? `${fieldType}_${existingDuplicates + 1}` : fieldType;

    const df = DATA_FIELDS.find((d) => d.key === fieldType);

    setEditingFieldConfig({
      ...editingFieldConfig,
      [newKey]: {
        x: 50,
        y: 50,
        fontSize: 14,
        fontColor: '#ffffff',
        fontFamily: 'Arial',
        align: 'center',
        dataField: fieldType,
        label: df ? `${df.label} ${existingDuplicates + 1}` : newKey,
      },
    });
    setSelectedFieldKey(newKey);
  };

  const handleDuplicateField = (key: string) => {
    if (!editingFieldConfig) return;

    const existingDuplicates = Object.keys(editingFieldConfig).filter((k) =>
      k.startsWith(key)
    ).length;
    const newKey = `${key}_${existingDuplicates + 1}`;

    setEditingFieldConfig({
      ...editingFieldConfig,
      [newKey]: {
        ...editingFieldConfig[key],
        x: Math.min(100, editingFieldConfig[key].x + 5),
        y: Math.min(100, editingFieldConfig[key].y + 5),
        label: editingFieldConfig[key].label
          ? `${editingFieldConfig[key].label} (copy)`
          : undefined,
      },
    });
    setSelectedFieldKey(newKey);
  };

  const handleDeleteField = (key: string) => {
    if (!editingFieldConfig) return;
    const { [key]: _, ...rest } = editingFieldConfig;
    setEditingFieldConfig(rest);
    if (selectedFieldKey === key) {
      setSelectedFieldKey(null);
    }
  };

  const handleSaveFieldConfig = async () => {
    if (!selectedTemplate || !editingFieldConfig) return;

    setSavingConfig(true);
    try {
      await updateTicketTemplateFieldConfig(selectedTemplate.id, editingFieldConfig);
      toast({ title: 'Saved', description: 'Field positions have been updated' });
      setShowEditorDialog(false);
      loadTemplates();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setSavingConfig(false);
    }
  };

  const handleResetFieldConfig = () => {
    setEditingFieldConfig(DEFAULT_FIELD_CONFIG);
    setSelectedFieldKey(null);
  };

  const resetForm = () => {
    setFormName('');
    setFormDescription('');
    setFormFile(null);
    setFormPreview(null);
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Ticket Template Engine"
          description="Upload templates, position fields visually, and generate professional tickets"
          actions={
            <Button onClick={() => setShowUploadDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Upload Template
            </Button>
          }
        />

        {/* Templates Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <Card key={template.id} className="glass-card border-0 shadow-md overflow-hidden">
              <div className="aspect-[2/1] bg-muted relative">
                <img
                  src={template.template_image_url}
                  alt={template.name}
                  className="w-full h-full object-cover"
                />
                {template.is_default && (
                  <div className="absolute top-2 left-2 px-2 py-1 bg-primary text-primary-foreground text-xs font-medium rounded">
                    Default
                  </div>
                )}
                <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/60 text-white text-xs rounded">
                  {Object.keys(template.field_config || {}).length} fields
                </div>
              </div>
              <CardContent className="pt-4">
                <h3 className="font-semibold truncate">{template.name}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                  {template.description || 'No description'}
                </p>
                <div className="text-xs text-muted-foreground mt-2">
                  {template.template_width} x {template.template_height}px
                </div>
                <div className="flex flex-wrap items-center gap-2 mt-4">
                  <Button variant="default" size="sm" onClick={() => handleEditFields(template)}>
                    <Move className="w-4 h-4 mr-1" />
                    Edit Fields
                  </Button>
                  {!template.is_default && (
                    <>
                      <Button variant="ghost" size="sm" onClick={() => handleSetDefault(template.id)}>
                        <Star className="w-4 h-4 mr-1" />
                        Default
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDelete(template)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {templates.length === 0 && (
          <div className="text-center py-12">
            <ImageIcon className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-medium mb-2">No templates yet</h3>
            <p className="text-muted-foreground mb-4">Upload your first ticket template to get started.</p>
            <Button onClick={() => setShowUploadDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Upload Template
            </Button>
          </div>
        )}

        {/* Upload Dialog */}
        <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Upload Ticket Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Template Name</Label>
                <Input
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g., Workshop Ticket, Hackathon Ticket"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Description</Label>
                <Textarea
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Brief description of this template"
                  rows={2}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Template Image</Label>
                <label
                  className={cn(
                    'block relative border-2 border-dashed rounded-lg overflow-hidden transition-colors cursor-pointer',
                    'aspect-[2/1]',
                    !formPreview
                      ? 'border-muted-foreground/25 bg-muted/30 hover:border-primary/50'
                      : 'border-primary/30'
                  )}
                >
                  {formPreview ? (
                    <img src={formPreview} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="absolute inset-0 w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                      <Upload className="w-8 h-8 mb-2" />
                      <p className="text-sm font-medium">Click to upload image</p>
                      <p className="text-xs mt-1">PNG, JPG, WEBP (max 20MB)</p>
                    </div>
                  )}
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </label>
                <p className="text-xs text-muted-foreground">
                  Recommended: 800x400px for standard tickets. Use 16:9 or 2:1 aspect ratio.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setShowUploadDialog(false);
                  resetForm();
                }}
              >
                Cancel
              </Button>
              <Button onClick={handleUpload} disabled={!formFile || !formName || uploading}>
                {uploading ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Upload className="w-4 h-4 mr-2" />
                )}
                Upload
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Template Editor Dialog */}
        <Dialog open={showEditorDialog} onOpenChange={setShowEditorDialog}>
          <DialogContent className="max-w-7xl max-h-[95vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Template Field Editor: {selectedTemplate?.name}
              </DialogTitle>
            </DialogHeader>

            {selectedTemplate && editingFieldConfig && (
              <Tabs defaultValue="editor" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="editor">
                    <Move className="w-4 h-4 mr-2" />
                    Position Fields
                  </TabsTrigger>
                  <TabsTrigger value="settings">
                    <Palette className="w-4 h-4 mr-2" />
                    Field Settings
                  </TabsTrigger>
                  <TabsTrigger value="preview">
                    <Eye className="w-4 h-4 mr-2" />
                    Preview Ticket
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="editor" className="mt-4">
                  <VisualFieldEditor
                    template={selectedTemplate}
                    fieldConfig={editingFieldConfig}
                    onFieldChange={setEditingFieldConfig}
                    imageRef={imageRef}
                    onFieldSelect={setSelectedFieldKey}
                    selectedField={selectedFieldKey}
                    onDeleteField={handleDeleteField}
                  />

                  {/* Add field buttons */}
                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="text-sm text-muted-foreground mr-2">Add field:</span>
                    {DATA_FIELDS.slice(0, 8).map((df) => (
                      <Button
                        key={df.key}
                        variant="outline"
                        size="sm"
                        onClick={() => handleAddField(df.key)}
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        {df.label}
                      </Button>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="settings" className="mt-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">Field Settings</h3>
                      <Button variant="outline" size="sm" onClick={handleResetFieldConfig}>
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reset All
                      </Button>
                    </div>

                    <div className="grid gap-4">
                      {Object.entries(editingFieldConfig).map(([key, config]) => (
                        <FieldSettingsEditor
                          key={key}
                          fieldKey={key}
                          config={config}
                          onUpdate={handleUpdateField}
                          onDelete={handleDeleteField}
                          onDuplicate={handleDuplicateField}
                        />
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="preview" className="mt-4">
                  <TicketPreview template={selectedTemplate} fieldConfig={editingFieldConfig} />
                </TabsContent>
              </Tabs>
            )}

            <DialogFooter className="flex gap-2 mt-4">
              <Button variant="outline" onClick={() => setShowEditorDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveFieldConfig} disabled={savingConfig}>
                {savingConfig ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Save Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </DashboardLayout>
  );
}
