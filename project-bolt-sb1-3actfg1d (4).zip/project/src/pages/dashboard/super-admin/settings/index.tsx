import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Save, Palette, Globe, Settings, Shield, Loader2 } from 'lucide-react';
import { getSystemSettings, updateSystemSettings } from '@/services/cms';
import type { SystemSettings } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

export default function SystemSettingsPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<SystemSettings | null>(null);

  useEffect(() => {
    getSystemSettings()
      .then(s => { if (s) setSettings(s); })
      .catch(() => toast({ title: 'Error', description: 'Failed to load settings', variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  const set = <K extends keyof SystemSettings>(key: K, value: SystemSettings[K]) =>
    setSettings(s => s ? { ...s, [key]: value } : s);

  const handleSave = async () => {
    if (!settings) return;
    try {
      setSaving(true);
      const updated = await updateSystemSettings({
        portal_name: settings.portal_name,
        portal_tagline: settings.portal_tagline,
        footer_text: settings.footer_text,
        language: settings.language,
        primary_color: settings.primary_color,
        accent_color: settings.accent_color,
        enable_dark_mode: settings.enable_dark_mode,
        show_announcements_on_home: settings.show_announcements_on_home,
        show_events_on_home: settings.show_events_on_home,
        show_gallery_on_home: settings.show_gallery_on_home,
      });
      setSettings(updated);
      toast({ title: 'Settings Saved', description: 'System settings have been updated' });
    } catch {
      toast({ title: 'Save Failed', description: 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
      </DashboardLayout>
    );
  }

  if (!settings) return null;

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader title="System Settings" description="Configure portal settings and preferences"
          actions={
            <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Changes
            </Button>
          }
        />

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Portal Settings */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center gap-2">
              <Globe className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">Portal Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Portal Name</Label>
                <Input value={settings.portal_name} onChange={e => set('portal_name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Portal Tagline</Label>
                <Input value={settings.portal_tagline} onChange={e => set('portal_tagline', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Footer Text</Label>
                <Input value={settings.footer_text} onChange={e => set('footer_text', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Language</Label>
                <Select value={settings.language} onValueChange={v => set('language', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ml">Malayalam</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Theme Settings */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center gap-2">
              <Palette className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">Theme Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Dark Mode</Label>
                  <p className="text-xs text-muted-foreground">Enable dark mode by default</p>
                </div>
                <Switch checked={settings.enable_dark_mode} onCheckedChange={v => set('enable_dark_mode', v)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Primary Color</Label>
                  <div className="flex gap-2">
                    <Input value={settings.primary_color} onChange={e => set('primary_color', e.target.value)} />
                    <div className="w-10 h-10 rounded-lg border shrink-0" style={{ backgroundColor: settings.primary_color }} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Accent Color</Label>
                  <div className="flex gap-2">
                    <Input value={settings.accent_color} onChange={e => set('accent_color', e.target.value)} />
                    <div className="w-10 h-10 rounded-lg border shrink-0" style={{ backgroundColor: settings.accent_color }} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Homepage Preferences */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">Homepage Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Show Announcements</Label>
                  <p className="text-xs text-muted-foreground">Display announcements section</p>
                </div>
                <Switch checked={settings.show_announcements_on_home} onCheckedChange={v => set('show_announcements_on_home', v)} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Show Events</Label>
                  <p className="text-xs text-muted-foreground">Display events section</p>
                </div>
                <Switch checked={settings.show_events_on_home} onCheckedChange={v => set('show_events_on_home', v)} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Show Gallery</Label>
                  <p className="text-xs text-muted-foreground">Display gallery preview</p>
                </div>
                <Switch checked={settings.show_gallery_on_home} onCheckedChange={v => set('show_gallery_on_home', v)} />
              </div>
            </CardContent>
          </Card>

          {/* Security */}
          <Card className="glass-card border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-muted/50">
                <p className="text-sm font-medium">Password Requirements</p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>Minimum 8 characters</li>
                  <li>At least one uppercase letter</li>
                  <li>At least one number</li>
                  <li>At least one special character</li>
                </ul>
              </div>
              <Button variant="outline" className="w-full">Configure Security Settings</Button>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
