import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { DataTable, PageHeader, ConfirmDialog } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Pencil, Trash2, UserPlus, Loader2, Upload, X } from 'lucide-react';
import { getTeamMembers, createTeamMember, updateTeamMember, deleteTeamMember, uploadTeamPhoto } from '@/services/cms';
import type { TeamMember } from '@/services/cms';
import { useToast } from '@/hooks/use-toast';

const categoryOptions = [
  { value: 'principal', label: 'Principal' },
  { value: 'ceo', label: 'CEO (Chief Executive Officer)' },
  { value: 'coo', label: 'COO (Chief Operating Officer)' },
  { value: 'cfo', label: 'CFO (Chief Financial Officer)' },
  { value: 'cpo', label: 'CPO (Chief Program Officer)' },
  { value: 'executive', label: 'Executive Member' },
  { value: 'member', label: 'Team Member' },
  { value: 'student_coordinator', label: 'Student Coordinator' },
];

const categoryLabels: Record<string, string> = Object.fromEntries(categoryOptions.map(c => [c.value, c.label]));

const emptyForm = {
  name: '',
  position: '',
  category: 'member',
  department: '',
  email: '',
  phone: '',
  bio: '',
  linkedin_url: '',
  github_url: '',
  instagram_url: '',
  is_active: true,
  display_order: 0,
  photo_url: '',
};

export default function TeamManagement() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<TeamMember | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<TeamMember | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      setLoading(true);
      setMembers(await getTeamMembers());
    } catch {
      toast({ title: 'Error', description: 'Failed to load team members', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const openCreate = () => {
    setEditTarget(null);
    setForm(emptyForm);
    setFormOpen(true);
  };

  const openEdit = (m: TeamMember) => {
    setEditTarget(m);
    setForm({
      name: m.name,
      position: m.position,
      category: m.category,
      department: m.department || '',
      email: m.email || '',
      phone: m.phone || '',
      bio: m.bio || '',
      linkedin_url: m.linkedin_url || '',
      github_url: m.github_url || '',
      instagram_url: m.instagram_url || '',
      is_active: m.is_active,
      display_order: m.display_order,
      photo_url: m.photo_url || '',
    });
    setFormOpen(true);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const ext = file.name.split('.').pop() || 'jpg';
      const timestamp = Date.now();
      const randomStr = Math.random().toString(36).substring(2, 8);
      const path = `team/${timestamp}-${randomStr}.${ext}`;

      const publicUrl = await uploadTeamPhoto(file, path);
      setForm(f => ({ ...f, photo_url: publicUrl }));
      toast({ title: 'Photo Uploaded', description: 'Profile photo uploaded successfully' });
    } catch (err: any) {
      toast({ title: 'Upload Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const clearPhoto = () => {
    setForm(f => ({ ...f, photo_url: '' }));
  };

  const handleSave = async () => {
    if (!form.name || !form.position) {
      toast({ title: 'Validation Error', description: 'Name and position are required', variant: 'destructive' });
      return;
    }
    try {
      setSaving(true);
      const payload = {
        name: form.name,
        position: form.position,
        category: form.category,
        department: form.department || null,
        email: form.email || null,
        phone: form.phone || null,
        bio: form.bio || null,
        linkedin_url: form.linkedin_url || null,
        github_url: form.github_url || null,
        instagram_url: form.instagram_url || null,
        is_active: form.is_active,
        display_order: form.display_order,
        photo_url: form.photo_url || null,
      };

      if (editTarget) {
        const updated = await updateTeamMember(editTarget.id, payload);
        setMembers(prev => prev.map(m => m.id === editTarget.id ? updated : m));
        toast({ title: 'Updated', description: `${form.name} has been updated` });
      } else {
        const created = await createTeamMember(payload);
        setMembers(prev => [...prev, created]);
        toast({ title: 'Added', description: `${form.name} has been added to the team` });
      }
      setFormOpen(false);
    } catch (err: any) {
      toast({ title: 'Save Failed', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      await deleteTeamMember(deleteTarget.id);
      setMembers(prev => prev.filter(m => m.id !== deleteTarget.id));
      toast({ title: 'Deleted', description: `${deleteTarget.name} has been removed` });
      setDeleteTarget(null);
    } catch {
      toast({ title: 'Error', description: 'Failed to delete member', variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Team Management"
          description="Manage team members, positions, and categories"
          actions={<Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={openCreate}><UserPlus className="w-4 h-4" />Add Member</Button>}
        />

        {loading ? (
          <div className="flex items-center justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <DataTable
            data={members}
            columns={[
              { key: 'name', header: 'Name', render: (m) => (
                <div className="flex items-center gap-3">
                  {m.photo_url ? (
                    <img src={m.photo_url} alt={m.name} className="w-9 h-9 rounded-full object-cover" />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-sm font-semibold">{m.name.charAt(0)}</div>
                  )}
                  <div>
                    <p className="font-medium">{m.name}</p>
                    <p className="text-xs text-muted-foreground">{m.email || '—'}</p>
                  </div>
                </div>
              )},
              { key: 'position', header: 'Position', render: (m) => <span className="text-sm">{m.position}</span> },
              { key: 'category', header: 'Category', render: (m) => <Badge variant="secondary">{categoryLabels[m.category] || m.category}</Badge> },
              { key: 'department', header: 'Department', render: (m) => <span className="text-sm text-muted-foreground">{m.department || '—'}</span> },
              { key: 'is_active', header: 'Status', render: (m) => <Badge variant={m.is_active ? 'default' : 'destructive'}>{m.is_active ? 'Active' : 'Inactive'}</Badge> },
            ]}
            searchKeys={['name', 'email', 'position']}
            searchPlaceholder="Search team members..."
            actions={(m) => (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" onClick={() => openEdit(m)}><Pencil className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => setDeleteTarget(m)}><Trash2 className="w-4 h-4" /></Button>
              </div>
            )}
          />
        )}

        {/* Add / Edit Dialog */}
        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editTarget ? 'Edit Team Member' : 'Add Team Member'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              {/* Photo Upload */}
              <div className="space-y-2">
                <Label>Profile Photo</Label>
                <div className="flex items-center gap-4">
                  {form.photo_url ? (
                    <div className="relative">
                      <img src={form.photo_url} alt="Profile" className="w-16 h-16 rounded-full object-cover border-2 border-primary/20" />
                      <button
                        type="button"
                        onClick={clearPhoto}
                        className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-destructive text-white flex items-center justify-center text-xs"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center border-2 border-dashed border-muted-foreground/30">
                      <Upload className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                  <div className="flex-1">
                    <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                    <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                      {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                      {uploading ? 'Uploading...' : 'Upload Photo'}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Name <span className="text-destructive">*</span></Label>
                  <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Full name" />
                </div>
                <div className="space-y-1.5">
                  <Label>Position <span className="text-destructive">*</span></Label>
                  <Input value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))} placeholder="Job title" />
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{categoryOptions.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Department</Label>
                  <Input value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))} placeholder="e.g. Computer Engineering" />
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Email</Label>
                  <Input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="member@email.com" />
                </div>
                <div className="space-y-1.5">
                  <Label>Phone</Label>
                  <Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+91 ..." />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Bio</Label>
                <Textarea value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} placeholder="Short biography or description" rows={3} />
              </div>
              <div className="space-y-1.5">
                <Label>LinkedIn URL</Label>
                <Input value={form.linkedin_url} onChange={e => setForm(f => ({ ...f, linkedin_url: e.target.value }))} placeholder="https://linkedin.com/in/..." />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>GitHub URL</Label>
                  <Input value={form.github_url} onChange={e => setForm(f => ({ ...f, github_url: e.target.value }))} placeholder="https://github.com/..." />
                </div>
                <div className="space-y-1.5">
                  <Label>Instagram URL</Label>
                  <Input value={form.instagram_url} onChange={e => setForm(f => ({ ...f, instagram_url: e.target.value }))} placeholder="https://instagram.com/..." />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Display Order</Label>
                <Input type="number" value={form.display_order} onChange={e => setForm(f => ({ ...f, display_order: Number(e.target.value) }))} />
              </div>
              <div className="flex items-center justify-between">
                <Label>Active</Label>
                <Switch checked={form.is_active} onCheckedChange={v => setForm(f => ({ ...f, is_active: v }))} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setFormOpen(false)}>Cancel</Button>
              <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                {editTarget ? 'Save Changes' : 'Add Member'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={confirmDelete}
          title="Delete Team Member" description={`Are you sure you want to delete ${deleteTarget?.name}?`}
          confirmText={deleting ? 'Deleting...' : 'Delete'} variant="destructive" />
      </motion.div>
    </DashboardLayout>
  );
}
