import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Award, Eye, Loader2, Users, CheckCircle,
  Ban, FileText, Image as ImageIcon, Search, AlertCircle,
} from 'lucide-react';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { PageHeader } from '@/components/dashboard/shared';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  getCertificatesByEvent, generateCertificate, bulkGenerateCertificates,
  revokeCertificate, getEligibleAttendees, downloadCertificateAsPDF,
  downloadCertificateAsPNG, type EligibleAttendee,
} from '@/services/certificates';
import type { Certificate } from '@/types/certificates';
import type { Event } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';

export default function CertificatesManagementPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<string>('');
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [attendees, setAttendees] = useState<EligibleAttendee[]>([]);
  const [loadingAttendees, setLoadingAttendees] = useState(false);
  const [generating, setGenerating] = useState<string | null>(null);
  const [bulkGenerating, setBulkGenerating] = useState(false);
  const [viewCert, setViewCert] = useState<Certificate | null>(null);
  const [revokeCert, setRevokeCert] = useState<Certificate | null>(null);
  const [revokeReason, setRevokeReason] = useState('');
  const [revoking, setRevoking] = useState(false);
  const [downloading, setDownloading] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  useEffect(() => { loadEvents(); }, []);

  const loadEvents = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .order('start_date', { ascending: false });
      if (error) throw error;
      setEvents((data || []) as Event[]);
    } catch {
      toast({ title: 'Error', description: 'Failed to load events', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const loadEventData = async (eventId: string) => {
    if (!eventId) {
      setCertificates([]);
      setAttendees([]);
      return;
    }
    try {
      setLoadingAttendees(true);
      const [certs, eligible] = await Promise.all([
        getCertificatesByEvent(eventId),
        getEligibleAttendees(eventId),
      ]);
      setCertificates(certs);
      setAttendees(eligible);
    } catch {
      toast({ title: 'Error', description: 'Failed to load certificate data', variant: 'destructive' });
    } finally {
      setLoadingAttendees(false);
    }
  };

  const handleEventChange = (eventId: string) => {
    setSelectedEventId(eventId);
    loadEventData(eventId);
  };

  const handleGenerate = async (attendee: EligibleAttendee) => {
    if (!user || !selectedEventId) return;
    const event = events.find((e) => e.id === selectedEventId);
    if (!event) return;

    setGenerating(attendee.registration_id);
    try {
      await generateCertificate(
        attendee.registration_id,
        attendee.user_id,
        attendee.user_name,
        attendee.user_email,
        selectedEventId,
        event.title,
        event.start_date,
        user.id
      );
      toast({ title: 'Certificate generated', description: `Certificate for ${attendee.user_name} has been issued` });
      await loadEventData(selectedEventId);
    } catch (err: any) {
      toast({ title: 'Generation failed', description: err.message, variant: 'destructive' });
    } finally {
      setGenerating(null);
    }
  };

  const handleBulkGenerate = async () => {
    if (!user || !selectedEventId) return;
    setBulkGenerating(true);
    try {
      const result = await bulkGenerateCertificates(selectedEventId, attendees, user.id);
      toast({
        title: 'Bulk generation complete',
        description: `${result.success} certificate(s) generated${result.failed > 0 ? `, ${result.failed} failed` : ''}`,
        variant: result.failed > 0 ? 'default' : 'default',
      });
      await loadEventData(selectedEventId);
    } catch (err: any) {
      toast({ title: 'Bulk generation failed', description: err.message, variant: 'destructive' });
    } finally {
      setBulkGenerating(false);
    }
  };

  const handleDownload = async (cert: Certificate, format: 'pdf' | 'png') => {
    if (!cert.generated_certificate_url) {
      toast({ title: 'No preview', description: 'Certificate image not available', variant: 'destructive' });
      return;
    }
    setDownloading(cert.id);
    try {
      const fileName = `certificate_${cert.certificate_number}`;
      if (format === 'pdf') {
        await downloadCertificateAsPDF(cert.generated_certificate_url, fileName);
      } else {
        await downloadCertificateAsPNG(cert.generated_certificate_url, fileName);
      }
      toast({ title: 'Downloaded', description: `Certificate downloaded as ${format.toUpperCase()}` });
    } catch (err: any) {
      toast({ title: 'Download failed', description: err.message, variant: 'destructive' });
    } finally {
      setDownloading(null);
    }
  };

  const handleRevoke = async () => {
    if (!revokeCert || !user) return;
    if (!revokeReason.trim()) {
      toast({ title: 'Reason required', description: 'Please provide a revoke reason', variant: 'destructive' });
      return;
    }
    setRevoking(true);
    try {
      await revokeCertificate(revokeCert.id, user.id, revokeReason);
      toast({ title: 'Revoked', description: `Certificate ${revokeCert.certificate_number} has been revoked` });
      setRevokeCert(null);
      setRevokeReason('');
      if (selectedEventId) await loadEventData(selectedEventId);
    } catch (err: any) {
      toast({ title: 'Revoke failed', description: err.message, variant: 'destructive' });
    } finally {
      setRevoking(false);
    }
  };

  const filteredCerts = certificates.filter((c) =>
    c.participant_name.toLowerCase().includes(search.toLowerCase()) ||
    c.certificate_number.toLowerCase().includes(search.toLowerCase())
  );

  const eligibleWithoutCert = attendees.filter((a) => !a.has_certificate);

  if (loading) {
    return (
      <DashboardLayout requiredRole="super_admin">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout requiredRole="super_admin">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <PageHeader
          title="Certificate Management"
          description="Generate, view, download, and revoke certificates for verified attendees"
        />

        {/* Event selector */}
        <Card className="glass-card border-0 shadow-md">
          <CardContent className="pt-6">
            <div className="space-y-1.5">
              <Label>Select Event</Label>
              <Select value={selectedEventId} onValueChange={handleEventChange}>
                <SelectTrigger><SelectValue placeholder="Choose an event to manage certificates" /></SelectTrigger>
                <SelectContent>
                  {events.map((event) => (
                    <SelectItem key={event.id} value={event.id}>{event.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {selectedEventId && (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/15 flex items-center justify-center">
                    <Users className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{attendees.length}</p>
                    <p className="text-xs text-muted-foreground">Eligible Attendees</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-500/15 flex items-center justify-center">
                    <Award className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{certificates.length}</p>
                    <p className="text-xs text-muted-foreground">Certificates Issued</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-500/15 flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-amber-500" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{eligibleWithoutCert.length}</p>
                    <p className="text-xs text-muted-foreground">Pending Generation</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-rose-500/15 flex items-center justify-center">
                    <Ban className="w-5 h-5 text-rose-500" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{certificates.filter((c) => c.certificate_status === 'revoked').length}</p>
                    <p className="text-xs text-muted-foreground">Revoked</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Bulk generate */}
            {eligibleWithoutCert.length > 0 && (
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between flex-wrap gap-4">
                    <div>
                      <h3 className="font-semibold">Bulk Generate Certificates</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {eligibleWithoutCert.length} attendee(s) eligible for certificates
                      </p>
                    </div>
                    <Button onClick={handleBulkGenerate} disabled={bulkGenerating}>
                      {bulkGenerating ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Award className="w-4 h-4 mr-2" />}
                      Generate All Certificates
                    </Button>
                  </div>

                  {loadingAttendees ? (
                    <div className="flex items-center justify-center py-6">
                      <Loader2 className="w-6 h-6 animate-spin text-primary" />
                    </div>
                  ) : (
                    <div className="mt-4 space-y-2">
                      {eligibleWithoutCert.map((attendee) => (
                        <div key={attendee.registration_id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-white/5">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium">
                              {attendee.user_name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-medium text-sm">{attendee.user_name}</p>
                              <p className="text-xs text-muted-foreground">{attendee.user_email}</p>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={generating === attendee.registration_id}
                            onClick={() => handleGenerate(attendee)}
                          >
                            {generating === attendee.registration_id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" />
                            ) : (
                              <Award className="w-3.5 h-3.5 mr-1" />
                            )}
                            Generate
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Certificates list */}
            <Card className="glass-card border-0 shadow-md">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between gap-4 mb-4">
                  <h3 className="font-semibold">Issued Certificates ({certificates.length})</h3>
                  {certificates.length > 0 && (
                    <div className="relative w-64">
                      <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search by name or number..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="pl-8 h-8 text-sm"
                      />
                    </div>
                  )}
                </div>

                {filteredCerts.length === 0 ? (
                  <div className="text-center py-8">
                    <Award className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground">
                      {certificates.length === 0 ? 'No certificates issued yet' : 'No matching certificates'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredCerts.map((cert) => (
                      <div key={cert.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-white/5">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={cn(
                            'w-8 h-8 rounded-full flex items-center justify-center shrink-0',
                            cert.certificate_status === 'issued' ? 'bg-emerald-500/15 text-emerald-500' : 'bg-rose-500/15 text-rose-500'
                          )}>
                            {cert.certificate_status === 'issued' ? <CheckCircle className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                          </div>
                          <div className="min-w-0">
                            <p className="font-medium text-sm truncate">{cert.participant_name}</p>
                            <p className="text-xs text-muted-foreground font-mono">{cert.certificate_number}</p>
                          </div>
                          <Badge variant={cert.certificate_status === 'issued' ? 'default' : 'destructive'} className="text-xs">
                            {cert.certificate_status}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {cert.generated_certificate_url && (
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setViewCert(cert)} title="View">
                              <Eye className="w-4 h-4" />
                            </Button>
                          )}
                          {cert.certificate_status === 'issued' && (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                disabled={downloading === cert.id}
                                onClick={() => handleDownload(cert, 'pdf')}
                                title="Download PDF"
                              >
                                {downloading === cert.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                disabled={downloading === cert.id}
                                onClick={() => handleDownload(cert, 'png')}
                                title="Download PNG"
                              >
                                <ImageIcon className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                onClick={() => setRevokeCert(cert)}
                                title="Revoke"
                              >
                                <Ban className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}

        {!selectedEventId && (
          <div className="text-center py-12">
            <Award className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-medium mb-2">Select an Event</h3>
            <p className="text-muted-foreground">Choose an event to view and manage certificates</p>
          </div>
        )}

        {/* View certificate dialog */}
        <Dialog open={!!viewCert} onOpenChange={(open) => !open && setViewCert(null)}>
          <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Certificate Preview</DialogTitle>
            </DialogHeader>
            {viewCert?.generated_certificate_url && (
              <img src={viewCert.generated_certificate_url} alt="Certificate" className="w-full rounded-lg border" />
            )}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><span className="text-muted-foreground">Student:</span> {viewCert?.participant_name}</div>
              <div><span className="text-muted-foreground">Number:</span> <span className="font-mono">{viewCert?.certificate_number}</span></div>
              <div><span className="text-muted-foreground">Event:</span> {viewCert?.event_name}</div>
              <div><span className="text-muted-foreground">Issue Date:</span> {viewCert?.issue_date}</div>
              <div><span className="text-muted-foreground">Status:</span> {viewCert?.certificate_status}</div>
              <div><span className="text-muted-foreground">QR Code:</span> <span className="font-mono">{viewCert?.qr_code}</span></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => viewCert && handleDownload(viewCert, 'png')} disabled={downloading === viewCert?.id}>
                {downloading === viewCert?.id ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ImageIcon className="w-4 h-4 mr-2" />}
                PNG
              </Button>
              <Button onClick={() => viewCert && handleDownload(viewCert, 'pdf')} disabled={downloading === viewCert?.id}>
                {downloading === viewCert?.id ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <FileText className="w-4 h-4 mr-2" />}
                PDF
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Revoke dialog */}
        <Dialog open={!!revokeCert} onOpenChange={(open) => !open && setRevokeCert(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-destructive" />
                Revoke Certificate
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                You are about to revoke certificate <span className="font-mono font-medium text-foreground">{revokeCert?.certificate_number}</span> for <span className="font-medium text-foreground">{revokeCert?.participant_name}</span>. This action will mark the certificate as invalid and prevent verification.
              </p>
              <div className="space-y-1.5">
                <Label>Revoke Reason</Label>
                <Input value={revokeReason} onChange={(e) => setRevokeReason(e.target.value)} placeholder="e.g., Attendance fraud, Duplicate issue" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setRevokeCert(null); setRevokeReason(''); }}>Cancel</Button>
              <Button variant="destructive" onClick={handleRevoke} disabled={revoking || !revokeReason.trim()}>
                {revoking ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Ban className="w-4 h-4 mr-2" />}
                Revoke Certificate
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </DashboardLayout>
  );
}
