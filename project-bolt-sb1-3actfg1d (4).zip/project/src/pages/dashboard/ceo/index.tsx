import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardLayout from '@/components/dashboard/layout/main-layout';
import { StatCard, ActivityFeed } from '@/components/dashboard/widgets';
import { getPublishedAnnouncements } from '@/services/cms';
import type { Announcement } from '@/services/cms';
import { getUpcomingEvents } from '@/services/events';
import type { Event } from '@/types/events';

export default function CEODashboard() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    getPublishedAnnouncements().then(a => setAnnouncements(a.slice(0, 5))).catch(() => {});
    getUpcomingEvents(5).then(setEvents).catch(() => {});
  }, []);

  return (
    <DashboardLayout requiredRole="ceo">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">CEO Dashboard</h1>
          <p className="text-sm text-muted-foreground">Executive leadership overview</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Upcoming Events" value={events.length} icon="Calendar" color="primary" />
          <StatCard title="Active Announcements" value={announcements.length} icon="Megaphone" color="accent" />
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <div className="glass-card rounded-xl border-0 shadow-lg p-4">
            <h3 className="font-semibold mb-4">Upcoming Events</h3>
            {events.length > 0 ? (
              <div className="space-y-3">
                {events.map(event => (
                  <div key={event.id} className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm font-medium">{event.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </p>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">{event.event_type}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No upcoming events.</p>
            )}
          </div>

          <ActivityFeed title="Recent Announcements" activities={announcements.map(a => ({
            id: a.id,
            title: a.title,
            description: a.description || '',
            time: a.publish_date ? new Date(a.publish_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : new Date(a.created_at).toLocaleDateString(),
            type: a.priority === 'high' ? 'warning' : 'info',
          }))} />
        </div>
      </motion.div>
    </DashboardLayout>
  );
}
