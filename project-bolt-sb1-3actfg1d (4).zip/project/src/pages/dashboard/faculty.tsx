import { DashboardLayout } from '@/components/dashboard/dashboard-layout';

export default function FacultyDashboard() {
  return <DashboardLayout title="Faculty Dashboard" requiredRole="faculty" />;
}
