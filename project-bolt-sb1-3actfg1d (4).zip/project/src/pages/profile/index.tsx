import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import {
  User, Mail, Phone, Calendar, BookOpen, Hash,
  Linkedin, Github, Instagram, Globe, Edit3, Save,
  Camera, Loader2, CheckCircle, Award, Star, Shield,
  ArrowLeft, LayoutDashboard, Clock, Building2,
  AlertCircle, Plus, Trash2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { roleLabels } from '@/types/auth';
import { cn } from '@/lib/utils';
import {
  getMyProfile, updateMyProfile, uploadProfilePhoto,
  getMyRegistrations, getMyAttendance,
} from '@/services/profile';
import type { UserProfile, EventRegistrationSummary, AttendanceRecord } from '@/services/profile';

const DEPARTMENTS = ['Mechanical Engineering', 'Polymer Technology', 'Architecture'];

const TABS = [
  { id: 'overview', label: 'Overview', icon: User },
  { id: 'events', label: 'Events', icon: Calendar },
  { id: 'certificates', label: 'Certificates', icon: Award },
  { id: 'achievements', label: 'Achievements', icon: Star },
  { id: 'settings', label: 'Settings', icon: Edit3 },
];

const BADGES = [
  { id: 'participant', label: 'Participant', icon: User, color: 'text-blue-400', bg: 'bg-blue-500/15 border-blue-500/20', desc: 'Attended at least 1 event', minEvents: 1 },
  { id: 'volunteer', label: 'Volunteer', icon: Shield, color: 'text-emerald-400', bg: 'bg-emerald-500/15 border-emerald-500/20', desc: 'Participated as a volunteer', minEvents: 3 },
  { id: 'executive', label: 'Executive Member', icon: Star, color: 'text-amber-400', bg: 'bg-amber-500/15 border-amber-500/20', desc: 'Executive committee role', minEvents: 0 },
  { id: 'leader', label: 'Innovation Leader', icon: Award, color: 'text-rose-400', bg: 'bg-rose-500/15 border-rose-500/20', desc: 'Led or organized an event', minEvents: 5 },
  { id: 'attendance', label: '100% Attendance', icon: CheckCircle, color: 'text-primary', bg: 'bg-primary/15 border-primary/20', desc: 'Perfect attendance record', minEvents: 3 },
];

function ProfilePhoto({ url, onUpload, uploading }: {
  url: string | null;
  onUpload: (file: File) => void;
  uploading: boolean;
}) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div className="relative group">
      <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full overflow-hidden border-4 border-primary/30 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
        {url ? (
          <img src={url} alt="Profile" className="w-full h-full object-cover" />
        ) : (
          <User className="w-10 h-10 sm:w-14 sm:h-14 text-primary/40" />
        )}
        {uploading && (
          <div className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center">
            <Loader2 className="w-6 h-6 text-white animate-spin" />
          </div>
        )}
      </div>
      <button
        onClick={() => ref.current?.click()}
        disabled={uploading}
        className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <Camera className="w-4 h-4 text-white" />
      </button>
      <input
        ref={ref}
        type="file"
        className="hidden"
        accept="image/jpeg,image/png,image/webp"
        onChange={e => { const f = e.target.files?.[0]; if (f) onUpload(f); }}
      />
    </div>
  );
}

function RoleBadge({ role }: { role: string }) {
  const colors: Record<string, string> = {
    super_admin: 'bg-rose-500/15 text-rose-400 border-rose-500/20',
    admin: 'bg-amber-500/15 text-amber-400 border-amber-500/20',
    faculty: 'bg-blue-500/15 text-blue-400 border-blue-500/20',
    ceo: 'bg-purple-500/15 text-purple-400 border-purple-500/20',
    program_officer: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
    executive: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/20',
    student: 'bg-primary/15 text-primary border-primary/20',
  };
  return (
    <span className={cn('inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border', colors[role] ?? colors.student)}>
      <Shield className="w-3 h-3" />
      {roleLabels[role as keyof typeof roleLabels] ?? role}
    </span>
  );
}

// ─── Tag Input ────────────────────────────────────────────────────────────────
function TagInput({ value, onChange, placeholder }: {
  value: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
}) {
  const [input, setInput] = useState('');
  const add = () => {
    const tag = input.trim();
    if (tag && !value.includes(tag)) onChange([...value, tag]);
    setInput('');
  };
  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        <Input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); add(); } }}
          placeholder={placeholder}
          className="flex-1"
        />
        <Button type="button" size="sm" variant="outline" onClick={add}>
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {value.map(tag => (
            <span key={tag} className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs bg-primary/10 text-primary border border-primary/20">
              {tag}
              <button type="button" onClick={() => onChange(value.filter(t => t !== tag))}>
                <Trash2 className="w-3 h-3 hover:text-destructive" />
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Tab: Overview ────────────────────────────────────────────────────────────
function OverviewTab({ profile }: { profile: UserProfile }) {
  const social = [
    { label: 'LinkedIn', icon: Linkedin, value: profile.linkedin_url },
    { label: 'GitHub', icon: Github, value: profile.github_url },
    { label: 'Instagram', icon: Instagram, value: profile.instagram_url },
    { label: 'Portfolio', icon: Globe, value: profile.portfolio_url },
  ].filter(s => s.value);

  return (
    <div className="grid sm:grid-cols-2 gap-4">
      {/* About */}
      <div className="sm:col-span-2 glass-card rounded-xl p-4">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">About</h3>
        <p className="text-sm text-foreground leading-relaxed">
          {profile.bio || <span className="text-muted-foreground italic">No bio added yet. Edit your profile to add one.</span>}
        </p>
      </div>

      {/* Academic Info */}
      <div className="glass-card rounded-xl p-4 space-y-3">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-1">Academic</h3>
        {[
          { icon: Building2, label: 'Department', value: profile.department },
          { icon: BookOpen, label: 'Semester', value: profile.semester ? `Semester ${profile.semester}` : null },
          { icon: Hash, label: 'Class', value: profile.class_name },
          { icon: Hash, label: 'Register No.', value: profile.register_number },
          { icon: Calendar, label: 'Joined', value: new Date(profile.created_at).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' }) },
        ].map(({ icon: Icon, label, value }) => value ? (
          <div key={label} className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Icon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
              <p className="text-sm font-medium">{value}</p>
            </div>
          </div>
        ) : null)}
      </div>

      {/* Contact Info */}
      <div className="glass-card rounded-xl p-4 space-y-3">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-1">Contact</h3>
        {[
          { icon: Mail, label: 'Email', value: profile.email },
          { icon: Phone, label: 'Phone', value: profile.phone },
        ].map(({ icon: Icon, label, value }) => value ? (
          <div key={label} className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Icon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
              <p className="text-sm font-medium break-all">{value}</p>
            </div>
          </div>
        ) : null)}
        {social.length > 0 && (
          <>
            <div className="h-px bg-white/5 my-1" />
            {social.map(({ label, icon: Icon, value }) => (
              <a key={label} href={value!} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-3 group">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
                  <p className="text-sm font-medium text-primary group-hover:underline truncate max-w-[140px]">{value}</p>
                </div>
              </a>
            ))}
          </>
        )}
      </div>

      {/* Skills */}
      {(profile.skills?.length > 0) && (
        <div className="glass-card rounded-xl p-4">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Skills</h3>
          <div className="flex flex-wrap gap-1.5">
            {profile.skills.map(skill => (
              <span key={skill} className="px-2.5 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20">
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Interests */}
      {(profile.interests?.length > 0) && (
        <div className="glass-card rounded-xl p-4">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Interests</h3>
          <div className="flex flex-wrap gap-1.5">
            {profile.interests.map(item => (
              <span key={item} className="px-2.5 py-1 rounded-full text-xs font-medium bg-accent/10 text-accent border border-accent/20">
                {item}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Tab: Events ──────────────────────────────────────────────────────────────
function EventsTab({ registrations, attendance }: {
  registrations: EventRegistrationSummary[];
  attendance: AttendanceRecord[];
}) {
  const [sub, setSub] = useState<'registered' | 'attended'>('registered');

  return (
    <div className="space-y-4">
      <div className="flex gap-2 p-1 rounded-xl bg-muted/30 w-fit">
        {(['registered', 'attended'] as const).map(t => (
          <button key={t} onClick={() => setSub(t)}
            className={cn('px-4 py-1.5 rounded-lg text-sm font-medium transition-all',
              sub === t ? 'bg-primary text-white shadow-sm' : 'text-muted-foreground hover:text-foreground')}>
            {t === 'registered' ? `Registered (${registrations.length})` : `Attended (${attendance.length})`}
          </button>
        ))}
      </div>

      {sub === 'registered' && (
        <div className="space-y-3">
          {registrations.length === 0 ? (
            <EmptyState icon={Calendar} title="No registrations yet" desc="Register for events to see them here." />
          ) : registrations.map(reg => (
            <Link key={reg.id} to={`/events/${reg.event_id}`}>
              <div className="glass-card rounded-xl p-4 flex items-center gap-4 hover:border-primary/30 transition-all">
                <div className="w-12 h-12 rounded-lg overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 shrink-0">
                  {(reg.event.banner_image_url || reg.event.banner_url) ? (
                    <img src={reg.event.banner_image_url || reg.event.banner_url!} alt="" className="w-full h-full object-cover" />
                  ) : <Calendar className="w-6 h-6 text-primary m-3" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{reg.event.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(reg.event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    {reg.event.venue ? ` · ${reg.event.venue}` : ''}
                  </p>
                </div>
                <span className={cn('shrink-0 text-xs px-2 py-0.5 rounded-full border',
                  reg.approval_status === 'approved' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20' :
                  reg.approval_status === 'pending' ? 'bg-amber-500/15 text-amber-400 border-amber-500/20' :
                  reg.approval_status === 'rejected' ? 'bg-rose-500/15 text-rose-400 border-rose-500/20' :
                  'bg-muted/60 text-muted-foreground border-muted')}>
                  {reg.approval_status}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}

      {sub === 'attended' && (
        <div className="space-y-3">
          {attendance.length === 0 ? (
            <EmptyState icon={Clock} title="No attendance records" desc="Attend events by scanning the QR code at the venue." />
          ) : attendance.map(rec => (
            <div key={rec.id} className="glass-card rounded-xl p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{rec.event.title}</p>
                <p className="text-xs text-muted-foreground">
                  Checked in: {new Date(rec.scanned_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Tab: Certificates ────────────────────────────────────────────────────────
function CertificatesTab() {
  return (
    <EmptyState
      icon={Award}
      title="No certificates yet"
      desc="Complete events and earn certificates. They will appear here once issued by the admin."
    />
  );
}

// ─── Tab: Achievements ────────────────────────────────────────────────────────
function AchievementsTab({ attendance, role }: { attendance: AttendanceRecord[]; role: string }) {
  const count = attendance.length;
  const isExecutive = ['executive', 'ceo', 'program_officer', 'admin', 'super_admin'].includes(role);

  const earned = BADGES.filter(b => {
    if (b.id === 'executive') return isExecutive;
    if (b.id === 'attendance') return count >= 3;
    if (b.id === 'leader') return count >= 5;
    if (b.id === 'volunteer') return count >= 3;
    if (b.id === 'participant') return count >= 1;
    return false;
  });

  return (
    <div className="space-y-4">
      <div className="glass-card rounded-xl p-4">
        <p className="text-sm text-muted-foreground">
          Earn badges by participating in events, volunteering, and being active in InnoTex.
          You have earned <span className="text-primary font-semibold">{earned.length}</span> of {BADGES.length} badges.
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {BADGES.map(badge => {
          const isEarned = earned.some(e => e.id === badge.id);
          const Icon = badge.icon;
          return (
            <div key={badge.id} className={cn('glass-card rounded-xl p-4 flex items-center gap-4 border transition-all',
              isEarned ? 'border-primary/30' : 'opacity-50')}>
              <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center border', badge.bg)}>
                <Icon className={cn('w-6 h-6', badge.color)} />
              </div>
              <div>
                <p className={cn('text-sm font-semibold', isEarned ? badge.color : 'text-muted-foreground')}>{badge.label}</p>
                <p className="text-xs text-muted-foreground">{badge.desc}</p>
                {isEarned && <p className="text-[10px] text-emerald-400 mt-0.5 font-medium">Earned</p>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Tab: Settings ────────────────────────────────────────────────────────────
function SettingsTab({ profile, onSaved }: { profile: UserProfile; onSaved: (p: UserProfile) => void }) {
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: profile.name,
    phone: profile.phone ?? '',
    bio: profile.bio ?? '',
    department: profile.department ?? '',
    linkedin_url: profile.linkedin_url ?? '',
    github_url: profile.github_url ?? '',
    instagram_url: profile.instagram_url ?? '',
    portfolio_url: profile.portfolio_url ?? '',
    skills: profile.skills ?? [],
    interests: profile.interests ?? [],
  });
  const [saving, setSaving] = useState(false);

  const set = (k: string, v: string | string[]) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await updateMyProfile({
        name: form.name.trim(),
        phone: form.phone.trim() || undefined,
        bio: form.bio.trim() || undefined,
        department: form.department || undefined,
        linkedin_url: form.linkedin_url.trim() || undefined,
        github_url: form.github_url.trim() || undefined,
        instagram_url: form.instagram_url.trim() || undefined,
        portfolio_url: form.portfolio_url.trim() || undefined,
        skills: form.skills,
        interests: form.interests,
      });
      onSaved(updated);
      toast({ title: 'Profile updated', description: 'Your changes have been saved.' });
    } catch {
      toast({ title: 'Error', description: 'Failed to save. Please try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-5">
      {/* Read-only notice */}
      <div className="flex items-start gap-3 p-3 rounded-xl bg-muted/30 border border-white/5">
        <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">
          Email, role, and approval status are managed by administrators and cannot be changed here.
        </p>
      </div>

      {/* Read-only fields */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Email (read-only)</Label>
          <Input value={profile.email} disabled className="opacity-60" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Role (read-only)</Label>
          <Input value={roleLabels[profile.role as keyof typeof roleLabels] ?? profile.role} disabled className="opacity-60" />
        </div>
      </div>

      <div className="h-px bg-white/5" />

      {/* Editable fields */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label>Full Name</Label>
          <Input value={form.name} onChange={e => set('name', e.target.value)} required />
        </div>
        <div className="space-y-1.5">
          <Label>Phone Number</Label>
          <Input value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+91 00000 00000" />
        </div>
      </div>

      <div className="space-y-1.5">
        <Label>Department</Label>
        <Select value={form.department} onValueChange={v => set('department', v)}>
          <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
          <SelectContent>
            {DEPARTMENTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label>Bio</Label>
        <Textarea
          value={form.bio}
          onChange={e => set('bio', e.target.value)}
          placeholder="Tell us about yourself..."
          rows={3}
        />
      </div>

      <div className="h-px bg-white/5" />
      <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wide">Social Links</p>

      <div className="grid sm:grid-cols-2 gap-4">
        {[
          { key: 'linkedin_url', label: 'LinkedIn URL', icon: Linkedin, ph: 'https://linkedin.com/in/...' },
          { key: 'github_url', label: 'GitHub URL', icon: Github, ph: 'https://github.com/...' },
          { key: 'instagram_url', label: 'Instagram URL', icon: Instagram, ph: 'https://instagram.com/...' },
          { key: 'portfolio_url', label: 'Portfolio URL', icon: Globe, ph: 'https://yoursite.com' },
        ].map(({ key, label, ph }) => (
          <div key={key} className="space-y-1.5">
            <Label>{label}</Label>
            <Input
              type="url"
              value={form[key as keyof typeof form] as string}
              onChange={e => set(key, e.target.value)}
              placeholder={ph}
            />
          </div>
        ))}
      </div>

      <div className="h-px bg-white/5" />

      <div className="space-y-1.5">
        <Label>Skills</Label>
        <TagInput value={form.skills} onChange={v => set('skills', v)} placeholder="Add a skill and press Enter" />
      </div>

      <div className="space-y-1.5">
        <Label>Interests</Label>
        <TagInput value={form.interests} onChange={v => set('interests', v)} placeholder="Add an interest and press Enter" />
      </div>

      <Button type="submit" disabled={saving} className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90">
        {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : <><Save className="w-4 h-4 mr-2" />Save Changes</>}
      </Button>
    </form>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────
function EmptyState({ icon: Icon, title, desc }: { icon: React.ElementType; title: string; desc: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
      <div className="w-16 h-16 rounded-2xl bg-muted/30 flex items-center justify-center">
        <Icon className="w-8 h-8 text-muted-foreground/50" />
      </div>
      <p className="font-semibold text-muted-foreground">{title}</p>
      <p className="text-sm text-muted-foreground/70 max-w-xs">{desc}</p>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function ProfilePage() {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [registrations, setRegistrations] = useState<EventRegistrationSummary[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (!isAuthenticated) { navigate('/login'); return; }
    (async () => {
      try {
        const [p, r, a] = await Promise.all([getMyProfile(), getMyRegistrations(), getMyAttendance()]);
        setProfile(p);
        setRegistrations(r);
        setAttendance(a);
      } catch {
        toast({ title: 'Error', description: 'Failed to load profile.', variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    })();
  }, [isAuthenticated, navigate, toast]);

  const handlePhotoUpload = async (file: File) => {
    if (!profile) return;
    setUploading(true);
    try {
      const url = await uploadProfilePhoto(file);
      const updated = await updateMyProfile({ profile_photo_url: url });
      setProfile(updated);
      toast({ title: 'Photo updated', description: 'Profile photo saved successfully.' });
    } catch {
      toast({ title: 'Upload failed', description: 'Could not upload photo. Try a smaller file.', variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 px-4">
        <AlertCircle className="w-12 h-12 text-muted-foreground" />
        <p className="text-muted-foreground text-center">Profile not found. Please contact an administrator.</p>
        <Link to="/"><Button variant="outline"><ArrowLeft className="w-4 h-4 mr-2" />Back to Home</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Ambient background */}
      <div className="fixed inset-0 -z-10 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-accent/5 rounded-full blur-[100px]" />
      </div>

      {/* Top Bar */}
      <div className="sticky top-0 z-40 glass border-b border-white/5">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center gap-3">
          <Link to="/">
            <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Home</span>
            </Button>
          </Link>
          <span className="text-sm font-semibold flex-1">My Profile</span>
          <Link to={user ? `/${user.role.replace('_', '-')}/dashboard` : '/login'}>
            <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
              <LayoutDashboard className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </Button>
          </Link>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-6 pb-24">
        {/* Profile Header Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-2xl p-6">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
            <ProfilePhoto url={profile.profile_photo_url} onUpload={handlePhotoUpload} uploading={uploading} />
            <div className="flex-1 text-center sm:text-left space-y-2 min-w-0">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 flex-wrap justify-center sm:justify-start">
                <h1 className="text-xl sm:text-2xl font-bold">{profile.name}</h1>
                <RoleBadge role={profile.role} />
              </div>
              {profile.department && (
                <p className="text-sm text-muted-foreground flex items-center gap-1.5 justify-center sm:justify-start">
                  <Building2 className="w-3.5 h-3.5" /> {profile.department}
                </p>
              )}
              <p className="text-sm text-muted-foreground flex items-center gap-1.5 justify-center sm:justify-start">
                <Mail className="w-3.5 h-3.5" /> {profile.email}
              </p>
              {profile.register_number && (
                <p className="text-sm text-muted-foreground flex items-center gap-1.5 justify-center sm:justify-start">
                  <Hash className="w-3.5 h-3.5" /> {profile.register_number}
                </p>
              )}
              <p className="text-xs text-muted-foreground/60 flex items-center gap-1.5 justify-center sm:justify-start">
                <Calendar className="w-3 h-3" />
                Joined {new Date(profile.created_at).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
              </p>
            </div>
            {/* Stats row */}
            <div className="flex sm:flex-col gap-4 sm:gap-2 shrink-0 text-center">
              <div>
                <p className="text-xl font-bold text-primary">{registrations.length}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Registered</p>
              </div>
              <div>
                <p className="text-xl font-bold text-accent">{attendance.length}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Attended</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-muted/20 border border-white/5 overflow-x-auto scrollbar-hide">
          {TABS.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-all flex-1 justify-center',
                  activeTab === tab.id
                    ? 'bg-primary text-white shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === 'overview' && <OverviewTab profile={profile} />}
            {activeTab === 'events' && <EventsTab registrations={registrations} attendance={attendance} />}
            {activeTab === 'certificates' && <CertificatesTab />}
            {activeTab === 'achievements' && <AchievementsTab attendance={attendance} role={profile.role} />}
            {activeTab === 'settings' && <SettingsTab profile={profile} onSaved={setProfile} />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
