import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Award, CheckCircle, XCircle, Loader2, ArrowLeft, Calendar, User,
  ShieldCheck, AlertTriangle, Download, ExternalLink,
} from 'lucide-react';
import { verifyCertificate, downloadCertificateAsPDF, downloadCertificateAsPNG } from '@/services/certificates';
import type { Certificate } from '@/types/certificates';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

type VerifyState = 'loading' | 'valid' | 'revoked' | 'not_found';

export default function CertificateVerifyPage() {
  const { certificateNumber } = useParams<{ certificateNumber: string }>();
  const [state, setState] = useState<VerifyState>('loading');
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (!certificateNumber) {
      setState('not_found');
      return;
    }
    verifyCertificate(certificateNumber)
      .then(({ valid, certificate: cert }) => {
        setCertificate(cert);
        if (!cert) setState('not_found');
        else if (valid) setState('valid');
        else setState('revoked');
      })
      .catch(() => setState('not_found'));
  }, [certificateNumber]);

  const handleDownload = async (format: 'pdf' | 'png') => {
    if (!certificate?.generated_certificate_url) return;
    setDownloading(true);
    try {
      const fileName = `certificate_${certificate.certificate_number}`;
      if (format === 'pdf') await downloadCertificateAsPDF(certificate.generated_certificate_url, fileName);
      else await downloadCertificateAsPNG(certificate.generated_certificate_url, fileName);
    } catch {
      // ignore download errors on public page
    } finally {
      setDownloading(false);
    }
  };

  if (state === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto" />
          <p className="mt-4 text-muted-foreground">Verifying certificate...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          {/* Status banner */}
          <Card className={`border-2 shadow-lg ${state === 'valid' ? 'border-emerald-500/30 bg-emerald-500/5' : state === 'revoked' ? 'border-rose-500/30 bg-rose-500/5' : 'border-amber-500/30 bg-amber-500/5'}`}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className={`w-14 h-14 rounded-full flex items-center justify-center shrink-0 ${state === 'valid' ? 'bg-emerald-500/15' : state === 'revoked' ? 'bg-rose-500/15' : 'bg-amber-500/15'}`}>
                  {state === 'valid' ? (
                    <CheckCircle className="w-8 h-8 text-emerald-500" />
                  ) : state === 'revoked' ? (
                    <XCircle className="w-8 h-8 text-rose-500" />
                  ) : (
                    <AlertTriangle className="w-8 h-8 text-amber-500" />
                  )}
                </div>
                <div>
                  <h1 className="text-2xl font-bold">
                    {state === 'valid' && 'Certificate Verified'}
                    {state === 'revoked' && 'Certificate Revoked'}
                    {state === 'not_found' && 'Certificate Not Found'}
                  </h1>
                  <p className="text-sm text-muted-foreground mt-1">
                    {state === 'valid' && 'This certificate is authentic and currently valid.'}
                    {state === 'revoked' && 'This certificate has been revoked and is no longer valid.'}
                    {state === 'not_found' && `No certificate found with number "${certificateNumber}".`}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Certificate details */}
          {certificate && (
            <>
              <Card className="shadow-lg">
                <CardContent className="pt-6 space-y-4">
                  <div className="flex items-center gap-2 pb-4 border-b">
                    <Award className="w-5 h-5 text-primary" />
                    <h2 className="font-semibold text-lg">Certificate Details</h2>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5" /> Student Name
                      </p>
                      <p className="font-medium">{certificate.participant_name}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Award className="w-3.5 h-3.5" /> Certificate Number
                      </p>
                      <p className="font-mono font-medium">{certificate.certificate_number}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" /> Event Name
                      </p>
                      <p className="font-medium">{certificate.event_name}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" /> Event Date
                      </p>
                      <p className="font-medium">{certificate.event_date}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" /> Issue Date
                      </p>
                      <p className="font-medium">{certificate.issue_date}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5" /> Verification Status
                      </p>
                      <p className={`font-medium ${state === 'valid' ? 'text-emerald-500' : 'text-rose-500'}`}>
                        {state === 'valid' ? 'Valid & Verified' : 'Revoked'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Certificate preview */}
              {certificate.generated_certificate_url && state === 'valid' && (
                <Card className="shadow-lg overflow-hidden">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="font-semibold">Certificate Preview</h2>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" disabled={downloading} onClick={() => handleDownload('png')}>
                          {downloading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                          <span className="ml-1">PNG</span>
                        </Button>
                        <Button size="sm" disabled={downloading} onClick={() => handleDownload('pdf')}>
                          {downloading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                          <span className="ml-1">PDF</span>
                        </Button>
                      </div>
                    </div>
                    <img src={certificate.generated_certificate_url} alt="Certificate" className="w-full rounded-lg border" />
                  </CardContent>
                </Card>
              )}

              {/* QR verification info */}
              <div className="text-center text-sm text-muted-foreground">
                <ShieldCheck className="w-4 h-4 inline mr-1" />
                Verified via QR code scan. This certificate can be authenticated at any time.
              </div>
            </>
          )}

          {/* Not found guidance */}
          {state === 'not_found' && (
            <Card className="shadow-lg">
              <CardContent className="pt-6 text-center py-8">
                <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Invalid Certificate Number</h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  The certificate number you entered does not exist in our system.
                  Please check the number and try again, or contact support if you believe this is an error.
                </p>
                <Button asChild className="mt-4">
                  <Link to="/"><ExternalLink className="w-4 h-4 mr-2" /> Visit Portal</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </motion.div>
      </div>
    </div>
  );
}
