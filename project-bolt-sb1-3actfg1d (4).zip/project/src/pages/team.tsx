import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Crown, UserCircle, Briefcase, Mail, Phone, Linkedin, Github, Instagram, Sparkles, Users, GraduationCap, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getTeamMembers } from '@/services/cms';
import type { TeamMember } from '@/services/cms';
import { cn } from '@/lib/utils';

const fadeInUp = {
  initial: { opacity: 0, y: 20, scale: 0.95 },
  animate: { opacity: 1, y: 0, scale: 1 },
  exit: { opacity: 0, y: 20, scale: 0.95 },
  transition: { duration: 0.4 },
};

const staggerContainer = {
  animate: { transition: { staggerChildren: 0.06 } },
};

// Premium Team Card Component
function TeamCard({ member, variant = 'default' }: { member: TeamMember; variant?: 'featured' | 'default' | 'compact' }) {
  const isFeatured = variant === 'featured';
  const isCompact = variant === 'compact';

  const socialLinks = [
    { url: member.linkedin_url, icon: Linkedin, label: 'LinkedIn', color: 'hover:text-[#0A66C2]' },
    { url: member.github_url, icon: Github, label: 'GitHub', color: 'hover:text-foreground' },
    { url: member.instagram_url, icon: Instagram, label: 'Instagram', color: 'hover:text-[#E4405F]' },
  ].filter((l) => l.url);

  return (
    <motion.div
      variants={fadeInUp}
      whileHover={{ y: -5 }}
      className="group h-full"
    >
      <div
        className={cn(
          'relative overflow-hidden rounded-2xl h-full',
          'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
          'border border-white/5 backdrop-blur-xl',
          'transition-all duration-500',
          'hover:border-white/10 hover:shadow-xl hover:shadow-black/20',
          isFeatured && 'p-1'
        )}
      >
        {/* Featured gradient border */}
        {isFeatured && (
          <div
            className="absolute inset-0 rounded-2xl opacity-50"
            style={{
              background: 'linear-gradient(135deg, hsl(246 65% 59%), hsl(263 70% 56%), hsl(187 94% 43%))',
              padding: '1px',
            }}
          />
        )}

        <div className={cn('relative', isFeatured ? 'p-6' : isCompact ? 'p-4' : 'p-5')}>
          {/* Avatar */}
          <div className="relative mx-auto mb-4">
            <div
              className={cn(
                'relative rounded-full overflow-hidden mx-auto',
                'ring-4 ring-primary/10 group-hover:ring-primary/20 transition-all',
                isFeatured ? 'w-28 h-28' : isCompact ? 'w-16 h-16' : 'w-20 h-20'
              )}
            >
              {/* Gradient background */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-secondary/20 to-accent/30" />

              {member.photo_url ? (
                <img
                  src={member.photo_url}
                  alt={member.name}
                  className="w-full h-full object-cover relative z-10"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center relative z-10">
                  <UserCircle className={cn('text-white/70', isFeatured ? 'w-12 h-12' : 'w-8 h-8')} />
                </div>
              )}

              {/* Hover glow */}
              <div className="absolute -inset-1 bg-gradient-to-br from-primary to-accent opacity-0 group-hover:opacity-30 blur-lg transition-opacity duration-500 rounded-full" />
            </div>

            {/* Status indicator for leadership */}
            {isFeatured && (
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-gradient-to-r from-primary to-accent text-[10px] text-white font-medium shadow-glow-sm">
                {member.category?.toUpperCase()}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="text-center">
            <h3
              className={cn(
                'font-semibold font-heading group-hover:text-primary transition-colors line-clamp-1',
                isFeatured ? 'text-xl' : 'text-base'
              )}
            >
              {member.name}
            </h3>

            <p
              className={cn(
                'font-medium mt-1',
                isFeatured ? 'text-sm text-primary' : 'text-xs text-primary'
              )}
            >
              {member.position}
            </p>

            {member.department && (
              <p className="text-xs text-muted-foreground mt-1">{member.department}</p>
            )}

            {member.bio && !isCompact && (
              <p className="text-xs text-muted-foreground mt-2 line-clamp-2 leading-relaxed">
                {member.bio}
              </p>
            )}

            {/* Social Links */}
            <div className="flex items-center justify-center gap-1.5 mt-3">
              {member.email && (
                <a
                  href={`mailto:${member.email}`}
                  aria-label="Email"
                  className={cn(
                    'w-8 h-8 rounded-lg flex items-center justify-center',
                    'bg-white/5 hover:bg-primary/10',
                    'text-muted-foreground hover:text-primary',
                    'transition-all duration-200'
                  )}
                >
                  <Mail className="w-3.5 h-3.5" />
                </a>
              )}
              {member.phone && (
                <a
                  href={`tel:${member.phone}`}
                  aria-label="Phone"
                  className={cn(
                    'w-8 h-8 rounded-lg flex items-center justify-center',
                    'bg-white/5 hover:bg-accent/10',
                    'text-muted-foreground hover:text-accent',
                    'transition-all duration-200'
                  )}
                >
                  <Phone className="w-3.5 h-3.5" />
                </a>
              )}
              {socialLinks.map((link) => (
                <a
                  key={link.url}
                  href={link.url!}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={link.label}
                  className={cn(
                    'w-8 h-8 rounded-lg flex items-center justify-center',
                    'bg-white/5 hover:bg-white/10',
                    'text-muted-foreground',
                    link.color,
                    'transition-all duration-200'
                  )}
                >
                  <link.icon className="w-3.5 h-3.5" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Top gradient line */}
        <div className="absolute top-0 left-4 right-4 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
      </div>
    </motion.div>
  );
}

// Team Section Component
function TeamSection({
  title,
  subtitle,
  badge,
  members,
  columns = 4,
  featured = false,
}: {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  members: TeamMember[];
  columns?: number;
  featured?: boolean;
}) {
  if (members.length === 0) return null;

  const gridCols = {
    2: 'sm:grid-cols-2',
    3: 'sm:grid-cols-2 lg:grid-cols-3',
    4: 'sm:grid-cols-2 lg:grid-cols-4',
    5: 'sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        {badge}
        <h3 className="text-2xl font-bold font-heading mt-3">{title}</h3>
        {subtitle && <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">{subtitle}</p>}
      </div>

      {/* Grid */}
      <motion.div
        variants={staggerContainer}
        initial="initial"
        animate="animate"
        className={cn('grid gap-4', gridCols[columns as keyof typeof gridCols] || gridCols[4])}
      >
        {members.map((member) => (
          <TeamCard key={member.id} member={member} variant={featured ? 'featured' : 'default'} />
        ))}
      </motion.div>
    </div>
  );
}

export default function Team() {
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('leadership');

  useEffect(() => {
    getTeamMembers()
      .then((data) => setMembers(data.filter((m) => m.is_active)))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  // Group members by category
  const leadership = members.filter((m) => ['ceo', 'coo', 'cfo', 'cpo'].includes(m.category));
  const executives = members.filter((m) => m.category === 'executive');
  const coreTeam = members.filter((m) => m.category === 'member');
  const coordinators = members.filter((m) => m.category === 'student_coordinator');
  const principal = members.filter((m) => m.category === 'principal');
  const other = members.filter(
    (m) => !['ceo', 'coo', 'cfo', 'cpo', 'executive', 'member', 'principal', 'student_coordinator'].includes(m.category)
  );

  const tabData = [
    { id: 'leadership', label: 'Leadership', icon: Crown, count: leadership.length },
    { id: 'executives', label: 'Executives', icon: Briefcase, count: executives.length },
    { id: 'core', label: 'Core Team', icon: Users, count: coreTeam.length },
    { id: 'coordinators', label: 'Coordinators', icon: GraduationCap, count: coordinators.length },
  ].filter((t) => t.count > 0);

  return (
    <div className="min-h-screen overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-28 pb-12 lg:pt-32 lg:pb-16">
        {/* Background effects */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/15 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/15 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-primary/10 to-accent/10 border border-white/5 mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Innovation Team</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-heading tracking-tight leading-[1.1] mb-6">
              Meet Our <span className="gradient-text">Team</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              The passionate individuals driving innovation and entrepreneurship at InnoTex.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Principal Section (if exists) - Above tabs */}
      {principal.length > 0 && (
        <section className="relative py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              {/* Principal Card - Featured */}
              <div
                className={cn(
                  'relative max-w-md mx-auto rounded-3xl p-8',
                  'bg-gradient-to-br from-primary/10 via-background to-accent/10',
                  'border border-white/5'
                )}
              >
                <div className="absolute top-4 left-4">
                  <Badge className="bg-gradient-to-r from-primary to-accent text-white border-0">
                    <Star className="w-3 h-3 mr-1" /> Patron
                  </Badge>
                </div>

                {principal.map((member) => (
                  <TeamCard key={member.id} member={member} variant="featured" />
                ))}
              </div>
            </motion.div>
          </div>
        </section>
      )}

      {/* Tabbed Content */}
      <section className="relative pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-24">
              <div className="relative">
                <div className="w-16 h-16 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
                <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-primary" />
              </div>
              <p className="text-muted-foreground mt-4">Loading team members...</p>
            </div>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              {/* Tab Navigation */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex justify-center mb-8"
              >
                <TabsList
                  className={cn(
                    'inline-flex gap-1 p-1 rounded-2xl',
                    'bg-background/50 backdrop-blur-xl border border-white/5'
                  )}
                >
                  {tabData.map((tab) => (
                    <TabsTrigger
                      key={tab.id}
                      value={tab.id}
                      className={cn(
                        'relative px-4 py-2.5 rounded-xl transition-all',
                        'data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/20 data-[state=active]:to-accent/20',
                        'data-[state=active]:shadow-lg data-[state=active]:text-primary'
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <tab.icon className="w-4 h-4" />
                        <span className="font-medium">{tab.label}</span>
                        <span className="text-xs px-1.5 py-0.5 rounded-full bg-white/10">
                          {tab.count}
                        </span>
                      </div>
                    </TabsTrigger>
                  ))}
                </TabsList>
              </motion.div>

              {/* Tab Content */}
              <AnimatePresence mode="wait">
                <TabsContent value="leadership" className="mt-0">
                  <motion.div
                    key="leadership"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <TeamSection
                      title="Leadership Team"
                      subtitle="The executive leadership steering InnoTex towards excellence"
                      badge={
                        <Badge className="bg-gradient-to-r from-primary/20 to-secondary/20 text-primary border-0">
                          <Crown className="w-3 h-3 mr-1" /> Leadership
                        </Badge>
                      }
                      members={leadership}
                      columns={Math.min(leadership.length, 4)}
                      featured
                    />
                  </motion.div>
                </TabsContent>

                <TabsContent value="executives" className="mt-0">
                  <motion.div
                    key="executives"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <TeamSection
                      title="Executive Team"
                      subtitle="The dedicated team managing key functional areas"
                      badge={
                        <Badge className="bg-gradient-to-r from-secondary/20 to-accent/20 text-secondary border-0">
                          <Briefcase className="w-3 h-3 mr-1" /> Executive
                        </Badge>
                      }
                      members={executives}
                      columns={4}
                    />
                  </motion.div>
                </TabsContent>

                <TabsContent value="core" className="mt-0">
                  <motion.div
                    key="core"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <TeamSection
                      title="Core Team Members"
                      subtitle="Our team members working across various initiatives"
                      badge={
                        <Badge className="bg-gradient-to-r from-primary/20 to-accent/20 text-primary border-0">
                          <Users className="w-3 h-3 mr-1" /> Core Team
                        </Badge>
                      }
                      members={coreTeam}
                      columns={4}
                    />
                  </motion.div>
                </TabsContent>

                <TabsContent value="coordinators" className="mt-0">
                  <motion.div
                    key="coordinators"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <TeamSection
                      title="Student Coordinators"
                      subtitle="Student leaders coordinating various activities"
                      badge={
                        <Badge className="bg-gradient-to-r from-accent/20 to-success/20 text-accent border-0">
                          <GraduationCap className="w-3 h-3 mr-1" /> Coordinators
                        </Badge>
                      }
                      members={coordinators}
                      columns={3}
                    />
                  </motion.div>
                </TabsContent>
              </AnimatePresence>

              {/* Other Members (non-tabbed, shown below tabs if any) */}
              {other.length > 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="mt-12 pt-8 border-t border-white/5"
                >
                  <TeamSection
                    title="Team Members"
                    members={other}
                    columns={4}
                  />
                </motion.div>
              )}

              {/* Empty State */}
              {members.length === 0 && (
                <div
                  className={cn(
                    'text-center py-24 rounded-2xl',
                    'bg-gradient-to-br from-white/2 to-transparent',
                    'border border-white/5'
                  )}
                >
                  <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4">
                    <UserCircle className="w-10 h-10 text-primary/50" />
                  </div>
                  <h3 className="text-xl font-semibold font-heading">No Team Members</h3>
                  <p className="text-sm text-muted-foreground mt-2">Team information is not available yet.</p>
                </div>
              )}
            </Tabs>
          )}
        </div>
      </section>
    </div>
  );
}
