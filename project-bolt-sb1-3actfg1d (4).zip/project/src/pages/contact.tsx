import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Send, MapPin, Phone, Mail, Clock,
  Instagram, Twitter, Linkedin, Github, ExternalLink, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { getContactInfo, getCollegeInfo } from '@/services/cms';
import type { ContactInfo, CollegeInfo } from '@/services/cms';

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
};

const stagger = {
  animate: { transition: { staggerChildren: 0.1 } },
};

const socialIconMap: Record<string, typeof Instagram> = {
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  github: Github,
  mail: Mail,
};

const socialColorMap: Record<string, string> = {
  instagram: 'hover:bg-pink-500/10 hover:text-pink-500',
  twitter: 'hover:bg-sky-500/10 hover:text-sky-500',
  linkedin: 'hover:bg-blue-500/10 hover:text-blue-500',
  github: 'hover:bg-gray-500/10 hover:text-gray-400',
  mail: 'hover:bg-primary/10 hover:text-primary',
};

export default function Contact() {
  const { toast } = useToast();
  const [contactInfo, setContactInfo] = useState<ContactInfo | null>(null);
  const [collegeInfo, setCollegeInfo] = useState<CollegeInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    Promise.all([getContactInfo(), getCollegeInfo()])
      .then(([ci, col]) => {
        setContactInfo(ci);
        setCollegeInfo(col);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    await new Promise((resolve) => setTimeout(resolve, 1000));

    toast({
      title: 'Message sent!',
      description: 'Thank you for reaching out. We will get back to you soon.',
    });

    setFormData({ name: '', email: '', subject: '', message: '' });
    setIsSubmitting(false);
  };

  const contactCards = contactInfo
    ? [
        { icon: MapPin, title: 'Location', details: [contactInfo.address] },
        { icon: Phone, title: 'Phone', details: [contactInfo.phone] },
        { icon: Mail, title: 'Email', details: [contactInfo.email] },
        { icon: Clock, title: 'Office Hours', details: [contactInfo.office_hours, contactInfo.saturday_hours] },
      ]
    : [];

  const socialLinks = contactInfo
    ? [
        { key: 'instagram', icon: 'instagram', label: 'Instagram', href: contactInfo.instagram_url },
        { key: 'twitter', icon: 'twitter', label: 'Twitter', href: contactInfo.twitter_url },
        { key: 'linkedin', icon: 'linkedin', label: 'LinkedIn', href: contactInfo.linkedin_url },
        { key: 'github', icon: 'github', label: 'GitHub', href: contactInfo.github_url },
        { key: 'mail', icon: 'mail', label: 'Email', href: contactInfo.mail_url },
      ]
    : [];

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent" />
          <div className="absolute top-1/3 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] mb-6">
              Get in <span className="gradient-text">Touch</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Have questions, ideas, or want to collaborate? We would love to hear from you.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Form + Info */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid lg:grid-cols-5 gap-10 lg:gap-16">
              {/* Form */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="lg:col-span-3"
              >
                <Card className="border-0 shadow-lg glass-card">
                  <CardContent className="pt-8 pb-8 px-6 lg:px-8">
                    <h2 className="text-2xl font-bold mb-2">Send us a Message</h2>
                    <p className="text-sm text-muted-foreground mb-8">
                      Fill out the form below and our team will respond within 24 hours.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-5">
                      <div className="grid sm:grid-cols-2 gap-5">
                        <div className="space-y-2">
                          <label htmlFor="name" className="text-sm font-medium">Name</label>
                          <Input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="Your name" required />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="email" className="text-sm font-medium">Email Address</label>
                          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} placeholder="you@email.com" required />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="subject" className="text-sm font-medium">Subject</label>
                        <Input id="subject" name="subject" value={formData.subject} onChange={handleChange} placeholder="What is this regarding?" required />
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="message" className="text-sm font-medium">Message</label>
                        <Textarea id="message" name="message" value={formData.message} onChange={handleChange} placeholder="Tell us more about your inquiry..." rows={5} required />
                      </div>

                      <Button
                        type="submit"
                        size="lg"
                        disabled={isSubmitting}
                        className="gap-2 w-full sm:w-auto bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20"
                      >
                        {isSubmitting ? 'Sending...' : 'Send Message'}
                        <Send className="w-4 h-4" />
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Info */}
              <motion.div
                variants={stagger}
                initial="initial"
                whileInView="animate"
                viewport={{ once: true, margin: '-100px' }}
                className="lg:col-span-2 space-y-5"
              >
                {contactCards.map((info) => (
                  <motion.div key={info.title} variants={fadeInUp}>
                    <Card className="hover:shadow-md transition-all duration-300 hover:border-primary/30 glass-card">
                      <CardContent className="pt-5 pb-5 flex items-start gap-4">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                          <info.icon className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold mb-1">{info.title}</h3>
                          {info.details.map((detail) => (
                            <p key={detail} className="text-sm text-muted-foreground">{detail}</p>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}

                {/* Social Links */}
                <motion.div variants={fadeInUp}>
                  <Card className="glass-card">
                    <CardContent className="pt-5 pb-5">
                      <h3 className="text-sm font-semibold mb-4">Follow Us</h3>
                      <div className="flex items-center gap-3">
                        {socialLinks.map((social) => {
                          const Icon = socialIconMap[social.icon] || Mail;
                          const colorClass = socialColorMap[social.icon] || '';
                          return (
                            <a
                              key={social.key}
                              href={social.href}
                              aria-label={social.label}
                              className={`w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-muted-foreground transition-colors ${colorClass}`}
                            >
                              <Icon className="w-5 h-5" />
                            </a>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </motion.div>
            </div>
          )}
        </div>
      </section>

      {/* Google Maps */}
      {collegeInfo && (
        <section className="py-20 lg:py-28 border-y bg-card/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl lg:text-4xl font-bold tracking-tight">Our Location</h2>
              <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
                Visit us at {collegeInfo.name}.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="overflow-hidden border-0 shadow-lg">
                <div className="relative h-[400px] bg-muted">
                  <iframe
                    src={collegeInfo.map_embed_url}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="College Location Map"
                  />
                </div>
                <CardContent className="pt-5 pb-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                    <div>
                      <p className="text-sm font-medium">{collegeInfo.name}</p>
                      <p className="text-sm text-muted-foreground">{collegeInfo.address}</p>
                    </div>
                  </div>
                  <a href={collegeInfo.map_link} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm" className="gap-2">
                      Open in Maps <ExternalLink className="w-3.5 h-3.5" />
                    </Button>
                  </a>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      )}
    </div>
  );
}
