import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Ticket as TicketIcon,
  Download,
  Printer,
  ArrowLeft,
  AlertTriangle,
  CheckCircle,
  FileDown,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { getTicketByQRCode, type EventTicket, getEventById } from '@/services/events';
import {
  getDefaultTicketTemplate,
  generateQRCodeDataUrl,
} from '@/services/ticket-templates';
import type { Event } from '@/types/events';
import type { TicketTemplate } from '@/types/events';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

// Animated Holographic Border Component
function HolographicBorder({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative p-[2px] rounded-3xl overflow-hidden">
      {/* Animated gradient border */}
      <div
        className="absolute inset-0 rounded-3xl"
        style={{
          background: 'linear-gradient(45deg, hsl(246 65% 59%), hsl(263 70% 56%), hsl(280 70% 60%), hsl(187 94% 43%), hsl(246 65% 59%))',
          backgroundSize: '300% 300%',
          animation: ' holographic 4s ease infinite',
        }}
      />
      {/* Glow reflection */}
      <div
        className="absolute inset-0 rounded-3xl opacity-50 blur-sm"
        style={{
          background: 'linear-gradient(45deg, hsl(246 65% 59%), hsl(263 70% 56%), hsl(280 70% 60%), hsl(187 94% 43%))',
          backgroundSize: '300% 300%',
          animation: 'holographic 4s ease infinite',
        }}
      />
      {/* Content background */}
      <div className="relative bg-background rounded-[22px]">
        {children}
      </div>
    </div>
  );
}

// Floating Particle Effect
function FloatingParticles() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full bg-primary/30"
          initial={{
            x: Math.random() * 100 + '%',
            y: '100%',
            opacity: 0,
          }}
          animate={{
            y: '-100%',
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 3,
            ease: 'linear',
          }}
        />
      ))}
    </div>
  );
}

// Template-based ticket renderer
function TemplateTicketRenderer({
  template,
  ticket,
  event,
  qrDataUrl,
  onRendered,
}: {
  template: TicketTemplate;
  ticket: EventTicket;
  event: Event;
  qrDataUrl: string;
  onRendered: (dataUrl: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !template || !qrDataUrl) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = template.template_width;
    canvas.height = template.template_height;

    const bgImg = new Image();
    bgImg.crossOrigin = 'anonymous';

    bgImg.onload = () => {
      ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

      const config = template.field_config;

      const drawText = (
        text: string,
        fc: {
          x: number;
          y: number;
          width?: number;
          fontSize?: number;
          fontColor?: string;
          fontFamily?: string;
          align?: 'left' | 'center' | 'right';
          dataField?: string;
          customText?: string;
        } | undefined
      ) => {
        if (!fc) return;

        const x = (fc.x / 100) * canvas.width;
        const y = (fc.y / 100) * canvas.height;
        const maxWidth = fc.width ? (fc.width / 100) * canvas.width : canvas.width * 0.8;

        ctx.font = `bold ${fc.fontSize || 14}px ${fc.fontFamily || 'Arial, sans-serif'}`;
        ctx.fillStyle = fc.fontColor || '#000000';
        ctx.textAlign = fc.align || 'center';
        ctx.textBaseline = 'middle';

        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = 3;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;

        ctx.fillText(text, x, y, maxWidth);

        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
      };

      // Draw fields
      if (config.participant_name) drawText(ticket.participant_name, config.participant_name);
      if (config.ticket_id) drawText(ticket.ticket_number, config.ticket_id);
      if (config.event_name) drawText(event.title, config.event_name);
      if (config.event_date) drawText(format(new Date(event.start_date), 'MMMM d, yyyy'), config.event_date);
      if (config.event_time && event.start_time) drawText(event.start_time.slice(0, 5), config.event_time);
      if (config.event_venue && event.venue) drawText(event.venue, config.event_venue);

      // Draw QR code
      if (config.qr_code && qrDataUrl) {
        const qrConfig = config.qr_code;
        const centerX = (qrConfig.x / 100) * canvas.width;
        const centerY = (qrConfig.y / 100) * canvas.height;
        const qrSize = ((qrConfig.size || 18) / 100) * Math.min(canvas.width, canvas.height);

        const qrImg = new Image();
        qrImg.onload = () => {
          // White circular background
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(centerX, centerY, qrSize / 2 + 6, 0, Math.PI * 2);
          ctx.fill();

          // QR code
          ctx.drawImage(qrImg, centerX - qrSize / 2, centerY - qrSize / 2, qrSize, qrSize);

          onRendered(canvas.toDataURL('image/png'));
        };
        qrImg.src = qrDataUrl;
      }
    };
    bgImg.src = template.template_image_url;
  }, [template, ticket, event, qrDataUrl, onRendered]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-auto rounded-xl shadow-2xl"
      style={{ maxWidth: '100%', height: 'auto' }}
    />
  );
}

// Premium Ticket Display
function PremiumTicketDisplay({
  ticket,
  event,
  template,
  qrDataUrl,
}: {
  ticket: EventTicket;
  event: Event;
  template: TicketTemplate | null;
  qrDataUrl: string;
}) {
  const [renderedUrl, setRenderedUrl] = useState<string>('');

  const handleDownload = async (format: 'png' | 'pdf') => {
    if (!renderedUrl) return;

    if (format === 'png') {
      const link = document.createElement('a');
      link.href = renderedUrl;
      link.download = `ticket-${ticket.ticket_number}.png`;
      link.click();
    } else {
      // PDF export
      const { default: jsPDF } = await import('jspdf');
      const pdf = new jsPDF({
        orientation: template?.template_width && template.template_width > template.template_height ? 'landscape' : 'portrait',
        unit: 'px',
        format: [template?.template_width || 800, template?.template_height || 400],
      });

      const img = new Image();
      img.src = renderedUrl;
      img.onload = () => {
        pdf.addImage(img, 'PNG', 0, 0, template?.template_width || 800, template?.template_height || 400);
        pdf.save(`ticket-${ticket.ticket_number}.pdf`);
      };
    }
  };

  return (
    <div className="relative max-w-3xl mx-auto">
      {/* 3D floating effect */}
      <motion.div
        initial={{ y: 20, rotateX: -5 }}
        animate={{ y: 0, rotateX: 0 }}
        transition={{ duration: 0.8, type: 'spring' }}
        className="relative"
        style={{ perspective: '1000px' }}
      >
        <HolographicBorder>
          <div className="relative bg-card rounded-[22px] overflow-hidden">
            {/* Glassmorphism overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-white/5 pointer-events-none" />

            {/* Top decorative glow */}
            <div className="absolute top-0 left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />

            {/* Ticket content */}
            <div className="relative p-8">
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                    <TicketIcon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">E-Ticket</p>
                    <Badge className="bg-success/20 text-success border-success/30 text-xs">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Valid
                    </Badge>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Ticket No.</p>
                  <p className="font-mono font-bold text-lg gradient-text">{ticket.ticket_number}</p>
                </div>
              </div>

              {/* Rendered ticket image */}
              <div className="relative">
                {template ? (
                  <TemplateTicketRenderer
                    template={template}
                    ticket={ticket}
                    event={event}
                    qrDataUrl={qrDataUrl}
                    onRendered={setRenderedUrl}
                  />
                ) : (
                  // Default ticket design
                  <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-primary/20 via-secondary/10 to-accent/20 p-6">
                    <FloatingParticles />

                    <div className="relative grid md:grid-cols-3 gap-6">
                      {/* Left: Info */}
                      <div className="md:col-span-2 space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Participant</p>
                          <h3 className="text-2xl font-bold font-heading gradient-text">{ticket.participant_name}</h3>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Event</p>
                            <p className="font-semibold">{event.title}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Date</p>
                            <p className="font-semibold">{format(new Date(event.start_date), 'MMM d, yyyy')}</p>
                          </div>
                          {event.start_time && (
                            <div>
                              <p className="text-sm text-muted-foreground mb-1">Time</p>
                              <p className="font-semibold">{event.start_time.slice(0, 5)}</p>
                            </div>
                          )}
                          {event.venue && (
                            <div>
                              <p className="text-sm text-muted-foreground mb-1">Venue</p>
                              <p className="font-semibold line-clamp-1">{event.venue}</p>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: QR Code */}
                      <div className="flex flex-col items-center justify-center">
                        <div className="relative">
                          <div className="absolute -inset-2 bg-gradient-to-br from-primary to-accent rounded-2xl opacity-20 blur-lg" />
                          <div className="relative bg-white p-3 rounded-xl shadow-lg">
                            {qrDataUrl && <img src={qrDataUrl} alt="QR Code" className="w-32 h-32" />}
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2 text-center">Scan to verify</p>
                      </div>
                    </div>

                    {/* Footer decorative line */}
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-accent" />
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleDownload('png')}
                  className={cn(
                    'flex items-center gap-2 px-5 py-2.5 rounded-xl',
                    'bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10',
                    'border border-white/10 hover:border-white/20',
                    'text-sm font-medium transition-all'
                  )}
                >
                  <Download className="w-4 h-4 text-primary" />
                  <span>Download PNG</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleDownload('pdf')}
                  className={cn(
                    'flex items-center gap-2 px-5 py-2.5 rounded-xl',
                    'bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10',
                    'border border-white/10 hover:border-white/20',
                    'text-sm font-medium transition-all'
                  )}
                >
                  <FileDown className="w-4 h-4 text-secondary" />
                  <span>Download PDF</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    const printWindow = window.open('', '_blank');
                    if (printWindow && renderedUrl) {
                      printWindow.document.write(`
                        <html>
                          <head><title>Event Ticket</title></head>
                          <body style="margin:0; display:flex; justify-content:center; align-items:center; min-height:100vh;">
                            <img src="${renderedUrl}" style="max-width:100%;" />
                          </body>
                        </html>
                      `);
                      printWindow.document.close();
                      printWindow.print();
                    }
                  }}
                  className={cn(
                    'flex items-center gap-2 px-5 py-2.5 rounded-xl',
                    'bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10',
                    'border border-white/10 hover:border-white/20',
                    'text-sm font-medium transition-all'
                  )}
                >
                  <Printer className="w-4 h-4 text-accent" />
                  <span>Print</span>
                </motion.button>
              </div>
            </div>
          </div>
        </HolographicBorder>
      </motion.div>
    </div>
  );
}

export default function PremiumTicketView() {
  const { registrationId } = useParams<{ registrationId: string }>();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [ticket, setTicket] = useState<EventTicket | null>(null);
  const [event, setEvent] = useState<Event | null>(null);
  const [template, setTemplate] = useState<TicketTemplate | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    async function loadTicketData() {
      if (!registrationId) {
        setError('No ticket ID provided');
        setLoading(false);
        return;
      }

      try {
        // For now, we'll use a simplified version
        // In production, you'd fetch the ticket by registration ID
        const qrData = `TICKET-${registrationId}`;
        const ticketData = await getTicketByQRCode(qrData);

        if (!ticketData) {
          setError('Ticket not found');
          return;
        }

        setTicket(ticketData);

        const eventData = await getEventById(ticketData.event_id);
        if (eventData) {
          setEvent(eventData);
        }

        // Try to get template
        let tmpl = await getDefaultTicketTemplate();
        setTemplate(tmpl);

        // Generate QR code
        const qr = await generateQRCodeDataUrl(qrData);
        setQrDataUrl(qr);
      } catch (err) {
        console.error('Error loading ticket:', err);
        setError('Failed to load ticket');
      } finally {
        setLoading(false);
      }
    }

    loadTicketData();
  }, [registrationId]);

  // Mock data for demo when real data isn't available
  useEffect(() => {
    if (!loading && !ticket && !error) {
      // Create mock ticket for demo
      const mockTicket: EventTicket = {
        id: registrationId || 'demo-ticket',
        ticket_number: `TKT-${Date.now().toString(36).toUpperCase()}`,
        qr_code: `TICKET-${registrationId}`,
        participant_name: 'Demo User',
        participant_email: 'demo@example.com',
        event_id: 'demo-event',
        registration_id: registrationId || 'demo-reg',
        user_id: null,
        qr_code_data: {},
        is_used: false,
        used_at: null,
        created_at: new Date().toISOString(),
        expires_at: null,
      };
      setTicket(mockTicket);

      const mockEvent: Event = {
        id: 'demo-event',
        title: 'Annual Tech Workshop 2026',
        event_type: 'Workshop',
        status: 'upcoming',
        start_date: '2026-06-25',
        end_date: null,
        start_time: '10:00',
        end_time: '17:00',
        venue: 'Main Auditorium',
        max_participants: 100,
        registration_deadline: null,
        organizer_name: 'InnoTex',
        organizer_email: 'contact@innotex.edu',
        is_featured: true,
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        short_description: 'Join us for the annual tech workshop!',
        full_description: null,
        category_id: null,
        poster_url: null,
        banner_url: null,
      };
      setEvent(mockEvent);

      generateQRCodeDataUrl(`TICKET-${registrationId}`).then(setQrDataUrl);
    }
  }, [loading, ticket, error, registrationId]);

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gradient-to-br from-background via-background/95 to-background/90">
        {/* Background effects */}
        <div className="fixed inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="relative pt-24 pb-16 px-4">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-8"
            >
              <button
                onClick={() => navigate(-1)}
                className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-4"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Go Back</span>
              </button>

              <div className="flex items-center justify-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <TicketIcon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold font-heading">Event Ticket</h1>
                  <p className="text-sm text-muted-foreground">Your digital pass to innovation</p>
                </div>
              </div>
            </motion.div>

            {/* Content */}
            {loading ? (
              <div className="flex flex-col items-center justify-center py-24">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
                  <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-primary" />
                </div>
                <p className="text-muted-foreground mt-4">Loading your ticket...</p>
              </div>
            ) : error ? (
              <div
                className={cn(
                  'text-center py-16 rounded-2xl',
                  'bg-gradient-to-br from-destructive/10 to-background',
                  'border border-destructive/20'
                )}
              >
                <AlertTriangle className="w-16 h-16 mx-auto text-destructive mb-4" />
                <h2 className="text-xl font-semibold mb-2">Ticket Not Found</h2>
                <p className="text-muted-foreground mb-6">{error}</p>
                <Button onClick={() => navigate('/events')}>
                  Browse Events
                </Button>
              </div>
            ) : (
              <AnimatePresence mode="wait">
                {ticket && event && (
                  <motion.div
                    key="ticket"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                  >
                    <PremiumTicketDisplay
                      ticket={ticket}
                      event={event}
                      template={template}
                      qrDataUrl={qrDataUrl}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            )}

            {/* Help text */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="text-center mt-8 text-sm text-muted-foreground"
            >
              <p>Present this ticket at the event entrance for verification</p>
              <p className="mt-1">The QR code contains your unique ticket ID for instant check-in</p>
            </motion.div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
