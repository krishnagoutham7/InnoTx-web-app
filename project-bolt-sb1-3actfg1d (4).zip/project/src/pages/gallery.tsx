import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ImageIcon, X, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getGalleryAlbums, getGalleryImages } from '@/services/cms';
import type { GalleryAlbum, GalleryImage } from '@/services/cms';

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
};

const stagger = {
  animate: { transition: { staggerChildren: 0.06 } },
};

export default function Gallery() {
  const [albums, setAlbums] = useState<GalleryAlbum[]>([]);
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeAlbum, setActiveAlbum] = useState<string>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    Promise.all([getGalleryAlbums(), getGalleryImages()])
      .then(([albs, imgs]) => {
        setAlbums(albs);
        setImages(imgs);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const filteredImages = activeAlbum === 'all'
    ? images
    : images.filter(img => img.album_id === activeAlbum);

  const openLightbox = (index: number) => setLightboxIndex(index);
  const closeLightbox = () => setLightboxIndex(null);

  const goNext = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex + 1) % filteredImages.length);
  };

  const goPrev = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex - 1 + filteredImages.length) % filteredImages.length);
  };

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent" />
          <div className="absolute top-1/3 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] mb-6">
              Our <span className="gradient-text">Gallery</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Capturing moments from our journey of innovation and entrepreneurship.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Category Filter + Grid */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex items-center justify-center py-24">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              {/* Filter by album */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="flex flex-wrap items-center justify-center gap-2 mb-12"
              >
                <Button
                  variant={activeAlbum === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveAlbum('all')}
                  className={activeAlbum === 'all' ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90' : ''}
                >
                  All ({images.length})
                </Button>
                {albums.map(album => (
                  <Button
                    key={album.id}
                    variant={activeAlbum === album.id ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setActiveAlbum(album.id)}
                    className={activeAlbum === album.id ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90' : ''}
                  >
                    {album.name} ({album.image_count || 0})
                  </Button>
                ))}
              </motion.div>

              {/* Grid */}
              {filteredImages.length > 0 ? (
                <motion.div
                  variants={stagger}
                  initial="initial"
                  whileInView="animate"
                  viewport={{ once: true }}
                  className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
                >
                  {filteredImages.map((image, index) => (
                    <motion.div
                      key={image.id}
                      variants={fadeInUp}
                      layout
                      className="group aspect-square rounded-xl overflow-hidden cursor-pointer"
                      onClick={() => openLightbox(index)}
                    >
                      <div className="w-full h-full relative bg-gradient-to-br from-muted to-muted/50 border hover:border-primary/30 transition-all duration-300">
                        {image.image_url ? (
                          <img
                            src={image.image_url}
                            alt={image.title || ''}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/5 group-hover:from-primary/10 group-hover:to-accent/10 transition-colors">
                            <ImageIcon className="w-10 h-10 text-muted-foreground/30" />
                          </div>
                        )}
                        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                          <p className="text-xs text-white/80">{image.title || ''}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-16">
                  <ImageIcon className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                  <p className="text-muted-foreground">No images in this album yet.</p>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center"
            onClick={closeLightbox}
          >
            <button
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
              onClick={closeLightbox}
            >
              <X className="w-5 h-5" />
            </button>

            <button
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
              onClick={(e) => { e.stopPropagation(); goPrev(); }}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
              onClick={(e) => { e.stopPropagation(); goNext(); }}
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            <div
              className="max-w-4xl w-full mx-8 aspect-video rounded-xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {filteredImages[lightboxIndex]?.image_url ? (
                <img
                  src={filteredImages[lightboxIndex].image_url!}
                  alt={filteredImages[lightboxIndex].title || ''}
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-muted/20 to-muted/10 flex items-center justify-center">
                  <div className="text-center">
                    <ImageIcon className="w-20 h-20 text-white/20 mx-auto mb-4" />
                    <p className="text-white/60 text-lg">{filteredImages[lightboxIndex]?.title || ''}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/40 text-sm">
              {lightboxIndex + 1} / {filteredImages.length}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
