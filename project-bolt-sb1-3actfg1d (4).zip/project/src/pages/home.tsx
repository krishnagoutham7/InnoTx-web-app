import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Lightbulb, Rocket, Users, Trophy, Calendar, ArrowRight,
  Megaphone, ChevronRight, Sparkles, GraduationCap, Eye,
  Target, ImageIcon, MapPin, Phone, Mail, Crown, UserCircle, Clock
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getUpcomingEvents } from '@/services/events';
import { getHomepageCMS, getCollegeInfo, getContactInfo, getPublishedAnnouncements, getTeamMembers } from '@/services/cms';
import type { HomepageCMS, CollegeInfo, ContactInfo, Announcement, TeamMember } from '@/services/cms';
import type { Event } from '@/types/events';

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
};

const stagger = {
  animate: { transition: { staggerChildren: 0.1 } },
};

const statIcons = [Lightbulb, Rocket, Users, Trophy];
const statColors = ['text-primary', 'text-accent', 'text-amber-500', 'text-rose-500'];

function AnimatedCounter({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting && !started) setStarted(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    const timer = setInterval(() => {
      current += step;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [started, target]);

  return (
    <div ref={ref} className="text-3xl lg:text-4xl font-bold mb-1">
      {count}{suffix}
    </div>
  );
}

function TeamPreviewCard({ member, icon: Icon }: { member: TeamMember; icon: typeof Crown }) {
  return (
    <Card className="group h-full hover:shadow-lg transition-all duration-300 hover:border-primary/30">
      <CardContent className="pt-6 pb-5 text-center">
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-3 group-hover:from-primary/30 group-hover:to-accent/30 transition-colors overflow-hidden">
          {member.photo_url ? (
            <img src={member.photo_url} alt={member.name} className="w-full h-full object-cover" />
          ) : (
            <Icon className="w-6 h-6 text-primary" />
          )}
        </div>
        <h3 className="text-sm font-semibold mb-0.5 group-hover:text-primary transition-colors">{member.name}</h3>
        <p className="text-xs text-primary font-medium">{member.position}</p>
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const [cms, setCms] = useState<HomepageCMS | null>(null);
  const [college, setCollege] = useState<CollegeInfo | null>(null);
  const [contactInfo, setContactInfo] = useState<ContactInfo | null>(null);
  const [liveEvents, setLiveEvents] = useState<Event[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [chiefs, setChiefs] = useState<TeamMember[]>([]);
  const [faculty, setFaculty] = useState<TeamMember[]>([]);
  const [executives, setExecutives] = useState<TeamMember[]>([]);

  useEffect(() => {
    getHomepageCMS().then(d => { if (d) setCms(d); }).catch(() => {});
    getCollegeInfo().then(d => { if (d) setCollege(d); }).catch(() => {});
    getContactInfo().then(d => { if (d) setContactInfo(d); }).catch(() => {});
    getUpcomingEvents(3).then(setLiveEvents).catch(() => {});
    getPublishedAnnouncements().then(a => setAnnouncements(a.slice(0, 4))).catch(() => {});
    getTeamMembers().then(members => {
      const active = members.filter(m => m.is_active);
      setChiefs(active.filter(m => m.category === 'chief'));
      setFaculty(active.filter(m => m.category === 'faculty'));
      setExecutives(active.filter(m => m.category === 'executive').slice(0, 4));
    }).catch(() => {});
  }, []);

  const stats = cms?.stats?.length ? cms.stats : [];

  return (
    <div className="overflow-hidden">
      {/* 1. Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-accent/5 to-transparent" />
          <div className="absolute top-1/4 left-1/6 w-[500px] h-[500px] bg-primary/15 rounded-full blur-[120px] animate-pulse" />
          <div className="absolute bottom-1/4 right-1/6 w-[400px] h-[400px] bg-accent/15 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1.5s' }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-primary/10 rounded-full blur-[80px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="text-center max-w-4xl mx-auto"
          >
            {/* Logos */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="flex items-center justify-center gap-6 mb-8"
            >
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-xl shadow-primary/30">
                <Lightbulb className="w-7 h-7 text-white" />
              </div>
              <div className="w-px h-10 bg-border" />
              <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center border">
                <GraduationCap className="w-7 h-7 text-muted-foreground" />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8"
            >
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">
                {college?.portal_tagline || 'Innovation • Entrepreneurship • Technology • Leadership'}
              </span>
            </motion.div>

            <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.1] mb-6">
              {cms?.hero_headline ? (
                <span className="gradient-text">{cms.hero_headline}</span>
              ) : (
                <>
                  Igniting{' '}
                  <span className="gradient-text">Innovation</span>
                  <br />
                  Shaping the <span className="gradient-text-alt">Future</span>
                </>
              )}
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              {college?.portal_description || cms?.hero_description || ''}
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/about">
                <Button size="lg" className="gap-2 text-base px-8 h-12 bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/25">
                  {cms?.hero_cta_primary_text || 'Explore Innovation'}
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link to="/gallery">
                <Button variant="outline" size="lg" className="gap-2 text-base px-8 h-12">
                  {cms?.hero_cta_secondary_text || 'View Events'}
                </Button>
              </Link>
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="mt-12 flex items-center justify-center gap-3 text-sm text-muted-foreground"
            >
              <GraduationCap className="w-4 h-4 text-primary" />
              <span>{college?.name || ''}</span>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* 2. Statistics Section */}
      {stats.length > 0 && (
        <section className="py-16 lg:py-20 border-y bg-card/50">
          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true, margin: '-100px' }}
            className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
          >
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
              {stats.map((stat, i) => (
                <motion.div key={stat.label} variants={fadeInUp}>
                  <Card className="border-0 shadow-none bg-transparent text-center">
                    <CardContent className="pt-6">
                      <div className={`w-12 h-12 rounded-xl bg-muted flex items-center justify-center mx-auto mb-4 ${statColors[i]}`}>
                        {(() => { const Icon = statIcons[i]; return <Icon className="w-6 h-6" />; })()}
                      </div>
                      <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                      <div className="text-sm text-muted-foreground">{stat.label}</div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>
      )}

      {/* 3. About Preview */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
                <Lightbulb className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-medium text-primary">About {college?.portal_name || 'InnoTex'}</span>
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold tracking-tight mb-6">
                {cms?.about_title || <>Where <span className="gradient-text">Ideas</span> Meet Opportunity</>}
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                {cms?.about_description || college?.portal_description || ''}
              </p>
              <Link to="/about" className="inline-block mt-8">
                <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20">
                  Read More <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="border-0 shadow-lg overflow-hidden">
                <div className="h-64 bg-gradient-to-br from-primary/20 via-accent/10 to-primary/5 flex items-center justify-center">
                  <div className="text-center">
                    <Lightbulb className="w-16 h-16 text-primary/40 mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">
                      {college?.portal_name || 'InnoTex'} at {college?.short_name || ''}
                    </p>
                  </div>
                </div>
                <CardContent className="pt-5 pb-5">
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: 'Innovation', value: 'Core Focus' },
                      { label: 'Entrepreneurship', value: 'Key Driver' },
                      { label: 'Technology', value: 'Enabler' },
                      { label: 'Leadership', value: 'Outcome' },
                    ].map((item) => (
                      <div key={item.label} className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">{item.label}</p>
                        <p className="text-sm font-semibold">{item.value}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 4. Vision Section */}
      {cms?.vision_content && (
        <section className="py-20 lg:py-28 border-y bg-card/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <Card className="border-0 shadow-xl bg-gradient-to-br from-background to-primary/5 overflow-hidden">
                <CardContent className="pt-10 pb-10 px-8 lg:px-12">
                  <div className="flex items-start gap-5">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shrink-0 shadow-lg shadow-primary/20">
                      <Eye className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <h2 className="text-2xl lg:text-3xl font-bold mb-4">{cms.vision_title}</h2>
                      <p className="text-muted-foreground leading-relaxed text-lg">
                        {cms.vision_content}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      )}

      {/* 5. Mission Section */}
      {cms?.mission_content && (
        <section className="py-20 lg:py-28">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <Card className="border-0 shadow-xl bg-gradient-to-br from-background to-accent/5 overflow-hidden">
                <CardContent className="pt-10 pb-10 px-8 lg:px-12">
                  <div className="flex items-start gap-5">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-primary flex items-center justify-center shrink-0 shadow-lg shadow-accent/20">
                      <Target className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <h2 className="text-2xl lg:text-3xl font-bold mb-4">{cms.mission_title}</h2>
                      <p className="text-muted-foreground leading-relaxed text-lg">
                        {cms.mission_content}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      )}

      {/* 6. Upcoming Events Preview */}
      <section className="py-20 lg:py-28 border-y bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <Calendar className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs font-medium text-primary">What's Coming Up</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold tracking-tight">Upcoming Events</h2>
            <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
              Join our events to learn, network, and build the future.
            </p>
          </motion.div>

          {liveEvents.length > 0 ? (
            <motion.div
              variants={stagger}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true, margin: '-100px' }}
              className="grid md:grid-cols-3 gap-6"
            >
              {liveEvents.map((event) => (
                <motion.div key={event.id} variants={fadeInUp}>
                  <Link to={`/events/${event.id}`}>
                    <Card className="group h-full hover:shadow-lg transition-all duration-300 hover:border-primary/30 glass-card">
                      <CardContent className="pt-6 flex flex-col h-full">
                        <div className="flex items-start justify-between mb-4">
                          <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-primary/10 text-primary">
                            {event.event_type}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                          </span>
                        </div>
                        <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                          {event.title}
                        </h3>
                        <p className="text-sm text-muted-foreground flex-1 line-clamp-2">{event.short_description}</p>
                        {(event.start_time || event.venue) && (
                          <div className="mt-3 space-y-1">
                            {event.start_time && (
                              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                                <Clock className="w-3 h-3 text-primary" />
                                {event.start_time.slice(0, 5)}{event.end_time ? ` — ${event.end_time.slice(0, 5)}` : ''}
                              </div>
                            )}
                            {event.venue && (
                              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                                <MapPin className="w-3 h-3 text-primary" />
                                {event.venue}
                              </div>
                            )}
                          </div>
                        )}
                        <div className="mt-5 pt-4 border-t">
                          <Button variant="ghost" size="sm" className="gap-1 text-primary p-0 h-auto hover:bg-transparent">
                            Learn more <ChevronRight className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No upcoming events at the moment. Check back soon!</p>
            </div>
          )}

          <div className="text-center mt-10">
            <Link to="/events">
              <Button variant="outline" className="gap-2">
                All Events <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 7. Announcements Preview */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <Megaphone className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs font-medium text-primary">Stay Updated</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold tracking-tight">Latest Announcements</h2>
            <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
              Important updates and news from the {college?.portal_name || 'InnoTex'} ecosystem.
            </p>
          </motion.div>

          {announcements.length > 0 ? (
            <motion.div
              variants={stagger}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true, margin: '-100px' }}
              className="max-w-3xl mx-auto space-y-3"
            >
              {announcements.map((item) => (
                <motion.div key={item.id} variants={fadeInUp}>
                  <div className="flex items-center gap-4 p-4 rounded-xl glass hover:border-primary/30 hover:shadow-sm transition-all group cursor-pointer">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Megaphone className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h3 className="text-sm font-medium truncate group-hover:text-primary transition-colors">
                          {item.title}
                        </h3>
                        {item.is_pinned && (
                          <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 bg-primary/10 text-primary border-0">
                            PINNED
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {item.publish_date
                          ? new Date(item.publish_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
                          : new Date(item.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </p>
                    </div>
                    {item.category && (
                      <Badge variant="outline" className="shrink-0 text-[10px]">{item.category}</Badge>
                    )}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <div className="text-center py-12">
              <Megaphone className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No announcements at the moment.</p>
            </div>
          )}
        </div>
      </section>

      {/* 8. Team Preview */}
      {(chiefs.length > 0 || faculty.length > 0 || executives.length > 0) && (
        <section className="py-20 lg:py-28 border-y bg-card/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
                <Users className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-medium text-primary">Our People</span>
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold tracking-tight">Team Preview</h2>
              <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
                Meet the passionate individuals driving {college?.portal_name || 'InnoTex'} forward.
              </p>
            </motion.div>

            {/* Chief Members */}
            {chiefs.length > 0 && (
              <div className="mb-10">
                <h3 className="text-lg font-semibold text-center mb-6">Chief Members</h3>
                <motion.div
                  variants={stagger}
                  initial="initial"
                  whileInView="animate"
                  viewport={{ once: true }}
                  className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto"
                >
                  {chiefs.map((member) => (
                    <motion.div key={member.id} variants={fadeInUp}>
                      <TeamPreviewCard member={member} icon={Crown} />
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            )}

            {/* Faculty Coordinators */}
            {faculty.length > 0 && (
              <div className="mb-10">
                <h3 className="text-lg font-semibold text-center mb-6">Faculty Coordinators</h3>
                <motion.div
                  variants={stagger}
                  initial="initial"
                  whileInView="animate"
                  viewport={{ once: true }}
                  className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-3xl mx-auto"
                >
                  {faculty.map((member) => (
                    <motion.div key={member.id} variants={fadeInUp}>
                      <TeamPreviewCard member={member} icon={GraduationCap} />
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            )}

            {/* Executive Members Preview */}
            {executives.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-center mb-6">Executive Members</h3>
                <motion.div
                  variants={stagger}
                  initial="initial"
                  whileInView="animate"
                  viewport={{ once: true }}
                  className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto"
                >
                  {executives.map((member) => (
                    <motion.div key={member.id} variants={fadeInUp}>
                      <TeamPreviewCard member={member} icon={UserCircle} />
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            )}

            <div className="text-center mt-10">
              <Link to="/team">
                <Button variant="outline" className="gap-2">
                  View Full Team <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* 9. Gallery Preview */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <ImageIcon className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs font-medium text-primary">Moments</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold tracking-tight">Gallery</h2>
            <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
              Glimpses from our events, workshops, and campus life.
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <motion.div
                key={i}
                variants={fadeInUp}
                className="group aspect-square rounded-xl bg-gradient-to-br from-muted to-muted/50 border overflow-hidden cursor-pointer hover:border-primary/30 transition-all"
              >
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/5 group-hover:from-primary/10 group-hover:to-accent/10 transition-colors">
                  <ImageIcon className="w-8 h-8 text-muted-foreground/30" />
                </div>
              </motion.div>
            ))}
          </motion.div>

          <div className="text-center mt-10">
            <Link to="/gallery">
              <Button variant="outline" className="gap-2">
                View Full Gallery <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 10. Contact Preview */}
      <section className="py-20 lg:py-28 border-y bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold tracking-tight">Get in Touch</h2>
            <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
              Reach out to us for collaboration, inquiries, or support.
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto"
          >
            {[
              { icon: MapPin, title: 'Address', value: contactInfo?.address || college?.address || '' },
              { icon: Phone, title: 'Phone', value: contactInfo?.phone || college?.phone || '' },
              { icon: Mail, title: 'Email', value: contactInfo?.email || college?.email || '' },
            ].map((item) => (
              <motion.div key={item.title} variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-all duration-300 hover:border-primary/30 text-center">
                  <CardContent className="pt-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <item.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-sm font-semibold mb-2">{item.title}</h3>
                    <p className="text-xs text-muted-foreground">{item.value}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>

          <div className="text-center mt-10">
            <Link to="/contact">
              <Button className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20">
                Contact Us <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative rounded-2xl overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-accent/10 to-primary/5" />
            <div className="relative px-8 py-16 lg:px-16 lg:py-20 text-center">
              <h2 className="text-3xl lg:text-4xl font-bold tracking-tight mb-4">
                Ready to Build Something Great?
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
                Join {college?.portal_name || 'InnoTex'} and be part of Kerala's next generation of innovators and entrepreneurs.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link to="/contact">
                  <Button size="lg" className="gap-2 text-base px-8 h-12 bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/25">
                    Join the Community <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to="/about">
                  <Button variant="outline" size="lg" className="gap-2 text-base px-8 h-12">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
