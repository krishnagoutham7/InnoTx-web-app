import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Calendar, MapPin, Clock, Users, Search,
  Loader2, Tag, ChevronRight, Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { getEvents, getEventCategories } from '@/services/events';
import type { Event, EventCategory, EventStatus } from '@/types/events';
import { eventStatusConfig } from '@/types/events';
import { cn } from '@/lib/utils';

const fadeInUp = { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.4 } };
const stagger = { animate: { transition: { staggerChildren: 0.08 } } };

const typeColors: Record<string, string> = {
  Workshop: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  Hackathon: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
  Seminar: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
  Webinar: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  Competition: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
  'Startup Event': 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20',
  'Innovation Challenge': 'bg-pink-500/10 text-pink-500 border-pink-500/20',
  'Training Program': 'bg-teal-500/10 text-teal-500 border-teal-500/20',
  'Industrial Visit': 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  Other: 'bg-muted text-muted-foreground',
};

function EventCard({ event }: { event: Event }) {
  const statusConf = eventStatusConfig[event.status];
  const typeColor = typeColors[event.event_type] || typeColors.Other;

  return (
    <motion.div variants={fadeInUp}>
      <Link to={`/events/${event.id}`}>
        <Card className="group h-full hover:shadow-xl transition-all duration-300 hover:border-primary/30 overflow-hidden glass-card">
          <div className="aspect-video bg-gradient-to-br from-primary/15 to-accent/15 relative overflow-hidden">
            {event.banner_image_url ? (
              <img
                src={event.banner_image_url}
                alt={event.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <Calendar className="w-14 h-14 text-primary/20" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute top-3 left-3 flex gap-2 flex-wrap">
              <span className={cn('text-[11px] font-medium px-2.5 py-1 rounded-full border bg-white/80 backdrop-blur-sm', typeColor)}>
                {event.event_type}
              </span>
            </div>
            <div className="absolute top-3 right-3">
              <span className={cn('text-[11px] font-medium px-2.5 py-1 rounded-full bg-white/80 backdrop-blur-sm', statusConf.bg, statusConf.color)}>
                {statusConf.label}
              </span>
            </div>
            {event.is_featured && (
              <div className="absolute bottom-3 left-3">
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-primary text-primary-foreground">
                  FEATURED
                </span>
              </div>
            )}
            {event.like_count !== undefined && event.like_count > 0 && (
              <div className="absolute bottom-3 right-3 flex items-center gap-1 text-white text-xs bg-black/40 backdrop-blur-sm px-2 py-1 rounded-full">
                <Heart className="w-3 h-3 fill-red-400 text-red-400" />
                <span>{event.like_count}</span>
              </div>
            )}
          </div>
          <CardContent className="pt-4 pb-5">
            <h3 className="font-semibold text-base mb-2 line-clamp-2 group-hover:text-primary transition-colors leading-snug">
              {event.title}
            </h3>
            <p className="text-xs text-muted-foreground line-clamp-2 mb-4 leading-relaxed">
              {event.short_description}
            </p>
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Calendar className="w-3.5 h-3.5 shrink-0 text-primary" />
                <span>
                  {new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  {event.end_date && event.end_date !== event.start_date &&
                    ` — ${new Date(event.end_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`}
                </span>
              </div>
              {event.start_time && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="w-3.5 h-3.5 shrink-0 text-primary" />
                  <span>{event.start_time.slice(0, 5)}{event.end_time ? ` — ${event.end_time.slice(0, 5)}` : ''}</span>
                </div>
              )}
              {event.venue && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <MapPin className="w-3.5 h-3.5 shrink-0 text-primary" />
                  <span className="truncate">{event.venue}</span>
                </div>
              )}
              {event.max_participants && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Users className="w-3.5 h-3.5 shrink-0 text-primary" />
                  <span>Max {event.max_participants} participants</span>
                </div>
              )}
            </div>
            <div className="mt-4 flex items-center text-xs font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity">
              View Details <ChevronRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}

const STATUS_FILTERS: Array<{ label: string; value: EventStatus | 'all' }> = [
  { label: 'All', value: 'all' },
  { label: 'Published', value: 'published' },
  { label: 'Upcoming', value: 'upcoming' },
  { label: 'Ongoing', value: 'ongoing' },
  { label: 'Completed', value: 'completed' },
];

export default function EventsPage() {
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<Event[]>([]);
  const [categories, setCategories] = useState<EventCategory[]>([]);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeStatus, setActiveStatus] = useState<EventStatus | 'all'>('all');

  useEffect(() => {
    async function load() {
      try {
        const [evts, cats] = await Promise.all([getEvents(), getEventCategories()]);
        setEvents(evts);
        setCategories(cats);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const filtered = events.filter(e => {
    if (activeStatus !== 'all' && e.status !== activeStatus) return false;
    if (activeCategory !== 'all' && e.category?.name !== activeCategory) return false;
    if (search && !e.title.toLowerCase().includes(search.toLowerCase()) &&
        !(e.short_description || '').toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent" />
          <div className="absolute top-1/3 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Calendar className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Events & Activities</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] mb-6">
              Upcoming <span className="gradient-text">Events</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Explore workshops, hackathons, seminars, and more — designed to ignite innovation.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-10 border-y bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-5">
          {/* Search */}
          <div className="relative max-w-lg mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search events..."
              className="pl-11 h-11"
            />
          </div>
          {/* Status filter */}
          <div className="flex flex-wrap justify-center gap-2">
            {STATUS_FILTERS.map(f => (
              <Button key={f.value} size="sm" variant={activeStatus === f.value ? 'default' : 'outline'}
                onClick={() => setActiveStatus(f.value)}
                className={activeStatus === f.value ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90' : ''}>
                {f.label}
              </Button>
            ))}
          </div>
          {/* Category filter */}
          <div className="flex flex-wrap justify-center gap-2">
            <Button size="sm" variant={activeCategory === 'all' ? 'secondary' : 'ghost'}
              onClick={() => setActiveCategory('all')} className="text-xs">
              <Tag className="w-3 h-3 mr-1" /> All Categories
            </Button>
            {categories.map(cat => (
              <Button key={cat.id} size="sm" variant={activeCategory === cat.name ? 'secondary' : 'ghost'}
                onClick={() => setActiveCategory(cat.name)} className="text-xs">
                {cat.name}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Events Grid */}
      <section className="py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex items-center justify-center py-24">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-24">
              <Calendar className="w-14 h-14 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No events found</h3>
              <p className="text-sm text-muted-foreground">Try adjusting your filters.</p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-6">
                <p className="text-sm text-muted-foreground">{filtered.length} event{filtered.length !== 1 ? 's' : ''} found</p>
              </div>
              <motion.div variants={stagger} initial="initial" animate="animate"
                className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map(event => <EventCard key={event.id} event={event} />)}
              </motion.div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}
