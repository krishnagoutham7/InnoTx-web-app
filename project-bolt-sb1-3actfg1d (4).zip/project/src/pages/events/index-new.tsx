import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Calendar, Clock, Search, Sparkles,
  Tag, Heart
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Carousel } from '@/components/carousel';
import { getEvents, getEventCategories } from '@/services/events';
import type { Event, EventCategory, EventStatus } from '@/types/events';
import { eventStatusConfig } from '@/types/events';
import { cn } from '@/lib/utils';

const typeColors: Record<string, string> = {
  Workshop: 'from-blue-500/20 to-blue-500/5 text-blue-400 border-blue-500/20',
  Hackathon: 'from-purple-500/20 to-purple-500/5 text-purple-400 border-purple-500/20',
  Seminar: 'from-emerald-500/20 to-emerald-500/5 text-emerald-400 border-emerald-500/20',
  Webinar: 'from-amber-500/20 to-amber-500/5 text-amber-400 border-amber-500/20',
  Competition: 'from-rose-500/20 to-rose-500/5 text-rose-400 border-rose-500/20',
  'Startup Event': 'from-indigo-500/20 to-indigo-500/5 text-indigo-400 border-indigo-500/20',
  'Innovation Challenge': 'from-pink-500/20 to-pink-500/5 text-pink-400 border-pink-500/20',
  'Training Program': 'from-teal-500/20 to-teal-500/5 text-teal-400 border-teal-500/20',
  'Industrial Visit': 'from-orange-500/20 to-orange-500/5 text-orange-400 border-orange-500/20',
  Other: 'from-muted/20 to-muted/5 text-muted-foreground border-muted/20',
};

// Compact event card for carousel
function EventCarouselCard({ event }: { event: Event }) {
  const statusConf = eventStatusConfig[event.status];
  const typeColor = typeColors[event.event_type] || typeColors.Other;

  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="h-full"
    >
      <Link
        to={`/events/${event.id}`}
        className={cn(
          'block h-full rounded-2xl overflow-hidden',
          'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
          'border border-white/5 backdrop-blur-xl',
          'transition-all duration-500',
          'hover:border-white/10 hover:shadow-xl hover:shadow-black/20',
          'group'
        )}
      >
        {/* Poster */}
        <div className="aspect-video relative overflow-hidden">
          {(event.poster_url || event.banner_image_url) ? (
            <img
              src={event.poster_url || event.banner_image_url || ''}
              alt={event.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 flex items-center justify-center">
              <Calendar className="w-12 h-12 text-white/20" />
            </div>
          )}

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

          {/* Status badge */}
          <div className="absolute top-3 left-3">
            <Badge className={cn('backdrop-blur-xl text-xs', statusConf.bg, statusConf.color)}>
              {statusConf.label}
            </Badge>
          </div>

          {/* Category badge */}
          <div className="absolute top-3 right-3">
            <span className={cn(
              'px-2.5 py-1 rounded-full text-[10px] font-medium border backdrop-blur-xl',
              'bg-gradient-to-r',
              typeColor
            )}>
              {event.event_type}
            </span>
          </div>

          {/* Likes */}
          {event.like_count !== undefined && event.like_count > 0 && (
            <div className="absolute bottom-3 right-3 flex items-center gap-1 bg-black/40 backdrop-blur-xl px-2 py-1 rounded-full">
              <Heart className="w-3 h-3 text-rose-400 fill-rose-400" />
              <span className="text-[10px] text-white font-medium">{event.like_count}</span>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-4">
          <h3 className="font-semibold text-sm line-clamp-2 group-hover:text-primary transition-colors">
            {event.title}
          </h3>

          <div className="mt-3 space-y-1.5">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Calendar className="w-3.5 h-3.5 text-primary/60" />
              <span>{new Date(event.start_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
            </div>
            {event.venue && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Tag className="w-3.5 h-3.5 text-secondary/60" />
                <span className="line-clamp-1">{event.venue}</span>
              </div>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

// Featured event card (larger)
function FeaturedEventCard({ event }: { event: Event }) {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="w-[500px] flex-shrink-0"
    >
      <Link
        to={`/events/${event.id}`}
        className={cn(
          'block rounded-3xl overflow-hidden',
          'bg-gradient-to-br from-primary/10 via-background to-accent/10',
          'border border-white/10',
          'group'
        )}
      >
        {/* Large poster */}
        <div className="aspect-[16/9] relative overflow-hidden">
          {(event.poster_url || event.banner_image_url) ? (
            <img
              src={event.poster_url || event.banner_image_url || ''}
              alt={event.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/30 via-secondary/20 to-accent/30 flex items-center justify-center">
              <Calendar className="w-20 h-20 text-white/20" />
            </div>
          )}

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />

          {/* Featured badge */}
          {event.is_featured && (
            <div className="absolute top-4 left-4">
              <Badge className="bg-gradient-to-r from-primary to-accent text-white border-0">
                <Sparkles className="w-3 h-3 mr-1" /> Featured
              </Badge>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-5">
          <h3 className="text-xl font-bold font-heading line-clamp-1 group-hover:text-primary transition-colors">
            {event.title}
          </h3>
          {event.short_description && (
            <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{event.short_description}</p>
          )}

          <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-primary" />
              <span>{new Date(event.start_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
            </div>
            {event.start_time && (
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-secondary" />
                <span>{event.start_time.slice(0, 5)}</span>
              </div>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [categories, setCategories] = useState<EventCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeStatus, setActiveStatus] = useState<EventStatus | 'all'>('all');

  useEffect(() => {
    getEventCategories().then(setCategories).catch(console.error);
    getEvents()
      .then((data) => setEvents(data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  // Filter events
  const filteredEvents = events.filter((e) => {
    const matchesSearch = !search ||
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      e.event_type?.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = activeStatus === 'all' || e.status === activeStatus;
    return matchesSearch && matchesStatus;
  });

  // Group events
  const featured = filteredEvents.filter((e) => e.is_featured).slice(0, 5);
  const upcoming = filteredEvents.filter((e) => e.status === 'upcoming');
  const ongoing = filteredEvents.filter((e) => e.status === 'ongoing');
  const completed = filteredEvents.filter((e) => e.status === 'completed');

  const statusTabs = [
    { id: 'all', label: 'All', count: filteredEvents.length },
    { id: 'upcoming', label: 'Upcoming', count: upcoming.length },
    { id: 'ongoing', label: 'Ongoing', count: ongoing.length },
    { id: 'completed', label: 'Past', count: completed.length },
  ];

  const displayEvents = activeStatus === 'all' ? filteredEvents : filteredEvents.filter((e) => e.status === activeStatus);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative pt-28 pb-8 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
          <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-primary/15 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-accent/15 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
        </div>

        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-primary/10 to-accent/10 border border-white/5 mb-4">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Innovation Events</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-extrabold font-heading tracking-tight">
              Explore <span className="gradient-text">Events</span>
            </h1>
            <p className="text-muted-foreground mt-3 max-w-xl mx-auto">
              Discover workshops, hackathons, and innovation challenges.
            </p>
          </motion.div>

          {/* Search */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="max-w-md mx-auto mb-6"
          >
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search events..."
                className={cn(
                  'pl-11 h-12 rounded-xl',
                  'bg-white/5 border-white/10',
                  'focus:border-primary/50 focus:ring-primary/20'
                )}
              />
            </div>
          </motion.div>

          {/* Status tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex justify-center"
          >
            <Tabs value={activeStatus} onValueChange={(v) => setActiveStatus(v as EventStatus | 'all')}>
              <TabsList className="bg-white/5 border border-white/5 rounded-xl p-1 h-auto">
                {statusTabs.map((tab) => (
                  <TabsTrigger
                    key={tab.id}
                    value={tab.id}
                    className={cn(
                      'px-4 py-2 rounded-lg text-sm',
                      'data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/20 data-[state=active]:to-accent/20',
                      'data-[state=active]:text-primary'
                    )}
                  >
                    {tab.label}
                    <span className="ml-1.5 text-xs px-1.5 py-0.5 rounded-full bg-white/10">{tab.count}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </motion.div>
        </div>
      </section>

      {/* Content - Tabbed to avoid scrolling */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 space-y-8">
          {/* Featured Section */}
          {featured.length > 0 && !search && activeStatus === 'all' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold font-heading flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" /> Featured Events
                </h2>
                <Link to="/events" className="text-sm text-primary hover:underline">
                  View all
                </Link>
              </div>
              <Carousel itemWidth={500} gap={20} showDots={featured.length > 2}>
                {featured.map((event) => (
                  <FeaturedEventCard key={event.id} event={event} />
                ))}
              </Carousel>
            </motion.div>
          )}

          {/* Events Grid/Cards */}
          {loading ? (
            <div className="flex justify-center py-12">
              <div className="w-12 h-12 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
            </div>
          ) : displayEvents.length === 0 ? (
            <div className="text-center py-16 rounded-2xl bg-gradient-to-br from-white/2 to-transparent border border-white/5">
              <Calendar className="w-16 h-16 text-muted-foreground/20 mx-auto mb-4" />
              <h3 className="text-lg font-semibold">No events found</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {search ? 'Try a different search term' : 'Check back later for new events'}
              </p>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold font-heading">
                  {activeStatus === 'all' ? 'All Events' : activeStatus.charAt(0).toUpperCase() + activeStatus.slice(1) + ' Events'}
                </h2>
                <span className="text-sm text-muted-foreground">{displayEvents.length} events</span>
              </div>

              {/* Horizontal scrollable cards */}
              <Carousel itemWidth={300} gap={16}>
                {displayEvents.map((event) => (
                  <EventCarouselCard key={event.id} event={event} />
                ))}
              </Carousel>
            </motion.div>
          )}

          {/* Category Filter Tags - Compact inline */}
          {categories.length > 0 && !search && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="pt-6 border-t border-white/5"
            >
              <h3 className="text-sm font-medium mb-3 text-muted-foreground">Browse by Category</h3>
              <div className="flex flex-wrap gap-2">
                {categories.map((cat) => (
                  <Link
                    key={cat.id}
                    to={`/events?category=${cat.id}`}
                    className={cn(
                      'px-3 py-1.5 rounded-lg text-sm',
                      'bg-gradient-to-r from-white/5 to-transparent',
                      'border border-white/5 hover:border-primary/20',
                      'text-muted-foreground hover:text-foreground',
                      'transition-all duration-200'
                    )}
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </section>
    </div>
  );
}
