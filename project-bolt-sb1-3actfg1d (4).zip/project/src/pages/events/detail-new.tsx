import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Calendar, MapPin, Clock, ArrowLeft,
  User, Mail, CheckCircle, AlertCircle, Ticket, XCircle, Heart, Share2,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SplitViewLayout } from '@/components/dashboard/tabbed-layout';
import {
  getEventById, getEventSpeakers, getRegistrationCountByEvent, registerForEvent, getRegistrationByEmail, cancelRegistration, getTicketForRegistration, toggleEventLike, getEventLikeCount, checkUserLiked
} from '@/services/events';
import type { Event, EventSpeaker, EventRegistration } from '@/types/events';
import type { EventTicket } from '@/services/events';
import { eventStatusConfig } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

export default function EventDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [event, setEvent] = useState<Event | null>(null);
  const [speakers, setSpeakers] = useState<EventSpeaker[]>([]);
  const [registrationCount, setRegistrationCount] = useState(0);
  const [showRegForm, setShowRegForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [existingReg, setExistingReg] = useState<EventRegistration | null>(null);
  const [ticket, setTicket] = useState<EventTicket | null>(null);
  const [regForm, setRegForm] = useState({ user_name: '', user_email: '', notes: '' });
  const [likeCount, setLikeCount] = useState(0);
  const [userLiked, setUserLiked] = useState(false);
  const [liking, setLiking] = useState(false);

  const handleLikeToggle = async () => {
    if (!user || !id) return;
    setLiking(true);
    try {
      const result = await toggleEventLike(id, user.id);
      setUserLiked(result.liked);
      setLikeCount(result.like_count);
    } catch (err) {
      console.error('Failed to toggle like:', err);
    } finally {
      setLiking(false);
    }
  };

  useEffect(() => {
    if (user) {
      setRegForm((prev) => ({
        ...prev,
        user_name: prev.user_name || user.name || '',
        user_email: user.email || '',
      }));
    }
  }, [user]);

  useEffect(() => {
    if (!id) return;
    async function load() {
      try {
        const [evtData, speakerData, regCount] = await Promise.all([
          getEventById(id!),
          getEventSpeakers(id!),
          getRegistrationCountByEvent(id!),
        ]);
        setEvent(evtData);
        setSpeakers(speakerData);
        setRegistrationCount(regCount);
        const likeCountData = await getEventLikeCount(id!);
        setLikeCount(likeCountData);
        if (user?.id) {
          const liked = await checkUserLiked(id!, user.id);
          setUserLiked(liked);
        }
        if (user?.email) {
          const reg = await getRegistrationByEmail(id!, user.email);
          if (reg) {
            setExistingReg(reg);
            if (reg.ticket_id) {
              const ticketData = await getTicketForRegistration(reg.id);
              setTicket(ticketData);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id, user]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!event || !regForm.user_email) return;
    setSubmitting(true);
    try {
      await registerForEvent({
        event_id: event.id,
        user_name: regForm.user_name || user?.name || '',
        user_email: regForm.user_email,
        user_id: user?.id,
        user_role: user?.role,
        notes: regForm.notes,
      });
      toast({ title: 'Registered!', description: 'You have successfully registered for this event.' });
      setShowRegForm(false);
      const reg = await getRegistrationByEmail(event.id, regForm.user_email);
      if (reg) {
        setExistingReg(reg);
        if (reg.ticket_id) {
          const t = await getTicketForRegistration(reg.id);
          setTicket(t);
        }
      }
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Registration failed', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = async () => {
    if (!existingReg || !event) return;
    try {
      await cancelRegistration(existingReg.id);
      toast({ title: 'Cancelled', description: 'Your registration has been cancelled.' });
      setExistingReg(null);
      setTicket(null);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Cancellation failed', variant: 'destructive' });
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({ title: 'Link copied!', description: 'Event link copied to clipboard' });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
          <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-primary" />
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen px-4">
        <AlertCircle className="w-16 h-16 text-muted-foreground/30 mb-4" />
        <h2 className="text-xl font-semibold">Event not found</h2>
        <p className="text-muted-foreground mt-2">This event may have been removed or doesn't exist.</p>
        <Button className="mt-4" onClick={() => navigate('/events')}>
          Browse Events
        </Button>
      </div>
    );
  }

  const statusConf = eventStatusConfig[event.status];
  const seatsLeft = event.max_participants ? event.max_participants - registrationCount : null;
  const isPast = new Date(event.start_date) < new Date();

  // Left content - Event details
  const LeftContent = () => (
    <div className="space-y-6">
      {/* Back button */}
      <Link
        to="/events"
        className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Events</span>
      </Link>

      {/* Hero Image */}
      <div className="relative rounded-3xl overflow-hidden aspect-[21/9]">
        {event.poster_url ? (
          <img
            src={event.poster_url}
            alt={event.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/30 via-secondary/20 to-accent/30 flex items-center justify-center">
            <Calendar className="w-16 h-16 text-white/30" />
          </div>
        )}
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

        {/* Status & Category badges */}
        <div className="absolute top-4 left-4 flex gap-2">
          <Badge className={cn('backdrop-blur-xl', statusConf.bg, statusConf.color)}>
            {statusConf.label}
          </Badge>
          {event.event_type && (
            <Badge className="bg-accent/20 text-accent border-accent/20 backdrop-blur-xl">
              {event.event_type}
            </Badge>
          )}
        </div>

        {/* Featured badge */}
        {event.is_featured && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-gradient-to-r from-primary to-accent text-white border-0">
              <Sparkles className="w-3 h-3 mr-1" /> Featured
            </Badge>
          </div>
        )}
      </div>

      {/* Title & Quick info */}
      <div>
        <h1 className="text-3xl font-bold font-heading">{event.title}</h1>
        <div className="flex flex-wrap gap-4 mt-4 text-muted-foreground">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            <span>{new Date(event.start_date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</span>
          </div>
          {event.start_time && (
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-secondary" />
              <span>{event.start_time.slice(0, 5)}{event.end_time ? ` — ${event.end_time.slice(0, 5)}` : ''}</span>
            </div>
          )}
          {event.venue && (
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-accent" />
              <span>{event.venue}</span>
            </div>
          )}
        </div>
      </div>

      {/* Tabs for Details, Speakers, etc. */}
      <Tabs defaultValue="about" className="w-full">
        <TabsList className="bg-white/5 border border-white/5 rounded-xl p-1">
          <TabsTrigger value="about" className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/20 data-[state=active]:to-accent/20">About</TabsTrigger>
          {speakers.length > 0 && <TabsTrigger value="speakers" className="rounded-lg">Speakers</TabsTrigger>}
          <TabsTrigger value="organizer" className="rounded-lg">Organizer</TabsTrigger>
        </TabsList>

        <TabsContent value="about" className="mt-4">
          <div className={cn(
            'prose prose-sm dark:prose-invert max-w-none',
            'rounded-2xl p-5',
            'bg-gradient-to-br from-white/2 to-transparent border border-white/5'
          )}>
            {event.short_description ? (
              <p className="text-muted-foreground leading-relaxed">{event.short_description}</p>
            ) : (
              <p className="text-muted-foreground">No description available.</p>
            )}
          </div>
        </TabsContent>

        {speakers.length > 0 && (
          <TabsContent value="speakers" className="mt-4">
            <div className="space-y-3">
              {speakers.map((speaker) => (
                <div
                  key={speaker.id}
                  className={cn(
                    'flex gap-4 p-4 rounded-xl',
                    'bg-gradient-to-r from-white/2 to-transparent border border-white/5'
                  )}
                >
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 shrink-0">
                    {speaker.photo_url ? (
                      <img src={speaker.photo_url} alt={speaker.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <User className="w-6 h-6 text-primary/50" />
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="font-medium">{speaker.name}</p>
                    {speaker.designation && <p className="text-xs text-muted-foreground">{speaker.designation}</p>}
                    {speaker.bio && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{speaker.bio}</p>}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        )}

        <TabsContent value="organizer" className="mt-4">
          <div className={cn(
            'rounded-2xl p-5',
            'bg-gradient-to-br from-white/2 to-transparent border border-white/5'
          )}>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                <User className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">{event.organizer_name || 'Event Organizer'}</p>
                {event.organizer_email && (
                  <a href={`mailto:${event.organizer_email}`} className="text-sm text-primary hover:underline flex items-center gap-1">
                    <Mail className="w-3 h-3" />
                    {event.organizer_email}
                  </a>
                )}
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );

  // Right content - Registration panel (sticky)
  const RightContent = () => (
    <div className="space-y-4">
      {/* Registration Card */}
      <div className={cn(
        'rounded-2xl overflow-hidden',
        'bg-gradient-to-br from-background/90 via-background/70 to-background/50',
        'border border-white/10 backdrop-blur-xl'
      )}>
        {/* Card header */}
        <div className="p-5 border-b border-white/5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Registration</p>
              <p className="text-2xl font-bold">{registrationCount}<span className="text-muted-foreground text-base font-normal"> / {event.max_participants || '∞'}</span></p>
            </div>
            <div className="flex items-center gap-2">
              {/* Like button */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleLikeToggle}
                disabled={liking}
                className={cn(
                  'w-10 h-10 rounded-xl flex items-center justify-center transition-colors',
                  userLiked ? 'bg-rose-500/20 text-rose-500' : 'bg-white/5 text-muted-foreground hover:text-rose-500'
                )}
              >
                <Heart className={cn('w-5 h-5', userLiked && 'fill-current')} />
              </motion.button>
              {/* Share button */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={copyLink}
                className="w-10 h-10 rounded-xl flex items-center justify-center bg-white/5 text-muted-foreground hover:text-foreground transition-colors"
              >
                <Share2 className="w-5 h-5" />
              </motion.button>
            </div>
          </div>
          {/* Like count */}
          <p className="text-xs text-muted-foreground mt-2">{likeCount} people interested</p>
        </div>

        {/* Card content */}
        <div className="p-5 space-y-4">
          {existingReg ? (
            /* Already registered state */
            <div className="space-y-4">
              <div className={cn(
                'flex items-center gap-3 p-3 rounded-xl',
                existingReg.registration_status === 'cancelled'
                  ? 'bg-destructive/10 text-destructive'
                  : 'bg-success/10 text-success'
              )}>
                {existingReg.registration_status === 'cancelled' ? (
                  <XCircle className="w-5 h-5" />
                ) : (
                  <CheckCircle className="w-5 h-5" />
                )}
                <div>
                  <p className="font-medium">
                    {existingReg.registration_status === 'cancelled' ? 'Registration Cancelled' : 'You are registered!'}
                  </p>
                  <p className="text-xs opacity-80">
                    {new Date(existingReg.registered_at).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              {existingReg.registration_status !== 'cancelled' && (
                <div className="space-y-2">
                  {ticket && (
                    <Button
                      className={cn(
                        'w-full gap-2',
                        'bg-gradient-to-r from-primary via-secondary to-accent',
                        'text-white font-medium',
                        'shadow-glow hover:shadow-glow-lg'
                      )}
                      onClick={() => existingReg.qr_code && navigate(`/ticket/${existingReg.qr_code}`)}
                    >
                      <Ticket className="w-4 h-4" />
                      View Ticket
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    className="w-full text-destructive hover:bg-destructive/10"
                    onClick={handleCancel}
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Cancel Registration
                  </Button>
                </div>
              )}
            </div>
          ) : (
            /* Not registered state */
            <div className="space-y-4">
              {!showRegForm ? (
                <>
                  {isPast ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      This event has already passed.
                    </p>
                  ) : seatsLeft !== null && seatsLeft <= 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      This event is fully booked.
                    </p>
                  ) : (
                    <Button
                      className={cn(
                        'w-full gap-2',
                        'bg-gradient-to-r from-primary via-secondary to-accent',
                        'text-white font-medium',
                        'shadow-glow hover:shadow-glow-lg transition-shadow'
                      )}
                      onClick={() => setShowRegForm(true)}
                    >
                      <CheckCircle className="w-4 h-4" />
                      Register Now
                    </Button>
                  )}
                </>
              ) : (
                /* Registration form */
                <form onSubmit={handleRegister} className="space-y-3">
                  <div>
                    <Label htmlFor="name" className="text-xs">Name</Label>
                    <Input
                      id="name"
                      value={regForm.user_name}
                      onChange={(e) => setRegForm((p) => ({ ...p, user_name: e.target.value }))}
                      placeholder="Your name"
                      required
                      className="input-premium mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-xs">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={regForm.user_email}
                      disabled
                      className="input-premium mt-1 opacity-60"
                    />
                  </div>
                  <div>
                    <Label htmlFor="notes" className="text-xs">Notes (optional)</Label>
                    <Input
                      id="notes"
                      value={regForm.notes}
                      onChange={(e) => setRegForm((p) => ({ ...p, notes: e.target.value }))}
                      placeholder="Any special requirements"
                      className="input-premium mt-1"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setShowRegForm(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={submitting}
                      className={cn(
                        'flex-1',
                        'bg-gradient-to-r from-primary to-accent'
                      )}
                    >
                      {submitting ? 'Registering...' : 'Confirm'}
                    </Button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Quick info cards */}
      <div className={cn(
        'rounded-2xl p-4',
        'bg-gradient-to-br from-white/2 to-transparent border border-white/5'
      )}>
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Seats Left</span>
            <span className={cn('font-semibold', seatsLeft && seatsLeft < 10 ? 'text-warning' : 'text-foreground')}>
              {seatsLeft ?? 'Unlimited'}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Registration</span>
            <span className="font-semibold text-primary">
              {event.registration_deadline ? `Until ${new Date(event.registration_deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}` : 'Open'}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Category</span>
            <span className="font-medium">{event.event_type || 'General'}</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background py-6">
      <div className="max-w-7xl mx-auto px-4">
        <SplitViewLayout
          left={<LeftContent />}
          right={<RightContent />}
          leftWidth="65%"
          rightWidth="35%"
        />
      </div>
    </div>
  );
}
