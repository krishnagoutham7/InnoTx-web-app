import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Calendar, MapPin, Clock, Users, ArrowLeft, Tag,
  User, Mail, CheckCircle, Loader2, X, AlertCircle, Ticket, XCircle, Heart, ZoomIn
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { getEventById, getEventSpeakers, getRegistrationCountByEvent, registerForEvent, getRegistrationByEmail, cancelRegistration, getTicketForRegistration, toggleEventLike, getEventLikeCount, checkUserLiked } from '@/services/events';
import type { Event, EventSpeaker, EventRegistration } from '@/types/events';
import type { EventTicket } from '@/services/events';
import { eventStatusConfig } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth';
import { cn } from '@/lib/utils';

export default function EventDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [event, setEvent] = useState<Event | null>(null);
  const [speakers, setSpeakers] = useState<EventSpeaker[]>([]);
  const [registrationCount, setRegistrationCount] = useState(0);
  const [showRegForm, setShowRegForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [existingReg, setExistingReg] = useState<EventRegistration | null>(null);
  const [ticket, setTicket] = useState<EventTicket | null>(null);
  const [regForm, setRegForm] = useState({ user_name: '', user_email: '', notes: '' });
  const [likeCount, setLikeCount] = useState(0);
  const [userLiked, setUserLiked] = useState(false);
  const [liking, setLiking] = useState(false);
  const [posterModalOpen, setPosterModalOpen] = useState(false);

  // Handle like toggle
  const handleLikeToggle = async () => {
    if (!user || !id) return;
    setLiking(true);
    try {
      const result = await toggleEventLike(id, user.id);
      setUserLiked(result.liked);
      setLikeCount(result.like_count);
    } catch (err) {
      console.error('Failed to toggle like:', err);
    } finally {
      setLiking(false);
    }
  };

  // Sync regForm with user when auth loads
  useEffect(() => {
    if (user) {
      setRegForm(prev => ({
        ...prev,
        user_name: prev.user_name || user.name || '',
        user_email: user.email || '', // Always use auth email - not editable
      }));
    }
  }, [user]);

  useEffect(() => {
    if (!id) return;
    async function load() {
      try {
        const [evtData, speakerData, regCount] = await Promise.all([
          getEventById(id!),
          getEventSpeakers(id!),
          getRegistrationCountByEvent(id!),
        ]);
        setEvent(evtData);
        setSpeakers(speakerData);
        setRegistrationCount(regCount);
        // Load like info
        const likeCountData = await getEventLikeCount(id!);
        setLikeCount(likeCountData);
        if (user?.id) {
          const liked = await checkUserLiked(id!, user.id);
          setUserLiked(liked);
        }
        if (user?.email) {
          const reg = await getRegistrationByEmail(id!, user.email);
          if (reg) {
            setExistingReg(reg);
            // Load ticket if registered
            if (reg.ticket_id) {
              const ticketData = await getTicketForRegistration(reg.id);
              setTicket(ticketData);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id, user]);

  const handleRegister = async () => {
    if (!regForm.user_name || !regForm.user_email) return;
    try {
      setSubmitting(true);
      const result = await registerForEvent({
        event_id: id!,
        user_name: regForm.user_name,
        user_email: regForm.user_email,
        user_role: user?.role,
        notes: regForm.notes || undefined,
        user_id: user?.id,
      });
      toast({ title: 'Registration Submitted!', description: `Your registration for ${event?.title} is pending approval.` });
      setRegistrationCount(c => c + 1);
      setExistingReg(result);
      setShowRegForm(false);
    } catch (err: any) {
      toast({ title: 'Registration Failed', description: err.message || 'You may already be registered', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelReg = async () => {
    if (!existingReg) return;
    try {
      setSubmitting(true);
      const result = await cancelRegistration(existingReg.id);
      if (result.success) {
        toast({ title: 'Cancelled', description: 'Your registration has been cancelled' });
        setRegistrationCount(c => Math.max(0, c - 1));
        // Update state to show cancelled status instead of hiding registration
        const updated = result.registration || { ...existingReg, registration_status: 'cancelled', approval_status: 'cancelled' };
        setExistingReg(updated);
        setTicket(null);
      } else {
        toast({ title: 'Error', description: result.error || 'Failed to cancel registration', variant: 'destructive' });
      }
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to cancel registration', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleViewTicket = () => {
    if (ticket?.qr_code) {
      navigate(`/ticket/${ticket.qr_code}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-32">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-32">
        <div className="text-center">
          <AlertCircle className="w-14 h-14 text-muted-foreground/30 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Event Not Found</h2>
          <Link to="/events"><Button variant="outline" className="gap-2"><ArrowLeft className="w-4 h-4" />Back to Events</Button></Link>
        </div>
      </div>
    );
  }

  const statusConf = eventStatusConfig[event.status];
  const seatsLeft = event.max_participants ? event.max_participants - registrationCount : null;
  const isFull = seatsLeft !== null && seatsLeft <= 0;
  const canRegister = !isFull && ['published', 'upcoming', 'registration_open'].includes(event.status) && (!existingReg || existingReg.approval_status === 'cancelled') && !!user;
  const isDeadlinePassed = event.registration_deadline
    ? new Date(event.registration_deadline) < new Date()
    : false;

  return (
    <div className="min-h-screen">
      {/* Back nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28">
        <Link to="/events" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Events
        </Link>
      </div>

      {/* Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative rounded-2xl overflow-hidden">
          <div className="aspect-[3/1] bg-gradient-to-br from-primary/20 via-accent/15 to-background flex items-center justify-center">
            {event.banner_image_url ? (
              <img
                src={event.banner_image_url}
                alt={event.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <Calendar className="w-24 h-24 text-primary/20" />
            )}
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6">
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className={cn('text-xs font-medium px-3 py-1 rounded-full', statusConf.bg, statusConf.bg, statusConf.color)}>
                {statusConf.label}
              </span>
              <Badge variant="outline" className="text-xs">{event.event_type}</Badge>
              {event.is_featured && <Badge className="text-xs bg-primary">Featured</Badge>}
              {event.category && <Badge variant="secondary" className="text-xs">{event.category.name}</Badge>}
            </div>
            <div className="flex items-end justify-between gap-4">
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight leading-tight">
                {event.title}
              </h1>
              <Button
                variant="ghost"
                size="lg"
                onClick={handleLikeToggle}
                disabled={!user || liking}
                className={cn(
                  'flex-shrink-0 gap-2',
                  userLiked && 'text-red-500 hover:text-red-600 hover:bg-red-50'
                )}
              >
                <Heart className={cn('w-5 h-5', userLiked && 'fill-current')} />
                <span className="text-sm">{likeCount}</span>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main */}
          <div className="lg:col-span-2 space-y-8">
            {/* Short description */}
            {event.short_description && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
                <p className="text-lg text-muted-foreground leading-relaxed">{event.short_description}</p>
              </motion.div>
            )}

            {/* Full description */}
            {event.full_description && (
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6">
                  <h2 className="text-xl font-semibold mb-4">About this Event</h2>
                  <p className="text-muted-foreground leading-relaxed whitespace-pre-line">{event.full_description}</p>
                </CardContent>
              </Card>
            )}

            {/* Event Poster */}
            {event.poster_image_url && (
              <Card className="glass-card border-0 shadow-md overflow-hidden">
                <CardContent className="p-0">
                  <div
                    className="relative cursor-pointer group"
                    onClick={() => setPosterModalOpen(true)}
                  >
                    <img
                      src={event.poster_image_url}
                      alt={`${event.title} poster`}
                      className="w-full object-contain max-h-[600px]"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 px-4 py-2 rounded-lg flex items-center gap-2 text-white">
                        <ZoomIn className="w-5 h-5" />
                        <span>Click to enlarge</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Speakers */}
            {speakers.length > 0 && (
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6">
                  <h2 className="text-xl font-semibold mb-5">Speakers</h2>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {speakers.map(s => (
                      <div key={s.id} className="flex items-start gap-4 p-4 rounded-xl bg-muted/40">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shrink-0">
                          <User className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-sm">{s.name}</p>
                          {s.designation && <p className="text-xs text-primary mb-1">{s.designation}</p>}
                          {s.bio && <p className="text-xs text-muted-foreground line-clamp-3">{s.bio}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Organizer */}
            {event.organizer_name && (
              <Card className="glass-card border-0 shadow-md">
                <CardContent className="pt-6">
                  <h2 className="text-xl font-semibold mb-4">Organizer</h2>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold">{event.organizer_name}</p>
                      {event.organizer_email && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                          <Mail className="w-3 h-3" /> {event.organizer_email}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-5">
            {/* Registration Card */}
            <Card className="glass-card border-0 shadow-lg sticky top-24">
              <CardContent className="pt-6 pb-6">
                <h3 className="font-semibold text-lg mb-4">Registration</h3>

                {/* Seats */}
                {event.max_participants && (
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Availability</span>
                      <span className={isFull ? 'text-destructive' : 'text-emerald-500'}>
                        {isFull ? 'Full' : `${seatsLeft} seats left`}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className={cn('h-full rounded-full transition-all', isFull ? 'bg-destructive' : 'bg-gradient-to-r from-primary to-accent')}
                        style={{ width: `${Math.min(100, (registrationCount / event.max_participants) * 100)}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{registrationCount} / {event.max_participants} registered</p>
                  </div>
                )}

                {existingReg ? (
                  <div className="space-y-3">
                    {existingReg.approval_status === 'approved' ? (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-600">
                        <CheckCircle className="w-4 h-4 shrink-0" />
                        <span className="text-sm font-medium">Approved - You are registered!</span>
                      </div>
                    ) : existingReg.approval_status === 'rejected' ? (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-600">
                        <XCircle className="w-4 h-4 shrink-0" />
                        <span className="text-sm font-medium">Registration Rejected</span>
                      </div>
                    ) : existingReg.approval_status === 'cancelled' ? (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-gray-500/10 border border-gray-500/20 text-gray-600">
                        <X className="w-4 h-4 shrink-0" />
                        <span className="text-sm font-medium">Registration Cancelled</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-600">
                        <Clock className="w-4 h-4 shrink-0" />
                        <span className="text-sm font-medium">Registration Pending Approval</span>
                      </div>
                    )}
                    {ticket && existingReg.approval_status === 'approved' && (
                      <Button className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90" onClick={handleViewTicket}>
                        <Ticket className="w-4 h-4 mr-2" />
                        View My Ticket
                      </Button>
                    )}
                    {existingReg.approval_status !== 'cancelled' && (
                      <Button variant="outline" size="sm" className="w-full text-destructive hover:text-destructive hover:border-destructive" onClick={handleCancelReg} disabled={submitting}>
                        {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <X className="w-4 h-4 mr-2" />}
                        Cancel Registration
                      </Button>
                    )}
                  </div>
                ) : showRegForm ? (
                  <div className="space-y-3">
                    <div className="space-y-1.5">
                      <Label className="text-xs">Full Name</Label>
                      <Input value={regForm.user_name} onChange={e => setRegForm({ ...regForm, user_name: e.target.value })} placeholder="Your name" className="h-9 text-sm" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs">Email</Label>
                      <Input type="email" value={regForm.user_email} readOnly className="h-9 text-sm bg-muted/50" />
                    </div>
                    <div className="flex gap-2">
                      <Button className="flex-1 bg-gradient-to-r from-primary to-accent hover:opacity-90 text-sm h-9" onClick={handleRegister} disabled={submitting || !regForm.user_name || !regForm.user_email}>
                        {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <CheckCircle className="w-4 h-4 mr-1" />}
                        Confirm
                      </Button>
                      <Button variant="outline" size="sm" className="h-9" onClick={() => setShowRegForm(false)}>Cancel</Button>
                    </div>
                  </div>
                ) : (
                  <Button
                    className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20"
                    disabled={!canRegister || isDeadlinePassed}
                    onClick={() => user ? setShowRegForm(true) : navigate('/login')}
                  >
                    {!user ? 'Login to Register' : isFull ? 'Event Full' : isDeadlinePassed ? 'Registration Closed' : event.status === 'completed' ? 'Event Ended' : 'Register Now'}
                  </Button>
                )}

                {event.registration_deadline && !existingReg && (
                  <p className="text-xs text-muted-foreground text-center mt-2">
                    Deadline: {new Date(event.registration_deadline).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Event Details Card */}
            <Card className="glass-card border-0 shadow-md">
              <CardContent className="pt-5 pb-5 space-y-4">
                <h3 className="font-semibold">Event Details</h3>
                {[
                  { icon: Calendar, label: 'Date', value: new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) + (event.end_date && event.end_date !== event.start_date ? ` — ${new Date(event.end_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long' })}` : '') },
                  event.start_time ? { icon: Clock, label: 'Time', value: `${event.start_time.slice(0, 5)}${event.end_time ? ` — ${event.end_time.slice(0, 5)}` : ''}` } : null,
                  event.venue ? { icon: MapPin, label: 'Venue', value: event.venue } : null,
                  event.max_participants ? { icon: Users, label: 'Capacity', value: `${event.max_participants} participants` } : null,
                  { icon: Tag, label: 'Type', value: event.event_type },
                ].filter(Boolean).map((detail) => detail && (
                  <div key={detail.label} className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      <detail.icon className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{detail.label}</p>
                      <p className="text-sm font-medium">{detail.value}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Poster Modal */}
      <Dialog open={posterModalOpen} onOpenChange={setPosterModalOpen}>
        <DialogContent className="max-w-4xl w-full p-0 overflow-hidden bg-black/90 border-0">
          {event?.poster_image_url && (
            <img
              src={event.poster_image_url}
              alt={`${event.title} poster`}
              className="w-full h-auto max-h-[90vh] object-contain"
            />
          )}
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 bg-black/50 text-white hover:bg-black/70"
            onClick={() => setPosterModalOpen(false)}
          >
            <X className="w-5 h-5" />
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
