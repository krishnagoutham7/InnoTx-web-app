import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Eye, Target, ListChecks, Building2, Landmark,
  ArrowRight, Lightbulb, Globe, BookOpen, Cpu, GraduationCap, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { getAboutPage, getCollegeInfo } from '@/services/cms';
import type { AboutPage, CollegeInfo } from '@/services/cms';

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
};

const stagger = {
  animate: { transition: { staggerChildren: 0.1 } },
};

const objectiveIcons = [Lightbulb, BookOpen, Globe, Cpu, Target, Building2];

export default function About() {
  const [about, setAbout] = useState<AboutPage | null>(null);
  const [college, setCollege] = useState<CollegeInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getAboutPage(), getCollegeInfo()])
      .then(([a, c]) => {
        setAbout(a);
        setCollege(c);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const objectives = about ? [
    { title: about.obj_1_title, description: about.obj_1_description },
    { title: about.obj_2_title, description: about.obj_2_description },
    { title: about.obj_3_title, description: about.obj_3_description },
    { title: about.obj_4_title, description: about.obj_4_description },
    { title: about.obj_5_title, description: about.obj_5_description },
    { title: about.obj_6_title, description: about.obj_6_description },
  ] : [];

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent" />
          <div className="absolute top-1/3 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] mb-6">
              About <span className="gradient-text">{college?.portal_name || 'InnoTex'}</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              {college?.portal_description || ''}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Institution Overview */}
      {college && (
        <section className="py-20 lg:py-28 border-y bg-card/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
                  <GraduationCap className="w-3.5 h-3.5 text-primary" />
                  <span className="text-xs font-medium text-primary">Our Institution</span>
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold tracking-tight mb-6">
                  {college.name}
                </h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    {college.name} is a premier technical institution in Kerala, committed to
                    providing quality education and fostering holistic development among students.
                    Located in {college.district} District, the college has been a beacon of
                    technical education for decades.
                  </p>
                  <p>
                    With a strong emphasis on practical learning and industry-relevant curriculum,
                    the institution prepares students to face real-world challenges with confidence
                    and competence. The establishment of IEDC ({college.portal_name}) marks a significant step
                    towards building an entrepreneurial ecosystem on campus.
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <Card className="border-0 shadow-lg bg-gradient-to-br from-background to-primary/5">
                  <CardContent className="pt-8 pb-8">
                    <div className="space-y-5">
                      {[
                        { label: 'Institution', value: college.name },
                        { label: 'Location', value: `${college.district}, ${college.state}` },
                        { label: 'Type', value: college.institution_type },
                        { label: 'District', value: college.district },
                        { label: 'Programme', value: college.programme },
                        { label: 'IEDC', value: college.portal_name },
                      ].map((item) => (
                        <div key={item.label} className="flex items-center justify-between pb-4 border-b last:border-0 last:pb-0">
                          <span className="text-sm text-muted-foreground">{item.label}</span>
                          <span className="text-sm font-medium text-right max-w-[60%]">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>
      )}

      {/* About InnoTex */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <Lightbulb className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs font-medium text-primary">Who We Are</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold tracking-tight mb-6">
              About <span className="gradient-text">{college?.portal_name || 'InnoTex'}</span>
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              {college?.portal_name || 'InnoTex'} is more than just a centre — it is a movement. Born from the vision of empowering
              every student with the tools and mindset to innovate, {college?.portal_name || 'InnoTex'} stands as the bridge between
              academic learning and entrepreneurial action. Through workshops, hackathons, mentorship
              programmes, and seed funding, we transform ideas into impactful ventures.
            </p>
            <div className="grid sm:grid-cols-3 gap-6">
              {[
                { icon: Lightbulb, title: 'Innovation', desc: 'Transforming ideas into solutions' },
                { icon: Globe, title: 'Entrepreneurship', desc: 'Building ventures from campus' },
                { icon: Cpu, title: 'Technology', desc: 'Leveraging tech for impact' },
              ].map((item) => (
                <Card key={item.title} className="border-0 shadow-lg glass-card">
                  <CardContent className="pt-6 pb-6 text-center">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-3">
                      <item.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-1">{item.title}</h3>
                    <p className="text-xs text-muted-foreground">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Vision & Mission */}
      {about && (
        <section className="py-20 lg:py-28 border-y bg-card/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              variants={stagger}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true, margin: '-100px' }}
              className="grid md:grid-cols-2 gap-8"
            >
              <motion.div variants={fadeInUp}>
                <Card className="h-full border-0 shadow-xl bg-gradient-to-br from-background to-primary/5">
                  <CardContent className="pt-8 pb-8">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-6 shadow-lg shadow-primary/20">
                      <Eye className="w-7 h-7 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold mb-4">{about.vision_heading}</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      {about.vision_content}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={fadeInUp}>
                <Card className="h-full border-0 shadow-xl bg-gradient-to-br from-background to-accent/5">
                  <CardContent className="pt-8 pb-8">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-primary flex items-center justify-center mb-6 shadow-lg shadow-accent/20">
                      <Target className="w-7 h-7 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold mb-4">{about.mission_heading}</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      {about.mission_content}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </div>
        </section>
      )}

      {/* Objectives */}
      {objectives.length > 0 && (
        <section className="py-20 lg:py-28">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
                <ListChecks className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-medium text-primary">What We Aim For</span>
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold tracking-tight">Our Objectives</h2>
            </motion.div>

            <motion.div
              variants={stagger}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true, margin: '-100px' }}
              className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {objectives.map((obj, i) => {
                const Icon = objectiveIcons[i];
                return (
                  <motion.div key={obj.title} variants={fadeInUp}>
                    <Card className="h-full hover:shadow-lg transition-all duration-300 hover:border-primary/30 group glass-card">
                      <CardContent className="pt-6">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4 group-hover:from-primary/30 group-hover:to-accent/30 transition-colors">
                          <Icon className="w-6 h-6 text-primary" />
                        </div>
                        <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                          {obj.title}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {obj.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>
      )}

      {/* IEDC Information */}
      {about && (
        <section className="py-20 lg:py-28 border-y bg-card/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
                  <Building2 className="w-3.5 h-3.5 text-primary" />
                  <span className="text-xs font-medium text-primary">IEDC Programme</span>
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold tracking-tight mb-6">
                  {about.iedc_title}
                </h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>{about.iedc_description_1}</p>
                  <p>{about.iedc_description_2}</p>
                  <p>{about.iedc_description_3}</p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <Card className="border-0 shadow-lg glass-card">
                  <CardContent className="pt-8 pb-8">
                    <div className="space-y-5">
                      {[
                        { label: 'Programme', value: 'IEDC by Kerala Startup Mission' },
                        { label: 'Established', value: 'Under KSUM Guidelines' },
                        { label: 'Seed Fund', value: 'Supported by Government of Kerala' },
                        { label: 'Mentorship', value: 'Industry & Academic Experts' },
                        { label: 'Network', value: '300+ IEDCs across Kerala' },
                        { label: 'Focus Areas', value: 'Technology, Social Innovation, Sustainability' },
                      ].map((item) => (
                        <div key={item.label} className="flex items-center justify-between pb-4 border-b last:border-0 last:pb-0">
                          <span className="text-sm text-muted-foreground">{item.label}</span>
                          <span className="text-sm font-medium text-right max-w-[60%]">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>
      )}

      {/* Kerala Startup Mission */}
      {about && (
        <section className="py-20 lg:py-28">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-2 lg:order-1"
              >
                <Card className="border-0 shadow-lg bg-gradient-to-br from-background to-primary/5">
                  <CardContent className="pt-8 pb-8">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-6 shadow-lg shadow-primary/20">
                      <Landmark className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{about.ksum_title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      {about.ksum_description_1}
                    </p>
                    <ul className="space-y-2.5">
                      {[
                        'Managing 300+ IEDCs across educational institutions',
                        'Providing seed funding and grants to student startups',
                        'Organising hackathons, bootcamps, and pitching events',
                        'Connecting startups with investors and mentors',
                        'Facilitating incubation and acceleration programmes',
                      ].map((item) => (
                        <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <ArrowRight className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-1 lg:order-2"
              >
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4">
                  <Landmark className="w-3.5 h-3.5 text-primary" />
                  <span className="text-xs font-medium text-primary">Our Backbone</span>
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold tracking-tight mb-6">
                  {about.ksum_title}
                </h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>{about.ksum_description_2}</p>
                  <p>{about.ksum_description_3}</p>
                </div>
                <div className="mt-8">
                  <a href={about.ksum_website} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" className="gap-2">
                      Visit KSUM Website <ArrowRight className="w-4 h-4" />
                    </Button>
                  </a>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
