import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Lightbulb, Rocket, Users, Trophy, Calendar, ArrowRight,
  Megaphone, Sparkles, GraduationCap, Eye,
  Target, ImageIcon, MapPin, Phone, Mail, Crown, UserCircle, Clock,
  Info, Bell, MailOpen, Send, ExternalLink, Landmark, ListChecks,
  X, ChevronLeft, ChevronRight as ChevronRightIcon,
  Search, Heart, TrendingUp, Archive, Pin, Camera, Video, Award,
  Home as HomeIcon, Ticket as TicketIcon, User, CheckCircle
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { getEvents, getTrendingEvents } from '@/services/events';
import {
  getHomepageCMS, getCollegeInfo, getContactInfo, getPublishedAnnouncements,
  getTeamMembers, getAboutPage, getGalleryAlbums, getGalleryImages
} from '@/services/cms';
import type { HomepageCMS, CollegeInfo, ContactInfo, Announcement, TeamMember, AboutPage, GalleryAlbum, GalleryImage } from '@/services/cms';
import type { Event, TrendingEvent } from '@/types/events';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

// Main tabs
const mainTabs = [
  { id: 'home', label: 'Home', icon: HomeIcon },
  { id: 'about', label: 'About', icon: Info },
  { id: 'team', label: 'Team', icon: Users },
  { id: 'events', label: 'Events', icon: Calendar },
  { id: 'gallery', label: 'Gallery', icon: ImageIcon },
  { id: 'announcements', label: 'News', icon: Megaphone },
  { id: 'contact', label: 'Contact', icon: Mail },
];

// Mobile bottom navigation
const mobileNavItems = [
  { id: 'home', label: 'Home', icon: HomeIcon, path: '/' },
  { id: 'events', label: 'Events', icon: Calendar, path: '/events' },
  { id: 'tickets', label: 'Tickets', icon: TicketIcon, path: '/dashboard/student/my-registrations' },
  { id: 'certificates', label: 'Certs', icon: Award, path: '/dashboard/student' },
  { id: 'profile', label: 'Profile', icon: User, path: '/profile' },
];

// Team sub-tabs
const teamTabs = [
  { id: 'leadership', label: 'Leadership', icon: Crown },
  { id: 'faculty', label: 'Faculty', icon: GraduationCap },
  { id: 'executives', label: 'Executives', icon: Rocket },
  { id: 'members', label: 'Members', icon: Users },
  { id: 'alumni', label: 'Alumni', icon: UserCircle },
];

// Events sub-tabs
const eventsTabs = [
  { id: 'upcoming', label: 'Upcoming', icon: Calendar },
  { id: 'ongoing', label: 'Ongoing', icon: Clock },
  { id: 'completed', label: 'Completed', icon: CheckCircle },
  { id: 'trending', label: 'Trending', icon: TrendingUp },
  { id: 'liked', label: 'Liked', icon: Heart },
];

// Gallery sub-tabs
const galleryTabs = [
  { id: 'photos', label: 'Photos', icon: Camera },
  { id: 'videos', label: 'Videos', icon: Video },
  { id: 'posters', label: 'Posters', icon: ImageIcon },
  { id: 'certificates', label: 'Certificates', icon: Award },
];

// Announcements sub-tabs
const announcementsTabs = [
  { id: 'latest', label: 'Latest', icon: Bell },
  { id: 'pinned', label: 'Pinned', icon: Pin },
  { id: 'archived', label: 'Archived', icon: Archive },
];

// Animated Counter
function AnimatedCounter({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting && !started) setStarted(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    const timer = setInterval(() => {
      current += step;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [started, target]);

  return (
    <div ref={ref} className="text-2xl sm:text-3xl font-bold mb-1">
      {count}{suffix}
    </div>
  );
}

// Team Card - Mobile Optimized
function TeamCard({ member, compact = false }: { member: TeamMember; compact?: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      className="group"
    >
      <Link to="/team" className="block">
        <div className={cn(
          "rounded-xl glass-card hover:border-primary/30 transition-all duration-300 text-center h-full",
          compact ? "p-3" : "p-4"
        )}>
          <div className={cn(
            "rounded-full mx-auto mb-2 overflow-hidden ring-2 ring-primary/20 group-hover:ring-primary/40 transition-all",
            compact ? "w-12 h-12" : "w-16 h-16 sm:w-20 sm:h-20"
          )}>
            {member.photo_url ? (
              <img src={member.photo_url} alt={member.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
                <UserCircle className={cn("text-primary/50", compact ? "w-6 h-6" : "w-8 h-8")} />
              </div>
            )}
          </div>
          <h3 className={cn(
            "font-semibold group-hover:text-primary transition-colors line-clamp-1",
            compact ? "text-xs" : "text-sm sm:text-base"
          )}>
            {member.name}
          </h3>
          <p className={cn(
            "text-primary font-medium mt-0.5 line-clamp-1",
            compact ? "text-[10px]" : "text-xs sm:text-sm"
          )}>
            {member.position}
          </p>
        </div>
      </Link>
    </motion.div>
  );
}

// Status badge config
const statusConfig: Record<string, { label: string; classes: string }> = {
  upcoming:            { label: 'Upcoming',     classes: 'bg-blue-500/15 text-blue-400 border-blue-500/20' },
  published:           { label: 'Open',         classes: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20' },
  registration_open:   { label: 'Reg. Open',    classes: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20' },
  registration_closed: { label: 'Reg. Closed',  classes: 'bg-amber-500/15 text-amber-400 border-amber-500/20' },
  ongoing:             { label: 'Live Now',     classes: 'bg-rose-500/15 text-rose-400 border-rose-500/20' },
  completed:           { label: 'Completed',    classes: 'bg-muted/60 text-muted-foreground border-muted' },
  cancelled:           { label: 'Cancelled',    classes: 'bg-red-500/15 text-red-400 border-red-500/20' },
  draft:               { label: 'Draft',        classes: 'bg-muted/60 text-muted-foreground border-muted' },
};

// Event Card - Mobile Optimized with full details
function EventCard({ event, liked = false }: { event: Event | TrendingEvent; liked?: boolean }) {
  const isTrending = 'like_count' in event;
  const likeCount = isTrending ? (event as TrendingEvent).like_count : 0;
  const fullEvent = isTrending ? null : (event as Event);

  const bannerUrl = fullEvent?.banner_image_url || fullEvent?.banner_url || null;
  const posterUrl = fullEvent?.poster_image_url || fullEvent?.poster_url || null;
  const imageUrl = bannerUrl || posterUrl;

  const status = fullEvent?.status ?? 'upcoming';
  const badge = statusConfig[status] ?? { label: status, classes: 'bg-muted/60 text-muted-foreground border-muted' };

  const isLive = status === 'ongoing';
  const isOpen = status === 'registration_open' || status === 'published';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      className="group"
    >
      <Link to={`/events/${event.id}`}>
        <div className="rounded-xl glass-card hover:border-primary/30 transition-all duration-300 h-full overflow-hidden">

          {/* Banner Image */}
          <div className="relative w-full aspect-video bg-gradient-to-br from-primary/10 to-accent/10 overflow-hidden">
            {imageUrl ? (
              <img
                src={imageUrl}
                alt={event.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Calendar className="w-10 h-10 text-primary/20" />
              </div>
            )}
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

            {/* Badges on image */}
            <div className="absolute top-2 left-2 flex items-center gap-1.5 flex-wrap">
              {fullEvent?.event_type && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-black/60 backdrop-blur-sm text-white border border-white/10">
                  {fullEvent.event_type.replace('_', ' ').toUpperCase()}
                </span>
              )}
              {isLive && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-500 text-white animate-pulse">
                  <span className="w-1.5 h-1.5 rounded-full bg-white" />
                  LIVE
                </span>
              )}
            </div>

            {/* Like count top-right */}
            <div className="absolute top-2 right-2 flex items-center gap-1">
              {liked && <Heart className="w-3.5 h-3.5 text-red-400 fill-red-400" />}
              {(likeCount > 0) && (
                <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] bg-black/60 backdrop-blur-sm text-white">
                  <Heart className="w-3 h-3" /> {likeCount}
                </span>
              )}
            </div>

            {/* Date on image bottom */}
            <div className="absolute bottom-2 left-2 right-2 flex items-end justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] text-white/70">
                  {new Date(event.start_date).toLocaleDateString('en-IN', { weekday: 'short' })}
                </span>
                <span className="text-sm font-bold text-white leading-tight">
                  {new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                </span>
              </div>
              {fullEvent?.status && (
                <span className={cn(
                  "inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold border backdrop-blur-sm",
                  badge.classes
                )}>
                  {badge.label}
                </span>
              )}
            </div>
          </div>

          {/* Card Body */}
          <div className="p-3 sm:p-4">
            <h3 className="text-sm sm:text-base font-semibold mb-1.5 group-hover:text-primary transition-colors line-clamp-2 leading-snug">
              {event.title}
            </h3>
            <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
              {isTrending ? (event as TrendingEvent).description : ((event as Event).short_description || '')}
            </p>

            {/* Meta row */}
            {fullEvent && (
              <div className="space-y-1.5 mb-3">
                {fullEvent.start_time && (
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3 text-primary shrink-0" />
                    <span className="truncate">
                      {fullEvent.start_time.slice(0, 5)}
                      {fullEvent.end_time ? ` – ${fullEvent.end_time.slice(0, 5)}` : ''}
                    </span>
                  </div>
                )}
                {fullEvent.venue && (
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <MapPin className="w-3 h-3 text-primary shrink-0" />
                    <span className="truncate">{fullEvent.venue}</span>
                  </div>
                )}
                {fullEvent.registration_deadline && (
                  <div className="flex items-center gap-1.5 text-xs text-amber-500/80">
                    <Clock className="w-3 h-3 shrink-0" />
                    <span className="truncate">
                      Reg. deadline: {new Date(fullEvent.registration_deadline).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                )}
                {fullEvent.organizer_name && (
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <User className="w-3 h-3 text-primary shrink-0" />
                    <span className="truncate">{fullEvent.organizer_name}</span>
                  </div>
                )}
              </div>
            )}

            {/* Footer row */}
            <div className="flex items-center justify-between pt-2 border-t border-white/5">
              {fullEvent?.max_participants && (
                <span className="text-[10px] text-muted-foreground/70">
                  Max: {fullEvent.max_participants} seats
                </span>
              )}
              <span className={cn(
                "ml-auto text-xs font-semibold",
                isOpen ? "text-emerald-400" : isLive ? "text-rose-400" : "text-primary"
              )}>
                {isOpen ? "Register →" : isLive ? "Join Now →" : "View Details →"}
              </span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

// Gallery Image Card - Touch Optimized
function GalleryImageCard({
  image,
  onClick,
  compact = false
}: {
  image: GalleryImage;
  onClick: () => void;
  compact?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="cursor-pointer group"
    >
      <div className={cn(
        "relative rounded-xl overflow-hidden",
        compact ? "aspect-[4/3]" : "aspect-square"
      )}>
        <div className="w-full h-full bg-gradient-to-br from-muted to-muted/50 border border-white/5 group-hover:border-primary/30 active:border-primary/50 transition-all">
          {image.image_url ? (
            <img
              src={image.image_url}
              alt={image.title || ''}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/5">
              <ImageIcon className="w-8 h-8 text-muted-foreground/30" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-active:opacity-100 transition-opacity flex items-end p-3">
            <p className="text-xs text-white line-clamp-1">{image.title}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// Announcement Card
function AnnouncementCard({ announcement }: { announcement: Announcement }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      whileTap={{ scale: 0.98 }}
      className="group"
    >
      <div className="p-4 rounded-xl glass-card hover:border-primary/30 active:border-primary/50 transition-all">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <Megaphone className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <h3 className="text-sm sm:text-base font-medium truncate group-hover:text-primary transition-colors">
                {announcement.title}
              </h3>
              {announcement.is_pinned && (
                <Badge className="text-[10px] px-1.5 py-0 h-4 bg-primary/10 text-primary border-0 shrink-0">PINNED</Badge>
              )}
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2">{announcement.description}</p>
            <p className="text-[10px] sm:text-xs text-muted-foreground/70 mt-1">
              {announcement.publish_date
                ? new Date(announcement.publish_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
                : new Date(announcement.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
            </p>
          </div>
          {announcement.category && (
            <Badge variant="outline" className="shrink-0 text-[10px]">{announcement.category}</Badge>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// Lightbox for Gallery
function Lightbox({
  images,
  index,
  onClose,
  onNext,
  onPrev
}: {
  images: GalleryImage[];
  index: number | null;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  if (index === null) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center touch-none"
      onClick={onClose}
    >
      <button
        className="absolute top-4 right-4 sm:top-6 sm:right-6 w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 active:bg-white/30 transition-colors"
        onClick={onClose}
      >
        <X className="w-6 h-6" />
      </button>

      <button
        className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 active:bg-white/30 transition-colors"
        onClick={(e) => { e.stopPropagation(); onPrev(); }}
      >
        <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7" />
      </button>

      <button
        className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 active:bg-white/30 transition-colors"
        onClick={(e) => { e.stopPropagation(); onNext(); }}
      >
        <ChevronRightIcon className="w-6 h-6 sm:w-7 sm:h-7" />
      </button>

      <div
        className="max-w-4xl w-full mx-4 sm:mx-8 aspect-video rounded-xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {images[index]?.image_url ? (
          <img
            src={images[index].image_url!}
            alt={images[index].title || ''}
            className="w-full h-full object-contain"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-muted/20 to-muted/10 flex items-center justify-center">
            <ImageIcon className="w-20 h-20 text-white/20" />
          </div>
        )}
      </div>

      <div className="absolute bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 text-white/60 text-sm sm:text-base">
        {index + 1} / {images.length}
      </div>
    </motion.div>
  );
}

// Sub-tab Navigation Component
function SubTabs({
  tabs,
  activeTab,
  onTabChange,
  className
}: {
  tabs: { id: string; label: string; icon: LucideIcon }[];
  activeTab: string;
  onTabChange: (id: string) => void;
  className?: string;
}) {
  return (
    <div className={cn(
      "flex items-center gap-1 p-1 rounded-xl bg-white/5 overflow-x-auto scrollbar-hide",
      className
    )}>
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;

        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap min-h-[40px]",
              isActive
                ? "bg-gradient-to-r from-primary/20 to-accent/20 text-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-white/5"
            )}
          >
            <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// Mobile Bottom Navigation
function MobileBottomNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-background/95 backdrop-blur-xl border-t border-white/5 safe-area-pb">
      <div className="flex items-center justify-around py-1">
        {mobileNavItems.map((item) => {
          const isActive = location.pathname === item.path ||
            (item.id === 'home' && location.pathname === '/') ||
            (item.path !== '/' && location.pathname.startsWith(item.path));
          const Icon = item.icon;

          return (
            <Link
              key={item.id}
              to={item.path}
              className={cn(
                "flex flex-col items-center justify-center py-2 px-3 min-w-[64px] min-h-[56px] rounded-xl transition-colors",
                isActive
                  ? "text-primary"
                  : "text-muted-foreground active:text-foreground"
              )}
            >
              <Icon className={cn("w-5 h-5 mb-1", isActive && "stroke-2")} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export default function Home() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('home');
  const [direction, setDirection] = useState(0);

  // Sub-tab states
  const [teamSubTab, setTeamSubTab] = useState('leadership');
  const [eventsSubTab, setEventsSubTab] = useState('upcoming');
  const [gallerySubTab, setGallerySubTab] = useState('photos');
  const [announcementsSubTab, setAnnouncementsSubTab] = useState('latest');

  // Search states
  const [teamSearch, setTeamSearch] = useState('');

  // Data states
  const [cms, setCms] = useState<HomepageCMS | null>(null);
  const [college, setCollege] = useState<CollegeInfo | null>(null);
  const [contactInfo, setContactInfo] = useState<ContactInfo | null>(null);
  const [aboutPage, setAboutPage] = useState<AboutPage | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [trendingEvents, setTrendingEvents] = useState<TrendingEvent[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [albums, setAlbums] = useState<GalleryAlbum[]>([]);
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [activeAlbum, setActiveAlbum] = useState('all');
  const [lightboxIndex, setLightbox] = useState<number | null>(null);

  // Contact form
  const [contactForm, setContactForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load all data
  useEffect(() => {
    getHomepageCMS().then(d => { if (d) setCms(d); }).catch(() => {});
    getCollegeInfo().then(d => { if (d) setCollege(d); }).catch(() => {});
    getContactInfo().then(d => { if (d) setContactInfo(d); }).catch(() => {});
    getAboutPage().then(d => { if (d) setAboutPage(d); }).catch(() => {});
    getEvents().then(setEvents).catch(() => {});
    getTrendingEvents(6).then(setTrendingEvents).catch(() => {});
    getPublishedAnnouncements().then(a => setAnnouncements(a.slice(0, 12))).catch(() => {});
    getTeamMembers().then(m => setTeamMembers(m.filter(x => x.is_active))).catch(() => {});
    getGalleryAlbums().then(setAlbums).catch(() => {});
    getGalleryImages().then(setImages).catch(() => {});
  }, []);

  // Tab change handler
  const handleTabChange = (tabId: string) => {
    const currentIndex = mainTabs.findIndex(t => t.id === activeTab);
    const newIndex = mainTabs.findIndex(t => t.id === tabId);
    setDirection(newIndex > currentIndex ? 1 : -1);
    setActiveTab(tabId);
  };

  // Contact form handler
  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: 'Message sent!', description: 'We will get back to you soon.' });
    setContactForm({ name: '', email: '', subject: '', message: '' });
    setIsSubmitting(false);
  };

  // Derived data
  const stats = cms?.stats?.length ? cms.stats : [];
  const statIcons = [Lightbulb, Rocket, Users, Trophy];
  const statColors = ['text-primary', 'text-accent', 'text-amber-500', 'text-rose-500'];

  const filteredImages = activeAlbum === 'all'
    ? images
    : images.filter(img => img.album_id === activeAlbum);

  const objectives = aboutPage ? [
    { title: aboutPage.obj_1_title, description: aboutPage.obj_1_description },
    { title: aboutPage.obj_2_title, description: aboutPage.obj_2_description },
    { title: aboutPage.obj_3_title, description: aboutPage.obj_3_description },
    { title: aboutPage.obj_4_title, description: aboutPage.obj_4_description },
    { title: aboutPage.obj_5_title, description: aboutPage.obj_5_description },
    { title: aboutPage.obj_6_title, description: aboutPage.obj_6_description },
  ] : [];

  // Team filters
  const leadership = teamMembers.filter(m => ['ceo', 'coo', 'cfo', 'cpo', 'chief'].includes(m.category));
  const faculty = teamMembers.filter(m => m.category === 'faculty');
  const executives = teamMembers.filter(m => m.category === 'executive');
  const members = teamMembers.filter(m => m.category === 'member');
  const alumni = teamMembers.filter(m => m.category === 'alumni');

  const filterTeamBySearch = (list: TeamMember[]) =>
    list.filter(m =>
      teamSearch === '' ||
      m.name.toLowerCase().includes(teamSearch.toLowerCase()) ||
      m.position.toLowerCase().includes(teamSearch.toLowerCase())
    );

  // Events filters
  const now = new Date();
  const upcomingEvents = events.filter(e => new Date(e.start_date) > now);
  const ongoingEvents = events.filter(e => {
    const start = new Date(e.start_date);
    const end = e.end_date ? new Date(e.end_date) : start;
    return start <= now && end >= now;
  });
  const completedEvents = events.filter(e => {
    const end = e.end_date ? new Date(e.end_date) : new Date(e.start_date);
    return end < now;
  });

  // Announcements filters
  const pinnedAnnouncements = announcements.filter(a => a.is_pinned);
  const archivedAnnouncements = announcements.filter(a => a.status === 'archived');
  const latestAnnouncements = announcements.filter(a => a.status !== 'archived');

  // Tab content variants
  const tabVariants = {
    enter: (dir: number) => ({ x: dir > 0 ? 30 : -30, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (dir: number) => ({ x: dir > 0 ? -30 : 30, opacity: 0 }),
  };

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      {/* Compact Hero Header */}
      <section className="relative pt-20 pb-4 lg:pt-24 lg:pb-6">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-accent/5 to-transparent" />
          <div className="absolute top-1/4 left-1/6 w-[300px] h-[300px] bg-primary/10 rounded-full blur-[100px]" />
          <div className="absolute bottom-1/4 right-1/6 w-[200px] h-[200px] bg-accent/10 rounded-full blur-[80px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            {/* Logo */}
            <div className="flex items-center justify-center gap-3 sm:gap-4 mb-3 sm:mb-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
                <Lightbulb className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div className="w-px h-8 bg-border" />
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-muted flex items-center justify-center border">
                <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6 text-muted-foreground" />
              </div>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-extrabold tracking-tight leading-[1.1] mb-2 sm:mb-3">
              {cms?.hero_headline ? (
                <span className="gradient-text">{cms.hero_headline}</span>
              ) : (
                <>
                  Igniting <span className="gradient-text">Innovation</span>
                </>
              )}
            </h1>

            <p className="text-sm sm:text-base text-muted-foreground max-w-lg mx-auto mb-3 line-clamp-2">
              {college?.portal_description || cms?.hero_description || ''}
            </p>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs font-medium text-primary">
                {college?.portal_tagline || 'Innovation • Entrepreneurship • Technology'}
              </span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Tab Navigation - Desktop */}
      <section className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b hidden md:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-1 py-2 overflow-x-auto scrollbar-hide">
            {mainTabs.map((tab) => {
              const isActive = activeTab === tab.id;
              const Icon = tab.icon;

              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={cn(
                    "relative flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap min-h-[44px]",
                    isActive
                      ? "text-primary bg-gradient-to-r from-primary/15 via-primary/10 to-accent/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {isActive && (
                    <motion.div
                      layoutId="activeTabIndicator"
                      className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full bg-gradient-to-r from-primary to-accent"
                      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Tab Navigation - Mobile (Icons only) */}
      <section className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b md:hidden">
        <div className="flex items-center justify-around py-1 overflow-x-auto scrollbar-hide">
          {mainTabs.map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;

            return (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={cn(
                  "relative flex flex-col items-center justify-center py-2 px-2 rounded-lg transition-all min-w-[52px] min-h-[48px]",
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] mt-0.5">{tab.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="activeTabMobile"
                    className="absolute bottom-0 left-1 right-1 h-0.5 rounded-full bg-gradient-to-r from-primary to-accent"
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* Tab Content */}
      <section className="flex-1 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <AnimatePresence mode="wait" custom={direction}>
            {/* HOME TAB */}
            {activeTab === 'home' && (
              <motion.div
                key="home"
                custom={direction}
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="space-y-4 sm:space-y-6"
              >
                {/* Stats Grid */}
                {stats.length > 0 && (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                    {stats.map((stat, i) => (
                      <div key={stat.label} className="rounded-xl p-3 sm:p-4 glass-card text-center">
                        <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-2 ${statColors[i]}`}>
                          {(() => { const Icon = statIcons[i]; return <Icon className="w-5 h-5 sm:w-6 sm:h-6" />; })()}
                        </div>
                        <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                        <div className="text-xs text-muted-foreground">{stat.label}</div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Quick Links - Mobile Optimized */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
                  {[
                    { icon: Calendar, label: 'Events', path: '/events', color: 'from-blue-500/20 to-cyan-500/20' },
                    { icon: Users, label: 'Team', path: '/team', color: 'from-primary/20 to-accent/20' },
                    { icon: ImageIcon, label: 'Gallery', path: '/gallery', color: 'from-amber-500/20 to-orange-500/20' },
                    { icon: Bell, label: 'News', path: '/announcements', color: 'from-emerald-500/20 to-teal-500/20' },
                  ].map((item) => (
                    <Link key={item.label} to={item.path}>
                      <motion.div
                        whileTap={{ scale: 0.95 }}
                        className={cn(
                          "p-3 sm:p-4 rounded-xl glass-card hover:border-primary/30 transition-all text-center min-h-[80px] sm:min-h-[100px]",
                          "flex flex-col items-center justify-center gap-2"
                        )}
                      >
                        <div className={cn("w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br flex items-center justify-center", item.color)}>
                          <item.icon className="w-5 h-5 sm:w-6 sm:h-6 text-foreground" />
                        </div>
                        <span className="text-xs sm:text-sm font-medium">{item.label}</span>
                      </motion.div>
                    </Link>
                  ))}
                </div>

                {/* Vision & Mission Cards */}
                {(cms?.vision_content || cms?.mission_content) && (
                  <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
                    {cms?.vision_content && (
                      <div className="rounded-xl p-4 sm:p-5 glass-card">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shrink-0">
                            <Eye className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                          </div>
                          <h3 className="font-semibold text-sm sm:text-base">{cms.vision_title}</h3>
                        </div>
                        <p className="text-xs sm:text-sm text-muted-foreground line-clamp-3">{cms.vision_content}</p>
                      </div>
                    )}
                    {cms?.mission_content && (
                      <div className="rounded-xl p-4 sm:p-5 glass-card">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-gradient-to-br from-accent to-accent/60 flex items-center justify-center shrink-0">
                            <Target className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                          </div>
                          <h3 className="font-semibold text-sm sm:text-base">{cms.mission_title}</h3>
                        </div>
                        <p className="text-xs sm:text-sm text-muted-foreground line-clamp-3">{cms.mission_content}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* CTA */}
                <div className="rounded-2xl p-4 sm:p-6 bg-gradient-to-br from-primary/15 via-accent/10 to-primary/5 border border-white/5">
                  <div className="text-center">
                    <h3 className="text-lg sm:text-xl font-bold mb-2">Ready to Build Something Great?</h3>
                    <p className="text-xs sm:text-sm text-muted-foreground mb-4">
                      Join {college?.portal_name || 'InnoTex'} and be part of Kerala's next generation.
                    </p>
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                      <Link to="/contact">
                        <Button size="lg" className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90 min-h-[48px] w-full sm:w-auto">
                          Join the Community <ArrowRight className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Link to="/about">
                        <Button variant="outline" size="lg" className="gap-2 min-h-[48px] w-full sm:w-auto">
                          Learn More
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ABOUT TAB */}
            {activeTab === 'about' && (
              <motion.div
                key="about"
                custom={direction}
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="space-y-4 overflow-y-auto max-h-[calc(100vh-18rem)] md:max-h-[calc(100vh-20rem)] scrollbar-premium pr-1"
              >
                <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
                  <div className="rounded-xl p-4 sm:p-5 glass-card">
                    <div className="inline-flex items-center gap-2 px-2 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-3">
                      <GraduationCap className="w-3.5 h-3.5" />
                      Institution
                    </div>
                    <h3 className="text-base sm:text-lg font-bold mb-2">{college?.name}</h3>
                    <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed line-clamp-4">
                      {college?.name} is a premier technical institution in Kerala, located in {college?.district} District.
                    </p>
                  </div>

                  <div className="rounded-xl p-4 sm:p-5 glass-card">
                    <div className="inline-flex items-center gap-2 px-2 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-3">
                      <Lightbulb className="w-3.5 h-3.5" />
                      {college?.portal_name || 'InnoTex'}
                    </div>
                    <h3 className="text-base sm:text-lg font-bold mb-2">{college?.portal_name || 'InnoTex'}</h3>
                    <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed line-clamp-4">
                      Empowering every student with the tools and mindset to innovate.
                    </p>
                  </div>
                </div>

                {aboutPage && (
                  <>
                    <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
                      <div className="rounded-xl p-4 sm:p-5 bg-gradient-to-br from-background to-primary/5">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-3 shadow-lg shadow-primary/20">
                          <Eye className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <h3 className="text-base sm:text-lg font-bold mb-2">{aboutPage.vision_heading}</h3>
                        <p className="text-xs sm:text-sm text-muted-foreground line-clamp-3">{aboutPage.vision_content}</p>
                      </div>

                      <div className="rounded-xl p-4 sm:p-5 bg-gradient-to-br from-background to-accent/5">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-accent to-primary flex items-center justify-center mb-3 shadow-lg shadow-accent/20">
                          <Target className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <h3 className="text-base sm:text-lg font-bold mb-2">{aboutPage.mission_heading}</h3>
                        <p className="text-xs sm:text-sm text-muted-foreground line-clamp-3">{aboutPage.mission_content}</p>
                      </div>
                    </div>

                    {objectives.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-3">
                          <ListChecks className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                          <h3 className="text-base sm:text-lg font-bold">Objectives</h3>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3">
                          {objectives.map((obj) => (
                            <div key={obj.title} className="rounded-lg p-3 sm:p-4 glass-card hover:border-primary/30 transition-all">
                              <h4 className="text-xs sm:text-sm font-semibold mb-1 line-clamp-1">{obj.title}</h4>
                              <p className="text-[10px] sm:text-xs text-muted-foreground line-clamp-2">{obj.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="rounded-xl p-4 sm:p-5 bg-gradient-to-br from-background to-primary/5 border">
                      <div className="flex items-start gap-3 sm:gap-4">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shrink-0 shadow-lg shadow-primary/20">
                          <Landmark className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-base sm:text-lg font-bold mb-2">{aboutPage.ksum_title}</h3>
                          <p className="text-xs sm:text-sm text-muted-foreground mb-3 line-clamp-3">{aboutPage.ksum_description_1}</p>
                          <a href={aboutPage.ksum_website} target="_blank" rel="noopener noreferrer">
                            <Button variant="outline" size="sm" className="gap-2 min-h-[40px]">
                              Visit KSUM <ExternalLink className="w-3.5 h-3.5" />
                            </Button>
                          </a>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </motion.div>
            )}

            {/* TEAM TAB */}
            {activeTab === 'team' && (
              <motion.div
                key="team"
                custom={direction}
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="space-y-4"
              >
                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={teamSearch}
                    onChange={(e) => setTeamSearch(e.target.value)}
                    placeholder="Search team members..."
                    className="pl-10 h-12"
                  />
                </div>

                {/* Sub-tabs */}
                <SubTabs
                  tabs={teamTabs}
                  activeTab={teamSubTab}
                  onTabChange={setTeamSubTab}
                />

                {teamMembers.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-muted-foreground">No team members found.</p>
                  </div>
                ) : (
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={teamSubTab}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                    >
                      {teamSubTab === 'leadership' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                          {filterTeamBySearch(leadership).map(m => <TeamCard key={m.id} member={m} />)}
                          {filterTeamBySearch(leadership).length === 0 && (
                            <div className="col-span-full text-center py-8 text-muted-foreground text-sm">No results</div>
                          )}
                        </div>
                      )}
                      {teamSubTab === 'faculty' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                          {filterTeamBySearch(faculty).map(m => <TeamCard key={m.id} member={m} />)}
                          {filterTeamBySearch(faculty).length === 0 && (
                            <div className="col-span-full text-center py-8 text-muted-foreground text-sm">No results</div>
                          )}
                        </div>
                      )}
                      {teamSubTab === 'executives' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                          {filterTeamBySearch(executives).map(m => <TeamCard key={m.id} member={m} />)}
                          {filterTeamBySearch(executives).length === 0 && (
                            <div className="col-span-full text-center py-8 text-muted-foreground text-sm">No results</div>
                          )}
                        </div>
                      )}
                      {teamSubTab === 'members' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                          {filterTeamBySearch(members).map(m => <TeamCard key={m.id} member={m} compact />)}
                          {filterTeamBySearch(members).length === 0 && (
                            <div className="col-span-full text-center py-8 text-muted-foreground text-sm">No results</div>
                          )}
                        </div>
                      )}
                      {teamSubTab === 'alumni' && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                          {filterTeamBySearch(alumni).map(m => <TeamCard key={m.id} member={m} compact />)}
                          {alumni.length === 0 && (
                            <div className="col-span-full text-center py-8 text-muted-foreground text-sm">No alumni records yet</div>
                          )}
                        </div>
                      )}
                    </motion.div>
                  </AnimatePresence>
                )}
              </motion.div>
            )}

            {/* EVENTS TAB */}
            {activeTab === 'events' && (
              <motion.div
                key="events"
                custom={direction}
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="space-y-4"
              >
                {/* Sub-tabs */}
                <SubTabs
                  tabs={eventsTabs}
                  activeTab={eventsSubTab}
                  onTabChange={setEventsSubTab}
                />

                <AnimatePresence mode="wait">
                  <motion.div
                    key={eventsSubTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    {eventsSubTab === 'upcoming' && (
                      upcomingEvents.length === 0 ? (
                        <div className="text-center py-12">
                          <Calendar className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No upcoming events.</p>
                        </div>
                      ) : (
                        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                          {upcomingEvents.map(e => <EventCard key={e.id} event={e} />)}
                        </div>
                      )
                    )}
                    {eventsSubTab === 'ongoing' && (
                      ongoingEvents.length === 0 ? (
                        <div className="text-center py-12">
                          <Clock className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No ongoing events.</p>
                        </div>
                      ) : (
                        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                          {ongoingEvents.map(e => <EventCard key={e.id} event={e} />)}
                        </div>
                      )
                    )}
                    {eventsSubTab === 'completed' && (
                      completedEvents.length === 0 ? (
                        <div className="text-center py-12">
                          <CheckCircle className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No completed events.</p>
                        </div>
                      ) : (
                        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                          {completedEvents.slice(0, 6).map(e => <EventCard key={e.id} event={e} />)}
                        </div>
                      )
                    )}
                    {eventsSubTab === 'trending' && (
                      trendingEvents.length === 0 ? (
                        <div className="text-center py-12">
                          <TrendingUp className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No trending events.</p>
                        </div>
                      ) : (
                        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                          {trendingEvents.map(e => <EventCard key={e.id} event={e} />)}
                        </div>
                      )
                    )}
                    {eventsSubTab === 'liked' && (
                      <div className="text-center py-12">
                        <Heart className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-muted-foreground text-sm">Log in to see your liked events.</p>
                        <Link to="/login">
                          <Button variant="outline" size="sm" className="mt-4 gap-2">
                            Sign In <ArrowRight className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>

                <div className="flex justify-center pt-2">
                  <Link to="/events">
                    <Button variant="outline" size="sm" className="gap-2 min-h-[44px]">
                      View All Events <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </motion.div>
            )}

            {/* GALLERY TAB */}
            {activeTab === 'gallery' && (
              <motion.div
                key="gallery"
                custom={direction}
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="space-y-4"
              >
                {/* Sub-tabs */}
                <SubTabs
                  tabs={galleryTabs}
                  activeTab={gallerySubTab}
                  onTabChange={setGallerySubTab}
                />

                {/* Album Filter */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setActiveAlbum('all')}
                    className={cn(
                      "px-3 py-1.5 rounded-lg text-xs font-medium transition-all min-h-[36px]",
                      activeAlbum === 'all'
                        ? "bg-gradient-to-r from-primary to-accent text-white"
                        : "bg-white/5 text-muted-foreground hover:bg-white/10"
                    )}
                  >
                    All ({images.length})
                  </button>
                  {albums.map(album => (
                    <button
                      key={album.id}
                      onClick={() => setActiveAlbum(album.id)}
                      className={cn(
                        "px-3 py-1.5 rounded-lg text-xs font-medium transition-all min-h-[36px]",
                        activeAlbum === album.id
                          ? "bg-gradient-to-r from-primary to-accent text-white"
                          : "bg-white/5 text-muted-foreground hover:bg-white/10"
                      )}
                    >
                      {album.name} ({album.image_count || 0})
                    </button>
                  ))}
                </div>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={gallerySubTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    {gallerySubTab === 'photos' && (
                      filteredImages.length === 0 ? (
                        <div className="text-center py-12">
                          <Camera className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No photos.</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-3">
                          {filteredImages.map((img, idx) => (
                            <GalleryImageCard key={img.id} image={img} onClick={() => setLightbox(idx)} />
                          ))}
                        </div>
                      )
                    )}
                    {gallerySubTab === 'videos' && (
                      <div className="text-center py-12">
                        <Video className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-muted-foreground">No videos yet.</p>
                      </div>
                    )}
                    {gallerySubTab === 'posters' && (
                      <div className="text-center py-12">
                        <ImageIcon className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-muted-foreground">No posters yet.</p>
                      </div>
                    )}
                    {gallerySubTab === 'certificates' && (
                      <div className="text-center py-12">
                        <Award className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-muted-foreground">Certificates available in your dashboard.</p>
                        <Link to="/dashboard/student">
                          <Button variant="outline" size="sm" className="mt-4 gap-2">
                            Go to Dashboard <ArrowRight className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>

                <AnimatePresence>
                  {lightboxIndex !== null && (
                    <Lightbox
                      images={filteredImages}
                      index={lightboxIndex}
                      onClose={() => setLightbox(null)}
                      onNext={() => setLightbox((lightboxIndex! + 1) % filteredImages.length)}
                      onPrev={() => setLightbox((lightboxIndex! - 1 + filteredImages.length) % filteredImages.length)}
                    />
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {/* ANNOUNCEMENTS TAB */}
            {activeTab === 'announcements' && (
              <motion.div
                key="announcements"
                custom={direction}
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="space-y-4"
              >
                {/* Sub-tabs */}
                <SubTabs
                  tabs={announcementsTabs}
                  activeTab={announcementsSubTab}
                  onTabChange={setAnnouncementsSubTab}
                />

                <AnimatePresence mode="wait">
                  <motion.div
                    key={announcementsSubTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="space-y-3"
                  >
                    {announcementsSubTab === 'latest' && (
                      latestAnnouncements.length === 0 ? (
                        <div className="text-center py-12">
                          <Bell className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No announcements.</p>
                        </div>
                      ) : (
                        latestAnnouncements.map(a => <AnnouncementCard key={a.id} announcement={a} />)
                      )
                    )}
                    {announcementsSubTab === 'pinned' && (
                      pinnedAnnouncements.length === 0 ? (
                        <div className="text-center py-12">
                          <Pin className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No pinned announcements.</p>
                        </div>
                      ) : (
                        pinnedAnnouncements.map(a => <AnnouncementCard key={a.id} announcement={a} />)
                      )
                    )}
                    {announcementsSubTab === 'archived' && (
                      archivedAnnouncements.length === 0 ? (
                        <div className="text-center py-12">
                          <Archive className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-muted-foreground">No archived announcements.</p>
                        </div>
                      ) : (
                        archivedAnnouncements.map(a => <AnnouncementCard key={a.id} announcement={a} />)
                      )
                    )}
                  </motion.div>
                </AnimatePresence>
              </motion.div>
            )}

            {/* CONTACT TAB */}
            {activeTab === 'contact' && (
              <motion.div
                key="contact"
                custom={direction}
                variants={tabVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="grid lg:grid-cols-5 gap-4 sm:gap-6"
              >
                {/* Contact Form */}
                <div className="lg:col-span-3">
                  <div className="rounded-xl p-4 sm:p-6 glass-card">
                    <div className="flex items-center gap-2 mb-4">
                      <MailOpen className="w-5 h-5 text-primary" />
                      <h3 className="text-lg font-bold">Send a Message</h3>
                    </div>

                    <form onSubmit={handleContactSubmit} className="space-y-4">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-xs font-medium mb-1.5 block">Name</label>
                          <Input
                            value={contactForm.name}
                            onChange={e => setContactForm(p => ({ ...p, name: e.target.value }))}
                            placeholder="Your name"
                            required
                            className="h-12"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-medium mb-1.5 block">Email</label>
                          <Input
                            type="email"
                            value={contactForm.email}
                            onChange={e => setContactForm(p => ({ ...p, email: e.target.value }))}
                            placeholder="you@email.com"
                            required
                            className="h-12"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-xs font-medium mb-1.5 block">Subject</label>
                        <Input
                          value={contactForm.subject}
                          onChange={e => setContactForm(p => ({ ...p, subject: e.target.value }))}
                          placeholder="What is this regarding?"
                          required
                          className="h-12"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-medium mb-1.5 block">Message</label>
                        <Textarea
                          value={contactForm.message}
                          onChange={e => setContactForm(p => ({ ...p, message: e.target.value }))}
                          placeholder="Tell us more..."
                          rows={4}
                          required
                        />
                      </div>

                      <Button
                        type="submit"
                        size="lg"
                        disabled={isSubmitting}
                        className="gap-2 w-full sm:w-auto bg-gradient-to-r from-primary to-accent hover:opacity-90 min-h-[48px]"
                      >
                        {isSubmitting ? 'Sending...' : 'Send Message'}
                        <Send className="w-4 h-4" />
                      </Button>
                    </form>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="lg:col-span-2 space-y-3">
                  {[
                    { icon: MapPin, title: 'Address', value: contactInfo?.address || college?.address || '' },
                    { icon: Phone, title: 'Phone', value: contactInfo?.phone || college?.phone || '' },
                    { icon: Mail, title: 'Email', value: contactInfo?.email || college?.email || '' },
                  ].map(item => (
                    <div key={item.title} className="rounded-xl p-4 glass-card hover:border-primary/30 transition-all">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                          <item.icon className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-medium text-muted-foreground">{item.title}</p>
                          <p className="text-xs sm:text-sm mt-0.5 break-words">{item.value}</p>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Social Links */}
                  <div className="rounded-xl p-4 glass-card">
                    <p className="text-xs font-medium text-muted-foreground mb-3">Follow Us</p>
                    <div className="flex items-center gap-2">
                      {contactInfo?.instagram_url && (
                        <a href={contactInfo.instagram_url} target="_blank" rel="noopener noreferrer"
                          className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-muted flex items-center justify-center hover:bg-pink-500/10 hover:text-pink-500 transition-colors">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                        </a>
                      )}
                      {contactInfo?.linkedin_url && (
                        <a href={contactInfo.linkedin_url} target="_blank" rel="noopener noreferrer"
                          className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-muted flex items-center justify-center hover:bg-blue-500/10 hover:text-blue-500 transition-colors">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.768 1.75-1.768 1.75.79 1.75 1.768-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                        </a>
                      )}
                      {contactInfo?.github_url && (
                        <a href={contactInfo.github_url} target="_blank" rel="noopener noreferrer"
                          className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-muted flex items-center justify-center hover:bg-gray-500/10 hover:text-gray-400 transition-colors">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav />
    </div>
  );
}
