import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Ticket,
  Download,
  Printer,
  Loader2,
  ArrowLeft,
  AlertTriangle,
  CheckCircle,
  FileDown,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { getTicketByQRCode, type EventTicket, getEventById } from '@/services/events';
import {
  getTicketTemplateById,
  getDefaultTicketTemplate,
  generateQRCodeDataUrl,
} from '@/services/ticket-templates';
import type { Event } from '@/types/events';
import type { TicketTemplate } from '@/types/events';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

// Template-based ticket renderer - overlays data on template image
function TemplateTicketRenderer({
  template,
  ticket,
  event,
  qrDataUrl,
  onRendered,
}: {
  template: TicketTemplate;
  ticket: EventTicket;
  event: Event;
  qrDataUrl: string;
  onRendered: (dataUrl: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !template || !qrDataUrl) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions from template
    canvas.width = template.template_width;
    canvas.height = template.template_height;

    // Load and draw template background
    const bgImg = new Image();
    bgImg.crossOrigin = 'anonymous';

    bgImg.onload = () => {
      // Draw template background
      ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

      const config = template.field_config;

      // Helper to draw text with optional styling
      const drawText = (
        text: string,
        fc: {
          x: number;
          y: number;
          width?: number;
          fontSize?: number;
          fontColor?: string;
          fontFamily?: string;
          align?: 'left' | 'center' | 'right';
        } | undefined
      ) => {
        if (!fc) return;

        const x = (fc.x / 100) * canvas.width;
        const y = (fc.y / 100) * canvas.height;
        const maxWidth = fc.width ? (fc.width / 100) * canvas.width : canvas.width * 0.8;

        ctx.font = `bold ${fc.fontSize || 14}px ${fc.fontFamily || 'Arial, sans-serif'}`;
        ctx.fillStyle = fc.fontColor || '#000000';
        ctx.textAlign = fc.align || 'center';
        ctx.textBaseline = 'middle';

        // Add text shadow for better readability
        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = 3;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;

        ctx.fillText(text, x, y, maxWidth);

        // Reset shadow
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;
      };

      // Draw all dynamic fields from template config - AUTO-FILL
      drawText(ticket.participant_name || '', config.participant_name);
      drawText(ticket.ticket_number || '', config.ticket_id);
      drawText(event.title || '', config.event_name);
      drawText(
        event.start_date ? format(new Date(event.start_date), 'MMMM d, yyyy') : 'TBD',
        config.event_date
      );
      drawText(event.start_time || 'TBD', config.event_time);
      drawText(event.venue || 'TBD', config.event_venue);

      // Optional fields
      if (config.department && ticket.participant_department) {
        drawText(ticket.participant_department, config.department);
      }
      if (config.student_id && ticket.participant_student_id) {
        drawText(ticket.participant_student_id, config.student_id);
      }
      if (config.registration_number && ticket.registration_number) {
        drawText(ticket.registration_number, config.registration_number);
      }
      if (config.issue_date) {
        drawText(ticket.created_at ? format(new Date(ticket.created_at), 'MMM d, yyyy') : format(new Date(), 'MMM d, yyyy'), config.issue_date);
      }

      // Draw QR code at configured position - CENTERED
      if (config.qr_code && qrDataUrl) {
        const qrImg = new Image();
        qrImg.onload = () => {
          // Calculate QR position and size - CENTERED at configured position
          const centerPercent = config.qr_code.size || 20;
          const qrSize = (centerPercent / 100) * Math.min(canvas.width, canvas.height);

          // Center coordinates from percentage
          const centerX = (config.qr_code.x / 100) * canvas.width;
          const centerY = (config.qr_code.y / 100) * canvas.height;

          // Calculate top-left corner for centered QR
          const qrX = centerX - qrSize / 2;
          const qrY = centerY - qrSize / 2;

          // Draw white background circle for better visibility
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(centerX, centerY, qrSize / 2 + 8, 0, Math.PI * 2);
          ctx.fill();

          // Draw QR code - perfectly centered
          ctx.drawImage(qrImg, qrX, qrY, qrSize, qrSize);

          // Return rendered image
          onRendered(canvas.toDataURL('image/png'));
        };
        qrImg.src = qrDataUrl;
      } else {
        onRendered(canvas.toDataURL('image/png'));
      }
    };

    bgImg.onerror = () => {
      console.error('Failed to load template image');
      onRendered('');
    };

    bgImg.src = template.template_image_url;
  }, [template, ticket, event, qrDataUrl, onRendered]);

  return <canvas ref={canvasRef} className="hidden" />;
}

// Default card fallback when no template exists
function DefaultTicketCard({
  ticket,
  event,
  qrDataUrl,
}: {
  ticket: EventTicket;
  event: Event;
  qrDataUrl: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-md mx-auto"
    >
      <div className="rounded-xl overflow-hidden shadow-xl border-2 border-primary/20 bg-gradient-to-br from-slate-900 to-slate-800">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-primary/20 to-accent/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Ticket className="w-4 h-4" />
              <span className="text-xs font-mono">{ticket.ticket_number}</span>
            </div>
            <Badge variant={ticket.is_used ? 'secondary' : 'default'}>
              {ticket.is_used ? 'USED' : 'VALID'}
            </Badge>
          </div>
          <h2 className="text-xl font-bold mt-3">{event.title}</h2>
        </div>

        {/* Body */}
        <CardContent className="pt-6">
          {/* QR Code */}
          <div className="text-center mb-6">
            <div className="inline-block p-3 bg-white rounded-lg">
              <img src={qrDataUrl} alt="QR Code" className="w-36 h-36" />
            </div>
            <p className="font-mono text-xs text-muted-foreground mt-2">{ticket.qr_code}</p>
          </div>

          {/* Details */}
          <div className="space-y-3 text-sm">
            <div className="flex justify-between py-2 border-b border-border/50">
              <span className="text-muted-foreground">Participant</span>
              <span className="font-semibold">{ticket.participant_name}</span>
            </div>
            {ticket.participant_department && (
              <div className="flex justify-between py-2 border-b border-border/50">
                <span className="text-muted-foreground">Department</span>
                <span className="font-semibold">{ticket.participant_department}</span>
              </div>
            )}
            {ticket.participant_student_id && (
              <div className="flex justify-between py-2 border-b border-border/50">
                <span className="text-muted-foreground">Student ID</span>
                <span className="font-semibold">{ticket.participant_student_id}</span>
              </div>
            )}
            <div className="flex justify-between py-2 border-b border-border/50">
              <span className="text-muted-foreground">Date</span>
              <span className="font-semibold">
                {event.start_date ? format(new Date(event.start_date), 'MMM d, yyyy') : 'TBD'}
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-border/50">
              <span className="text-muted-foreground">Time</span>
              <span className="font-semibold">{event.start_time || 'TBD'}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-muted-foreground">Venue</span>
              <span className="font-semibold">{event.venue || 'TBD'}</span>
            </div>
          </div>
        </CardContent>
      </div>
    </motion.div>
  );
}

// Main ticket view page
export default function TicketViewPage() {
  const { qrCode } = useParams<{ qrCode: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [ticket, setTicket] = useState<EventTicket | null>(null);
  const [event, setEvent] = useState<Event | null>(null);
  const [template, setTemplate] = useState<TicketTemplate | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [renderedTicket, setRenderedTicket] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load ticket and template data
  useEffect(() => {
    if (!qrCode) return;
    loadTicketData();
  }, [qrCode]);

  async function loadTicketData() {
    try {
      setLoading(true);
      setError(null);

      // Load ticket
      const ticketData = await getTicketByQRCode(qrCode!);
      if (!ticketData) {
        setError('Ticket not found');
        setLoading(false);
        return;
      }
      setTicket(ticketData);

      // Load event
      const eventData = await getEventById(ticketData.event_id);
      if (!eventData) {
        setError('Event not found');
        setLoading(false);
        return;
      }
      setEvent(eventData);

      // Load template - try event-specific first, then default
      let ticketTemplate: TicketTemplate | null = null;

      if (eventData.ticket_template_id) {
        ticketTemplate = await getTicketTemplateById(eventData.ticket_template_id);
      }

      if (!ticketTemplate) {
        ticketTemplate = await getDefaultTicketTemplate();
      }

      setTemplate(ticketTemplate);

      // Generate QR code
      const qrData = JSON.stringify({
        ticket_id: ticketData.ticket_number,
        qr_code: ticketData.qr_code,
        event_id: ticketData.event_id,
        user_id: ticketData.user_id,
        verification: `${window.location.origin}/verify/${ticketData.qr_code}`,
      });
      const qr = await generateQRCodeDataUrl(qrData);
      setQrDataUrl(qr);
    } catch (err: any) {
      console.error('Error loading ticket:', err);
      setError(err.message || 'Failed to load ticket');
    } finally {
      setLoading(false);
    }
  }

  // Handle rendered ticket callback
  const handleRendered = useCallback((dataUrl: string) => {
    setRenderedTicket(dataUrl);
  }, []);

  // Download as PNG
  const handleDownloadPNG = useCallback(() => {
    if (!renderedTicket) return;

    const link = document.createElement('a');
    link.download = `ticket-${ticket?.ticket_number || 'download'}.png`;
    link.href = renderedTicket;
    link.click();

    toast({ title: 'Downloaded!', description: 'Ticket saved as PNG' });
  }, [renderedTicket, ticket, toast]);

  // Download as PDF
  const handleDownloadPDF = useCallback(async () => {
    if (!renderedTicket || !template) return;

    try {
      toast({ title: 'Generating PDF...' });

      // Dynamic import of jsPDF
      const jsPDFModule = await import('jspdf');
      const jsPDF = jsPDFModule.default || jsPDFModule;

      const pdf = new jsPDF({
        orientation: template.template_width > template.template_height ? 'landscape' : 'portrait',
        unit: 'px',
        format: [template.template_width, template.template_height],
      });

      pdf.addImage(renderedTicket, 'PNG', 0, 0, template.template_width, template.template_height);
      pdf.save(`ticket-${ticket?.ticket_number || 'event'}.pdf`);

      toast({ title: 'PDF Downloaded!', description: 'Your ticket has been saved' });
    } catch (err: any) {
      toast({ title: 'PDF Error', description: err.message, variant: 'destructive' });
    }
  }, [renderedTicket, template, ticket, toast]);

  // Print ticket
  const handlePrint = useCallback(() => {
    if (!renderedTicket) return;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Event Ticket - ${ticket?.ticket_number}</title>
            <style>
              * { margin: 0; padding: 0; box-sizing: border-box; }
              body {
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                background: #f5f5f5;
                padding: 20px;
              }
              img {
                max-width: 100%;
                height: auto;
                box-shadow: 0 4px 24px rgba(0,0,0,0.15);
                border-radius: 8px;
              }
              @media print {
                body { background: white; padding: 0; }
                img { box-shadow: none; }
              }
            </style>
          </head>
          <body>
            <img src="${renderedTicket}" alt="Event Ticket" />
            <script>setTimeout(() => window.print(), 300);</script>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  }, [renderedTicket, ticket]);

  // Determine if we have a template
  const hasTemplate = !!template && !!renderedTicket;
  const isValidTicket = ticket && !ticket.is_used && event &&
    (event.status === 'upcoming' || event.status === 'ongoing' || event.status === 'registration_open');

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-950 to-slate-900">
      <Navbar />
      <main className="flex-1">
        {/* Header */}
        <section className="pt-24 pb-6">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="mb-4 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg">
                <Ticket className="w-7 h-7 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold">
                  {hasTemplate ? 'Event Ticket' : 'Participation Ticket'}
                </h1>
                <p className="text-muted-foreground">
                  {hasTemplate ? 'Your custom event pass' : 'Your event entry pass'}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Content */}
        <section className="pb-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-24 gap-4">
                <Loader2 className="w-10 h-10 animate-spin text-primary" />
                <p className="text-muted-foreground">Loading your ticket...</p>
              </div>
            ) : error ? (
              <Card className="max-w-md mx-auto">
                <CardContent className="py-12 text-center">
                  <AlertTriangle className="w-14 h-14 mx-auto text-destructive mb-4" />
                  <h2 className="text-xl font-semibold mb-2">Ticket Not Found</h2>
                  <p className="text-muted-foreground mb-6">{error}</p>
                  <Button onClick={() => navigate('/')}>Go Home</Button>
                </CardContent>
              </Card>
            ) : ticket && event ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Hidden canvas renderer for template */}
                {template && qrDataUrl && (
                  <TemplateTicketRenderer
                    template={template}
                    ticket={ticket}
                    event={event}
                    qrDataUrl={qrDataUrl}
                    onRendered={handleRendered}
                  />
                )}

                {/* Show template-based ticket OR default card */}
                {hasTemplate ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-4"
                  >
                    {/* Status Badge */}
                    <div className="flex justify-center">
                      <Badge
                        variant={ticket.is_used ? 'secondary' : 'default'}
                        className={`text-sm px-4 py-1 ${
                          ticket.is_used
                            ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                            : 'bg-green-500/20 text-green-400 border-green-500/30'
                        }`}
                      >
                        {ticket.is_used ? 'USED' : 'VALID'}
                      </Badge>
                    </div>

                    {/* Rendered Ticket from Template */}
                    <div className="relative rounded-xl overflow-hidden shadow-2xl border border-border/50 max-w-2xl mx-auto">
                      <img
                        src={renderedTicket}
                        alt="Event Ticket"
                        className="w-full h-auto"
                        style={{
                          aspectRatio: `${template!.template_width}/${template!.template_height}`,
                        }}
                      />
                    </div>

                    {/* Ticket ID */}
                    <p className="text-center font-mono text-sm text-muted-foreground">
                      {ticket.ticket_number}
                    </p>
                  </motion.div>
                ) : (
                  <DefaultTicketCard ticket={ticket} event={event} qrDataUrl={qrDataUrl} />
                )}

                {/* Download Actions - Only show for template tickets */}
                {hasTemplate && (
                  <div className="flex flex-wrap justify-center gap-3 max-w-lg mx-auto">
                    <Button onClick={handleDownloadPNG} className="flex-1 min-w-[120px]">
                      <Download className="w-4 h-4 mr-2" />
                      PNG
                    </Button>
                    <Button onClick={handleDownloadPDF} variant="outline" className="flex-1 min-w-[120px]">
                      <FileDown className="w-4 h-4 mr-2" />
                      PDF
                    </Button>
                    <Button onClick={handlePrint} variant="secondary" className="flex-1 min-w-[120px]">
                      <Printer className="w-4 h-4 mr-2" />
                      Print
                    </Button>
                  </div>
                )}

                {/* Status Messages */}
                {isValidTicket && (
                  <div className="max-w-md mx-auto p-4 bg-green-500/10 border border-green-500/30 rounded-lg flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-400 shrink-0" />
                    <span className="text-sm text-green-300">
                      This ticket is valid. Present it at the event entrance for attendance verification.
                    </span>
                  </div>
                )}

                {ticket?.is_used && (
                  <div className="max-w-md mx-auto p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg flex items-center gap-3">
                    <AlertTriangle className="w-5 h-5 text-yellow-400 shrink-0" />
                    <span className="text-sm text-yellow-300">
                      This ticket was used on{' '}
                      {ticket.used_at ? format(new Date(ticket.used_at), 'PPp') : 'N/A'}
                    </span>
                  </div>
                )}
              </motion.div>
            ) : (
              <Card className="max-w-md mx-auto">
                <CardContent className="py-12 text-center text-muted-foreground">
                  No ticket data available
                </CardContent>
              </Card>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
