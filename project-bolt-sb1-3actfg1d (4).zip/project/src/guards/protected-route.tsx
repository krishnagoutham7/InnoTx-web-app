import { Navigate, useLocation } from 'react-router-dom';
import type { UserRole } from '@/types/auth';
import { useAuth, roleRoutes } from '@/contexts/auth';

const VALID_ROLES: UserRole[] = ['super_admin', 'admin', 'faculty', 'ceo', 'program_officer', 'executive', 'student'];

function isValidRole(role: string | undefined): role is UserRole {
  return !!role && VALID_ROLES.includes(role as UserRole);
}

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}

interface RoleGuardProps {
  allowedRoles: UserRole | UserRole[];
  children: React.ReactNode;
}

export function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  const roleArray = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
  if (!roleArray.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
}

interface DashboardGuardProps {
  requiredRole: UserRole;
  children: React.ReactNode;
}

export function DashboardGuard({ requiredRole, children }: DashboardGuardProps) {
  const { user, isLoading, isAuthenticated } = useAuth();
  const location = useLocation();

  console.log('[DashboardGuard]', { path: location.pathname, requiredRole, userRole: user?.role, isLoading, isAuthenticated });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    console.log('[DashboardGuard] not authenticated, redirecting to /login');
    return <Navigate to="/login" replace />;
  }

  if (user.mustChangePassword) {
    console.log('[DashboardGuard] must change password, redirecting');
    return <Navigate to="/change-password" replace />;
  }

  // Handle invalid or null role — assign default and redirect
  if (!isValidRole(user.role)) {
    console.warn('[DashboardGuard] invalid role:', user.role, 'redirecting to /unauthorized');
    return <Navigate to="/unauthorized" replace />;
  }

  if (user.role !== requiredRole) {
    const correctRoute = roleRoutes[user.role];
    console.log('[DashboardGuard] role mismatch, redirecting to', correctRoute);
    if (correctRoute) {
      return <Navigate to={correctRoute} replace />;
    }
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
}
