import { supabase } from '@/lib/supabase';
import type { User, UserRole } from '@/types/auth';

interface AuthUserProfile {
  id: string;
  auth_user_id: string;
  email: string;
  name: string;
  role: string;
  is_active: boolean;
  department: string | null;
  branch: string | null;
  semester: number | null;
  status: string;
  must_change_password: boolean;
}

export async function signInWithEmail(email: string, password: string): Promise<{ user: User | null; error: string | null; mustChangePassword?: boolean }> {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    return { user: null, error: error.message };
  }

  if (!data.user) {
    return { user: null, error: 'No user returned from authentication.' };
  }

  const profile = await getUserProfile(data.user.id);

  if (!profile) {
    await supabase.auth.signOut();
    console.error('[Auth] signIn: profile not found for user', data.user.id);
    return { user: null, error: 'User profile not found. Please contact an administrator.' };
  }

  if (!profile.is_active) {
    await supabase.auth.signOut();
    return { user: null, error: 'Your account has been disabled. Please contact an administrator.' };
  }

  if (profile.status !== 'approved') {
    await supabase.auth.signOut();
    return { user: null, error: 'Your account is pending approval. Please wait for an administrator to approve your registration.' };
  }

  const validRoles = ['super_admin', 'admin', 'faculty', 'ceo', 'program_officer', 'executive', 'student'];
  const role = validRoles.includes(profile.role) ? (profile.role as UserRole) : 'student' as UserRole;
  if (!validRoles.includes(profile.role)) {
    console.warn('[Auth] signIn: invalid role', profile.role, 'defaulting to student');
  }

  if (profile.must_change_password) {
    console.log('[Auth] signIn: must change password', { id: profile.auth_user_id, role });
    return {
      user: {
        id: profile.auth_user_id,
        email: profile.email,
        name: profile.name,
        role,
        mustChangePassword: true,
      },
      error: null,
      mustChangePassword: true,
    };
  }

  console.log('[Auth] signIn: success', { id: profile.auth_user_id, role });

  return {
    user: {
      id: profile.auth_user_id,
      email: profile.email,
      name: profile.name,
      role,
    },
    error: null,
  };
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}

export async function getCurrentUser(): Promise<User | null> {
  const { data } = await supabase.auth.getSession();

  if (!data.session?.user) {
    console.log('[Auth] getCurrentUser: no session');
    return null;
  }

  const profile = await getUserProfile(data.session.user.id);
  if (!profile) {
    console.warn('[Auth] getCurrentUser: profile not found for', data.session.user.id);
    return null;
  }
  if (!profile.is_active) {
    console.warn('[Auth] getCurrentUser: account disabled');
    return null;
  }
  if (profile.status !== 'approved') {
    console.warn('[Auth] getCurrentUser: not approved, status =', profile.status);
    return null;
  }

  const validRoles = ['super_admin', 'admin', 'faculty', 'ceo', 'program_officer', 'executive', 'student'];
  const role = validRoles.includes(profile.role) ? (profile.role as UserRole) : 'student' as UserRole;
  if (!validRoles.includes(profile.role)) {
    console.warn('[Auth] getCurrentUser: invalid role', profile.role, 'defaulting to student');
  }

  console.log('[Auth] getCurrentUser: success', { id: profile.auth_user_id, role });

  return {
    id: profile.auth_user_id,
    email: profile.email,
    name: profile.name,
    role,
    mustChangePassword: profile.must_change_password || undefined,
  };
}

export async function getUserProfile(authUserId: string): Promise<AuthUserProfile | null> {
  const { data, error } = await supabase
    .from('auth_user_profiles')
    .select('*')
    .eq('auth_user_id', authUserId)
    .maybeSingle();

  if (error || !data) return null;
  return data as AuthUserProfile;
}

export function onAuthStateChange(callback: (user: User | null) => void) {
  return supabase.auth.onAuthStateChange((_event, session) => {
    // MUST NOT use await directly — wraps async work in IIFE to avoid deadlock
    if (!session?.user) {
      console.log('[Auth] onAuthStateChange: no session, user = null');
      callback(null);
      return;
    }

    (async () => {
      const user = await getCurrentUser();
      console.log('[Auth] onAuthStateChange: fetched user', user ? { id: user.id, role: user.role } : 'null');
      callback(user);
    })();
  });
}

export async function registerUser(params: {
  email: string;
  password: string;
  name: string;
  department?: string;
  branch?: string;
  semester?: number;
}): Promise<{ success: boolean; error?: string }> {
  const { data, error } = await supabase.auth.signUp({
    email: params.email,
    password: params.password,
  });

  if (error) {
    return { success: false, error: error.message };
  }

  if (!data.user) {
    return { success: false, error: 'Registration failed. Please try again.' };
  }

  const { error: profileError } = await supabase
    .from('auth_user_profiles')
    .insert({
      auth_user_id: data.user.id,
      email: params.email,
      name: params.name,
      role: 'student',
      is_active: true,
      department: params.department || null,
      branch: params.branch || null,
      semester: params.semester || null,
      status: 'pending',
      must_change_password: false,
    });

  if (profileError) {
    return { success: false, error: 'Failed to create user profile. Please contact an administrator.' };
  }

  const { error: portalError } = await supabase
    .from('cms_portal_users')
    .insert({
      email: params.email,
      name: params.name,
      role: 'student',
      is_active: true,
      department: params.department || null,
      branch: params.branch || null,
      semester: params.semester || null,
      status: 'pending',
      must_change_password: false,
      last_login: null,
    });

  if (portalError) {
    console.error('Failed to create portal user record:', portalError.message);
  }

  return { success: true };
}

export async function changePassword(newPassword: string): Promise<{ success: boolean; error?: string }> {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) {
    console.error('[Auth] changePassword: failed', error.message);
    return { success: false, error: error.message };
  }

  const { data } = await supabase.auth.getSession();
  const userId = data.session?.user?.id;
  if (userId) {
    await supabase
      .from('auth_user_profiles')
      .update({ must_change_password: false })
      .eq('auth_user_id', userId);
    console.log('[Auth] changePassword: success, cleared must_change_password');
  }

  return { success: true };
}
