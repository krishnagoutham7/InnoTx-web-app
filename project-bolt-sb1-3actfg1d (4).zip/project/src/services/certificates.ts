import { supabase } from '@/lib/supabase';
import { sendNotificationToUser } from '@/services/cms';
import type {
  CertificateTemplate,
  Certificate,
  CertificateFieldConfigs,
  CertificateFormData,
} from '@/types/certificates';

const TEMPLATE_BUCKET = 'certificate-templates';

// ── Template CRUD ───────────────────────────────────────────────────────────

export async function getCertificateTemplates(): Promise<CertificateTemplate[]> {
  const { data, error } = await supabase
    .from('certificate_templates')
    .select('*')
    .eq('is_active', true)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []) as CertificateTemplate[];
}

export async function getCertificateTemplateById(id: string): Promise<CertificateTemplate | null> {
  const { data, error } = await supabase
    .from('certificate_templates')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as CertificateTemplate | null;
}

export async function getDefaultCertificateTemplate(): Promise<CertificateTemplate | null> {
  const { data, error } = await supabase
    .from('certificate_templates')
    .select('*')
    .eq('is_default', true)
    .eq('is_active', true)
    .maybeSingle();
  if (error) throw error;
  if (data) return data as CertificateTemplate;

  const { data: fallback, error: fbError } = await supabase
    .from('certificate_templates')
    .select('*')
    .eq('is_active', true)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();
  if (fbError) throw fbError;
  return fallback as CertificateTemplate | null;
}

export async function uploadCertificateTemplate(
  file: File,
  name: string,
  description: string,
  userId: string,
  fieldConfig?: Partial<CertificateFieldConfigs>
): Promise<CertificateTemplate> {
  const fileExt = file.name.split('.').pop()?.toLowerCase() || 'png';
  const fileName = `cert_template_${Date.now()}.${fileExt}`;
  const filePath = fileName;

  const { error: uploadError } = await supabase.storage
    .from(TEMPLATE_BUCKET)
    .upload(filePath, file, { upsert: true });

  if (uploadError) throw uploadError;

  const { data: urlData } = supabase.storage.from(TEMPLATE_BUCKET).getPublicUrl(filePath);
  const url = urlData.publicUrl;

  const img = new window.Image();
  img.crossOrigin = 'anonymous';
  const dimensions = await new Promise<{ width: number; height: number }>((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('Image load timeout')), 10000);
    img.onload = () => { clearTimeout(timeout); resolve({ width: img.width, height: img.height }); };
    img.onerror = () => { clearTimeout(timeout); reject(new Error('Failed to load image')); };
    img.src = url;
  });

  const defaultFieldConfig: CertificateFieldConfigs = {
    participant_name: { x: 50, y: 35, width: 80, fontSize: 36, fontColor: '#1a1a2e', fontFamily: 'Georgia', fontWeight: 'bold', align: 'center', dataField: 'participant_name' },
    certificate_number: { x: 50, y: 45, width: 60, fontSize: 14, fontColor: '#555555', fontFamily: 'Courier New', align: 'center', dataField: 'certificate_number' },
    event_name: { x: 50, y: 55, width: 80, fontSize: 22, fontColor: '#0f3460', fontFamily: 'Georgia', align: 'center', dataField: 'event_name' },
    event_date: { x: 35, y: 68, width: 30, fontSize: 16, fontColor: '#333333', fontFamily: 'Arial', align: 'left', dataField: 'event_date' },
    issue_date: { x: 65, y: 68, width: 30, fontSize: 16, fontColor: '#333333', fontFamily: 'Arial', align: 'right', dataField: 'issue_date' },
    qr_code: { x: 90, y: 85, size: 12 },
    ...fieldConfig,
  };

  const { data, error } = await supabase
    .from('certificate_templates')
    .insert({
      name,
      description,
      template_image_url: url,
      template_storage_path: filePath,
      template_width: dimensions.width,
      template_height: dimensions.height,
      field_config: defaultFieldConfig,
      created_by: userId,
    })
    .select()
    .single();

  if (error) {
    await supabase.storage.from(TEMPLATE_BUCKET).remove([filePath]);
    throw error;
  }

  return data as CertificateTemplate;
}

export async function updateCertificateTemplate(
  id: string,
  updates: Partial<CertificateFormData>
): Promise<CertificateTemplate> {
  const { data, error } = await supabase
    .from('certificate_templates')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as CertificateTemplate;
}

export async function deleteCertificateTemplate(id: string): Promise<void> {
  const template = await getCertificateTemplateById(id);
  if (template?.template_storage_path) {
    await supabase.storage.from(TEMPLATE_BUCKET).remove([template.template_storage_path]);
  }
  const { error } = await supabase.from('certificate_templates').delete().eq('id', id);
  if (error) throw error;
}

export async function setDefaultCertificateTemplate(id: string): Promise<void> {
  const { error } = await supabase.rpc('set_default_certificate_template', { p_template_id: id });
  if (error) throw error;
}

export async function updateCertificateTemplateFieldConfig(
  id: string,
  fieldConfig: CertificateFieldConfigs
): Promise<CertificateTemplate> {
  const { data, error } = await supabase
    .from('certificate_templates')
    .update({ field_config: fieldConfig, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as CertificateTemplate;
}

// ── QR Code Generation ──────────────────────────────────────────────────────

export async function generateCertificateQRCodeDataUrl(data: string): Promise<string> {
  const QRCode = await import('qrcode');
  return await QRCode.toDataURL(data, { width: 300, margin: 1 });
}

// ── Certificate Image Generation ────────────────────────────────────────────

function buildFontString(config: {
  fontSize?: number;
  fontFamily?: string;
  fontWeight?: string;
  bold?: boolean;
  italic?: boolean;
}): string {
  const parts: string[] = [];
  if (config.italic) parts.push('italic');
  const weight = config.bold ? 'bold' : config.fontWeight;
  if (weight && weight !== 'normal') parts.push(weight);
  parts.push(`${config.fontSize || 14}px`);
  parts.push(config.fontFamily || 'Arial');
  return parts.join(' ');
}

export async function generateCertificateImage(
  template: CertificateTemplate,
  certificate: Certificate,
  qrCodeDataUrl: string
): Promise<string> {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) { reject(new Error('Canvas context not available')); return; }

    canvas.width = template.template_width;
    canvas.height = template.template_height;

    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const config = template.field_config;

      const drawText = (text: string, fc: any) => {
        const x = (fc.x / 100) * canvas.width;
        const y = (fc.y / 100) * canvas.height;
        const maxWidth = fc.width ? (fc.width / 100) * canvas.width : canvas.width * 0.8;

        ctx.font = buildFontString(fc);
        ctx.fillStyle = fc.fontColor || '#000000';
        ctx.textAlign = fc.align || 'center';
        ctx.textBaseline = 'middle';
        if (fc.letterSpacing && ctx.letterSpacing !== undefined) {
          (ctx as any).letterSpacing = `${fc.letterSpacing}px`;
        }
        ctx.fillText(text, x, y, maxWidth);
        if ((ctx as any).letterSpacing !== undefined) {
          (ctx as any).letterSpacing = '0px';
        }
      };

      if (config.participant_name) drawText(certificate.participant_name, config.participant_name);
      if (config.certificate_number) drawText(certificate.certificate_number, config.certificate_number);
      if (config.event_name) drawText(certificate.event_name, config.event_name);
      if (config.event_date) drawText(certificate.event_date, config.event_date);
      if (config.issue_date) drawText(certificate.issue_date, config.issue_date);

      if (config.qr_code) {
        const qrX = (config.qr_code.x / 100) * canvas.width;
        const qrY = (config.qr_code.y / 100) * canvas.height;
        const qrSize = ((config.qr_code.size || 12) / 100) * Math.min(canvas.width, canvas.height);
        const qrImg = new window.Image();
        qrImg.onload = () => {
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(qrX, qrY, qrSize / 2 + 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.drawImage(qrImg, qrX - qrSize / 2, qrY - qrSize / 2, qrSize, qrSize);
          resolve(canvas.toDataURL('image/png'));
        };
        qrImg.onerror = () => resolve(canvas.toDataURL('image/png'));
        qrImg.src = qrCodeDataUrl;
      } else {
        resolve(canvas.toDataURL('image/png'));
      }
    };
    img.onerror = () => reject(new Error('Failed to load certificate template image'));
    img.src = template.template_image_url;
  });
}

// ── Certificate CRUD ────────────────────────────────────────────────────────

export async function getCertificatesByEvent(eventId: string): Promise<Certificate[]> {
  const { data, error } = await supabase
    .from('certificates')
    .select('*, event:events(id, title, start_date, venue)')
    .eq('event_id', eventId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []) as unknown as Certificate[];
}

export async function getMyCertificates(): Promise<Certificate[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from('certificates')
    .select('*, event:events(id, title, start_date, venue)')
    .eq('user_id', user.id)
    .eq('certificate_status', 'issued')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []) as unknown as Certificate[];
}

export async function getCertificateByNumber(certificateNumber: string): Promise<Certificate | null> {
  const { data, error } = await supabase
    .from('certificates')
    .select('*, event:events(id, title, start_date, venue)')
    .eq('certificate_number', certificateNumber)
    .maybeSingle();
  if (error) throw error;
  return data as unknown as Certificate | null;
}

export async function getCertificateByQRCode(qrCode: string): Promise<Certificate | null> {
  const { data, error } = await supabase
    .from('certificates')
    .select('*, event:events(id, title, start_date, venue)')
    .eq('qr_code', qrCode)
    .maybeSingle();
  if (error) throw error;
  return data as unknown as Certificate | null;
}

// ── Eligible Attendees ──────────────────────────────────────────────────────

export interface EligibleAttendee {
  registration_id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  event_id: string;
  event_title: string;
  event_start_date: string;
  event_venue: string | null;
  attendance_verified: boolean;
  certificate_eligible: boolean;
  has_certificate: boolean;
}

export async function getEligibleAttendees(eventId: string): Promise<EligibleAttendee[]> {
  // Fetch registrations with attendance info
  const { data: regs, error: regError } = await supabase
    .from('event_registrations')
    .select('id, user_id, user_name, user_email, attendance_verified, event_id, registration_status, approval_status')
    .eq('event_id', eventId)
    .in('approval_status', ['approved'])
    .in('registration_status', ['confirmed']);
  if (regError) throw regError;

  // Fetch attendance records for this event
  const { data: attendance, error: attError } = await supabase
    .from('event_attendance')
    .select('registration_id, user_id, certificate_eligible')
    .eq('event_id', eventId);
  if (attError) throw attError;

  // Fetch existing certificates
  const { data: certs, error: certError } = await supabase
    .from('certificates')
    .select('registration_id')
    .eq('event_id', eventId);
  if (certError) throw certError;

  const certRegIds = new Set((certs || []).map((c: any) => c.registration_id));

  // Build eligible list: present + verified
  const attendanceMap = new Map((attendance || []).map((a: any) => [a.registration_id, a]));
  const eligible: EligibleAttendee[] = [];

  for (const reg of (regs || [])) {
    const att = attendanceMap.get(reg.id);
    const isPresent = att?.certificate_eligible === true || reg.attendance_verified === true;
    if (!isPresent) continue;

    eligible.push({
      registration_id: reg.id,
      user_id: reg.user_id,
      user_name: reg.user_name,
      user_email: reg.user_email,
      event_id: eventId,
      event_title: '',
      event_start_date: '',
      event_venue: null,
      attendance_verified: reg.attendance_verified,
      certificate_eligible: att?.certificate_eligible ?? false,
      has_certificate: certRegIds.has(reg.id),
    });
  }

  return eligible;
}

// ── Certificate Generation ───────────────────────────────────────────────────

export async function generateCertificate(
  registrationId: string,
  userId: string,
  userName: string,
  userEmail: string | null,
  eventId: string,
  eventTitle: string,
  eventStartDate: string,
  generatedBy: string
): Promise<Certificate> {
  console.log('[Certificate] generateCertificate: start', { registrationId, userId, eventId });
  const { data: existing } = await supabase
    .from('certificates')
    .select('id')
    .eq('registration_id', registrationId)
    .maybeSingle();
  if (existing) throw new Error('Certificate already exists for this registration');

  let template = await getDefaultCertificateTemplate();
  if (!template) {
    throw new Error('No certificate template found. Please create and set a default template first.');
  }

  // Check event-specific template
  const { data: eventData } = await supabase
    .from('events')
    .select('certificate_template_id')
    .eq('id', eventId)
    .maybeSingle();
  if (eventData?.certificate_template_id) {
    const eventTemplate = await getCertificateTemplateById(eventData.certificate_template_id);
    if (eventTemplate) template = eventTemplate;
  }

  const issueDate = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  const eventDate = new Date(eventStartDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  // Insert certificate record
  const { data: cert, error: certError } = await supabase
    .from('certificates')
    .insert({
      event_id: eventId,
      user_id: userId,
      registration_id: registrationId,
      template_id: template.id,
      participant_name: userName,
      participant_email: userEmail,
      event_name: eventTitle,
      event_date: eventDate,
      issue_date: issueDate,
      generated_by: generatedBy,
      certificate_status: 'issued',
    })
    .select()
    .single();
  if (certError) {
    if (certError.code === 'PGRST116') {
      throw new Error('Certificate creation blocked by security policy. Ensure your role is synced in auth_user_profiles.');
    }
    throw new Error(`Failed to create certificate: ${certError.message}`);
  }
  if (!cert) {
    throw new Error('Certificate creation returned no data. RLS may be blocking the insert.');
  }

  const certificate = cert as Certificate;

  // Generate QR code
  const verifyUrl = `${window.location.origin}/verify-certificate/${certificate.certificate_number}`;
  const qrCodeDataUrl = await generateCertificateQRCodeDataUrl(verifyUrl);

  // Generate certificate image
  const certImageUrl = await generateCertificateImage(template, certificate, qrCodeDataUrl);

  // Update with generated image
  const { error: updateError } = await supabase
    .from('certificates')
    .update({
      generated_certificate_url: certImageUrl,
      generated_at: new Date().toISOString(),
    })
    .eq('id', certificate.id);
  if (updateError) {
    console.error('[Certificate] Failed to store certificate URL:', updateError.message);
  }

  console.log('[Certificate] generateCertificate: success', { id: certificate.id, number: certificate.certificate_number });

  certificate.generated_certificate_url = certImageUrl;

  // Send notification to user
  if (certificate.user_id) {
    sendNotificationToUser({
      userId: certificate.user_id,
      title: 'Certificate Generated',
      message: `Your certificate for "${eventTitle}" has been generated. Certificate Number: ${certificate.certificate_number}`,
      type: 'certificate_generated',
      actionUrl: `/dashboard/student/my-certificates`,
      priority: 'high',
    });
  }

  return certificate;
}

export async function bulkGenerateCertificates(
  eventId: string,
  attendees: EligibleAttendee[],
  generatedBy: string
): Promise<{ success: number; failed: number; errors: string[] }> {
  let success = 0;
  let failed = 0;
  const errors: string[] = [];

  // Get event info
  const { data: eventData } = await supabase
    .from('events')
    .select('id, title, start_date, venue')
    .eq('id', eventId)
    .maybeSingle();
  if (!eventData) throw new Error('Event not found');

  const toGenerate = attendees.filter((a) => !a.has_certificate);

  for (const attendee of toGenerate) {
    try {
      await generateCertificate(
        attendee.registration_id,
        attendee.user_id,
        attendee.user_name,
        attendee.user_email,
        eventId,
        eventData.title,
        eventData.start_date,
        generatedBy
      );
      success++;
    } catch (err: any) {
      failed++;
      errors.push(`${attendee.user_name}: ${err.message}`);
    }
  }

  return { success, failed, errors };
}

// ── Revoke Certificate ──────────────────────────────────────────────────────

export async function revokeCertificate(
  certificateId: string,
  revokedBy: string,
  reason: string
): Promise<void> {
  const { error } = await supabase
    .from('certificates')
    .update({
      certificate_status: 'revoked',
      revoked_by: revokedBy,
      revoked_at: new Date().toISOString(),
      revoke_reason: reason,
      updated_at: new Date().toISOString(),
    })
    .eq('id', certificateId);
  if (error) throw error;
}

// ── Download ────────────────────────────────────────────────────────────────

export async function downloadCertificateAsPNG(certImageUrl: string, fileName: string): Promise<void> {
  const link = window.document.createElement('a');
  link.href = certImageUrl;
  link.download = `${fileName}.png`;
  window.document.body.appendChild(link);
  link.click();
  window.document.body.removeChild(link);
}

export async function downloadCertificateAsPDF(certImageUrl: string, fileName: string): Promise<void> {
  const [{ default: jsPDF }] = await Promise.all([
    import('jspdf'),
  ]);

  const img = new window.Image();
  img.crossOrigin = 'anonymous';
  await new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = reject;
    img.src = certImageUrl;
  });

  const canvas = document.createElement('canvas');
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas not available');
  ctx.drawImage(img, 0, 0);

  const imgData = canvas.toDataURL('image/png');
  const isLandscape = img.width > img.height;
  const pdf = new jsPDF({
    orientation: isLandscape ? 'landscape' : 'portrait',
    unit: 'px',
    format: [img.width, img.height],
  });
  pdf.addImage(imgData, 'PNG', 0, 0, img.width, img.height);
  pdf.save(`${fileName}.pdf`);
}

// ── Verification ────────────────────────────────────────────────────────────

export async function verifyCertificate(certificateNumber: string): Promise<{
  valid: boolean;
  certificate: Certificate | null;
}> {
  const cert = await getCertificateByNumber(certificateNumber);
  return {
    valid: cert !== null && cert.certificate_status === 'issued',
    certificate: cert,
  };
}
