import { supabase } from '@/lib/supabase';

// ── Types ──────────────────────────────────────────────────────────────────────

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  category: string;
  department: string | null;
  email: string | null;
  phone: string | null;
  photo_url: string | null;
  bio: string | null;
  linkedin_url: string | null;
  github_url: string | null;
  instagram_url: string | null;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface GalleryAlbum {
  id: string;
  name: string;
  description: string | null;
  cover_image_url: string | null;
  display_order: number;
  created_at: string;
  updated_at: string;
  image_count?: number;
}

export interface GalleryImage {
  id: string;
  album_id: string | null;
  title: string | null;
  description: string | null;
  image_url: string | null;
  is_featured: boolean;
  display_order: number;
  created_at: string;
}

export interface Announcement {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  priority: 'low' | 'medium' | 'high';
  status: 'draft' | 'published' | 'archived';
  is_pinned: boolean;
  publish_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface HomepageStat {
  label: string;
  value: number;
  suffix: string;
}

export interface HomepageCMS {
  id: string;
  hero_headline: string;
  hero_tagline: string;
  hero_description: string;
  hero_cta_primary_text: string;
  hero_cta_primary_link: string;
  hero_cta_secondary_text: string;
  hero_cta_secondary_link: string;
  stats: HomepageStat[];
  about_title: string;
  about_description: string | null;
  vision_title: string;
  vision_content: string | null;
  mission_title: string;
  mission_content: string | null;
  show_announcements: boolean;
  show_events: boolean;
  show_gallery: boolean;
  created_at: string;
  updated_at: string;
}

export interface SystemSettings {
  id: string;
  portal_name: string;
  portal_tagline: string;
  footer_text: string;
  language: string;
  primary_color: string;
  accent_color: string;
  enable_dark_mode: boolean;
  show_announcements_on_home: boolean;
  show_events_on_home: boolean;
  show_gallery_on_home: boolean;
  updated_at: string;
}

export interface PortalUser {
  id: string;
  auth_user_id?: string;
  email: string;
  name: string;
  role: string;
  is_active: boolean;
  last_login: string | null;
  department: string | null;
  branch: string | null;
  semester: number | null;
  status: string;
  must_change_password: boolean;
  created_at: string;
}

export interface PendingRegistration {
  id: string;
  auth_user_id: string;
  email: string;
  name: string;
  role: string;
  is_active: boolean;
  department: string | null;
  branch: string | null;
  semester: number | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface Role {
  id: string;
  label: string;
  description: string;
  permissions: string[];
  is_system: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface DashboardStats {
  total_users: number;
  total_team_members: number;
  total_announcements: number;
  published_announcements: number;
  total_gallery_images: number;
  total_albums: number;
  active_announcements: number;
}

// ── Team Members ───────────────────────────────────────────────────────────────

export async function getTeamMembers(): Promise<TeamMember[]> {
  const { data, error } = await supabase
    .from('cms_team_members')
    .select('*')
    .order('display_order');
  if (error) throw error;
  return data || [];
}

export async function createTeamMember(member: Omit<TeamMember, 'id' | 'created_at' | 'updated_at'>): Promise<TeamMember> {
  const { data, error } = await supabase
    .from('cms_team_members')
    .insert(member)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updateTeamMember(id: string, updates: Partial<Omit<TeamMember, 'id' | 'created_at'>>): Promise<TeamMember> {
  const { data, error } = await supabase
    .from('cms_team_members')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteTeamMember(id: string): Promise<void> {
  const { error } = await supabase.from('cms_team_members').delete().eq('id', id);
  if (error) throw error;
}

// ── Gallery Albums ────────────────────────────────────────────────────────────

export async function getGalleryAlbums(): Promise<GalleryAlbum[]> {
  const { data: albums, error: albumError } = await supabase
    .from('cms_gallery_albums')
    .select('*')
    .order('display_order');
  if (albumError) throw albumError;

  const { data: counts, error: countError } = await supabase
    .from('cms_gallery_images')
    .select('album_id');
  if (countError) throw countError;

  const countMap: Record<string, number> = {};
  (counts || []).forEach(r => {
    if (r.album_id) countMap[r.album_id] = (countMap[r.album_id] || 0) + 1;
  });

  return (albums || []).map(a => ({ ...a, image_count: countMap[a.id] || 0 }));
}

export async function createGalleryAlbum(album: { name: string; description?: string; cover_image_url?: string; display_order?: number }): Promise<GalleryAlbum> {
  const { data, error } = await supabase
    .from('cms_gallery_albums')
    .insert(album)
    .select()
    .single();
  if (error) throw error;
  return { ...data, image_count: 0 };
}

export async function updateGalleryAlbum(id: string, updates: Partial<{ name: string; description: string; cover_image_url: string; display_order: number }>): Promise<GalleryAlbum> {
  const { data, error } = await supabase
    .from('cms_gallery_albums')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteGalleryAlbum(id: string): Promise<void> {
  const { error } = await supabase.from('cms_gallery_albums').delete().eq('id', id);
  if (error) throw error;
}

// ── Gallery Images ────────────────────────────────────────────────────────────

export async function getGalleryImages(albumId?: string): Promise<GalleryImage[]> {
  let query = supabase.from('cms_gallery_images').select('*').order('display_order');
  if (albumId) query = query.eq('album_id', albumId);
  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}

export async function createGalleryImage(image: { album_id?: string; title?: string; description?: string; image_url?: string; is_featured?: boolean; display_order?: number }): Promise<GalleryImage> {
  const { data, error } = await supabase
    .from('cms_gallery_images')
    .insert(image)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteGalleryImage(id: string): Promise<void> {
  const { error } = await supabase.from('cms_gallery_images').delete().eq('id', id);
  if (error) throw error;
}

// ── Announcements ─────────────────────────────────────────────────────────────

export async function getAnnouncements(): Promise<Announcement[]> {
  const { data, error } = await supabase
    .from('cms_announcements')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function getPublishedAnnouncements(): Promise<Announcement[]> {
  const { data, error } = await supabase
    .from('cms_announcements')
    .select('*')
    .eq('status', 'published')
    .order('is_pinned', { ascending: false })
    .order('publish_date', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function createAnnouncement(ann: Omit<Announcement, 'id' | 'created_at' | 'updated_at'>): Promise<Announcement> {
  const { data, error } = await supabase
    .from('cms_announcements')
    .insert(ann)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updateAnnouncement(id: string, updates: Partial<Omit<Announcement, 'id' | 'created_at'>>): Promise<Announcement> {
  const { data, error } = await supabase
    .from('cms_announcements')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteAnnouncement(id: string): Promise<void> {
  const { error } = await supabase.from('cms_announcements').delete().eq('id', id);
  if (error) throw error;
}

// ── Homepage CMS ──────────────────────────────────────────────────────────────

export async function getHomepageCMS(): Promise<HomepageCMS | null> {
  const { data, error } = await supabase
    .from('cms_homepage')
    .select('*')
    .eq('id', 'default')
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateHomepageCMS(updates: Partial<Omit<HomepageCMS, 'id'>>): Promise<HomepageCMS> {
  const { data, error } = await supabase
    .from('cms_homepage')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', 'default')
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ── System Settings ───────────────────────────────────────────────────────────

export async function getSystemSettings(): Promise<SystemSettings | null> {
  const { data, error } = await supabase
    .from('cms_system_settings')
    .select('*')
    .eq('id', 'default')
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateSystemSettings(updates: Partial<Omit<SystemSettings, 'id'>>): Promise<SystemSettings> {
  const { data, error } = await supabase
    .from('cms_system_settings')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', 'default')
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ── Portal Users ──────────────────────────────────────────────────────────────

export async function getPortalUsers(): Promise<PortalUser[]> {
  const { data, error } = await supabase
    .from('auth_user_profiles')
    .select('id, auth_user_id, email, name, role, is_active, department, branch, semester, status, must_change_password, created_at')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []).map((u: any) => ({
    id: u.id,
    auth_user_id: u.auth_user_id,
    email: u.email,
    name: u.name,
    role: u.role,
    is_active: u.is_active,
    department: u.department,
    branch: u.branch,
    semester: u.semester,
    status: u.status,
    must_change_password: u.must_change_password,
    created_at: u.created_at,
    last_login: null,
  })) as PortalUser[];
}

export async function createPortalUser(user: Omit<PortalUser, 'id' | 'created_at'>): Promise<PortalUser> {
  const { data, error } = await supabase
    .from('cms_portal_users')
    .insert(user)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updatePortalUser(id: string, updates: Partial<Omit<PortalUser, 'id' | 'created_at'>>): Promise<PortalUser> {
  const { data: authProfile } = await supabase
    .from('auth_user_profiles')
    .select('email')
    .eq('id', id)
    .maybeSingle();
  const email = authProfile?.email;
  if (!email) throw new Error('User not found');

  const updateFields: Record<string, any> = { ...updates };

  const { data: portalData, error: portalError } = await supabase
    .from('cms_portal_users')
    .update(updateFields)
    .eq('email', email)
    .select()
    .maybeSingle();
  if (portalError) throw portalError;

  const authUpdate: Record<string, any> = { updated_at: new Date().toISOString() };
  if (updates.role !== undefined) authUpdate.role = updates.role;
  if (updates.is_active !== undefined) authUpdate.is_active = updates.is_active;
  if (updates.status !== undefined) authUpdate.status = updates.status;
  if (updates.must_change_password !== undefined) authUpdate.must_change_password = updates.must_change_password;
  if (updates.name !== undefined) authUpdate.name = updates.name;
  if (updates.department !== undefined) authUpdate.department = updates.department;
  if (updates.branch !== undefined) authUpdate.branch = updates.branch;
  if (updates.semester !== undefined) authUpdate.semester = updates.semester;

  const { error: authError } = await supabase
    .from('auth_user_profiles')
    .update(authUpdate)
    .eq('email', email);
  if (authError) {
    console.error('[UserMgmt] Failed to sync auth_user_profiles:', authError.message);
  } else {
    console.log('[UserMgmt] updatePortalUser: synced to auth_user_profiles', { email, fields: Object.keys(authUpdate) });
  }

  return portalData || { ...updates, id, email } as PortalUser;
}

export async function deletePortalUser(id: string, authUserId?: string): Promise<void> {
  if (!authUserId) {
    const { data: profile } = await supabase
      .from('auth_user_profiles')
      .select('auth_user_id')
      .eq('id', id)
      .maybeSingle();
    if (!profile?.auth_user_id) throw new Error('Could not find auth user ID for deletion');
    authUserId = profile.auth_user_id;
  }

  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) throw new Error('Not authenticated');

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const response = await fetch(`${supabaseUrl}/functions/v1/delete-user`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
    },
    body: JSON.stringify({ userId: authUserId, profileId: id }),
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || `Deletion failed (HTTP ${response.status})`);
  }
}

// ── College Info ──────────────────────────────────────────────────────────────

export interface CollegeInfo {
  id: string;
  name: string;
  short_name: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  map_embed_url: string;
  map_link: string;
  portal_name: string;
  portal_tagline: string;
  portal_description: string;
  institution_type: string;
  district: string;
  state: string;
  programme: string;
  updated_at: string;
}

export async function getCollegeInfo(): Promise<CollegeInfo | null> {
  const { data, error } = await supabase
    .from('cms_college_info')
    .select('*')
    .eq('id', 'default')
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateCollegeInfo(updates: Partial<Omit<CollegeInfo, 'id'>>): Promise<CollegeInfo> {
  const { data, error } = await supabase
    .from('cms_college_info')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', 'default')
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ── Contact Info ──────────────────────────────────────────────────────────────

export interface ContactInfo {
  id: string;
  address: string;
  phone: string;
  email: string;
  office_hours: string;
  saturday_hours: string;
  instagram_url: string;
  twitter_url: string;
  linkedin_url: string;
  github_url: string;
  mail_url: string;
  updated_at: string;
}

export async function getContactInfo(): Promise<ContactInfo | null> {
  const { data, error } = await supabase
    .from('cms_contact_info')
    .select('*')
    .eq('id', 'default')
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateContactInfo(updates: Partial<Omit<ContactInfo, 'id'>>): Promise<ContactInfo> {
  const { data, error } = await supabase
    .from('cms_contact_info')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', 'default')
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ── About Page ────────────────────────────────────────────────────────────────

export interface AboutPage {
  id: string;
  vision_heading: string;
  vision_content: string;
  mission_heading: string;
  mission_content: string;
  obj_1_title: string; obj_1_description: string;
  obj_2_title: string; obj_2_description: string;
  obj_3_title: string; obj_3_description: string;
  obj_4_title: string; obj_4_description: string;
  obj_5_title: string; obj_5_description: string;
  obj_6_title: string; obj_6_description: string;
  iedc_title: string;
  iedc_description_1: string;
  iedc_description_2: string;
  iedc_description_3: string;
  ksum_title: string;
  ksum_description_1: string;
  ksum_description_2: string;
  ksum_description_3: string;
  ksum_website: string;
  updated_at: string;
}

export async function getAboutPage(): Promise<AboutPage | null> {
  const { data, error } = await supabase
    .from('cms_about_page')
    .select('*')
    .eq('id', 'default')
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateAboutPage(updates: Partial<Omit<AboutPage, 'id'>>): Promise<AboutPage> {
  const { data, error } = await supabase
    .from('cms_about_page')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', 'default')
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ── Dashboard Stats ───────────────────────────────────────────────────────────

export async function getDashboardStats(): Promise<DashboardStats> {
  const [users, teamMembers, announcements, galleryImages, galleryAlbums] = await Promise.all([
    supabase.from('cms_portal_users').select('id', { count: 'exact', head: true }),
    supabase.from('cms_team_members').select('id', { count: 'exact', head: true }).eq('is_active', true),
    supabase.from('cms_announcements').select('id, status', { count: 'exact' }),
    supabase.from('cms_gallery_images').select('id', { count: 'exact', head: true }),
    supabase.from('cms_gallery_albums').select('id', { count: 'exact', head: true }),
  ]);

  const annData = (announcements.data || []) as Array<{ id: string; status: string }>;
  const published = annData.filter(a => a.status === 'published').length;

  return {
    total_users: users.count || 0,
    total_team_members: teamMembers.count || 0,
    total_announcements: announcements.count || 0,
    published_announcements: published,
    total_gallery_images: galleryImages.count || 0,
    total_albums: galleryAlbums.count || 0,
    active_announcements: published,
  };
}

// ── Pending Registrations ──────────────────────────────────────────────────────

export async function getPendingRegistrations(): Promise<PendingRegistration[]> {
  const { data, error } = await supabase
    .from('auth_user_profiles')
    .select('*')
    .eq('status', 'pending')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []) as PendingRegistration[];
}

export async function approveUser(id: string, role: string): Promise<void> {
  const profile = await supabase.from('auth_user_profiles').select('email').eq('id', id).maybeSingle();
  const email = profile.data?.email;

  const { error } = await supabase
    .from('auth_user_profiles')
    .update({ status: 'approved', role, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;

  if (email) {
    await supabase
      .from('cms_portal_users')
      .update({ status: 'approved', role, updated_at: new Date().toISOString() })
      .eq('email', email);
  }
}

export async function rejectUser(id: string): Promise<void> {
  const profile = await supabase.from('auth_user_profiles').select('email, auth_user_id').eq('id', id).maybeSingle();
  const email = profile.data?.email;
  const authUserId = profile.data?.auth_user_id;

  const { error } = await supabase
    .from('auth_user_profiles')
    .update({ status: 'rejected', is_active: false, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;

  if (email) {
    await supabase
      .from('cms_portal_users')
      .update({ status: 'rejected', is_active: false, updated_at: new Date().toISOString() })
      .eq('email', email);
  }

  // Disable the auth user so they can't log in
  if (authUserId) {
    const serviceRoleKey = import.meta.env.VITE_SUPABASE_SERVICE_ROLE_KEY;
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    if (serviceRoleKey && supabaseUrl) {
      await fetch(`${supabaseUrl}/auth/v1/admin/users/${authUserId}`, {
        method: 'DELETE',
        headers: {
          apikey: serviceRoleKey,
          Authorization: `Bearer ${serviceRoleKey}`,
        },
      });
    }
  }
}

export async function forcePasswordReset(userId: string): Promise<void> {
  const { data: authProfile } = await supabase
    .from('auth_user_profiles')
    .select('email')
    .eq('id', userId)
    .maybeSingle();
  const email = authProfile?.email;
  if (!email) throw new Error('User email not found');

  const { error: authError } = await supabase
    .from('auth_user_profiles')
    .update({ must_change_password: true, updated_at: new Date().toISOString() })
    .eq('email', email);
  if (authError) throw authError;

  await supabase
    .from('cms_portal_users')
    .update({ must_change_password: true })
    .eq('email', email);
}

// ── Roles ──────────────────────────────────────────────────────────────────────

export async function getRoles(): Promise<Role[]> {
  const { data, error } = await supabase
    .from('cms_roles')
    .select('*')
    .order('display_order');
  if (error) throw error;
  return (data || []) as Role[];
}

export async function createRole(role: Omit<Role, 'created_at' | 'updated_at'>): Promise<Role> {
  const { data, error } = await supabase
    .from('cms_roles')
    .insert(role)
    .select()
    .single();
  if (error) throw error;
  return data as Role;
}

export async function updateRole(id: string, updates: Partial<Omit<Role, 'id' | 'created_at'>>): Promise<Role> {
  const { data, error } = await supabase
    .from('cms_roles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as Role;
}

export async function deleteRole(id: string): Promise<void> {
  const { error } = await supabase.from('cms_roles').delete().eq('id', id);
  if (error) throw error;
}

// ── Gallery Storage ────────────────────────────────────────────────────────────

export async function uploadGalleryImage(file: File, path: string): Promise<string> {
  const { data, error } = await supabase.storage
    .from('gallery')
    .upload(path, file, { upsert: true });
  if (error) throw error;

  const { data: urlData } = supabase.storage
    .from('gallery')
    .getPublicUrl(data.path);

  return urlData.publicUrl;
}

export async function deleteGalleryStorageFile(path: string): Promise<void> {
  const { error } = await supabase.storage
    .from('gallery')
    .remove([path]);
  if (error) throw error;
}

export async function uploadTeamPhoto(file: File, path: string): Promise<string> {
  const { data, error } = await supabase.storage
    .from('gallery')
    .upload(path, file, { upsert: true });
  if (error) throw error;

  const { data: urlData } = supabase.storage
    .from('gallery')
    .getPublicUrl(data.path);

  return urlData.publicUrl;
}

// ── Notifications ──────────────────────────────────────────────────────────────

export interface Notification {
  id: string;
  title: string;
  message: string;
  notification_type: 'event_alert' | 'meeting_alert' | 'certificate_available' | 'announcement' | 'custom' | 'registration_submitted' | 'registration_approved' | 'registration_rejected' | 'ticket_generated' | 'attendance_verified' | 'certificate_generated' | 'role_changed' | 'password_reset' | 'event_published';
  target_type: 'all' | 'role' | 'department' | 'team' | 'individual';
  target_role: string[] | null;
  target_department: string[] | null;
  target_user_ids: string[] | null;
  sender_id: string | null;
  priority_level: 'low' | 'medium' | 'high' | 'critical';
  scheduled_at: string | null;
  sent_at: string | null;
  expires_at: string | null;
  status: 'draft' | 'scheduled' | 'sending' | 'sent' | 'cancelled' | 'expired';
  attachment_url: string | null;
  action_url: string | null;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
  sender_name?: string;
  recipient_count?: number;
  read_count?: number;
}

export interface UserNotification {
  id: string;
  notification_id: string;
  user_id: string;
  is_read: boolean;
  read_at: string | null;
  delivered_at: string | null;
  created_at: string;
  notification?: Notification;
}

export interface NotificationLog {
  id: string;
  notification_id: string | null;
  action_type: string;
  performed_by: string | null;
  timestamp: string;
  metadata: Record<string, any>;
}

export interface NotificationStats {
  total_sent: number;
  total_read: number;
  read_rate: number;
  by_type: Record<string, number>;
  by_priority: Record<string, number>;
  recent_count: number;
}

export interface CreateNotificationInput {
  title: string;
  message: string;
  notification_type: Notification['notification_type'];
  target_type: Notification['target_type'];
  target_role?: string[];
  target_department?: string[];
  target_user_ids?: string[];
  priority_level?: Notification['priority_level'];
  scheduled_at?: string;
  expires_at?: string;
  attachment_url?: string;
  metadata?: Record<string, any>;
  send_now?: boolean;
}

export async function getNotifications(filters?: {
  status?: string;
  type?: string;
  priority?: string;
  search?: string;
}): Promise<Notification[]> {
  let query = supabase
    .from('notifications')
    .select('*')
    .order('created_at', { ascending: false });

  if (filters?.status) query = query.eq('status', filters.status);
  if (filters?.type) query = query.eq('notification_type', filters.type);
  if (filters?.priority) query = query.eq('priority_level', filters.priority);
  if (filters?.search) query = query.ilike('title', `%${filters.search}%`);

  const { data, error } = await query;
  if (error) throw error;

  const notificationsWithCounts = await Promise.all(
    (data || []).map(async (n) => {
      const { count: recipientCount } = await supabase
        .from('user_notifications')
        .select('*', { count: 'exact', head: true })
        .eq('notification_id', n.id);

      const { count: readCount } = await supabase
        .from('user_notifications')
        .select('*', { count: 'exact', head: true })
        .eq('notification_id', n.id)
        .eq('is_read', true);

      return {
        ...n,
        recipient_count: recipientCount || 0,
        read_count: readCount || 0,
      };
    })
  );

  return notificationsWithCounts;
}

export async function getNotification(id: string): Promise<Notification | null> {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('id', id)
    .single();
  if (error) throw error;
  return data;
}

export async function createNotification(input: CreateNotificationInput): Promise<Notification> {
  const status = input.send_now ? 'sent' : (input.scheduled_at ? 'scheduled' : 'draft');

  const { data, error } = await supabase
    .from('notifications')
    .insert({
      title: input.title,
      message: input.message,
      notification_type: input.notification_type,
      target_type: input.target_type,
      target_role: input.target_role || null,
      target_department: input.target_department || null,
      target_user_ids: input.target_user_ids || null,
      priority_level: input.priority_level || 'medium',
      scheduled_at: input.scheduled_at || null,
      sent_at: input.send_now ? new Date().toISOString() : null,
      expires_at: input.expires_at || null,
      attachment_url: input.attachment_url || null,
      metadata: input.metadata || {},
      status,
    })
    .select()
    .single();

  if (error) throw error;

  await logNotificationAction(data.id, 'created', null);

  if (input.send_now) {
    await deliverNotification(data);
  }

  return data;
}

export async function updateNotification(id: string, updates: Partial<CreateNotificationInput>): Promise<Notification> {
  const { data: existing } = await supabase
    .from('notifications')
    .select('*')
    .eq('id', id)
    .single();

  if (!existing) throw new Error('Notification not found');

  const updateData: Record<string, any> = {
    ...updates,
    updated_at: new Date().toISOString(),
  };

  if (updates.send_now && existing.status === 'draft') {
    updateData.status = 'sent';
    updateData.sent_at = new Date().toISOString();
  }

  const { data, error } = await supabase
    .from('notifications')
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;

  await logNotificationAction(id, 'updated', null);

  if (updates.send_now && existing.status === 'draft') {
    await deliverNotification(data);
  }

  return data;
}

export async function deleteNotification(id: string): Promise<void> {
  await logNotificationAction(id, 'deleted', null);

  const { error } = await supabase
    .from('notifications')
    .delete()
    .eq('id', id);
  if (error) throw error;
}

export async function cancelNotification(id: string): Promise<Notification> {
  const { data, error } = await supabase
    .from('notifications')
    .update({ status: 'cancelled', updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;

  await logNotificationAction(id, 'cancelled', null);
  return data;
}

async function deliverNotification(notification: Notification): Promise<void> {
  let userIds: string[] = [];

  if (notification.target_type === 'all') {
    const { data: users } = await supabase
      .from('auth_user_profiles')
      .select('auth_user_id')
      .eq('is_active', true)
      .eq('status', 'approved');
    userIds = (users || []).map(u => u.auth_user_id);
  } else if (notification.target_type === 'individual' && notification.target_user_ids) {
    userIds = notification.target_user_ids;
  } else if (notification.target_type === 'role' && notification.target_role) {
    const { data: users } = await supabase
      .from('auth_user_profiles')
      .select('auth_user_id')
      .eq('is_active', true)
      .eq('status', 'approved')
      .in('role', notification.target_role);
    userIds = (users || []).map(u => u.auth_user_id);
  } else if (notification.target_type === 'department' && notification.target_department) {
    const { data: users } = await supabase
      .from('auth_user_profiles')
      .select('auth_user_id')
      .eq('is_active', true)
      .eq('status', 'approved')
      .in('department', notification.target_department);
    userIds = (users || []).map(u => u.auth_user_id);
  }

  if (userIds.length > 0) {
    const inserts = userIds.map(userId => ({
      notification_id: notification.id,
      user_id: userId,
      delivered_at: new Date().toISOString(),
    }));

    const { error } = await supabase
      .from('user_notifications')
      .insert(inserts);

    if (error) console.error('Failed to deliver notifications:', error);
  }

  await logNotificationAction(notification.id, 'sent', null, { recipient_count: userIds.length });
}

async function logNotificationAction(
  notificationId: string,
  actionType: string,
  performedBy: string | null,
  metadata?: Record<string, any>
): Promise<void> {
  await supabase
    .from('notification_logs')
    .insert({
      notification_id: notificationId,
      action_type: actionType,
      performed_by: performedBy,
      metadata: metadata || {},
    });
}

export async function getUserNotifications(filters?: {
  is_read?: boolean;
  type?: string;
  limit?: number;
}): Promise<UserNotification[]> {
  const userId = (await supabase.auth.getUser()).data.user?.id;
  if (!userId) return [];

  let query = supabase
    .from('user_notifications')
    .select('*, notification:notifications(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (filters?.is_read !== undefined) {
    query = query.eq('is_read', filters.is_read);
  }

  if (filters?.limit) {
    query = query.limit(filters.limit);
  }

  const { data, error } = await query;
  if (error) throw error;

  let result = data || [];
  if (filters?.type) {
    result = result.filter(un => un.notification?.notification_type === filters.type);
  }

  return result as UserNotification[];
}

export async function getUnreadNotificationCount(): Promise<number> {
  const userId = (await supabase.auth.getUser()).data.user?.id;
  if (!userId) return 0;

  const { count, error } = await supabase
    .from('user_notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('is_read', false);

  if (error) throw error;
  return count || 0;
}

export async function markNotificationAsRead(userNotificationId: string): Promise<void> {
  const { error } = await supabase
    .from('user_notifications')
    .update({
      is_read: true,
      read_at: new Date().toISOString(),
    })
    .eq('id', userNotificationId);
  if (error) throw error;

  const { data: un } = await supabase
    .from('user_notifications')
    .select('notification_id')
    .eq('id', userNotificationId)
    .single();

  if (un) {
    await logNotificationAction(un.notification_id, 'read', null);
  }
}

export async function markAllNotificationsAsRead(): Promise<void> {
  const userId = (await supabase.auth.getUser()).data.user?.id;
  if (!userId) return;

  const { error } = await supabase
    .from('user_notifications')
    .update({
      is_read: true,
      read_at: new Date().toISOString(),
    })
    .eq('user_id', userId)
    .eq('is_read', false);
  if (error) throw error;
}

export async function deleteUserNotification(userNotificationId: string): Promise<void> {
  const { error } = await supabase
    .from('user_notifications')
    .delete()
    .eq('id', userNotificationId);
  if (error) throw error;
}

export async function getNotificationStats(): Promise<NotificationStats> {
  const { count: totalSent } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'sent');

  const { count: totalRead } = await supabase
    .from('user_notifications')
    .select('*', { count: 'exact', head: true })
    .eq('is_read', true);

  const { data: typeData } = await supabase
    .from('notifications')
    .select('notification_type')
    .eq('status', 'sent');

  const byType: Record<string, number> = {};
  (typeData || []).forEach(n => {
    byType[n.notification_type] = (byType[n.notification_type] || 0) + 1;
  });

  const { data: priorityData } = await supabase
    .from('notifications')
    .select('priority_level')
    .eq('status', 'sent');

  const byPriority: Record<string, number> = {};
  (priorityData || []).forEach(n => {
    byPriority[n.priority_level] = (byPriority[n.priority_level] || 0) + 1;
  });

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

  const { count: recentCount } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'sent')
    .gte('sent_at', sevenDaysAgo.toISOString());

  return {
    total_sent: totalSent || 0,
    total_read: totalRead || 0,
    read_rate: totalSent ? (totalRead || 0) / totalSent : 0,
    by_type: byType,
    by_priority: byPriority,
    recent_count: recentCount || 0,
  };
}

export async function getNotificationLogs(notificationId?: string): Promise<NotificationLog[]> {
  let query = supabase
    .from('notification_logs')
    .select('*')
    .order('timestamp', { ascending: false })
    .limit(100);

  if (notificationId) {
    query = query.eq('notification_id', notificationId);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}

export function subscribeToUserNotifications(
  userId: string,
  callback: (payload: any) => void
) {
  return supabase
    .channel('user_notifications_changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'user_notifications',
        filter: `user_id=eq.${userId}`,
      },
      callback
    )
    .subscribe();
}

export function subscribeToUnreadCount(
  userId: string,
  callback: () => void
) {
  return supabase
    .channel('unread_count_changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'user_notifications',
        filter: `user_id=eq.${userId}`,
      },
      callback
    )
    .subscribe();
}

// ── Direct notification helpers (call DB functions via RPC) ──────────────────

export async function sendNotificationToUser(params: {
  userId: string;
  title: string;
  message: string;
  type?: string;
  actionUrl?: string;
  priority?: string;
  metadata?: Record<string, any>;
}): Promise<string | null> {
  const { data, error } = await supabase.rpc('send_notification_to_user', {
    p_user_id: params.userId,
    p_title: params.title,
    p_message: params.message,
    p_type: params.type || 'custom',
    p_action_url: params.actionUrl || null,
    p_priority: params.priority || 'medium',
    p_metadata: params.metadata || {},
  });
  if (error) {
    console.error('[Notification] sendNotificationToUser error:', error.message);
    return null;
  }
  return data as string | null;
}

export async function sendNotificationToAdmins(params: {
  title: string;
  message: string;
  type?: string;
  actionUrl?: string;
  priority?: string;
  metadata?: Record<string, any>;
}): Promise<void> {
  const { error } = await supabase.rpc('send_notification_to_admins', {
    p_title: params.title,
    p_message: params.message,
    p_type: params.type || 'custom',
    p_action_url: params.actionUrl || null,
    p_priority: params.priority || 'medium',
    p_metadata: params.metadata || {},
  });
  if (error) {
    console.error('[Notification] sendNotificationToAdmins error:', error.message);
  }
}
