import { supabase } from '@/lib/supabase';
import type { Event, EventRegistration } from '@/types/events';
import type { TicketTemplate, TicketTemplateFormData, TicketFieldConfigs } from '@/types/events';

const TEMPLATE_BUCKET = 'ticket-templates';

// ── Ticket Template CRUD ─────────────────────────────────────────────────────────

export async function getTicketTemplates(): Promise<TicketTemplate[]> {
  const { data, error } = await supabase
    .from('ticket_templates')
    .select('*')
    .eq('is_active', true)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []) as TicketTemplate[];
}

export async function getTicketTemplateById(id: string): Promise<TicketTemplate | null> {
  const { data, error } = await supabase
    .from('ticket_templates')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as TicketTemplate | null;
}

export async function getDefaultTicketTemplate(): Promise<TicketTemplate | null> {
  const { data, error } = await supabase
    .from('ticket_templates')
    .select('*')
    .eq('is_default', true)
    .eq('is_active', true)
    .maybeSingle();
  if (error) throw error;
  return data as TicketTemplate | null;
}

export async function uploadTicketTemplate(
  file: File,
  name: string,
  description: string,
  userId: string,
  fieldConfig?: Partial<TicketFieldConfigs>
): Promise<TicketTemplate> {
  const fileExt = file.name.split('.').pop()?.toLowerCase() || 'png';
  const fileName = `template_${Date.now()}.${fileExt}`;
  const filePath = fileName;

  // Upload file
  const { error: uploadError } = await supabase.storage
    .from(TEMPLATE_BUCKET)
    .upload(filePath, file, { upsert: true });

  if (uploadError) {
    console.error('Storage upload error:', uploadError);
    throw uploadError;
  }

  // Get public URL
  const { data: urlData } = supabase.storage.from(TEMPLATE_BUCKET).getPublicUrl(filePath);
  const url = urlData.publicUrl;

  // Get image dimensions with timeout
  const img = new window.Image();
  img.crossOrigin = 'anonymous';
  const dimensions = await new Promise<{ width: number; height: number }>((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error('Image load timeout'));
    }, 10000);

    img.onload = () => {
      clearTimeout(timeout);
      resolve({ width: img.width, height: img.height });
    };
    img.onerror = () => {
      clearTimeout(timeout);
      reject(new Error('Failed to load image'));
    };
    img.src = url;
  });

  // Default field config with sensible positions
  const defaultFieldConfig: TicketFieldConfigs = {
    participant_name: { x: 50, y: 35, width: 40, fontSize: 18, fontColor: '#ffffff', fontFamily: 'Arial', align: 'center' },
    ticket_id: { x: 50, y: 50, width: 40, fontSize: 10, fontColor: '#cccccc', fontFamily: 'monospace', align: 'center' },
    event_name: { x: 50, y: 65, width: 40, fontSize: 14, fontColor: '#ffffff', fontFamily: 'Arial', align: 'center' },
    event_date: { x: 20, y: 80, width: 30, fontSize: 11, fontColor: '#aaaaaa', fontFamily: 'Arial', align: 'left' },
    event_time: { x: 80, y: 80, width: 15, fontSize: 11, fontColor: '#aaaaaa', fontFamily: 'Arial', align: 'right' },
    event_venue: { x: 50, y: 88, width: 60, fontSize: 10, fontColor: '#999999', fontFamily: 'Arial', align: 'center' },
    qr_code: { x: 85, y: 50, size: 20 },
  };

  // Create template record
  const { data, error } = await supabase
    .from('ticket_templates')
    .insert({
      name,
      description,
      template_image_url: url,
      template_storage_path: filePath,
      template_width: dimensions.width,
      template_height: dimensions.height,
      field_config: { ...defaultFieldConfig, ...fieldConfig },
      created_by: userId,
    })
    .select()
    .single();

  if (error) {
    // Cleanup uploaded file
    await supabase.storage.from(TEMPLATE_BUCKET).remove([filePath]);
    throw error;
  }

  return data as TicketTemplate;
}

export async function updateTicketTemplate(
  id: string,
  updates: Partial<TicketTemplateFormData>
): Promise<TicketTemplate> {
  const { data, error } = await supabase
    .from('ticket_templates')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data as TicketTemplate;
}

export async function deleteTicketTemplate(id: string): Promise<void> {
  // Get template to find storage path
  const template = await getTicketTemplateById(id);
  if (template?.template_storage_path) {
    await supabase.storage.from(TEMPLATE_BUCKET).remove([template.template_storage_path]);
  }

  const { error } = await supabase.from('ticket_templates').delete().eq('id', id);
  if (error) throw error;
}

export async function setDefaultTicketTemplate(id: string): Promise<void> {
  const { error } = await supabase.rpc('set_default_ticket_template', { p_template_id: id });
  if (error) throw error;
}

export async function updateTicketTemplateFieldConfig(
  id: string,
  fieldConfig: TicketFieldConfigs
): Promise<TicketTemplate> {
  const { data, error } = await supabase
    .from('ticket_templates')
    .update({
      field_config: fieldConfig,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data as TicketTemplate;
}

// ── Ticket Generation ─────────────────────────────────────────────────────────

// Generate QR code data URL using dynamic import
export async function generateQRCodeDataUrl(data: string): Promise<string> {
  const QRCode = await import('qrcode');
  return await QRCode.toDataURL(data, { width: 200, margin: 1 });
}

// Generate ticket image using template and event/registration data
export async function generateTicketImage(
  template: TicketTemplate,
  registration: EventRegistration,
  event: Event,
  qrCodeDataUrl: string
): Promise<string> {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      reject(new Error('Canvas context not available'));
      return;
    }

    canvas.width = template.template_width;
    canvas.height = template.template_height;

    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      // Draw template background
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      const config = template.field_config;

      // Helper to draw text
      const drawText = (text: string, fc: { x: number; y: number; width?: number; fontSize?: number; fontColor?: string; fontFamily?: string; fontWeight?: string; align?: 'left' | 'center' | 'right'; letterSpacing?: number; bold?: boolean; italic?: boolean; underline?: boolean }) => {
        const x = (fc.x / 100) * canvas.width;
        const y = (fc.y / 100) * canvas.height;
        const maxWidth = fc.width ? (fc.width / 100) * canvas.width : canvas.width * 0.8;

        const parts: string[] = [];
        if (fc.italic) parts.push('italic');
        const weight = fc.bold ? 'bold' : fc.fontWeight;
        if (weight && weight !== 'normal') parts.push(weight);
        parts.push(`${fc.fontSize || 12}px`);
        parts.push(fc.fontFamily || 'Arial');
        ctx.font = parts.join(' ');

        if (fc.letterSpacing && (ctx as any).letterSpacing !== undefined) {
          (ctx as any).letterSpacing = `${fc.letterSpacing}px`;
        }

        ctx.fillStyle = fc.fontColor || '#000000';
        ctx.textAlign = fc.align || 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, x, y, maxWidth);

        if (fc.underline) {
          ctx.strokeStyle = fc.fontColor || '#000000';
          ctx.lineWidth = Math.max(1, (fc.fontSize || 12) / 12);
          const textWidth = ctx.measureText(text).width;
          let underlineX = x;
          if (fc.align === 'center') underlineX = x - textWidth / 2;
          else if (fc.align === 'right') underlineX = x - textWidth;
          const underlineY = y + (fc.fontSize || 12) / 2 + 2;
          ctx.beginPath();
          ctx.moveTo(underlineX, underlineY);
          ctx.lineTo(underlineX + textWidth, underlineY);
          ctx.stroke();
        }

        if ((ctx as any).letterSpacing !== undefined) {
          (ctx as any).letterSpacing = '0px';
        }
      };

      // Draw all fields
      drawText(registration.user_name, config.participant_name);
      drawText(registration.ticket_id || '', config.ticket_id);
      drawText(event.title, config.event_name);
      drawText(new Date(event.start_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }), config.event_date);
      drawText(event.start_time || '', config.event_time);
      drawText(event.venue || '', config.event_venue);
      if (registration.department && config.department) {
        drawText(registration.department, config.department);
      }

      // Draw QR code
      if (config.qr_code) {
        const qrX = (config.qr_code.x / 100) * canvas.width;
        const qrY = (config.qr_code.y / 100) * canvas.height;
        const qrSize = ((config.qr_code.size || 20) / 100) * Math.min(canvas.width, canvas.height);

        const qrImg = new window.Image();
        qrImg.onload = () => {
          ctx.drawImage(qrImg, qrX - qrSize / 2, qrY - qrSize / 2, qrSize, qrSize);
          resolve(canvas.toDataURL('image/png'));
        };
        qrImg.onerror = () => resolve(canvas.toDataURL('image/png'));
        qrImg.src = qrCodeDataUrl;
      } else {
        resolve(canvas.toDataURL('image/png'));
      }
    };
    img.onerror = () => reject(new Error('Failed to load template image'));
    img.src = template.template_image_url;
  });
}

// Generate and store ticket for registration
export async function generateTicketForRegistrationWithTemplate(
  registration: EventRegistration,
  event: Event
): Promise<string> {
  // Get template for event or default
  let template = await getDefaultTicketTemplate();

  if (event.ticket_template_id) {
    const eventTemplate = await getTicketTemplateById(event.ticket_template_id);
    if (eventTemplate) template = eventTemplate;
  }

  if (!template) {
    throw new Error('No ticket template found');
  }

  // Generate QR code
  const qrData = JSON.stringify({
    ticket_id: registration.ticket_id,
    user_id: registration.user_id,
    event_id: event.id,
    verification: registration.qr_code,
  });
  const qrCodeDataUrl = await generateQRCodeDataUrl(qrData);

  // Generate ticket image
  const ticketImageUrl = await generateTicketImage(template, registration, event, qrCodeDataUrl);

  // Store generated ticket URL
  if (registration.ticket_id) {
    await supabase
      .from('event_tickets')
      .update({
        generated_ticket_url: ticketImageUrl,
        generated_at: new Date().toISOString(),
      })
      .eq('id', registration.ticket_id);
  }

  return ticketImageUrl;
}

// Download ticket as PDF
export async function downloadTicketAsPDF(ticketImageUrl: string, fileName: string): Promise<void> {
  // Dynamic import of jsPDF (need to add to package.json)
  // For now, just download the image
  const link = window.document.createElement('a');
  link.href = ticketImageUrl;
  link.download = `${fileName}.png`;
  window.document.body.appendChild(link);
  link.click();
  window.document.body.removeChild(link);
}

// Download ticket as PNG
export async function downloadTicketAsPNG(ticketImageUrl: string, fileName: string): Promise<void> {
  const link = window.document.createElement('a');
  link.href = ticketImageUrl;
  link.download = `${fileName}.png`;
  window.document.body.appendChild(link);
  link.click();
  window.document.body.removeChild(link);
}
