import { supabase } from '@/lib/supabase';

export interface UserProfile {
  id: string;
  auth_user_id: string;
  email: string;
  name: string;
  role: string;
  is_active: boolean;
  department: string | null;
  branch: string | null;
  semester: number | null;
  status: string;
  created_at: string;
  // Extended profile fields
  bio: string | null;
  phone: string | null;
  class_name: string | null;
  register_number: string | null;
  linkedin_url: string | null;
  github_url: string | null;
  instagram_url: string | null;
  portfolio_url: string | null;
  skills: string[];
  interests: string[];
  profile_photo_url: string | null;
}

export interface ProfileUpdateInput {
  name?: string;
  phone?: string;
  bio?: string;
  department?: string;
  linkedin_url?: string;
  github_url?: string;
  instagram_url?: string;
  portfolio_url?: string;
  skills?: string[];
  interests?: string[];
  profile_photo_url?: string;
}

export async function getMyProfile(): Promise<UserProfile | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('auth_user_profiles')
    .select('*')
    .eq('auth_user_id', user.id)
    .maybeSingle();

  if (error) throw error;
  return data as UserProfile | null;
}

export async function updateMyProfile(updates: ProfileUpdateInput): Promise<UserProfile> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('auth_user_profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('auth_user_id', user.id)
    .select()
    .single();

  if (error) throw error;
  return data as UserProfile;
}

export async function uploadProfilePhoto(file: File): Promise<string> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const ext = file.name.split('.').pop()?.toLowerCase() ?? 'jpg';
  const path = `${user.id}/avatar.${ext}`;

  const { error } = await supabase.storage
    .from('profile-photos')
    .upload(path, file, { upsert: true, contentType: file.type });

  if (error) throw error;

  const { data: urlData } = supabase.storage
    .from('profile-photos')
    .getPublicUrl(path);

  return `${urlData.publicUrl}?t=${Date.now()}`;
}

export interface EventRegistrationSummary {
  id: string;
  event_id: string;
  registered_at: string;
  approval_status: string;
  registration_status: string;
  ticket_id: string | null;
  qr_code: string | null;
  event: {
    id: string;
    title: string;
    start_date: string;
    end_date: string | null;
    venue: string | null;
    status: string;
    banner_image_url: string | null;
    banner_url: string | null;
  };
}

export async function getMyRegistrations(): Promise<EventRegistrationSummary[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from('event_registrations')
    .select('id, event_id, registered_at, approval_status, registration_status, ticket_id, qr_code, event:events(id, title, start_date, end_date, venue, status, banner_image_url, banner_url)')
    .eq('user_id', user.id)
    .order('registered_at', { ascending: false });

  if (error) throw error;
  return (data || []) as unknown as EventRegistrationSummary[];
}

export interface AttendanceRecord {
  id: string;
  event_id: string;
  scanned_at: string;
  certificate_eligible: boolean | null;
  event: {
    id: string;
    title: string;
    start_date: string;
    venue: string | null;
  };
}

export async function getMyAttendance(): Promise<AttendanceRecord[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from('event_attendance')
    .select('id, event_id, scanned_at, certificate_eligible, event:events(id, title, start_date, venue)')
    .eq('user_id', user.id)
    .order('scanned_at', { ascending: false });

  if (error) throw error;
  return (data || []) as unknown as AttendanceRecord[];
}
