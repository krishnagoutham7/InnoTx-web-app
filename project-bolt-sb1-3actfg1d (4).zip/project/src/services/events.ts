import { supabase } from '@/lib/supabase';
import { sendNotificationToUser } from '@/services/cms';
import type { Event, EventCategory, EventSpeaker, EventResource, EventRegistration, EventFormData, LikeAnalytics, TrendingEvent } from '@/types/events';

const BANNER_BUCKET = 'event-banners';
const POSTER_BUCKET = 'event-posters';

// ── Categories ────────────────────────────────────────────────────────────────

export async function getEventCategories(): Promise<EventCategory[]> {
  const { data, error } = await supabase
    .from('event_categories')
    .select('*')
    .order('display_order');
  if (error) throw error;
  return data || [];
}

// ── Events ────────────────────────────────────────────────────────────────────

export async function getEvents(includeDrafts = false): Promise<Event[]> {
  let query = supabase
    .from('events')
    .select('*, category:event_categories(*)')
    .order('start_date', { ascending: true });

  if (!includeDrafts) {
    query = query.in('status', ['published', 'upcoming', 'registration_open', 'registration_closed', 'ongoing', 'completed']);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data || []) as Event[];
}

export async function getAllEvents(): Promise<Event[]> {
  const { data, error } = await supabase
    .from('events')
    .select('*, category:event_categories(*)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []) as Event[];
}

export async function getEventById(id: string): Promise<Event | null> {
  const { data, error } = await supabase
    .from('events')
    .select('*, category:event_categories(*), speakers:event_speakers(*)')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as Event | null;
}

export async function getFeaturedEvents(): Promise<Event[]> {
  const { data, error } = await supabase
    .from('events')
    .select('*, category:event_categories(*)')
    .eq('is_featured', true)
    .in('status', ['published', 'upcoming', 'registration_open', 'ongoing'])
    .order('start_date')
    .limit(3);
  if (error) throw error;
  return (data || []) as Event[];
}

export async function getUpcomingEvents(limit = 5): Promise<Event[]> {
  const today = new Date().toISOString().split('T')[0];
  const { data, error } = await supabase
    .from('events')
    .select('*, category:event_categories(*)')
    .in('status', ['published', 'upcoming'])
    .gte('start_date', today)
    .order('start_date')
    .limit(limit);
  if (error) throw error;
  return (data || []) as Event[];
}

export async function createEvent(form: EventFormData): Promise<Event> {
  const payload = {
    ...form,
    max_participants: form.max_participants ? Number(form.max_participants) : null,
    end_date: form.end_date || null,
    start_time: form.start_time || null,
    end_time: form.end_time || null,
    registration_deadline: form.registration_deadline || null,
    category_id: form.category_id || null,
  };
  const { data, error } = await supabase
    .from('events')
    .insert(payload)
    .select('*, category:event_categories(*)')
    .single();
  if (error) throw error;

  // Notify all admins about the new event
  sendNotificationToUser({
    userId: data.created_by || '',
    title: 'New Event Published',
    message: `Event "${data.title}" has been published.`,
    type: 'event_published',
    actionUrl: `/events/${data.id}`,
    priority: 'medium',
  }).catch(() => {});

  return data as Event;
}

export async function updateEvent(id: string, form: Partial<EventFormData>): Promise<Event> {
  const payload = {
    ...form,
    max_participants: form.max_participants !== undefined
      ? (form.max_participants ? Number(form.max_participants) : null)
      : undefined,
    end_date: form.end_date !== undefined ? (form.end_date || null) : undefined,
    start_time: form.start_time !== undefined ? (form.start_time || null) : undefined,
    end_time: form.end_time !== undefined ? (form.end_time || null) : undefined,
    registration_deadline: form.registration_deadline !== undefined ? (form.registration_deadline || null) : undefined,
    category_id: form.category_id !== undefined ? (form.category_id || null) : undefined,
    venue: form.venue !== undefined ? (form.venue || null) : undefined,
    organizer_name: form.organizer_name !== undefined ? (form.organizer_name || null) : undefined,
    organizer_email: form.organizer_email !== undefined ? (form.organizer_email || null) : undefined,
    short_description: form.short_description !== undefined ? (form.short_description || null) : undefined,
    full_description: form.full_description !== undefined ? (form.full_description || null) : undefined,
    updated_at: new Date().toISOString(),
  };
  const { data, error } = await supabase
    .from('events')
    .update(payload)
    .eq('id', id)
    .select('*, category:event_categories(*)')
    .single();
  if (error) throw error;
  return data as Event;
}

export async function deleteEvent(id: string): Promise<void> {
  const { error } = await supabase.from('events').delete().eq('id', id);
  if (error) throw error;
}

export async function publishEvent(id: string): Promise<Event> {
  return updateEvent(id, { status: 'published' });
}

export async function archiveEvent(id: string): Promise<Event> {
  return updateEvent(id, { status: 'archived' });
}

// ── Speakers ──────────────────────────────────────────────────────────────────

export async function getEventSpeakers(eventId: string): Promise<EventSpeaker[]> {
  const { data, error } = await supabase
    .from('event_speakers')
    .select('*')
    .eq('event_id', eventId)
    .order('display_order');
  if (error) throw error;
  return data || [];
}

export async function createSpeaker(speaker: Omit<EventSpeaker, 'id' | 'created_at'>): Promise<EventSpeaker> {
  const { data, error } = await supabase
    .from('event_speakers')
    .insert(speaker)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteSpeaker(id: string): Promise<void> {
  const { error } = await supabase.from('event_speakers').delete().eq('id', id);
  if (error) throw error;
}

// ── Resources ─────────────────────────────────────────────────────────────────

export async function getEventResources(eventId: string): Promise<EventResource[]> {
  const { data, error } = await supabase
    .from('event_resources')
    .select('*')
    .eq('event_id', eventId)
    .order('display_order');
  if (error) throw error;
  return data || [];
}

// ── Registrations ─────────────────────────────────────────────────────────────

export async function getEventRegistrations(eventId: string): Promise<EventRegistration[]> {
  const { data, error } = await supabase
    .from('event_registrations')
    .select('*')
    .eq('event_id', eventId)
    .order('registered_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function getRegistrationCountByEvent(eventId: string): Promise<number> {
  const { count, error } = await supabase
    .from('event_registrations')
    .select('id', { count: 'exact', head: true })
    .eq('event_id', eventId)
    .eq('approval_status', 'approved');
  if (error) throw error;
  return count || 0;
}

export async function registerForEvent(registration: {
  event_id: string;
  user_name: string;
  user_email: string;
  user_role?: string;
  notes?: string;
  user_id?: string;
  department?: string;
  semester?: string;
  student_id?: string;
}): Promise<EventRegistration> {
  const existing = await getRegistrationByEmail(registration.event_id, registration.user_email);

  if (existing) {
    if (existing.approval_status === 'cancelled') {
      const { data, error } = await supabase
        .from('event_registrations')
        .update({
          user_name: registration.user_name,
          user_role: registration.user_role || null,
          user_id: registration.user_id || null,
          notes: registration.notes || null,
          department: registration.department || null,
          semester: registration.semester || null,
          student_id: registration.student_id || null,
          registration_status: 'pending',
          approval_status: 'pending',
          approved_by: null,
          approval_date: null,
          remarks: null,
          cancelled_at: null,
          ticket_id: null,
          qr_code: null,
          ticket_generated_at: null,
        })
        .eq('id', existing.id)
        .select()
        .single();

      if (error) throw error;

      await supabase.from('registration_approval_logs').insert({
        registration_id: data.id,
        action: 'created',
        previous_status: 'cancelled',
        new_status: 'pending',
        performed_by: registration.user_id || null,
        remarks: 'Re-registered after cancellation',
      });

      return data;
    }
    throw new Error('You are already registered for this event');
  }

  const { data, error } = await supabase
    .from('event_registrations')
    .insert({
      event_id: registration.event_id,
      user_name: registration.user_name,
      user_email: registration.user_email,
      user_role: registration.user_role || null,
      user_id: registration.user_id || null,
      notes: registration.notes || null,
      department: registration.department || null,
      semester: registration.semester || null,
      student_id: registration.student_id || null,
      registration_status: 'pending',
      approval_status: 'pending',
    })
    .select()
    .single();

  if (error) throw error;

  await supabase.from('registration_approval_logs').insert({
    registration_id: data.id,
    action: 'created',
    new_status: 'pending',
    performed_by: registration.user_id || null,
  });

  return data;
}

export async function approveRegistration(
  registrationId: string,
  approvedBy: string,
  remarks?: string
): Promise<{ success: boolean; registration?: EventRegistration; error?: string }> {
  const { data, error } = await supabase.rpc('approve_registration', {
    p_registration_id: registrationId,
    p_approved_by: approvedBy,
    p_remarks: remarks || null,
  });

  if (error) {
    return { success: false, error: error.message };
  }

  if (!data?.success) {
    return { success: false, error: data?.error || 'Failed to approve registration' };
  }

  const { data: updatedReg } = await supabase
    .from('event_registrations')
    .select('*')
    .eq('id', registrationId)
    .single();

  if (updatedReg) {
    const event = await getEventById(updatedReg.event_id);
    if (event) {
      await generateTicketForRegistration(updatedReg, event);
    }
    // Send notification to user
    if (updatedReg.user_id) {
      sendNotificationToUser({
        userId: updatedReg.user_id,
        title: 'Registration Approved',
        message: `Your registration for "${event?.title || 'the event'}" has been approved. Your ticket has been generated.`,
        type: 'registration_approved',
        actionUrl: `/ticket/${updatedReg.ticket_qr_code || ''}`,
        priority: 'high',
      });
    }
  }

  return { success: true, registration: updatedReg };
}

export async function rejectRegistration(
  registrationId: string,
  rejectedBy: string,
  remarks?: string
): Promise<{ success: boolean; registration?: EventRegistration; error?: string }> {
  const { data, error } = await supabase.rpc('reject_registration', {
    p_registration_id: registrationId,
    p_rejected_by: rejectedBy,
    p_remarks: remarks || null,
  });

  if (error) {
    return { success: false, error: error.message };
  }

  if (!data?.success) {
    return { success: false, error: data?.error || 'Failed to reject registration' };
  }

  const { data: updatedReg } = await supabase
    .from('event_registrations')
    .select('*')
    .eq('id', registrationId)
    .single();

  // Send notification to user
  if (updatedReg?.user_id) {
    const { data: eventData } = await supabase
      .from('events')
      .select('title')
      .eq('id', updatedReg.event_id)
      .maybeSingle();
    sendNotificationToUser({
      userId: updatedReg.user_id,
      title: 'Registration Rejected',
      message: `Your registration for "${eventData?.title || 'the event'}" has been rejected. ${remarks ? `Reason: ${remarks}` : 'Please contact the administrator for more information.'}`,
      type: 'registration_rejected',
      priority: 'high',
    });
  }

  return { success: true, registration: updatedReg };
}

export async function bulkApproveRegistrations(
  registrationIds: string[],
  approvedBy: string,
  remarks?: string
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  for (const id of registrationIds) {
    const result = await approveRegistration(id, approvedBy, remarks);
    if (result.success) {
      success++;
    } else {
      failed++;
    }
  }

  return { success, failed };
}

export async function bulkRejectRegistrations(
  registrationIds: string[],
  rejectedBy: string,
  remarks?: string
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  for (const id of registrationIds) {
    const result = await rejectRegistration(id, rejectedBy, remarks);
    if (result.success) {
      success++;
    } else {
      failed++;
    }
  }

  return { success, failed };
}

export async function getRegistrationsByEvent(eventId: string): Promise<EventRegistration[]> {
  const { data, error } = await supabase
    .from('event_registrations')
    .select('*')
    .eq('event_id', eventId)
    .order('registered_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function getRegistrationsByStatus(
  eventId: string,
  status: 'pending' | 'approved' | 'rejected' | 'waitlisted'
): Promise<EventRegistration[]> {
  const { data, error } = await supabase
    .from('event_registrations')
    .select('*')
    .eq('event_id', eventId)
    .eq('approval_status', status)
    .order('registered_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function getUserRegistrations(userId: string): Promise<EventRegistration[]> {
  const { data, error } = await supabase
    .from('event_registrations')
    .select('*, event:events(*)')
    .eq('user_id', userId)
    .order('registered_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function cancelRegistration(id: string): Promise<{ success: boolean; registration?: EventRegistration; error?: string }> {
  const { data, error } = await supabase.rpc('cancel_event_registration', {
    p_registration_id: id,
  });

  if (error) {
    return { success: false, error: error.message };
  }

  if (!data?.success) {
    return { success: false, error: data?.error || 'Failed to cancel registration' };
  }

  const { data: updatedReg } = await supabase
    .from('event_registrations')
    .select('*')
    .eq('id', id)
    .single();

  return { success: true, registration: updatedReg };
}

export async function getRegistrationByEmail(eventId: string, email: string): Promise<EventRegistration | null> {
  const { data, error } = await supabase
    .from('event_registrations')
    .select('*')
    .eq('event_id', eventId)
    .eq('user_email', email)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function getRegistrationsByEmail(email: string): Promise<EventRegistration[]> {
  const { data, error } = await supabase
    .from('event_registrations')
    .select('*, event:events(*, category:event_categories(*))')
    .eq('user_email', email)
    .order('registered_at', { ascending: false });
  if (error) throw error;
  return (data || []) as EventRegistration[];
}

export async function getAllRegistrations(): Promise<EventRegistration[]> {
  const { data, error } = await supabase
    .from('event_registrations')
    .select('*, event:events(title, start_date, event_type)')
    .order('registered_at', { ascending: false });
  if (error) throw error;
  return (data || []) as EventRegistration[];
}

// ── Analytics ─────────────────────────────────────────────────────────────────

export async function getEventAnalytics() {
  const [events, registrations] = await Promise.all([
    getAllEvents(),
    getAllRegistrations(),
  ]);

  const today = new Date().toISOString().split('T')[0];

  const totalEvents = events.length;
  const upcomingEvents = events.filter(e => ['published', 'upcoming'].includes(e.status) && e.start_date >= today).length;
  const completedEvents = events.filter(e => e.status === 'completed').length;
  const ongoingEvents = events.filter(e => e.status === 'ongoing').length;
  const totalRegistrations = registrations.filter(r => r.approval_status === 'approved').length;
  const featuredEvents = events.filter(e => e.is_featured).length;

  const categoryCount: Record<string, number> = {};
  events.forEach(e => {
    const cat = e.category?.name || 'Other';
    categoryCount[cat] = (categoryCount[cat] || 0) + 1;
  });

  const regPerEvent: Record<string, number> = {};
  registrations.forEach(r => {
    if (r.approval_status === 'approved') {
      const key = r.event_id;
      regPerEvent[key] = (regPerEvent[key] || 0) + 1;
    }
  });

  const popularEvents = events
    .map(e => ({ ...e, reg_count: regPerEvent[e.id] || 0 }))
    .sort((a, b) => b.reg_count - a.reg_count)
    .slice(0, 5);

  return {
    totalEvents, upcomingEvents, completedEvents, ongoingEvents,
    totalRegistrations, featuredEvents, categoryCount, popularEvents,
    recentRegistrations: registrations.slice(0, 10),
  };
}

// ── Attendance System Types ───────────────────────────────────────────────────────

export interface EventTicket {
  id: string;
  ticket_number: string;
  registration_id: string;
  event_id: string;
  user_id: string | null;
  participant_name: string;
  participant_email: string;
  participant_department?: string;
  participant_student_id?: string;
  registration_number?: string;
  qr_code: string;
  qr_code_data: Record<string, any>;
  is_used: boolean;
  used_at: string | null;
  created_at: string;
  expires_at: string | null;
}

export interface EventAttendance {
  id: string;
  event_id: string;
  registration_id: string;
  ticket_id: string;
  user_id: string | null;
  participant_name: string;
  participant_email: string;
  scanned_at: string;
  scanned_by: string | null;
  attendance_method: 'qr_scan' | 'manual';
  notes: string | null;
}

export interface AttendanceWindow {
  id: string;
  event_id: string;
  attendance_open: string | null;
  attendance_close: string | null;
  is_attendance_open: boolean;
  allow_manual_override: boolean;
  created_at: string;
  updated_at: string;
}

export interface AttendanceLog {
  id: string;
  event_id: string | null;
  ticket_id: string | null;
  registration_id: string | null;
  action_type: string;
  action_result: string;
  error_message: string | null;
  scanned_by: string | null;
  metadata: Record<string, any>;
  created_at: string;
}

export interface AttendanceStats {
  total_registrations: number;
  total_attended: number;
  attendance_percentage: number;
  pending_attendance: number;
}

// ── Ticket Generation ─────────────────────────────────────────────────────────────

export async function generateTicketForRegistration(
  registration: EventRegistration,
  event: Event
): Promise<EventTicket> {
  const { data: existingTicket } = await supabase
    .from('event_tickets')
    .select('*')
    .eq('registration_id', registration.id)
    .maybeSingle();

  if (existingTicket) {
    return existingTicket as EventTicket;
  }

  const qrCode = `QR-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;

  const { data: ticket, error } = await supabase
    .from('event_tickets')
    .insert({
      registration_id: registration.id,
      event_id: event.id,
      user_id: registration.user_id || null,
      participant_name: registration.user_name,
      participant_email: registration.user_email,
      participant_department: registration.department || null,
      participant_student_id: registration.student_id || null,
      registration_number: registration.student_id || registration.id.substring(0, 8).toUpperCase(),
      qr_code: qrCode,
      qr_code_data: {
        registration_id: registration.id,
        event_id: event.id,
        generated_at: new Date().toISOString(),
      },
      expires_at: event.end_date ? new Date(event.end_date + 'T23:59:59').toISOString() : null,
    })
    .select()
    .single();

  if (error) throw error;

  await supabase
    .from('event_registrations')
    .update({
      ticket_id: ticket.id,
      qr_code: qrCode,
      ticket_generated_at: new Date().toISOString(),
    })
    .eq('id', registration.id);

  await logAttendanceAction({
    event_id: event.id,
    ticket_id: ticket.id,
    registration_id: registration.id,
    action_type: 'ticket_generated',
    action_result: 'success',
    metadata: { ticket_number: ticket.ticket_number },
  });

  return ticket;
}

export async function getTicketForRegistration(registrationId: string): Promise<EventTicket | null> {
  const { data, error } = await supabase
    .from('event_tickets')
    .select('*')
    .eq('registration_id', registrationId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function getTicketByQRCode(qrCode: string): Promise<EventTicket | null> {
  const { data, error } = await supabase
    .from('event_tickets')
    .select('*')
    .eq('qr_code', qrCode)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function getUserTickets(userId: string): Promise<(EventTicket & { event?: Event })[]> {
  const { data, error } = await supabase
    .from('event_tickets')
    .select('*, event:events(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

// ── Attendance Management ─────────────────────────────────────────────────────────

export async function validateQRForAttendance(
  qrCode: string,
  eventId: string
): Promise<{ valid: boolean; error?: string; message?: string; ticket?: EventTicket }> {
  const { data, error } = await supabase.rpc('validate_qr_for_attendance', {
    p_qr_code: qrCode,
    p_event_id: eventId,
  });

  if (error) {
    return { valid: false, error: 'SYSTEM_ERROR', message: error.message };
  }

  return data as any;
}

export async function markAttendance(
  qrCode: string,
  eventId: string,
  scannedBy: string,
  notes?: string
): Promise<{ success: boolean; attendance?: EventAttendance; error?: string; message?: string }> {
  const validation = await validateQRForAttendance(qrCode, eventId);

  if (!validation.valid) {
    await logAttendanceAction({
      event_id: eventId,
      action_type: 'scan_failed',
      action_result: 'failure',
      error_message: validation.message,
      scanned_by: scannedBy,
      metadata: { qr_code: qrCode, error: validation.error },
    });

    return { success: false, error: validation.error, message: validation.message };
  }

  const ticket = await getTicketByQRCode(qrCode);
  if (!ticket) {
    return { success: false, error: 'TICKET_NOT_FOUND', message: 'Ticket not found' };
  }

  const { data: attendance, error: insertError } = await supabase
    .from('event_attendance')
    .insert({
      event_id: eventId,
      registration_id: ticket.registration_id,
      ticket_id: ticket.id,
      user_id: ticket.user_id,
      participant_name: ticket.participant_name,
      participant_email: ticket.participant_email,
      scanned_by: scannedBy,
      attendance_method: 'qr_scan',
      notes: notes || null,
      certificate_eligible: true,
    })
    .select()
    .single();

  if (insertError) {
    await logAttendanceAction({
      event_id: eventId,
      ticket_id: ticket.id,
      registration_id: ticket.registration_id,
      action_type: 'scan_failed',
      action_result: 'failure',
      error_message: insertError.message,
      scanned_by: scannedBy,
    });

    return { success: false, error: 'INSERT_FAILED', message: 'Failed to record attendance' };
  }

  await supabase
    .from('event_tickets')
    .update({ is_used: true, used_at: new Date().toISOString() })
    .eq('id', ticket.id);

  await logAttendanceAction({
    event_id: eventId,
    ticket_id: ticket.id,
    registration_id: ticket.registration_id,
    action_type: 'attendance_marked',
    action_result: 'success',
    scanned_by: scannedBy,
    metadata: { attendance_id: attendance.id },
  });

  // Send notification to user
  if (ticket.user_id) {
    const { data: eventData } = await supabase
      .from('events')
      .select('title')
      .eq('id', eventId)
      .maybeSingle();
    sendNotificationToUser({
      userId: ticket.user_id,
      title: 'Attendance Verified',
      message: `Your attendance for "${eventData?.title || 'the event'}" has been verified. You are now eligible for a certificate.`,
      type: 'attendance_verified',
      actionUrl: `/dashboard/student/my-certificates`,
      priority: 'high',
    });
  }

  return { success: true, attendance };
}

export async function getEventAttendance(eventId: string): Promise<EventAttendance[]> {
  const { data, error } = await supabase
    .from('event_attendance')
    .select('*')
    .eq('event_id', eventId)
    .order('scanned_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function getEventAttendanceStats(eventId: string): Promise<AttendanceStats> {
  const { count: totalRegistrations } = await supabase
    .from('event_registrations')
    .select('*', { count: 'exact', head: true })
    .eq('event_id', eventId)
    .eq('approval_status', 'approved');

  const { count: totalAttended } = await supabase
    .from('event_attendance')
    .select('*', { count: 'exact', head: true })
    .eq('event_id', eventId);

  const total = totalRegistrations || 0;
  const attended = totalAttended || 0;

  return {
    total_registrations: total,
    total_attended: attended,
    attendance_percentage: total > 0 ? Math.round((attended / total) * 100) : 0,
    pending_attendance: total - attended,
  };
}

// ── Attendance Window Management ─────────────────────────────────────────────────

export async function getAttendanceWindow(eventId: string): Promise<AttendanceWindow | null> {
  const { data, error } = await supabase
    .from('event_attendance_windows')
    .select('*')
    .eq('event_id', eventId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function setAttendanceWindow(
  eventId: string,
  window: {
    attendance_open?: string;
    attendance_close?: string;
    is_attendance_open?: boolean;
    allow_manual_override?: boolean;
  },
  userId: string
): Promise<AttendanceWindow> {
  const existing = await getAttendanceWindow(eventId);

  let result;
  if (existing) {
    const { data, error } = await supabase
      .from('event_attendance_windows')
      .update({
        ...window,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id)
      .select()
      .single();
    if (error) throw error;
    result = data;
  } else {
    const { data, error } = await supabase
      .from('event_attendance_windows')
      .insert({
        event_id: eventId,
        ...window,
      })
      .select()
      .single();
    if (error) throw error;
    result = data;
  }

  await logAttendanceAction({
    event_id: eventId,
    action_type: window.is_attendance_open ? 'attendance_window_opened' : 'attendance_window_closed',
    action_result: 'success',
    scanned_by: userId,
    metadata: { window },
  });

  return result;
}

export async function openAttendance(eventId: string, userId: string): Promise<void> {
  await setAttendanceWindow(eventId, { is_attendance_open: true }, userId);
}

export async function closeAttendance(eventId: string, userId: string): Promise<void> {
  await setAttendanceWindow(eventId, { is_attendance_open: false }, userId);
}

// ── Attendance Logs ───────────────────────────────────────────────────────────────

export async function logAttendanceAction(log: {
  event_id?: string | null;
  ticket_id?: string | null;
  registration_id?: string | null;
  action_type: string;
  action_result: string;
  error_message?: string | null;
  scanned_by?: string | null;
  metadata?: Record<string, any>;
}): Promise<void> {
  await supabase.from('attendance_logs').insert({
    event_id: log.event_id || null,
    ticket_id: log.ticket_id || null,
    registration_id: log.registration_id || null,
    action_type: log.action_type,
    action_result: log.action_result,
    error_message: log.error_message || null,
    scanned_by: log.scanned_by || null,
    metadata: log.metadata || {},
  });
}

export async function getAttendanceLogs(
  eventId: string,
  limit = 50
): Promise<AttendanceLog[]> {
  const { data, error } = await supabase
    .from('attendance_logs')
    .select('*')
    .eq('event_id', eventId)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data || [];
}

// ── Real-time Subscriptions ─────────────────────────────────────────────────────────

export function subscribeToAttendanceUpdates(
  eventId: string,
  callback: (payload: any) => void
) {
  return supabase
    .channel(`attendance_${eventId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'event_attendance',
        filter: `event_id=eq.${eventId}`,
      },
      callback
    )
    .subscribe();
}

// ── Event Media Uploads ─────────────────────────────────────────────────────────

export async function uploadEventBanner(
  eventId: string,
  file: File,
  userId: string
): Promise<{ url: string; thumbnailUrl: string }> {
  const fileExt = file.name.split('.').pop()?.toLowerCase() || 'webp';
  const fileName = `banner.${fileExt}`;
  const filePath = `${eventId}/${fileName}`;

  const { error: uploadError } = await supabase.storage
    .from(BANNER_BUCKET)
    .upload(filePath, file, { upsert: true });

  if (uploadError) throw uploadError;

  const { data: urlData } = supabase.storage.from(BANNER_BUCKET).getPublicUrl(filePath);
  const url = urlData.publicUrl;
  const thumbnailUrl = url;

  const { error: updateError } = await supabase
    .from('events')
    .update({
      banner_image_url: url,
      banner_thumbnail_url: thumbnailUrl,
      banner_storage_path: filePath,
      banner_uploaded_by: userId,
      banner_uploaded_at: new Date().toISOString(),
    })
    .eq('id', eventId);

  if (updateError) throw updateError;

  return { url, thumbnailUrl };
}

export async function uploadEventPoster(
  eventId: string,
  file: File,
  userId: string
): Promise<string> {
  const fileExt = file.name.split('.').pop()?.toLowerCase() || 'webp';
  const fileName = `poster.${fileExt}`;
  const filePath = `${eventId}/${fileName}`;

  const { error: uploadError } = await supabase.storage
    .from(POSTER_BUCKET)
    .upload(filePath, file, { upsert: true });

  if (uploadError) throw uploadError;

  const { data: urlData } = supabase.storage.from(POSTER_BUCKET).getPublicUrl(filePath);
  const url = urlData.publicUrl;

  const { error: updateError } = await supabase
    .from('events')
    .update({
      poster_image_url: url,
      poster_storage_path: filePath,
      poster_uploaded_by: userId,
      poster_uploaded_at: new Date().toISOString(),
    })
    .eq('id', eventId);

  if (updateError) throw updateError;

  return url;
}

export async function deleteEventBanner(eventId: string): Promise<void> {
  const { data: event } = await supabase
    .from('events')
    .select('banner_storage_path')
    .eq('id', eventId)
    .single();

  if (event?.banner_storage_path) {
    await supabase.storage.from(BANNER_BUCKET).remove([event.banner_storage_path]);
  }

  await supabase
    .from('events')
    .update({
      banner_image_url: null,
      banner_thumbnail_url: null,
      banner_storage_path: null,
      banner_uploaded_by: null,
      banner_uploaded_at: null,
    })
    .eq('id', eventId);
}

export async function deleteEventPoster(eventId: string): Promise<void> {
  const { data: event } = await supabase
    .from('events')
    .select('poster_storage_path')
    .eq('id', eventId)
    .single();

  if (event?.poster_storage_path) {
    await supabase.storage.from(POSTER_BUCKET).remove([event.poster_storage_path]);
  }

  await supabase
    .from('events')
    .update({
      poster_image_url: null,
      poster_storage_path: null,
      poster_uploaded_by: null,
      poster_uploaded_at: null,
    })
    .eq('id', eventId);
}

// ── Like System ─────────────────────────────────────────────────────────

export async function getEventLikeCount(eventId: string): Promise<number> {
  const { data, error } = await supabase.rpc('get_event_like_count', { p_event_id: eventId });
  if (error) throw error;
  return data || 0;
}

export async function checkUserLiked(eventId: string, userId: string): Promise<boolean> {
  const { data, error } = await supabase.rpc('user_liked_event', {
    p_event_id: eventId,
    p_user_id: userId,
  });
  if (error) throw error;
  return data || false;
}

export async function toggleEventLike(
  eventId: string,
  userId: string
): Promise<{ action: 'liked' | 'unliked'; liked: boolean; like_count: number }> {
  const { data, error } = await supabase.rpc('toggle_event_like', {
    p_event_id: eventId,
    p_user_id: userId,
  });
  if (error) throw error;
  return data;
}

export async function getEventWithLikeInfo(eventId: string, userId?: string): Promise<Event | null> {
  const { data, error } = await supabase
    .from('events')
    .select('*, category:event_categories(*), speakers:event_speakers(*)')
    .eq('id', eventId)
    .maybeSingle();

  if (error) throw error;
  if (!data) return null;

  const likeCount = await getEventLikeCount(eventId);
  let userLiked = false;
  if (userId) {
    userLiked = await checkUserLiked(eventId, userId);
  }

  return {
    ...data,
    like_count: likeCount,
    user_liked: userLiked,
  } as Event;
}

export async function getEventsWithLikeInfo(userId?: string): Promise<Event[]> {
  const { data, error } = await supabase
    .from('events')
    .select('*, category:event_categories(*)')
    .in('status', ['published', 'upcoming', 'registration_open', 'registration_closed', 'ongoing', 'completed'])
    .order('start_date', { ascending: true });

  if (error) throw error;
  if (!data || data.length === 0) return [];

  const eventIds = data.map(e => e.id);
  const { data: likeData } = await supabase
    .from('event_likes')
    .select('event_id')
    .in('event_id', eventIds);

  const likeCounts: Record<string, number> = {};
  (likeData || []).forEach(l => {
    likeCounts[l.event_id] = (likeCounts[l.event_id] || 0) + 1;
  });

  let userLikedEvents: string[] = [];
  if (userId) {
    const { data: userLikes } = await supabase
      .from('event_likes')
      .select('event_id')
      .eq('user_id', userId)
      .in('event_id', eventIds);
    userLikedEvents = (userLikes || []).map(l => l.event_id);
  }

  return data.map(e => ({
    ...e,
    like_count: likeCounts[e.id] || 0,
    user_liked: userLikedEvents.includes(e.id),
  })) as Event[];
}

// ── Trending & Analytics ─────────────────────────────────────────────────────────

export async function getTrendingEvents(limit = 10): Promise<TrendingEvent[]> {
  const { data, error } = await supabase.rpc('get_trending_events', { p_limit: limit });
  if (error) throw error;
  return (data || []) as TrendingEvent[];
}

export async function getLikeAnalytics(): Promise<LikeAnalytics> {
  const { data, error } = await supabase.rpc('get_like_analytics');
  if (error) throw error;
  return data as LikeAnalytics;
}

export async function getLatestPosters(limit = 6): Promise<Event[]> {
  const { data, error } = await supabase
    .from('events')
    .select('*, category:event_categories(*)')
    .not('poster_image_url', 'is', null)
    .in('status', ['published', 'upcoming', 'registration_open', 'ongoing'])
    .order('poster_uploaded_at', { ascending: false })
    .limit(limit);

  if (error) throw error;

  const eventIds = (data || []).map(e => e.id);
  const { data: likeData } = await supabase
    .from('event_likes')
    .select('event_id')
    .in('event_id', eventIds);

  const likeCounts: Record<string, number> = {};
  (likeData || []).forEach(l => {
    likeCounts[l.event_id] = (likeCounts[l.event_id] || 0) + 1;
  });

  return (data || []).map(e => ({
    ...e,
    like_count: likeCounts[e.id] || 0,
  })) as Event[];
}
