import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import type { AuthContextType, LoginCredentials, User, UserRole } from '@/types/auth';
import { signInWithEmail, signOut, getCurrentUser, onAuthStateChange, changePassword } from '@/services/auth';
import { roleRoutes } from '@/types/auth';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const loginInProgress = useRef(false);
  const initFetchInProgress = useRef(true);

  useEffect(() => {
    let mounted = true;

    getCurrentUser()
      .then(u => {
        if (!mounted) return;
        console.log('[AuthProvider] initial getCurrentUser:', u ? { id: u.id, role: u.role } : 'null');
        setUser(u);
      })
      .catch(err => {
        if (!mounted) return;
        console.error('[AuthProvider] initial getCurrentUser failed:', err);
        setUser(null);
      })
      .finally(() => {
        if (!mounted) return;
        initFetchInProgress.current = false;
        setIsLoading(false);
      });

    const { data: { subscription } } = onAuthStateChange(u => {
      if (loginInProgress.current) return;
      if (initFetchInProgress.current) return;
      console.log('[AuthProvider] onAuthStateChange:', u ? { id: u.id, role: u.role } : 'null');
      setUser(u);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const login = useCallback(
    async (credentials: LoginCredentials): Promise<{ success: boolean; error?: string; mustChangePassword?: boolean }> => {
      setIsLoading(true);
      loginInProgress.current = true;
      try {
        const result = await signInWithEmail(credentials.email, credentials.password);
        if (result.error) {
          setIsLoading(false);
          loginInProgress.current = false;
          return { success: false, error: result.error };
        }
        if (result.user) {
          console.log('[AuthProvider] login: setting user', { id: result.user.id, role: result.user.role });
          setUser(result.user);
        }
        setIsLoading(false);
        loginInProgress.current = false;
        return { success: true, mustChangePassword: result.mustChangePassword };
      } catch (err) {
        console.error('[AuthProvider] login: exception', err);
        setIsLoading(false);
        loginInProgress.current = false;
        return { success: false, error: 'An unexpected error occurred. Please try again.' };
      }
    },
    []
  );

  const logout = useCallback(async () => {
    await signOut();
    setUser(null);
  }, []);

  const hasRole = useCallback((roles: string | string[]): boolean => {
    if (!user) return false;
    const roleArray = Array.isArray(roles) ? roles : [roles];
    return roleArray.includes(user.role);
  }, [user]);

  const updateUserPassword = useCallback(async (newPassword: string): Promise<{ success: boolean; error?: string }> => {
    const result = await changePassword(newPassword);
    if (result.success && user) {
      setUser({ ...user, mustChangePassword: undefined });
    }
    return result;
  }, [user]);

  const refreshUser = useCallback(async () => {
    console.log('[AuthProvider] refreshUser: refetching from DB');
    const refreshedUser = await getCurrentUser();
    console.log('[AuthProvider] refreshUser: result', refreshedUser ? { id: refreshedUser.id, role: refreshedUser.role } : 'null');
    setUser(refreshedUser);
  }, []);

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    hasRole,
    updateUserPassword,
    refreshUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export { roleRoutes };
export type { UserRole };
