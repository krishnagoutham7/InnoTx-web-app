import { useState, useEffect, useRef, useCallback } from 'react';
import {
  getUserNotifications,
  getUnreadNotificationCount,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  deleteUserNotification,
  subscribeToUserNotifications,
  type UserNotification,
} from '@/services/cms';
import { useAuth } from '@/contexts/auth';
import { useToast } from '@/hooks/use-toast';
import { playNotificationSound, showBrowserNotification } from '@/lib/notification-utils';

export function useNotifications() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [notifications, setNotifications] = useState<UserNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const lastNotificationId = useRef<string | null>(null);

  const loadNotifications = useCallback(async () => {
    try {
      const data = await getUserNotifications({ limit: 50 });
      setNotifications(data);
    } catch (err) {
      console.error('[Notifications] Failed to load:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadUnreadCount = useCallback(async () => {
    try {
      const count = await getUnreadNotificationCount();
      setUnreadCount(count);
    } catch (err) {
      console.error('[Notifications] Failed to load unread count:', err);
    }
  }, []);

  const handleNewNotification = useCallback((payload: any) => {
    const eventType = payload?.eventType;
    const newRow = payload?.new;
    if (!newRow) return;

    if (eventType === 'INSERT') {
      if (lastNotificationId.current === newRow.id) return;
      lastNotificationId.current = newRow.id;

      loadNotifications();
      loadUnreadCount();

      // Fetch the full notification to get title/message
      getUserNotifications({ limit: 1 }).then((data) => {
        const notif = data[0];
        if (!notif) return;

        const title = notif.notification?.title || 'New Notification';
        const message = notif.notification?.message || '';
        const actionUrl = notif.notification?.action_url;

        playNotificationSound();
        showBrowserNotification(title, message, actionUrl);

        toast({ title, description: message });
      });
    } else if (eventType === 'UPDATE' || eventType === 'DELETE') {
      loadNotifications();
      loadUnreadCount();
    }
  }, [loadNotifications, loadUnreadCount, toast]);

  // Initial load
  useEffect(() => {
    loadNotifications();
    loadUnreadCount();
  }, [loadNotifications, loadUnreadCount]);

  // Realtime subscription
  useEffect(() => {
    if (!user) return;
    const channel = subscribeToUserNotifications(user.id, handleNewNotification);
    return () => { channel.unsubscribe(); };
  }, [user, handleNewNotification]);

  const markAsRead = useCallback(async (id: string) => {
    await markNotificationAsRead(id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    setUnreadCount(prev => Math.max(0, prev - 1));
  }, []);

  const markAllRead = useCallback(async () => {
    await markAllNotificationsAsRead();
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    setUnreadCount(0);
  }, []);

  const deleteNotification = useCallback(async (id: string) => {
    await deleteUserNotification(id);
    setNotifications(prev => prev.filter(n => n.id !== id));
    setUnreadCount(prev => Math.max(0, prev - 1));
  }, []);

  return {
    notifications,
    unreadCount,
    loading,
    markAsRead,
    markAllRead,
    deleteNotification,
    refresh: () => { loadNotifications(); loadUnreadCount(); },
  };
}
