// This file previously contained mock data for CMS entities.
// All data is now served from Supabase via @/services/cms and @/services/events.
// The announcement categories list remains as a shared constant.

export const announcementCategories = ['General', 'Events', 'Workshops', 'Funding', 'Partnership', 'Report', 'Achievement'];
