import type { UserRole } from '@/types/auth';

export interface NavItem {
  label: string;
  href: string;
  icon: string;
  badge?: number;
  children?: NavItem[];
}

export const superAdminNav: NavItem[] = [
  { label: 'Overview', href: '/dashboard/super-admin', icon: 'LayoutDashboard' },
  { label: 'Website CMS', href: '/dashboard/super-admin/cms/homepage', icon: 'Globe', children: [
    { label: 'Homepage', href: '/dashboard/super-admin/cms/homepage', icon: 'Home' },
    { label: 'About Page', href: '/dashboard/super-admin/cms/about', icon: 'Info' },
    { label: 'Contact Info', href: '/dashboard/super-admin/cms/contact', icon: 'Phone' },
    { label: 'Footer', href: '/dashboard/super-admin/cms/footer', icon: 'PanelBottom' },
  ]},
  { label: 'College Info', href: '/dashboard/super-admin/cms/college', icon: 'Building2' },
  { label: 'Events', href: '/dashboard/super-admin/events', icon: 'Calendar', children: [
    { label: 'All Events', href: '/dashboard/super-admin/events', icon: 'List' },
    { label: 'Create Event', href: '/dashboard/super-admin/events/create', icon: 'Plus' },
    { label: 'Analytics', href: '/dashboard/super-admin/events/analytics', icon: 'BarChart3' },
  ]},
  { label: 'Attendance Reports', href: '/dashboard/super-admin/attendance-reports', icon: 'ClipboardCheck' },
  { label: 'Notifications', href: '/dashboard/super-admin/notifications', icon: 'Bell' },
  { label: 'Team', href: '/dashboard/super-admin/team', icon: 'Users' },
  { label: 'Gallery', href: '/dashboard/super-admin/gallery', icon: 'Images' },
  { label: 'Announcements', href: '/dashboard/super-admin/announcements', icon: 'Megaphone' },
  { label: 'Users', href: '/dashboard/super-admin/users', icon: 'UserCog' },
  { label: 'Registrations', href: '/dashboard/super-admin/registrations', icon: 'UserPlus' },
  { label: 'Ticket Templates', href: '/dashboard/super-admin/ticket-templates', icon: 'Ticket' },
  { label: 'Certificate Templates', href: '/dashboard/super-admin/certificate-templates', icon: 'Award' },
  { label: 'Certificates', href: '/dashboard/super-admin/certificates', icon: 'GraduationCap' },
  { label: 'Roles', href: '/dashboard/super-admin/roles', icon: 'Shield' },
  { label: 'Settings', href: '/dashboard/super-admin/settings', icon: 'Settings' },
  { label: 'Branding', href: '/dashboard/super-admin/branding', icon: 'Palette' },
];

export const adminNav: NavItem[] = [
  { label: 'Overview', href: '/dashboard/admin', icon: 'LayoutDashboard' },
  { label: 'Homepage', href: '/dashboard/admin/homepage', icon: 'Home' },
  { label: 'Events', href: '/dashboard/admin/events', icon: 'Calendar' },
  { label: 'Team', href: '/dashboard/admin/team', icon: 'Users' },
  { label: 'Gallery', href: '/dashboard/admin/gallery', icon: 'Images' },
  { label: 'Announcements', href: '/dashboard/admin/announcements', icon: 'Megaphone' },
  { label: 'Contact Info', href: '/dashboard/admin/contact', icon: 'Phone' },
  { label: 'Media Library', href: '/dashboard/admin/media', icon: 'Folder' },
  { label: 'Preview', href: '/', icon: 'Eye' },
];

export const facultyNav: NavItem[] = [
  { label: 'Overview', href: '/dashboard/faculty', icon: 'LayoutDashboard' },
  { label: 'Announcements', href: '/dashboard/faculty/announcements', icon: 'Megaphone' },
  { label: 'Events', href: '/dashboard/faculty/events', icon: 'Calendar' },
  { label: 'Resources', href: '/dashboard/faculty/resources', icon: 'BookOpen' },
  { label: 'Reports', href: '/dashboard/faculty/reports', icon: 'FileText' },
];

export const ceoNav: NavItem[] = [
  { label: 'Overview', href: '/dashboard/ceo', icon: 'LayoutDashboard' },
  { label: 'Performance', href: '/dashboard/ceo/performance', icon: 'TrendingUp' },
  { label: 'Strategy', href: '/dashboard/ceo/strategy', icon: 'Target' },
  { label: 'Organization', href: '/dashboard/ceo/organization', icon: 'Network' },
  { label: 'Reports', href: '/dashboard/ceo/reports', icon: 'BarChart3' },
];

export const programOfficerNav: NavItem[] = [
  { label: 'Overview', href: '/dashboard/program-officer', icon: 'LayoutDashboard' },
  { label: 'Tasks', href: '/dashboard/program-officer/tasks', icon: 'ListTodo' },
  { label: 'Activities', href: '/dashboard/program-officer/activities', icon: 'Activity' },
  { label: 'Statistics', href: '/dashboard/program-officer/statistics', icon: 'BarChart2' },
  { label: 'Calendar', href: '/dashboard/program-officer/calendar', icon: 'Calendar' },
];

export const executiveNav: NavItem[] = [
  { label: 'Overview', href: '/dashboard/executive', icon: 'LayoutDashboard' },
  { label: 'My Tasks', href: '/dashboard/executive/tasks', icon: 'ListTodo' },
  { label: 'Announcements', href: '/dashboard/executive/announcements', icon: 'Megaphone' },
  { label: 'Resources', href: '/dashboard/executive/resources', icon: 'BookOpen' },
];

export const studentNav: NavItem[] = [
  { label: 'Overview', href: '/dashboard/student', icon: 'LayoutDashboard' },
  { label: 'My Registrations', href: '/dashboard/student/my-registrations', icon: 'ClipboardList' },
  { label: 'My Events & Tickets', href: '/dashboard/student/my-events', icon: 'Ticket' },
  { label: 'My Certificates', href: '/dashboard/student/my-certificates', icon: 'Award' },
  { label: 'My Profile', href: '/profile', icon: 'UserCircle' },
  { label: 'My Events', href: '/dashboard/student/events', icon: 'Calendar' },
  { label: 'Announcements', href: '/dashboard/student/announcements', icon: 'Megaphone' },
  { label: 'Resources', href: '/dashboard/student/resources', icon: 'BookOpen' },
  { label: 'Quick Links', href: '/dashboard/student/links', icon: 'Link' },
];

export const roleNavigation: Record<UserRole, NavItem[]> = {
  super_admin: superAdminNav,
  admin: adminNav,
  faculty: facultyNav,
  ceo: ceoNav,
  program_officer: programOfficerNav,
  executive: executiveNav,
  student: studentNav,
};

export const roleDashboardPaths: Record<UserRole, string> = {
  super_admin: '/dashboard/super-admin',
  admin: '/dashboard/admin',
  faculty: '/dashboard/faculty',
  ceo: '/dashboard/ceo',
  program_officer: '/dashboard/program-officer',
  executive: '/dashboard/executive',
  student: '/dashboard/student',
};
