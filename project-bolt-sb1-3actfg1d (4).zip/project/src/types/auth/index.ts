export type UserRole =
  | 'super_admin'
  | 'admin'
  | 'faculty'
  | 'ceo'
  | 'program_officer'
  | 'executive'
  | 'student';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  mustChangePassword?: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<{ success: boolean; error?: string; mustChangePassword?: boolean }>;
  logout: () => void;
  hasRole: (roles: UserRole | UserRole[]) => boolean;
  updateUserPassword: (newPassword: string) => Promise<{ success: boolean; error?: string }>;
  refreshUser: () => Promise<void>;
}

export const roleRoutes: Record<UserRole, string> = {
  super_admin: '/dashboard/super-admin',
  admin: '/dashboard/admin',
  faculty: '/dashboard/faculty',
  ceo: '/dashboard/ceo',
  program_officer: '/dashboard/program-officer',
  executive: '/dashboard/executive',
  student: '/dashboard/student',
};

export const roleLabels: Record<UserRole, string> = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  faculty: 'Faculty Coordinator',
  ceo: 'CEO',
  program_officer: 'Program Officer',
  executive: 'Executive Member',
  student: 'Student',
};

export const SESSION_KEY = 'innotex_session';
export const REMEMBER_KEY = 'innotex_remember';
