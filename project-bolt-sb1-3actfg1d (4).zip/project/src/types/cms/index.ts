import type { UserRole } from '@/types/auth';

export type MemberCategory =
  | 'principal'
  | 'faculty'
  | 'program_officer'
  | 'ceo'
  | 'executive'
  | 'student_coordinator'
  | 'alumni_mentor';

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  category: MemberCategory;
  department?: string;
  email?: string;
  phone?: string;
  photoUrl?: string;
  socials?: {
    linkedin?: string;
    github?: string;
    instagram?: string;
  };
  isActive: boolean;
  displayOrder: number;
  createdAt: string;
  updatedAt: string;
}

export type AnnouncementPriority = 'low' | 'medium' | 'high';
export type AnnouncementStatus = 'draft' | 'published' | 'archived';

export interface Announcement {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: AnnouncementPriority;
  status: AnnouncementStatus;
  isPinned: boolean;
  publishDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface GalleryAlbum {
  id: string;
  name: string;
  description?: string;
  coverImage?: string;
  imageCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface GalleryImage {
  id: string;
  albumId: string;
  title: string;
  description?: string;
  imageUrl?: string;
  tags?: string[];
  isFeatured: boolean;
  displayOrder: number;
  createdAt: string;
}

export interface HomepageCMS {
  hero: {
    headline: string;
    tagline: string;
    description: string;
    ctaPrimary: { text: string; link: string };
    ctaSecondary: { text: string; link: string };
  };
  statistics: Array<{ label: string; value: number; suffix?: string }>;
  aboutPreview: {
    title: string;
    description: string;
  };
  vision: { title: string; content: string };
  mission: { title: string; content: string };
}

export interface CollegeInfo {
  name: string;
  shortName: string;
  description: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  affiliation: string;
  accreditation?: string;
  principalName?: string;
  logoUrl?: string;
  bannerUrl?: string;
  mapEmbedUrl: string;
}

export interface SystemSettings {
  portalName: string;
  portalTagline: string;
  theme: 'light' | 'dark' | 'system';
  primaryColor: string;
  accentColor: string;
  enableDarkMode: boolean;
  showAnnouncementsOnHome: boolean;
  showEventsOnHome: boolean;
  showGalleryOnHome: boolean;
  footerText: string;
  language: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  isActive: boolean;
  lastLogin?: string;
  createdAt: string;
  avatar?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  isRead: boolean;
  createdAt: string;
}

export interface DashboardStats {
  totalUsers: number;
  totalTeamMembers: number;
  totalAnnouncements: number;
  publishedAnnouncements: number;
  totalGalleryImages: number;
  totalAlbums: number;
  activeAnnouncements: number;
  pendingUpdates: number;
  websiteStatus: 'online' | 'maintenance' | 'offline';
}

export const memberCategoryLabels: Record<MemberCategory, string> = {
  principal: 'Principal',
  faculty: 'Faculty Coordinator',
  program_officer: 'Program Officer',
  ceo: 'CEO',
  executive: 'Executive Member',
  student_coordinator: 'Student Coordinator',
  alumni_mentor: 'Alumni Mentor',
};

export const priorityLabels: Record<AnnouncementPriority, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
};

export const statusLabels: Record<AnnouncementStatus, string> = {
  draft: 'Draft',
  published: 'Published',
  archived: 'Archived',
};
