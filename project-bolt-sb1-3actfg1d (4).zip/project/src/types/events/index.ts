// Event management types

export type EventType =
  | 'Workshop'
  | 'Hackathon'
  | 'Seminar'
  | 'Webinar'
  | 'Competition'
  | 'Startup Event'
  | 'Innovation Challenge'
  | 'Training Program'
  | 'Industrial Visit'
  | 'Other';

export type EventStatus =
  | 'draft'
  | 'published'
  | 'upcoming'
  | 'registration_open'
  | 'registration_closed'
  | 'ongoing'
  | 'completed'
  | 'cancelled'
  | 'archived';

export type RegistrationStatus = 'pending' | 'confirmed' | 'cancelled' | 'waitlisted';

export interface EventCategory {
  id: string;
  name: string;
  description: string | null;
  color: string;
  icon: string;
  display_order: number;
  created_at: string;
}

export interface Event {
  id: string;
  title: string;
  short_description: string | null;
  full_description: string | null;
  category_id: string | null;
  event_type: EventType;
  status: EventStatus;
  start_date: string;
  end_date: string | null;
  start_time: string | null;
  end_time: string | null;
  venue: string | null;
  max_participants: number | null;
  registration_deadline: string | null;
  poster_url: string | null;
  banner_url: string | null;
  organizer_name: string | null;
  organizer_email: string | null;
  is_featured: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  // New media fields
  banner_image_url?: string | null;
  banner_thumbnail_url?: string | null;
  banner_storage_path?: string | null;
  poster_image_url?: string | null;
  poster_storage_path?: string | null;
  // Ticket template
  ticket_template_id?: string | null;
  // Certificate template
  certificate_template_id?: string | null;
  // Joined fields
  category?: EventCategory;
  speakers?: EventSpeaker[];
  registration_count?: number;
  like_count?: number;
  user_liked?: boolean;
}

export interface EventSpeaker {
  id: string;
  event_id: string;
  name: string;
  designation: string | null;
  bio: string | null;
  photo_url: string | null;
  display_order: number;
  created_at: string;
}

export interface EventResource {
  id: string;
  event_id: string;
  title: string;
  file_url: string | null;
  resource_type: 'document' | 'presentation' | 'poster' | 'other';
  display_order: number;
  created_at: string;
}

export interface EventRegistration {
  id: string;
  event_id: string;
  user_name: string;
  user_email: string;
  user_role: string | null;
  registration_status: RegistrationStatus;
  registered_at: string;
  notes: string | null;
  user_id?: string | null;
  ticket_id?: string | null;
  qr_code?: string | null;
  ticket_generated_at?: string | null;
  // Approval workflow fields
  approval_status?: 'pending' | 'approved' | 'rejected' | 'cancelled' | 'waitlisted';
  approved_by?: string | null;
  approval_date?: string | null;
  remarks?: string | null;
  department?: string | null;
  semester?: string | null;
  student_id?: string | null;
  attendance_verified?: boolean;
  certificate_status?: 'not_eligible' | 'eligible' | 'generated' | 'issued';
  cancelled_at?: string | null;
  // Joined
  event?: Event;
}

export const eventTypes: EventType[] = [
  'Workshop', 'Hackathon', 'Seminar', 'Webinar', 'Competition',
  'Startup Event', 'Innovation Challenge', 'Training Program', 'Industrial Visit', 'Other',
];

export const eventStatusConfig: Record<EventStatus, { label: string; color: string; bg: string }> = {
  draft: { label: 'Draft', color: 'text-muted-foreground', bg: 'bg-muted' },
  published: { label: 'Published', color: 'text-emerald-600', bg: 'bg-emerald-500/10' },
  upcoming: { label: 'Upcoming', color: 'text-blue-600', bg: 'bg-blue-500/10' },
  registration_open: { label: 'Registration Open', color: 'text-green-600', bg: 'bg-green-500/10' },
  registration_closed: { label: 'Registration Closed', color: 'text-orange-600', bg: 'bg-orange-500/10' },
  ongoing: { label: 'Ongoing', color: 'text-primary', bg: 'bg-primary/10' },
  completed: { label: 'Completed', color: 'text-slate-500', bg: 'bg-slate-500/10' },
  cancelled: { label: 'Cancelled', color: 'text-destructive', bg: 'bg-destructive/10' },
  archived: { label: 'Archived', color: 'text-amber-600', bg: 'bg-amber-500/10' },
};

export interface EventFormData {
  title: string;
  short_description: string;
  full_description: string;
  category_id: string;
  event_type: EventType;
  status: EventStatus;
  start_date: string;
  end_date: string;
  start_time: string;
  end_time: string;
  venue: string;
  max_participants: string;
  registration_deadline: string;
  organizer_name: string;
  organizer_email: string;
  is_featured: boolean;
  // Media fields
  banner_image_url?: string;
  poster_image_url?: string;
}

export const emptyEventForm: EventFormData = {
  title: '',
  short_description: '',
  full_description: '',
  category_id: '',
  event_type: 'Workshop',
  status: 'draft',
  start_date: '',
  end_date: '',
  start_time: '',
  end_time: '',
  venue: '',
  max_participants: '',
  registration_deadline: '',
  organizer_name: '',
  organizer_email: '',
  is_featured: false,
};

// Event Like type
export interface EventLike {
  id: string;
  event_id: string;
  user_id: string;
  created_at: string;
}

// Like analytics
export interface LikeAnalytics {
  total_likes: number;
  total_events_with_likes: number;
  most_liked_event: { title: string; likes: number } | null;
  least_liked_event: { title: string; likes: number } | null;
  this_month_likes: number;
}

// Trending event
export interface TrendingEvent {
  id: string;
  title: string;
  description: string | null;
  banner_image_url: string | null;
  poster_image_url: string | null;
  like_count: number;
  status: string;
  start_date: string;
}

// Ticket Template Field Configuration
export interface TicketFieldConfig {
  x: number;      // Position as percentage (0-100)
  y: number;      // Position as percentage (0-100)
  width?: number; // Width as percentage (for text fields)
  fontSize?: number;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  align?: 'left' | 'center' | 'right';
  letterSpacing?: number;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  size?: number;  // For QR code, as percentage
  label?: string; // Display label for custom fields
  dataField?: string; // Source data field for dynamic content
  customText?: string; // Static text for custom_text fields
}

// Dynamic field configs - allows any field name including duplicates (venue_2, registration_id_2)
export type TicketFieldConfigs = Record<string, TicketFieldConfig>;

// Standard field names with their display labels
export const STANDARD_FIELD_LABELS: Record<string, string> = {
  participant_name: 'Student Name',
  ticket_id: 'Ticket ID',
  event_name: 'Event Name',
  event_date: 'Event Date',
  event_time: 'Event Time',
  event_venue: 'Venue',
  department: 'Department',
  registration_id: 'Registration ID',
  registration_number: 'Registration Number',
  student_id: 'Student ID',
  issue_date: 'Issue Date',
  qr_code: 'QR Code',
  custom_text: 'Custom Text',
};

// Available data fields for auto-fill
export const AVAILABLE_DATA_FIELDS = [
  { key: 'participant_name', label: 'Student Name' },
  { key: 'participant_email', label: 'Email' },
  { key: 'ticket_id', label: 'Ticket Number' },
  { key: 'event_name', label: 'Event Name' },
  { key: 'event_date', label: 'Event Date' },
  { key: 'event_time', label: 'Event Time' },
  { key: 'event_venue', label: 'Venue' },
  { key: 'department', label: 'Department' },
  { key: 'registration_id', label: 'Registration ID' },
  { key: 'student_id', label: 'Student ID' },
  { key: 'issue_date', label: 'Issue Date' },
  { key: 'custom_text', label: 'Custom Text (static)' },
];

// Ticket Template
export interface TicketTemplate {
  id: string;
  name: string;
  description: string | null;
  template_image_url: string;
  template_storage_path: string;
  template_width: number;
  template_height: number;
  field_config: TicketFieldConfigs;
  is_default: boolean;
  is_active: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface TicketTemplateFormData {
  name: string;
  description: string;
  template_width: number;
  template_height: number;
  field_config: TicketFieldConfigs;
}
