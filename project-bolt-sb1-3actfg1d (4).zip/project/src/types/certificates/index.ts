export interface CertificateFieldConfig {
  x: number;
  y: number;
  width?: number;
  fontSize?: number;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  align?: 'left' | 'center' | 'right';
  letterSpacing?: number;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  size?: number;
  label?: string;
  dataField?: string;
  customText?: string;
}

export type CertificateFieldConfigs = Record<string, CertificateFieldConfig>;

export const CERTIFICATE_FIELD_LABELS: Record<string, string> = {
  participant_name: 'Student Name',
  certificate_number: 'Certificate Number',
  event_name: 'Event Name',
  event_date: 'Event Date',
  issue_date: 'Issue Date',
  qr_code: 'QR Code',
  custom_text: 'Custom Text',
};

export const CERTIFICATE_DATA_FIELDS = [
  { key: 'participant_name', label: 'Student Name', sample: 'John Doe' },
  { key: 'certificate_number', label: 'Certificate Number', sample: 'CERT-2026-ABCD1234' },
  { key: 'event_name', label: 'Event Name', sample: 'Annual Tech Workshop 2026' },
  { key: 'event_date', label: 'Event Date', sample: 'June 15, 2026' },
  { key: 'issue_date', label: 'Issue Date', sample: 'June 22, 2026' },
  { key: 'custom_text', label: 'Custom Text', sample: 'Custom Label' },
];

export interface CertificateTemplate {
  id: string;
  name: string;
  description: string | null;
  template_image_url: string;
  template_storage_path: string;
  template_width: number;
  template_height: number;
  field_config: CertificateFieldConfigs;
  is_default: boolean;
  is_active: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface Certificate {
  id: string;
  certificate_number: string;
  event_id: string;
  user_id: string;
  registration_id: string;
  template_id: string | null;
  participant_name: string;
  participant_email: string | null;
  event_name: string;
  event_date: string;
  issue_date: string;
  qr_code: string;
  generated_certificate_url: string | null;
  certificate_status: 'issued' | 'revoked';
  generated_by: string | null;
  generated_at: string;
  revoked_by: string | null;
  revoked_at: string | null;
  revoke_reason: string | null;
  created_at: string;
  updated_at: string;
  event?: {
    id: string;
    title: string;
    start_date: string;
    venue: string | null;
  };
}

export interface CertificateFormData {
  name: string;
  description: string;
  template_width: number;
  template_height: number;
  field_config: CertificateFieldConfigs;
}

export const DEFAULT_CERTIFICATE_FIELD_CONFIG: CertificateFieldConfigs = {
  participant_name: { x: 50, y: 35, width: 80, fontSize: 36, fontColor: '#1a1a2e', fontFamily: 'Georgia', fontWeight: 'bold', align: 'center', dataField: 'participant_name' },
  certificate_number: { x: 50, y: 45, width: 60, fontSize: 14, fontColor: '#555555', fontFamily: 'Courier New', align: 'center', dataField: 'certificate_number' },
  event_name: { x: 50, y: 55, width: 80, fontSize: 22, fontColor: '#0f3460', fontFamily: 'Georgia', align: 'center', dataField: 'event_name' },
  event_date: { x: 35, y: 68, width: 30, fontSize: 16, fontColor: '#333333', fontFamily: 'Arial', align: 'left', dataField: 'event_date' },
  issue_date: { x: 65, y: 68, width: 30, fontSize: 16, fontColor: '#333333', fontFamily: 'Arial', align: 'right', dataField: 'issue_date' },
  qr_code: { x: 90, y: 85, size: 12 },
};
